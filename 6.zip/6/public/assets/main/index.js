System.register("chunks:///_virtual/Splash.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts"], (function(e) {
    "use strict";
    var n, o, a, t, l, i, d, r, u, s, c, g, h;
    return {
        setters: [function(e) {
            n = e.inheritsLoose,
            o = e.defineProperty,
            a = e.assertThisInitialized
        }
        , function(e) {
            t = e.cclegacy,
            l = e._decorator,
            i = e.assetManager,
            d = e.director,
            r = e.sys,
            u = e.Component
        }
        , function(e) {
            s = e.logger
        }
        , function(e) {
            c = e.SceneNames,
            g = e.BundleNames,
            h = e.StorageKey
        }
        ],
        execute: function() {
            var f;
            t._RF.push({}, "01680Z8ZghMhIHy3Ac4UXWM", "Splash", void 0);
            var p = l.ccclass;
            l.property,
            e("Splash", p("Splash")(f = function(e) {
                function t() {
                    for (var n, t = arguments.length, l = new Array(t), r = 0; r < t; r++)
                        l[r] = arguments[r];
                    return n = e.call.apply(e, [this].concat(l)) || this,
                    o(a(n), "onTutorialBundleLoaded", (function(e, o) {
                        console.log("Finished loading bundle. " + o.name + ", loading scene"),
                        o.loadScene(c.PreTutorial, n.onSceneLoaded)
                    }
                    )),
                    o(a(n), "onTutorialBundleLoadedForMainMenuFlow", (function(e, o) {
                        console.log("Finished loading bundle: " + o.name),
                        console.log("Starting to load " + g.Game + " bundle."),
                        i.loadBundle(g.Game, n.onGameBundleLoaded)
                    }
                    )),
                    o(a(n), "onGameBundleLoaded", (function(e, o) {
                        console.log("Finished loading bundle: " + o.name + ", loading scene"),
                        o.loadScene(c.Menu, n.onSceneLoaded)
                    }
                    )),
                    o(a(n), "onSceneLoaded", (function(e, o) {
                        console.log("Finished loading scene: " + o.name + ", starting it."),
                        n.scheduleOnce((function() {
                            d.runScene(o)
                        }
                        ), 2)
                    }
                    )),
                    n
                }
                return n(t, e),
                t.prototype.start =async function() {
                    var e =await CoinApp.getItem(h.FinishedTutorial);
                    console.log("finishedTutorial = " + e),
                    null == e || 0 == e ? (console.log("Starting to load " + g.Tutorial + " bundle."),
                    i.loadBundle(g.Tutorial, this.onTutorialBundleLoaded)) : (console.log("Starting to load " + g.Tutorial + " bundle."),
                    i.loadBundle(g.Tutorial, this.onTutorialBundleLoadedForMainMenuFlow))
                }
                ,
                t
            }(u)) || f);
            t._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIEnemyCounter.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var e, r, n, a, o, i, c, u, s, h, p;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            r = t.inheritsLoose,
            n = t.initializerDefineProperty,
            a = t.assertThisInitialized,
            o = t.defineProperty
        }
        , function(t) {
            i = t.cclegacy,
            c = t._decorator,
            u = t.Label,
            s = t.Component
        }
        , function(t) {
            h = t.ProjectEventType
        }
        , function(t) {
            p = t.projectEvent
        }
        ],
        execute: function() {
            var l, C, f, y, d, v;
            i._RF.push({}, "0288arVRBBOBq+Tz1HU+L+8", "UIEnemyCounter", void 0);
            var D = c.ccclass
              , I = c.property
              , U = c.executionOrder;
            t("UIEnemyCounter", (l = D("UIEnemyCounter"),
            C = U(-10),
            f = I(u),
            l(y = C((v = e((d = function(t) {
                function e() {
                    for (var e, r = arguments.length, i = new Array(r), c = 0; c < r; c++)
                        i[c] = arguments[c];
                    return e = t.call.apply(t, [this].concat(i)) || this,
                    n(a(e), "lCounter", v, a(e)),
                    o(a(e), "characterCount", 0),
                    e
                }
                r(e, t);
                var i = e.prototype;
                return i.onEnable = function() {
                    p.on(h.CharacterSpawn, this.onCharacterSpawn, this),
                    p.on(h.CharacterDeath, this.onCharacterDeath, this)
                }
                ,
                i.onDisable = function() {
                    p.off(h.CharacterSpawn, this.onCharacterSpawn, this),
                    p.off(h.CharacterDeath, this.onCharacterDeath, this)
                }
                ,
                i.start = function() {
                    this.updateUIText()
                }
                ,
                i.onCharacterSpawn = function() {
                    this.characterCount++,
                    this.characterCount > 8 && this.updateUIText()
                }
                ,
                i.onCharacterDeath = function() {
                    this.characterCount--,
                    this.updateUIText()
                }
                ,
                i.updateUIText = function() {
                    this.lCounter && (this.lCounter.string = this.characterCount.toFixed(),
                    this.lCounter.updateRenderData(!0))
                }
                ,
                e
            }(s)).prototype, "lCounter", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = d)) || y) || y));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AudioListener.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./env"], (function(e) {
    "use strict";
    var i, t, n, r, s, a, o, c, l, u, h, p, b, m, d, f;
    return {
        setters: [function(e) {
            i = e.defineProperty,
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            r = e.initializerDefineProperty,
            s = e.assertThisInitialized,
            a = e.createClass
        }
        , function(e) {
            o = e.cclegacy,
            c = e._decorator,
            l = e.CCFloat,
            u = e.CCBoolean,
            h = e.Node,
            p = e.MeshRenderer,
            b = e.Color,
            m = e.Vec3,
            d = e.Component
        }
        , function(e) {
            f = e.DEBUG
        }
        ],
        execute: function() {
            var g, D, C, y, v, w, _, x, L, P, z, A, E;
            o._RF.push({}, "03e27UIeUhPkbnm9lwYkGFi", "AudioListener", void 0);
            var k = c.ccclass
              , F = c.property;
            e("AudioListener", (g = k("AudioListener"),
            D = F(l),
            C = F(l),
            y = F(u),
            v = F([h]),
            g((E = A = function(e) {
                function i() {
                    for (var i, t = arguments.length, n = new Array(t), a = 0; a < t; a++)
                        n[a] = arguments[a];
                    return i = e.call.apply(e, [this].concat(n)) || this,
                    r(s(i), "minDistance", x, s(i)),
                    r(s(i), "maxDistance", L, s(i)),
                    r(s(i), "showDebug", P, s(i)),
                    r(s(i), "debugCircles", z, s(i)),
                    i
                }
                n(i, e);
                var t = i.prototype;
                return t.onEnable = function() {
                    i._instance = this,
                    this.debugCircles[0].active = this.showDebug && f,
                    this.debugCircles[1].active = this.showDebug && f,
                    this.debugCircles[0].setWorldScale(2 * this.minDistance, 2 * this.minDistance, 2 * this.minDistance),
                    this.debugCircles[1].setWorldScale(2 * this.maxDistance, 2 * this.maxDistance, 2 * this.maxDistance),
                    this.debugCircles[0].getComponent(p).material.setProperty("color", b.GREEN),
                    this.debugCircles[1].getComponent(p).material.setProperty("color", b.YELLOW)
                }
                ,
                t.onDisable = function() {
                    i._instance == this && (i._instance = null)
                }
                ,
                t.getVolumeScale = function(e) {
                    var i = m.distance(e, this.node.worldPosition);
                    if (i >= this.maxDistance)
                        return 0;
                    if (i <= this.minDistance)
                        return 1;
                    var t = this.maxDistance - this.minDistance;
                    return (i -= this.minDistance) / t
                }
                ,
                a(i, null, [{
                    key: "instance",
                    get: function() {
                        return i._instance
                    }
                }]),
                i
            }(d),
            i(A, "_instance", void 0),
            x = t((_ = E).prototype, "minDistance", [D], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 2
                }
            }),
            L = t(_.prototype, "maxDistance", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 30
                }
            }),
            P = t(_.prototype, "showDebug", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            z = t(_.prototype, "debugCircles", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            w = _)) || w));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuMissionOverlayEventProxy.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./MainMenuMissionOverlay.ts"], (function(i) {
    "use strict";
    var n, e, t, r, a, o, s, l;
    return {
        setters: [function(i) {
            n = i.applyDecoratedDescriptor,
            e = i.inheritsLoose,
            t = i.initializerDefineProperty,
            r = i.assertThisInitialized
        }
        , function(i) {
            a = i.cclegacy,
            o = i._decorator,
            s = i.Component
        }
        , function(i) {
            l = i.MainMenuMissionOverlay
        }
        ],
        execute: function() {
            var u, c, y, v, p;
            a._RF.push({}, "0455bdimx1C9J4wjtRLOzJT", "MainMenuMissionOverlayEventProxy", void 0);
            var M = o.ccclass
              , m = o.property;
            i("MainMenuMissionOverlayEventProxy", (u = M("MainMenuMissionOverlayEventProxy"),
            c = m(l),
            u((p = n((v = function(i) {
                function n() {
                    for (var n, e = arguments.length, a = new Array(e), o = 0; o < e; o++)
                        a[o] = arguments[o];
                    return n = i.call.apply(i, [this].concat(a)) || this,
                    t(r(n), "missionOverlay", p, r(n)),
                    n
                }
                e(n, i);
                var a = n.prototype;
                return a.animateWidgetEntry = function(i) {
                    this.missionOverlay.animateWidgetEntry(i)
                }
                ,
                a.animateCompletionBars = function() {
                    this.missionOverlay.animateBars()
                }
                ,
                n
            }(s)).prototype, "missionOverlay", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = v)) || y));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletPools.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts"], (function(e) {
    "use strict";
    var t, n, o, i, l, r, s, a, u, c, p, f, h, g, b;
    return {
        setters: [function(e) {
            t = e.defineProperty,
            n = e.applyDecoratedDescriptor,
            o = e.inheritsLoose,
            i = e.initializerDefineProperty,
            l = e.assertThisInitialized
        }
        , function(e) {
            r = e.cclegacy,
            s = e._decorator,
            a = e.Prefab,
            u = e.director,
            c = e.NodePool,
            p = e.instantiate,
            f = e.Component
        }
        , function(e) {
            h = e.logger
        }
        , function(e) {
            g = e.WeaponBulletType,
            b = e.WeaponBulletTypeName
        }
        ],
        execute: function() {
            var d, v, y, P, m, R, B, E, x;
            r._RF.push({}, "05dd301Hp9ElIvabv8Hf8xU", "BulletPools", void 0);
            var O = s.ccclass
              , _ = s.property
              , w = s.executionOrder;
            e("BulletPools", (d = O("BulletPools"),
            v = w(-5),
            y = _([a]),
            d(P = v((x = E = function(e) {
                function n() {
                    for (var n, o = arguments.length, r = new Array(o), s = 0; s < o; s++)
                        r[s] = arguments[s];
                    return n = e.call.apply(e, [this].concat(r)) || this,
                    i(l(n), "prefabs", R, l(n)),
                    i(l(n), "initCount", B, l(n)),
                    t(l(n), "pools", []),
                    t(l(n), "scene", void 0),
                    n
                }
                o(n, e);
                var r = n.prototype;
                return r.onLoad = function() {
                    if (null == n.instance) {
                        n.instance = this,
                        this.scene = u.getScene();
                        var e = Object.keys(g)
                          , t = Object.keys(b);
                        if (e.length != t.length && console.log("ERROR: Mismatch bullet type enums"),
                        this.prefabs.length == t.length)
                            for (var o = 0; o < t.length; o++) {
                                for (var i = new c(t[o]), l = 0; l < this.initCount; l++) {
                                    var r = p(this.prefabs[o]);
                                    i.put(r)
                                }
                                this.pools.push(i)
                            }
                        else
                            console.log("ERROR: Invalid count of bullets prefabs")
                    }
                }
                ,
                r.onDestroy = function() {
                    this.pools.forEach((function(e) {
                        e.clear()
                    }
                    )),
                    n.instance == this && (n.instance = null)
                }
                ,
                r.get = function(e) {
                    e >= this.pools.length && console.log("Error invalid bullet type, pool does not exist");
                    var t = null;
                    return null == (t = this.pools[e].get()) && (t = p(this.prefabs[e])),
                    t.setParent(this.scene),
                    t
                }
                ,
                r.put = function(e, t) {
                    e >= this.pools.length ? console.log("Error invalid bullet type, pool does not exist") : this.pools[e].put(t)
                }
                ,
                n
            }(f),
            t(E, "instance", void 0),
            R = n((m = x).prototype, "prefabs", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            B = n(m.prototype, "initCount", [_], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 10
                }
            }),
            P = m)) || P) || P));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TweenCollection.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenBase.ts"], (function(e) {
    "use strict";
    var n, t, o, i, r, s, c, l, a;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            o = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            r = e.defineProperty
        }
        , function(e) {
            s = e.cclegacy,
            c = e._decorator,
            l = e.Component
        }
        , function(e) {
            a = e.TweenBase
        }
        ],
        execute: function() {
            var u, p, f;
            s._RF.push({}, "07cb6bJU3BD76BFX5Zbi7Ki", "TweenCollection", void 0);
            var h = c.ccclass
              , w = c.property
              , y = c.menu;
            e("TweenCollection", h("TweenCollection")(u = y("Tween/Collection")((f = n((p = function(e) {
                function n() {
                    for (var n, t = arguments.length, s = new Array(t), c = 0; c < t; c++)
                        s[c] = arguments[c];
                    return n = e.call.apply(e, [this].concat(s)) || this,
                    o(i(n), "getInChildren", f, i(n)),
                    r(i(n), "tweens", []),
                    n
                }
                t(n, e);
                var s = n.prototype;
                return s.onLoad = function() {
                    this.getInChildren ? this.tweens = this.node.getComponentsInChildren(a) : this.tweens = this.node.getComponents(a)
                }
                ,
                s.play = function() {
                    this.tweens.forEach((function(e) {
                        e.play()
                    }
                    ))
                }
                ,
                s.reset = function() {
                    this.tweens.forEach((function(e) {
                        e.reset()
                    }
                    ))
                }
                ,
                s.playReverse = function() {
                    this.tweens.forEach((function(e) {
                        e.playReverse()
                    }
                    ))
                }
                ,
                s.stop = function() {
                    this.tweens.forEach((function(e) {
                        e.stop()
                    }
                    ))
                }
                ,
                n
            }(l)).prototype, "getInChildren", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            u = p)) || u) || u);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TweenEnums.ts", ["cc"], (function(u) {
    "use strict";
    var n;
    return {
        setters: [function(u) {
            n = u.cclegacy
        }
        ],
        execute: function() {
            var t;
            u("TweenEasing", void 0),
            n._RF.push({}, "08554ORux1Mnp7Yhy8xylfV", "TweenEnums", void 0),
            function(u) {
                u[u.linear = 0] = "linear",
                u[u.smooth = 1] = "smooth",
                u[u.fade = 2] = "fade",
                u[u.constant = 3] = "constant",
                u[u.quadIn = 4] = "quadIn",
                u[u.quadOut = 5] = "quadOut",
                u[u.quadInOut = 6] = "quadInOut",
                u[u.quadOutIn = 7] = "quadOutIn",
                u[u.cubicIn = 8] = "cubicIn",
                u[u.cubicOut = 9] = "cubicOut",
                u[u.cubicInOut = 10] = "cubicInOut",
                u[u.cubicOutIn = 11] = "cubicOutIn",
                u[u.quartIn = 12] = "quartIn",
                u[u.quartOut = 13] = "quartOut",
                u[u.quartInOut = 14] = "quartInOut",
                u[u.quartOutIn = 15] = "quartOutIn",
                u[u.quintIn = 16] = "quintIn",
                u[u.quintOut = 17] = "quintOut",
                u[u.quintInOut = 18] = "quintInOut",
                u[u.quintOutIn = 19] = "quintOutIn",
                u[u.sineIn = 20] = "sineIn",
                u[u.sineOut = 21] = "sineOut",
                u[u.sineInOut = 22] = "sineInOut",
                u[u.sineOutIn = 23] = "sineOutIn",
                u[u.expoIn = 24] = "expoIn",
                u[u.expoOut = 25] = "expoOut",
                u[u.expoInOut = 26] = "expoInOut",
                u[u.expoOutIn = 27] = "expoOutIn",
                u[u.circIn = 28] = "circIn",
                u[u.circOut = 29] = "circOut",
                u[u.circInOut = 30] = "circInOut",
                u[u.circOutIn = 31] = "circOutIn",
                u[u.elasticIn = 32] = "elasticIn",
                u[u.elasticOut = 33] = "elasticOut",
                u[u.elasticInOut = 34] = "elasticInOut",
                u[u.elasticOutIn = 35] = "elasticOutIn",
                u[u.backIn = 36] = "backIn",
                u[u.backOut = 37] = "backOut",
                u[u.backInOut = 38] = "backInOut",
                u[u.backOutIn = 39] = "backOutIn",
                u[u.bounceIn = 40] = "bounceIn",
                u[u.bounceOut = 41] = "bounceOut",
                u[u.bounceInOut = 42] = "bounceInOut",
                u[u.bounceOutIn = 43] = "bounceOutIn"
            }(t || (t = u("TweenEasing", {}))),
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIVirtualJoystick.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./TweenCollection.ts"], (function(t) {
    "use strict";
    var i, n, o, e, s, u, r, a, h, l, c, p, d, _, f, U, y, I;
    return {
        setters: [function(t) {
            i = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            o = t.initializerDefineProperty,
            e = t.assertThisInitialized,
            s = t.defineProperty
        }
        , function(t) {
            u = t.cclegacy,
            r = t._decorator,
            a = t.Enum,
            h = t.UIOpacity,
            l = t.Node,
            c = t.Vec2,
            p = t.UITransform,
            d = t.systemEvent,
            _ = t.SystemEventType,
            f = t.Vec3,
            U = t.Component
        }
        , function(t) {
            y = t.logger
        }
        , function(t) {
            I = t.TweenCollection
        }
        ],
        execute: function() {
            var w, O, P, v, D, M, T, g, E, C, S, b, H;
            u._RF.push({}, "09e1dLFgZhCrL2KX2024O5A", "UIVirtualJoystick", void 0);
            var V, m = r.ccclass, k = r.property;
            !function(t) {
                t[t.ResetPosition = 0] = "ResetPosition",
                t[t.Hide = 1] = "Hide"
            }(V || (V = {}));
            t("UIVirtualJoystick", (w = m("UIVirtualJoystick"),
            O = k({
                type: a(V)
            }),
            P = k(h),
            v = k(l),
            D = k(I),
            M = k(I),
            w((E = i((g = function(t) {
                function i() {
                    for (var i, n = arguments.length, u = new Array(n), r = 0; r < n; r++)
                        u[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(u)) || this,
                    o(e(i), "style", E, e(i)),
                    o(e(i), "contentOpacity", C, e(i)),
                    o(e(i), "pivot", S, e(i)),
                    o(e(i), "tweenShow", b, e(i)),
                    o(e(i), "tweenHide", H, e(i)),
                    s(e(i), "_isInputDown", !1),
                    s(e(i), "_inputUIPos", new c),
                    s(e(i), "_inputUIPosOnDown", new c),
                    s(e(i), "_inputUIDelta", new c),
                    s(e(i), "_radius", 64),
                    s(e(i), "_initialVirtualJoystickPosition", void 0),
                    i
                }
                n(i, t);
                var u = i.prototype;
                return u.onLoad = function() {
                    var t = this.node.getComponent(p);
                    t && (this._radius = t.contentSize.width / 2)
                }
                ,
                u.start = function() {
                    d.on(_.MOUSE_MOVE, this.onMouseMove, this),
                    d.on(_.MOUSE_DOWN, this.onMouseDown, this),
                    d.on(_.MOUSE_UP, this.onMouseUp, this),
                    d.on(_.TOUCH_START, this.onTouchStart, this),
                    d.on(_.TOUCH_MOVE, this.onTouchMove, this),
                    d.on(_.TOUCH_END, this.onTouchEndOrCancel, this),
                    d.on(_.TOUCH_CANCEL, this.onTouchEndOrCancel, this),
                    this.node.parent && this.node.setSiblingIndex(this.node.parent.children.length - 1),
                    this.style == V.Hide && (this.contentOpacity.opacity = 0),
                    this._initialVirtualJoystickPosition = new f(this.node.worldPosition),
                    console.log("Virtual joystick initial position: " + this._initialVirtualJoystickPosition)
                }
                ,
                u.onDestroy = function() {
                    d.off(_.MOUSE_MOVE, this.onMouseMove, this),
                    d.off(_.MOUSE_DOWN, this.onMouseDown, this),
                    d.off(_.MOUSE_UP, this.onMouseUp, this),
                    d.off(_.TOUCH_START, this.onTouchStart, this),
                    d.off(_.TOUCH_MOVE, this.onTouchMove, this),
                    d.off(_.TOUCH_END, this.onTouchEndOrCancel, this),
                    d.off(_.TOUCH_CANCEL, this.onTouchEndOrCancel, this)
                }
                ,
                u.update = function() {
                    this.updatePivotPosition()
                }
                ,
                u.onMouseDown = function(t) {
                    t.getUILocation(this._inputUIPosOnDown),
                    this.onInputStart()
                }
                ,
                u.onMouseMove = function(t) {
                    this._isInputDown && (t.getUILocation(this._inputUIPos),
                    this.onInputMove())
                }
                ,
                u.onMouseUp = function(t) {
                    this.onInputEnd()
                }
                ,
                u.onTouchStart = function(t, i) {
                    i.getUILocation(this._inputUIPosOnDown),
                    this.onInputStart()
                }
                ,
                u.onTouchMove = function(t, i) {
                    this._isInputDown && (i.getUILocation(this._inputUIPos),
                    this.onInputMove())
                }
                ,
                u.onTouchEndOrCancel = function(t, i) {
                    this.onInputEnd()
                }
                ,
                u.onInputStart = function() {
                    var t, i;
                    (this._isInputDown = !0,
                    this.updateContainerPosition(),
                    this.style == V.Hide) && (null === (t = this.tweenHide) || void 0 === t || t.stop(),
                    null === (i = this.tweenShow) || void 0 === i || i.play())
                }
                ,
                u.onInputMove = function() {
                    this._inputUIDelta = this._inputUIPos.subtract(this._inputUIPosOnDown),
                    this._inputUIDelta.length() < this._radius ? this._inputUIDelta.multiplyScalar(1 / this._radius) : this._inputUIDelta.normalize()
                }
                ,
                u.onInputEnd = function() {
                    var t, i;
                    (this._isInputDown = !1,
                    this._inputUIDelta.set(0, 0),
                    this.style == V.Hide) ? (null === (t = this.tweenShow) || void 0 === t || t.stop(),
                    null === (i = this.tweenHide) || void 0 === i || i.play()) : (console.log("Virtual joystick input up setting position to " + this._initialVirtualJoystickPosition),
                    this.node.setWorldPosition(this._initialVirtualJoystickPosition))
                }
                ,
                u.updateContainerPosition = function() {
                    this.node.setWorldPosition(this._inputUIPosOnDown.x, this._inputUIPosOnDown.y, 0)
                }
                ,
                u.updatePivotPosition = function() {
                    this.pivot.setPosition(this._inputUIDelta.x * this._radius, this._inputUIDelta.y * this._radius, 0)
                }
                ,
                i
            }(U)).prototype, "style", [O], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return V.ResetPosition
                }
            }),
            C = i(g.prototype, "contentOpacity", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            S = i(g.prototype, "pivot", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = i(g.prototype, "tweenShow", [D], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return null
                }
            }),
            H = i(g.prototype, "tweenHide", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return null
                }
            }),
            T = g)) || T));
            u._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuCanvas.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./Mission.ts", "./GlobalPlayer.ts", "./MainMenuMissionOverlay.ts", "./PanelManager.ts", "./PanelEnums.ts", "./MainMenuOverlay.ts", "./LoadingPrepareMatch.ts"], (function(e) {
    "use strict";
    var n, i, o, a, t, s, l, r, c, d, u, h, v, g, f, p, y, M, m, P, O, S, C, L, b, F;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            o = e.initializerDefineProperty,
            a = e.assertThisInitialized,
            t = e.defineProperty,
            s = e.createForOfIteratorHelperLoose
        }
        , function(e) {
            l = e.cclegacy,
            r = e._decorator,
            c = e.Canvas,
            d = e.assetManager,
            u = e.director,
            h = e.Component
        }
        , function(e) {
            v = e.logger,
            g = e.LogCategory
        }
        , function(e) {
            f = e.SceneLevels,
            p = e.UIEventType,
            y = e.BundleNames
        }
        , function(e) {
            M = e.projectEvent
        }
        , function(e) {
            m = e.Mission
        }
        , function(e) {
            P = e.globalPlayer
        }
        , function(e) {
            O = e.MainMenuMissionOverlay
        }
        , function(e) {
            S = e.PanelManager
        }
        , function(e) {
            C = e.EventPanel,
            L = e.PanelId
        }
        , function(e) {
            b = e.MainMenuOverlay
        }
        , function(e) {
            F = e.LoadingPrepareMatch
        }
        ],
        execute: function() {
            var A, k, B, T, G, I, R;
            l._RF.push({}, "0a4a907P8pP4ovvrz/0e4e+", "MainMenuCanvas", void 0);
            var E = r.ccclass
              , x = r.property;
            e("MainMenuCanvas", (A = E("MainMenuCanvas"),
            k = x(b),
            B = x(O),
            A((I = n((G = function(e) {
                function n() {
                    for (var n, i = arguments.length, s = new Array(i), l = 0; l < i; l++)
                        s[l] = arguments[l];
                    return n = e.call.apply(e, [this].concat(s)) || this,
                    o(a(n), "menuOverlay", I, a(n)),
                    o(a(n), "missionOverlay", R, a(n)),
                    t(a(n), "currentArena", void 0),
                    t(a(n), "alreadyClickedToPlay", !1),
                    t(a(n), "loadingSceneFinished", !1),
                    t(a(n), "loadingPanelClosed", !1),
                    t(a(n), "loadedScene", void 0),
                    t(a(n), "canvas", void 0),
                    t(a(n), "onGameBundleLoaded", (function(e, i) {
                       console.log("Finished loading bundle. " + i.name + ", loading scene"),
                        i.loadScene(f[n.currentArena.Index], n.onSceneLoaded)
                    }
                    )),
                    t(a(n), "onSceneLoaded", (function(e, i) {
                       console.log("Finished loading scene " + i.name),
                        n.loadedScene = i,
                        n.loadingSceneFinished = !0,
                        n.tryGoToLoadedScene()
                    }
                    )),
                    n
                }
                i(n, e);
                var l = n.prototype;
                return l.onLoad = function() {
                    M.on(p.ButtonClickPlay, this.loadSelectedLevel, this),
                    M.on(p.ButtonClickMissions, this.openMissionOverlay, this),
                    M.on(p.ArenaSelected, this.onArenaSelected, this),
                    this.canvas = this.node.getComponent(c)
                }
                ,
                l.onDestroy = function() {
                    M.off(C.OpenFinish, this.onPanelOpenFinish, this),
                    M.off(p.ButtonClickMissions, this.openMissionOverlay, this),
                    M.off(p.ButtonClickPlay, this.loadSelectedLevel, this),
                    M.off(p.ArenaSelected, this.onArenaSelected, this)
                }
                ,
                l.start = function() {
                  //xz 每日成就 
                    this.menuOverlay.canvas = this,
                    this.missionOverlay.canvas = this,
                    this.scheduleOnce(this.checkMissions, .25)
                }
                ,
                l.checkMissions =async function() {
                    var e, n = P.getClaimableMissions();
                    n.length > 0 && (this.missionOverlay.setupSpecific(n),
                   await this.autoClaimMissions(),
                    null === (e = S.instance) || void 0 === e || e.open(L.MissionOverlay))
                }
                ,
                l.autoClaimMissions =async function() {
                    P.claimFirstWinOfTheDay(),
                   console.log("Trying to redeem missions...", g.Metagame);
                    for (var e, n = s(P.missions); !(e = n()).done; ) {
                        var i = e.value[1];
                        if (console.log("-Checking mission " + m.logMission(i), g.Metagame),
                        m.isMissionRedeemable(i)) {
                            var o =await P.redeemMission(i);
                           console.log("--Redeemed for " + o, g.Metagame)
                        }
                    }
                    P.save()
                }
               
                ,
                l.openMissionOverlay = function() {
                    var e;
                    this.missionOverlay.setupAll(),
                    null === (e = S.instance) || void 0 === e || e.open(L.MissionOverlay)
                }
                ,
                l.onArenaSelected = function(e) {
                    this.currentArena = e
                }
                ,
                l.loadSelectedLevel = function() {
                    if (!this.alreadyClickedToPlay) {
                        this.alreadyClickedToPlay = !0,
                        this.currentArena ||console.log("ERROR: Invalid level index received"),
                        this.canvas.enabled = !1,
                       console.log("Received request to load level: " + this.currentArena.Index),
                        F.instance.show(),
                        M.on(C.OpenFinish, this.onPanelOpenFinish, this),
                       console.log("Get game bundle to load prototype scene");
                        var e = d.getBundle(y.Game);
                        if (e) {
                            var n = f[this.currentArena.Index];
                            e.loadScene(n, this.onSceneLoaded)
                        } else
                           console.log("Bundle invalid, loading it"),
                            d.loadBundle(y.Game, this.onGameBundleLoaded)
                    }
                }
                ,
                l.onPanelOpenFinish = function(e) {
                    e == L.LoadingMatch && (console.log("LoadingMatch panel finished open"),
                    this.loadingPanelClosed = !0,
                    this.tryGoToLoadedScene())
                }
                ,
                l.tryGoToLoadedScene = function() {
                    this.loadingPanelClosed && this.loadingSceneFinished && (console.log("LoadingMatch panel finished open and scene loading finished, runin it"),
                    u.runScene(this.loadedScene))
                }
                ,
                n
            }(h)).prototype, "menuOverlay", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            R = n(G.prototype, "missionOverlay", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            T = G)) || T));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIMatchPageViewToScreenWidth.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectEvent.ts"], (function(e) {
    "use strict";
    var t, i, n, o, r, a, s, h, c, d, g, u, p;
    return {
        setters: [function(e) {
            t = e.inheritsLoose,
            i = e.defineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            r = e._decorator,
            a = e.UITransform,
            s = e.PageView,
            h = e.SystemEventType,
            c = e.Widget,
            d = e.Component
        }
        , function(e) {
            g = e.logger,
            u = e.LogCategory
        }
        , function(e) {
            p = e.projectEvent
        }
        ],
        execute: function() {
            var f;
            e("EventPageView", void 0),
            o._RF.push({}, "0bda6lOJlBGopAenYqp7rJw", "UIMatchPageViewToScreenWidth", void 0);
            var w, l = r.ccclass;
            r.property;
            !function(e) {
                e.FinishedResize = "page-view-finished-resize"
            }(w || (w = e("EventPageView", {})));
            e("UIMatchPageViewToScreenWidth", l("UIMatchPageViewToScreenWidth")(f = function(e) {
                function o() {
                    for (var t, o = arguments.length, r = new Array(o), a = 0; a < o; a++)
                        r[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(r)) || this,
                    i(n(t), "pageView", void 0),
                    i(n(t), "uiTransform", void 0),
                    i(n(t), "content", void 0),
                    t
                }
                t(o, e);
                var r = o.prototype;
                return r.onLoad = function() {
                    this.uiTransform = this.node.getComponent(a),
                    this.pageView = this.node.getComponent(s),
                    this.pageView && (this.content = this.pageView.content),
                    this.node.on(h.SIZE_CHANGED, this.onSizeChanged, this)
                }
                ,
                r.onSizeChanged = function() {
                    var e = this;
                    this.uiTransform && this.content && this.uiTransform && this.pageView && (this.content.children.forEach((function(t) {
                        var i = t.getComponent(a);
                        i && e.uiTransform && (i.width != e.uiTransform.width && console.log("PageView width: " + e.uiTransform.width + " - content child width: " + i.width, u.UI),
                        i.width = e.uiTransform.width,
                        t.getComponentsInChildren(c).forEach((function(e) {
                            e.updateAlignment()
                        }
                        )))
                    }
                    )),
                    this.pageView._updatePageView(),
                    p.emit(w.FinishedResize))
                }
                ,
                o
            }(d)) || f);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterHitEffect.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts"], (function(e) {
    "use strict";
    var t, i, a, n, r, o, s, h, c, l, m, u, d;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            a = e.initializerDefineProperty,
            n = e.assertThisInitialized,
            r = e.defineProperty
        }
        , function(e) {
            o = e.cclegacy,
            s = e._decorator,
            h = e.Color,
            c = e.Vec3,
            l = e.SkinnedMeshRenderer,
            m = e.tween,
            u = e.Component
        }
        , function(e) {
            d = e.EventCharacterAction
        }
        ],
        execute: function() {
            var f, p, C, g, v, H, y;
            o._RF.push({}, "0c306FlaHNFh4kUbV6cenHG", "CharacterHitEffect", void 0);
            var b = s.ccclass
              , w = s.property;
            e("CharacterHitEffect", (f = b("CharacterHitEffect"),
            p = w(h),
            C = w({
                step: .05,
                range: [0, 1],
                slide: !0
            }),
            f((H = t((v = function(e) {
                function t() {
                    for (var t, i = arguments.length, o = new Array(i), s = 0; s < i; s++)
                        o[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    a(n(t), "damageColor", H, n(t)),
                    r(n(t), "damageColorAlpha", new c(0,0,0)),
                    a(n(t), "duration", y, n(t)),
                    r(n(t), "mesh", void 0),
                    t
                }
                i(t, e);
                var o = t.prototype;
                return o.start = function() {
                    this.mesh = this.getComponentInChildren(l),
                    this.mesh && this.mesh.material && (this.damageColor.a = 0)
                }
                ,
                o.onEnable = function() {
                    this.node.on(d.HitReceived, this.onHitReceived, this)
                }
                ,
                o.onDisable = function() {
                    this.node.off(d.HitReceived, this.onHitReceived, this)
                }
                ,
                o.onHitReceived = function(e) {
                    var t = this;
                    this.mesh && this.mesh.material && m(this.damageColorAlpha).to(this.duration, new c(255,0,0), {
                        onUpdate: function() {
                            t.mesh && t.mesh.material && (t.damageColor.a = t.damageColorAlpha.x,
                            t.changeTintColor(t.damageColor))
                        }
                    }).to(this.duration, new c(0,0,0), {
                        onUpdate: function() {
                            t.mesh && t.mesh.material && (t.damageColor.a = t.damageColorAlpha.x,
                            t.changeTintColor(t.damageColor))
                        }
                    }).union().start()
                }
                ,
                o.changeTintColor = function(e) {
                    if (this.mesh && this.mesh.material) {
                        var t = this.mesh.material.passes[0].getHandle("tintColor");
                        this.mesh.material.passes[0].setUniform(t, e)
                    }
                }
                ,
                t
            }(u)).prototype, "damageColor", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new h
                }
            }),
            y = t(v.prototype, "duration", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .1
                }
            }),
            g = v)) || g));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/LoadingPrepareMatch.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./PanelManager.ts", "./PanelEnums.ts", "./PlayerUIModel.ts"], (function(e) {
    "use strict";
    var n, a, t, i, r, o, l, c, s, u, p, d;
    return {
        setters: [function(e) {
            n = e.defineProperty,
            a = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            i = e.initializerDefineProperty,
            r = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            l = e._decorator,
            c = e.Canvas,
            s = e.Component
        }
        , function(e) {
            u = e.PanelManager
        }
        , function(e) {
            p = e.PanelId
        }
        , function(e) {
            d = e.PlayerUIModel
        }
        ],
        execute: function() {
            var f, h, v, y, g, M, P, b, I;
            o._RF.push({}, "0e02cIBsTJJfpK8TJtu53Ka", "LoadingPrepareMatch", void 0);
            var L = l.ccclass
              , m = l.property;
            e("LoadingPrepareMatch", (f = L("LoadingPrepareMatch"),
            h = m(c),
            v = m(d),
            f((I = b = function(e) {
                function n() {
                    for (var n, a = arguments.length, t = new Array(a), o = 0; o < a; o++)
                        t[o] = arguments[o];
                    return n = e.call.apply(e, [this].concat(t)) || this,
                    i(r(n), "canvas", M, r(n)),
                    i(r(n), "playerUIModel", P, r(n)),
                    n
                }
                t(n, e);
                var a = n.prototype;
                return a.onLoad = function() {
                    n.instance = this
                }
                ,
                a.start = function() {
                    this.canvas.enabled = !1
                }
                ,
                a.show = function() {
                    var e, n;
                    null === (e = this.playerUIModel) || void 0 === e || e.setup(),
                    this.canvas.enabled = !0,
                    u.instance && (null === (n = u.instance) || void 0 === n || n.open(p.LoadingMatch))
                }
                ,
                a.hide = function() {
                    this.canvas.enabled = !1
                }
                ,
                n
            }(s),
            n(b, "instance", void 0),
            M = a((g = I).prototype, "canvas", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = a(g.prototype, "playerUIModel", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = g)) || y));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/ExperienceWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts"], (function(e) {
    "use strict";
    var t, r, n, i, a, l, o, c, s, p, u, b;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            n = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            a = e.cclegacy,
            l = e._decorator,
            o = e.Label,
            c = e.ProgressBar,
            s = e.Component
        }
        , function(e) {
            p = e.MetagameEvent
        }
        , function(e) {
            u = e.projectEvent
        }
        , function(e) {
            b = e.globalPlayer
        }
        ],
        execute: function() {
            var g, f, L, d, v, h, x, y, P, E;
            a._RF.push({}, "0edc9+At+RJ9pHZi+SMMdbS", "ExperienceWidget", void 0);
            var U = l.ccclass
              , m = l.property
              , T = l.executionOrder;
            e("ExperienceWidget", (g = U("ExperienceWidget"),
            f = T(410),
            L = m(o),
            d = m(o),
            v = m(c),
            g(h = f((y = t((x = function(e) {
                function t() {
                    for (var t, r = arguments.length, a = new Array(r), l = 0; l < r; l++)
                        a[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    n(i(t), "currentLevelLabel", y, i(t)),
                    n(i(t), "experienceLabel", P, i(t)),
                    n(i(t), "experienceProgressBar", E, i(t)),
                    t
                }
                r(t, e);
                var a = t.prototype;
                return a.start = function() {
                    this.updateUI()
                }
                ,
                a.onEnable = function() {
                    u.on(p.LevelUp, this.updateUI, this)
                }
                ,
                a.onDisable = function() {
                    u.off(p.LevelUp, this.updateUI, this)
                }
                ,
                a.updateUI = function() {
                    this.setLabelText(this.currentLevelLabel, "" + (b.level + 1)),
                    this.setLabelText(this.experienceLabel, b.experience + "/" + b.getCurrentLevelUpTarget()),
                    this.experienceProgressBar.progress = b.experience / b.getCurrentLevelUpTarget()
                }
                ,
                a.setLabelText = function(e, t) {
                    e.string = t,
                    e.updateRenderData(!0)
                }
                ,
                t
            }(s)).prototype, "currentLevelLabel", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = t(x.prototype, "experienceLabel", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = t(x.prototype, "experienceProgressBar", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            h = x)) || h) || h));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponUpgradeWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./WeaponEnums.ts", "./GlobalPlayer.ts", "./MetagameWeaponData.ts"], (function(e) {
    "use strict";
    var a, t, n, i, o, r, l, p, s, u, g, c, m, b, d, h, f, W, v, y;
    return {
        setters: [function(e) {
            a = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            n = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            o = e.defineProperty
        }
        , function(e) {
            r = e.cclegacy,
            l = e._decorator,
            p = e.Sprite,
            s = e.Label,
            u = e.Button,
            g = e.Node,
            c = e.Prefab,
            m = e.Component
        }
        , function(e) {
            b = e.logger,
            d = e.LogCategory
        }
        , function(e) {
            h = e.MetagameEvent
        }
        , function(e) {
            f = e.projectEvent
        }
        , function(e) {
            W = e.WeaponType
        }
        , function(e) {
            v = e.globalPlayer
        }
        , function(e) {
            y = e.MetagameWeaponData
        }
        ],
        execute: function() {
            var D, L, w, U, x, P, z, B, M, C, T, V, R, F, I, N, _, j, E, S, G;
            r._RF.push({}, "0efe4wTG7dP7qsU/RZPZ5BK", "WeaponUpgradeWidget", void 0);
            var Z = l.ccclass
              , k = l.property;
            e("WeaponUpgradeWidget", (D = Z("WeaponUpgradeWidget"),
            L = k(p),
            w = k(s),
            U = k(s),
            x = k(s),
            P = k(s),
            z = k(s),
            B = k(u),
            M = k(g),
            C = k(c),
            D((R = a((V = function(e) {
                function a() {
                    for (var a, t = arguments.length, r = new Array(t), l = 0; l < t; l++)
                        r[l] = arguments[l];
                    return a = e.call.apply(e, [this].concat(r)) || this,
                    n(i(a), "sptIcon", R, i(a)),
                    n(i(a), "lName", F, i(a)),
                    n(i(a), "lLevel", I, i(a)),
                    n(i(a), "lBaseDmgValue", N, i(a)),
                    n(i(a), "lRangeValue", _, i(a)),
                    n(i(a), "lUpgradeCostValue", j, i(a)),
                    n(i(a), "btnBuyUpgrade", E, i(a)),
                    n(i(a), "containerMaxLevel", S, i(a)),
                    n(i(a), "metagameWeaponDataPrefab", G, i(a)),
                    o(i(a), "metagameWeaponData", void 0),
                    o(i(a), "weapon", void 0),
                    a
                }
                t(a, e);
                var r = a.prototype;
                return r.onLoad = function() {
                    this.getWeaponDatas()
                }
                ,
                r.setup = function(e) {
                  //xz 武器升级界面 单个武器节点
                    this.weapon = e,
                   console.log("Setting up widget " + this.node.name + " with weapon " + W[e], d.UI),
                    this.getWeaponDatas();
                    var a = v.getWeaponLevel(e);
                    if (null != a) {
                        var t = a + 1;
                        this.setLabelText(this.lLevel, t.toFixed()),
                        v.isWeaponMaxLevel(e) ? (this.containerMaxLevel.active = !0,
                        this.btnBuyUpgrade.node.active = !1) : (this.containerMaxLevel.active = !1,
                        this.btnBuyUpgrade.node.active = !0)
                    }
                    var n = this.metagameWeaponData.getWeaponName(e);
                    this.setLabelText(this.lName, n);
                    var i = v.getWeaponUpgradeCost(e);
                    null != i && this.setLabelText(this.lUpgradeCostValue, i.toFixed()),
                    this.btnBuyUpgrade.interactable = v.canPurchaseWeaponUpgrade(e);
                    var o = this.metagameWeaponData.getWeaponData(e);
                    if (null != o) {
                        var r = v.getWeaponDamageMultiplier(e)
                          , l = o.Damage * r;
                       console.log(this.node.name + " Setting up weapon upgrade widget damage: " + o.Damage + " multiplier: " + r + " result: " + l, d.UI),
                        this.setLabelText(this.lBaseDmgValue, l.toFixed()),
                        this.setLabelText(this.lRangeValue, o.Range.toFixed())
                    }
                    this.sptIcon.spriteFrame = this.metagameWeaponData.getWeaponIcon(e)
                }
                ,
                r.purchaseUpgrade = function() {
                    f.emit(h.WeaponUpgradePurchaseConfirmation, this.weapon)
                }
                ,
                r.setLabelText = function(e, a) {
                    e.string = a,
                    e.updateRenderData(!0)
                }
                ,
                r.getWeaponDatas = function() {
                    this.metagameWeaponData = this.metagameWeaponDataPrefab.data.getComponent(y)
                }
                ,
                a
            }(m)).prototype, "sptIcon", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            F = a(V.prototype, "lName", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = a(V.prototype, "lLevel", [U], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            N = a(V.prototype, "lBaseDmgValue", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            _ = a(V.prototype, "lRangeValue", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            j = a(V.prototype, "lUpgradeCostValue", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = a(V.prototype, "btnBuyUpgrade", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            S = a(V.prototype, "containerMaxLevel", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            G = a(V.prototype, "metagameWeaponDataPrefab", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            T = V)) || T));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/ExperienceRewardWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, n, r, i, a, o, c, l, u, s, p;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            r = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            a = e.asyncToGenerator
        }
        , function(e) {
            o = e.cclegacy,
            c = e._decorator,
            l = e.UIOpacity,
            u = e.Label,
            s = e.Animation,
            p = e.Component
        }
        ],
        execute: function() {
            var d, y, f, h, b, g, m, w, v;
            o._RF.push({}, "10552FrgBBMWpEYv7Q0rsQS", "ExperienceRewardWidget", void 0);
            var R = c.ccclass
              , x = c.property;
            e("ExperienceRewardWidget", (d = R("ExperienceRewardWidget"),
            y = x(l),
            f = x(u),
            h = x(s),
            d((m = t((g = function(e) {
                function t() {
                    for (var t, n = arguments.length, a = new Array(n), o = 0; o < n; o++)
                        a[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    r(i(t), "contentOpacity", m, i(t)),
                    r(i(t), "label", w, i(t)),
                    r(i(t), "animation", v, i(t)),
                    t
                }
                n(t, e);
                var o = t.prototype;
                return o.start = function() {
                    this.contentOpacity.opacity = 0
                }
                ,
                o.show = function() {
                    var e = a(regeneratorRuntime.mark((function e(t) {
                        var n;
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    return this.label.string = "+" + t.toFixed(),
                                    this.label.updateRenderData(!0),
                                    this.animation.play(),
                                    n = this.animation.defaultClip.duration,
                                    e.next = 6,
                                    this.delay(n);
                                case 6:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e, this)
                    }
                    )));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                o.delay = function(e) {
                    return new Promise((function(t) {
                        return setTimeout(t, 1e3 * e)
                    }
                    ))
                }
                ,
                t
            }(p)).prototype, "contentOpacity", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            w = t(g.prototype, "label", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = t(g.prototype, "animation", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = g)) || b));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterHealthRegenVFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts"], (function(t) {
    "use strict";
    var e, n, a, i, r, o, s, c, l, h;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            a = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            r = t.defineProperty
        }
        , function(t) {
            o = t.cclegacy,
            s = t._decorator,
            c = t.ParticleSystem,
            l = t.Component
        }
        , function(t) {
            h = t.EventCharacterAction
        }
        ],
        execute: function() {
            var p, u, f, g, R;
            o._RF.push({}, "10aeb9jVu1BnZy9jKQyHI+/", "CharacterHealthRegenVFX", void 0);
            var y = s.ccclass
              , v = s.property;
            t("CharacterHealthRegenVFX", (p = y("CharacterHealthRegenVFX"),
            u = v([c]),
            p((R = e((g = function(t) {
                function e() {
                    for (var e, n = arguments.length, o = new Array(n), s = 0; s < n; s++)
                        o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    a(i(e), "particles", R, i(e)),
                    r(i(e), "originalRates", new Map),
                    e
                }
                n(e, t);
                var o = e.prototype;
                return o.onLoad = function() {
                    var t = this;
                    this.particles.length > 0 && this.particles.forEach((function(e) {
                        e && (e.playOnAwake = !1),
                        t.originalRates.set(e.name, e.rateOverTime.constant)
                    }
                    ))
                }
                ,
                o.onEnable = function() {
                    this.node.on(h.HealthRegenStart, this.onRegenStart, this),
                    this.node.on(h.HealthRegenStop, this.onRegenStop, this)
                }
                ,
                o.onDisable = function() {
                    this.node.off(h.HealthRegenStart, this.onRegenStart, this),
                    this.node.off(h.HealthRegenStop, this.onRegenStop, this)
                }
                ,
                o.onRegenStart = function() {
                    var t = this;
                    this.particles.length > 0 && this.particles.forEach((function(e) {
                        null == e || e.play(),
                        e.rateOverTime.constant = t.originalRates.get(e.name)
                    }
                    ))
                }
                ,
                o.onRegenStop = function() {
                    var t = this;
                    this.particles.length > 0 && this.particles.forEach((function(e) {
                        e.rateOverTime.constant = 0,
                        t.scheduleOnce((function() {
                            null == e || e.stop()
                        }
                        ), e.duration)
                    }
                    ))
                }
                ,
                e
            }(l)).prototype, "particles", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            f = g)) || f));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TutorialVolume.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./TweenCollection.ts", "./GameplayEnums.ts", "./MatchController.ts", "./TutorialStepBase.ts"], (function(t) {
    "use strict";
    var e, i, n, o, a, r, c, l, s, u, p, h;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            r = t._decorator
        }
        , function(t) {
            c = t.ProjectEventType
        }
        , function(t) {
            l = t.projectEvent
        }
        , function(t) {
            s = t.TweenCollection
        }
        , function(t) {
            u = t.MatchState
        }
        , function(t) {
            p = t.MatchController
        }
        , function(t) {
            h = t.TutorialStepBase
        }
        ],
        execute: function() {
            var v, f, y, d, T, m;
            a._RF.push({}, "116fdKoaWpFgLkDGEz/+RRk", "TutorialVolume", void 0);
            var w = r.ccclass
              , M = r.property;
            t("TutorialVolume", (v = w("TutorialVolume"),
            f = M(s),
            v((T = e((d = function(t) {
                function e() {
                    for (var e, i = arguments.length, a = new Array(i), r = 0; r < i; r++)
                        a[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    n(o(e), "startActive", T, o(e)),
                    n(o(e), "tween", m, o(e)),
                    e
                }
                i(e, t);
                var a = e.prototype;
                return a.onLoad = function() {
                    t.prototype.onLoad.call(this),
                    this.startActive && l.on(c.MatchStart, this.onMatchStart, this)
                }
                ,
                a.onDestroy = function() {
                    this.startActive && l.off(c.MatchStart, this.onMatchStart, this)
                }
                ,
                a.onMatchStart = function() {
                    this.activate()
                }
                ,
                a.playerEntered = function() {
                    var t;
                    (null === (t = p.instance) || void 0 === t ? void 0 : t.state) == u.Runing && this.activate()
                }
                ,
                a.playerExited = function() {
                    this.deactivate()
                }
                ,
                a.activate = function() {
                    var e;
                    t.prototype.activate.call(this),
                    null === (e = this.tween) || void 0 === e || e.play()
                }
                ,
                a.deactivate = function() {
                    var e;
                    t.prototype.deactivate.call(this),
                    null === (e = this.tween) || void 0 === e || e.playReverse()
                }
                ,
                e
            }(h)).prototype, "startActive", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            m = e(d.prototype, "tween", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = d)) || y));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestRaycastTileMap.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./index.js", "./index.mjs_cjs=&original=.js"], (function(t) {
    "use strict";
    var e, n, r, i, a, o, s, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            n = t.defineProperty,
            r = t.assertThisInitialized
        }
        , function(t) {
            i = t.cclegacy,
            a = t._decorator,
            o = t.Component
        }
        , function(t) {
            s = t.logger
        }
        , function(t) {
            c = t.default
        }
        , null],
        execute: function() {
            var l;
            i._RF.push({}, "12b30IYXGVNFqggMOPox1Lq", "TestRaycastTileMap", void 0);
            var u = a.ccclass;
            a.property,
            t("TestRaycastTileMap", u("TestRaycastTileMap")(l = function(t) {
                function i() {
                    for (var e, i = arguments.length, a = new Array(i), o = 0; o < i; o++)
                        a[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    n(r(e), "tilemap", [[0, 0, 0, 1], [1, 0, 0, 1], [1, 0, 0, 1], [1, 1, 1, 1]]),
                    n(r(e), "getTileAt", (function(t, n) {
                        return e.tilemap[n][t]
                    }
                    )),
                    e
                }
                return e(i, t),
                i.prototype.start = function() {
                    console.log(c);
                    var t = new Array(2)
                      , e = new Array(2)
                      , n = c(this.getTileAt, [1, 0], [0, 1], 100, t, e);
                    console.log(n),
                    console.log(t),
                    console.log(e)
                }
                ,
                i
            }(o)) || l);
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Target.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, o, r;
    return {
        setters: [function(t) {
            e = t.defineProperty
        }
        , function(t) {
            o = t.cclegacy,
            r = t.Vec3
        }
        ],
        execute: function() {
            o._RF.push({}, "161cdqHRXVJ6JrRIC2ZDBX+", "Target", void 0);
            var s = t("Target", function() {
                function t() {}
                return t.direction = function(t, e, o) {
                    t.set(o.worldPosition),
                    e.getWorldPosition(this.sourcePos),
                    t.subtract(this.sourcePos),
                    t.normalize()
                }
                ,
                t.distance = function(t, e) {
                    var o = new r;
                    return o.set(e.worldPosition),
                    t.getWorldPosition(this.sourcePos),
                    o.subtract(this.sourcePos),
                    o.length()
                }
                ,
                t
            }());
            e(s, "sourcePos", new r),
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/SetStartScale.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, i, r, n, a, c, o, l;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            r = t.initializerDefineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            c = t._decorator,
            o = t.Vec3,
            l = t.Component
        }
        ],
        execute: function() {
            var s, u, p;
            a._RF.push({}, "169bdcUl3NMWaUF0uI1dfuk", "SetStartScale", void 0);
            var S = c.ccclass
              , f = c.property;
            t("SetStartScale", S("SetStartScale")((p = e((u = function(t) {
                function e() {
                    for (var e, i = arguments.length, a = new Array(i), c = 0; c < i; c++)
                        a[c] = arguments[c];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    r(n(e), "initialScale", p, n(e)),
                    e
                }
                return i(e, t),
                e.prototype.onLoad = function() {
                    this.node.setScale(this.initialScale)
                }
                ,
                e
            }(l)).prototype, "initialScale", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new o
                }
            }),
            s = u)) || s);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotFleeData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./BotStateData.ts"], (function(t) {
    "use strict";
    var e, i, n, r, a, o, c;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            r = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            o = t._decorator
        }
        , function(t) {
            c = t.BotStateData
        }
        ],
        execute: function() {
            var l, s, u;
            a._RF.push({}, "170e3Y6NitPbpJeE1/TFCQp", "BotFleeData", void 0);
            var p = o.ccclass
              , f = o.property;
            t("BotFleeData", p("BotFleeData")((u = e((s = function(t) {
                function e() {
                    for (var e, i = arguments.length, a = new Array(i), o = 0; o < i; o++)
                        a[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    n(r(e), "mininumFleeingDistance", u, r(e)),
                    e
                }
                return i(e, t),
                e
            }(c)).prototype, "mininumFleeingDistance", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 10
                }
            }),
            l = s)) || l);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestPathfinding.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Pathfinding.ts"], (function(t) {
    "use strict";
    var e, i, n, r, o, a, s, c, l, f, p, u;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            o = t.defineProperty
        }
        , function(t) {
            a = t.cclegacy,
            s = t._decorator,
            c = t.Prefab,
            l = t.instantiate,
            f = t.path,
            p = t.Component
        }
        , function(t) {
            u = t.Pathfinding
        }
        ],
        execute: function() {
            var d, h, P, g, y;
            a._RF.push({}, "17aeedHUHxM0ZA2KHM5frEe", "TestPathfinding", void 0);
            var b = s.ccclass
              , v = s.property;
            t("TestPathfinding", (d = b("TestPathfinding"),
            h = v({
                type: c,
                tooltip: "Prefabs to visualize"
            }),
            d((y = e((g = function(t) {
                function e() {
                    for (var e, i = arguments.length, a = new Array(i), s = 0; s < i; s++)
                        a[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    n(r(e), "prefab", y, r(e)),
                    o(r(e), "byakugan", void 0),
                    e
                }
                return i(e, t),
                e.prototype.start = function() {
                    var t = this;
                    u.instance.getPathToRandomPoint(this.node.worldPosition.x, this.node.worldPosition.z).forEach((function(e) {
                        var i = l(t.prefab);
                        i.setParent(t.node),
                        i.setPosition(e[0], 0, e[1])
                    }
                    )),
                    logger.log(f)
                }
                ,
                e
            }(p)).prototype, "prefab", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = g)) || P));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestRaycastPathfindingTileMap.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./Pathfinding.ts"], (function(n) {
    "use strict";
    var t, i, a, e, r, s;
    return {
        setters: [function(n) {
            t = n.inheritsLoose
        }
        , function(n) {
            i = n.cclegacy,
            a = n._decorator,
            e = n.Component
        }
        , function(n) {
            r = n.logger
        }
        , function(n) {
            s = n.Pathfinding
        }
        ],
        execute: function() {
            var c;
            i._RF.push({}, "17e36nH1iRKp485a6dMqEu7", "TestRaycastPathfindingTileMap", void 0);
            var o = a.ccclass;
            a.property,
            n("TestRaycastPathfindingTileMap", o("TestRaycastPathfindingTileMap")(c = function(n) {
                function i() {
                    return n.apply(this, arguments) || this
                }
                return t(i, n),
                i.prototype.start = function() {
                    var n, t, i = null === (n = s.instance) || void 0 === n ? void 0 : n.raycastOnOriginalMap([1, 5], [1, 0], 1);
                   console.log("raycastOnOriginalMap: " + i),
                    i = null === (t = s.instance) || void 0 === t ? void 0 : t.raycastOnOriginalMap([1, 5], [1, 0], 10),
                   console.log("raycastOnOriginalMap: " + i)
                }
                ,
                i
            }(e)) || c);
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/GameplayEnums.ts", ["cc"], (function(t) {
    "use strict";
    var n;
    return {
        setters: [function(t) {
            n = t.cclegacy
        }
        ],
        execute: function() {
            var e;
            t("MatchState", void 0),
            n._RF.push({}, "19ed3jQViRFOb8PTyRKEc62", "GameplayEnums", void 0),
            function(t) {
                t[t.Starting = 0] = "Starting",
                t[t.Runing = 1] = "Runing",
                t[t.Finished = 2] = "Finished"
            }(e || (e = t("MatchState", {}))),
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RotateCharacterModel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var e, o, n, i, s, h, a, r, u, c, _, v, p, d, l, T, E;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            o = t.inheritsLoose,
            n = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            s = t.defineProperty,
            h = t.createClass
        }
        , function(t) {
            a = t.cclegacy,
            r = t._decorator,
            u = t.Vec2,
            c = t.Vec3,
            _ = t.Quat,
            v = t.Node,
            p = t.systemEvent,
            d = t.SystemEventType,
            l = t.ViewGroup
        }
        , function(t) {
            T = t.UIEventType
        }
        , function(t) {
            E = t.projectEvent
        }
        ],
        execute: function() {
            var f, R, g;
            a._RF.push({}, "1b1bbDWRd5ANaeJIaFUWeZb", "RotateCharacterModel", void 0);
            var M = r.ccclass
              , y = r.property
              , O = r.executionOrder;
            t("RotateCharacterModel", M("RotateCharacterModel")(f = O(3)((g = e((R = function(t) {
                function e() {
                    for (var e, o = arguments.length, h = new Array(o), a = 0; a < o; a++)
                        h[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(h)) || this,
                    n(i(e), "speedRotate", g, i(e)),
                    s(i(e), "_targetToRotate", void 0),
                    s(i(e), "_targetNodeToReceiveEvents", void 0),
                    s(i(e), "_isInputDown", !1),
                    s(i(e), "_mousePos", new u),
                    s(i(e), "_mousePosOnDown", new u),
                    s(i(e), "_inputDelta", new u),
                    s(i(e), "_euler", new c),
                    s(i(e), "_quatIdentiy", new _),
                    e
                }
                o(e, t);
                var a = e.prototype;
                return a.onLoad = function() {
                    this._targetNodeToReceiveEvents = this.node
                }
                ,
                a.start = function() {
                    _.identity(this._quatIdentiy)
                }
                ,
                a.onEnable = function() {
                    this._targetNodeToReceiveEvents && (this._targetNodeToReceiveEvents.on(v.EventType.MOUSE_MOVE, this.onMouseMove, this),
                    this._targetNodeToReceiveEvents.on(v.EventType.MOUSE_DOWN, this.onMouseDown, this),
                    this._targetNodeToReceiveEvents.on(v.EventType.MOUSE_UP, this.onMouseUp, this, !0),
                    p.on(d.MOUSE_UP, this.onMouseUp, this),
                    this._targetNodeToReceiveEvents.on(v.EventType.TOUCH_START, this.onTouchStart, this, !0),
                    this._targetNodeToReceiveEvents.on(v.EventType.TOUCH_MOVE, this.onTouchMove, this, !0),
                    this._targetNodeToReceiveEvents.on(v.EventType.TOUCH_END, this.onTouchEndOrCancel, this, !0),
                    this._targetNodeToReceiveEvents.on(v.EventType.TOUCH_CANCEL, this.onTouchEndOrCancel, this, !0),
                    this.resetRotation(),
                    E.on(T.StopRotateModel, this.onRequestStop, this),
                    E.on(T.CharacterModelChanged, this.onModelChanged, this))
                }
                ,
                a.onDisable = function() {
                    this._isInputDown = !1,
                    this._targetNodeToReceiveEvents && (this._targetNodeToReceiveEvents.off(v.EventType.MOUSE_MOVE, this.onMouseMove, this),
                    this._targetNodeToReceiveEvents.off(v.EventType.MOUSE_DOWN, this.onMouseDown, this),
                    this._targetNodeToReceiveEvents.off(v.EventType.MOUSE_UP, this.onMouseUp, this, !0),
                    p.off(d.MOUSE_UP, this.onMouseUp, this),
                    this._targetNodeToReceiveEvents.off(v.EventType.TOUCH_START, this.onTouchStart, this),
                    this._targetNodeToReceiveEvents.off(v.EventType.TOUCH_MOVE, this.onTouchMove, this),
                    this._targetNodeToReceiveEvents.off(v.EventType.TOUCH_END, this.onTouchEndOrCancel, this),
                    this._targetNodeToReceiveEvents.off(v.EventType.TOUCH_CANCEL, this.onTouchEndOrCancel, this),
                    E.off(T.StopRotateModel, this.onRequestStop, this),
                    E.off(T.CharacterModelChanged, this.onModelChanged, this))
                }
                ,
                a.update = function(t) {
                    this._isInputDown && this.moveBy(this._inputDelta.x, this.speedRotate * t)
                }
                ,
                a.onRequestStop = function() {
                    this.onInputUp()
                }
                ,
                a.onModelChanged = function(t) {
                    var e;
                    t && (null === (e = t.node) || void 0 === e ? void 0 : e.isValid) && t.node.children.length >= 1 ? this._targetToRotate = t.node.children[0] : this._targetToRotate = null
                }
                ,
                a.onMouseDown = function(t) {
                    this._isInputDown = !0,
                    t.getLocation(this._mousePosOnDown)
                }
                ,
                a.onMouseMove = function(t) {
                    this._isInputDown && (t.getLocation(this._mousePos),
                    this._inputDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._inputDelta.normalize())
                }
                ,
                a.onMouseUp = function(t) {
                    this.onInputUp()
                }
                ,
                a.onTouchStart = function(t, e) {
                    t && t.getLocation(this._mousePosOnDown),
                    this._isInputDown = !0
                }
                ,
                a.onTouchMove = function(t, e) {
                    t && (t.getLocation(this._mousePos),
                    this._inputDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._inputDelta.normalize())
                }
                ,
                a.onTouchEndOrCancel = function(t, e) {
                    this.onInputUp()
                }
                ,
                a.onInputUp = function() {
                    this._isInputDown = !1,
                    this._inputDelta.set(0, 0)
                }
                ,
                a.moveBy = function(t, e) {
                    this._targetToRotate && this._isInputDown && (this._euler.set(this._targetToRotate.eulerAngles),
                    this._euler.y += t * e,
                    this._targetToRotate.setRotationFromEuler(this._euler))
                }
                ,
                a.resetRotation = function() {
                    var t;
                    null === (t = this._targetToRotate) || void 0 === t || t.setRotation(this._quatIdentiy)
                }
                ,
                h(e, [{
                    key: "targetToRotate",
                    set: function(t) {
                        this._targetToRotate = t ? t.children[0] : null
                    }
                }]),
                e
            }(l)).prototype, "speedRotate", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 500
                }
            }),
            f = R)) || f) || f);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIMissionCompleteSFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./AudioManager.ts"], (function(e) {
    "use strict";
    var t, n, o, i, s, r, c, l, a, p, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            o = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            s = e.cclegacy,
            r = e._decorator,
            c = e.Prefab,
            l = e.Component
        }
        , function(e) {
            a = e.UIEventType
        }
        , function(e) {
            p = e.projectEvent
        }
        , function(e) {
            u = e.AudioManager
        }
        ],
        execute: function() {
            var f, y, h, v, m;
            s._RF.push({}, "1c9d7oYRO9O94hU9YEPLvEU", "UIMissionCompleteSFX", void 0);
            var M = r.ccclass
              , C = r.property;
            e("UIMissionCompleteSFX", (f = M("UIMissionCompleteSFX"),
            y = C(c),
            f((m = t((v = function(e) {
                function t() {
                    for (var t, n = arguments.length, s = new Array(n), r = 0; r < n; r++)
                        s[r] = arguments[r];
                    return t = e.call.apply(e, [this].concat(s)) || this,
                    o(i(t), "key", m, i(t)),
                    t
                }
                n(t, e);
                var s = t.prototype;
                return s.onEnable = function() {
                    p.on(a.MissionComplete, this.onMissionComplete, this)
                }
                ,
                s.onDisable = function() {
                    p.off(a.MissionComplete, this.onMissionComplete, this)
                }
                ,
                s.onMissionComplete = function() {
                    var e;
                    this.key && (null === (e = u.instance) || void 0 === e || e.playByKey(this.key))
                }
                ,
                t
            }(l)).prototype, "key", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            h = v)) || h));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterShrinkingAreaDamage.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(e) {
    "use strict";
    var t, n, a, i, o, s, r, h, c, d;
    return {
        setters: [function(e) {
            t = e.inheritsLoose,
            n = e.defineProperty,
            a = e.assertThisInitialized
        }
        , function(e) {
            i = e.cclegacy,
            o = e._decorator,
            s = e.Component
        }
        , function(e) {
            r = e.ProjectEventType
        }
        , function(e) {
            h = e.projectEvent
        }
        , function(e) {
            c = e.EventCharacterAction
        }
        , function(e) {
            d = e.CharacterBlackboard
        }
        ],
        execute: function() {
            var m;
            i._RF.push({}, "1dd83bAUi5Ok5qsQfP03KTj", "CharacterShrinkingAreaDamage", void 0);
            var g = o.ccclass;
            o.property,
            e("CharacterShrinkingAreaDamage", g("CharacterShrinkingAreaDamage")(m = function(e) {
                function i() {
                    for (var t, i = arguments.length, o = new Array(i), s = 0; s < i; s++)
                        o[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    n(a(t), "insideOfDamageZoneCount", 0),
                    n(a(t), "data", void 0),
                    n(a(t), "damageTimer", 0),
                    t
                }
                t(i, e);
                var o = i.prototype;
                return o.onEnable = function() {
                    this.node.on(c.EnterDamageZone, this.onEnterDamageZone, this),
                    this.node.on(c.ExitDamageZone, this.onExitDamageZone, this),
                    h.on(r.MatchFinish, this.onMatchFinish, this)
                }
                ,
                o.onDisable = function() {
                    this.node.off(c.EnterDamageZone, this.onEnterDamageZone, this),
                    this.node.off(c.ExitDamageZone, this.onExitDamageZone, this),
                    h.off(r.MatchFinish, this.onMatchFinish, this)
                }
                ,
                o.start = function() {
                    this.data = this.node.getComponent(d)
                }
                ,
                o.update = function(e) {
                    this.data && 0 != this.data.IsAlive && (this.data.inDamageZone = this.insideOfDamageZoneCount > 0,
                    0 != this.insideOfDamageZoneCount && (this.damageTimer += e,
                    this.damageTimer >= this.data.AreaDamageInterval && (this.damageTimer = 0,
                    this.node.emit(c.HitReceived, this.data.AreaDamage))))
                }
                ,
                o.onEnterDamageZone = function() {
                    var e;
                    0 == this.insideOfDamageZoneCount && (null === (e = this.data) || void 0 === e ? void 0 : e.IsPlayer) && h.emit(r.PlayerEnterDamageZone),
                    this.insideOfDamageZoneCount++
                }
                ,
                o.onExitDamageZone = function() {
                    var e;
                    (this.insideOfDamageZoneCount--,
                    this.insideOfDamageZoneCount < 0) && (this.insideOfDamageZoneCount = 0,
                    0 == this.insideOfDamageZoneCount && (null === (e = this.data) || void 0 === e ? void 0 : e.IsPlayer) && h.emit(r.PlayerExitDamageZone))
                }
                ,
                o.onMatchFinish = function() {
                    this.insideOfDamageZoneCount = 0
                }
                ,
                i
            }(s)) || m);
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayerNode.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterBlackboard.ts"], (function(e) {
    "use strict";
    var t, r, o, n, c, a;
    return {
        setters: [function(e) {
            t = e.defineProperty,
            r = e.inheritsLoose
        }
        , function(e) {
            o = e.cclegacy,
            n = e._decorator,
            c = e.Component
        }
        , function(e) {
            a = e.CharacterBlackboard
        }
        ],
        execute: function() {
            var i, s, u;
            o._RF.push({}, "1ee21979QxPvboWO2RMt3bE", "PlayerNode", void 0);
            var l = n.ccclass
              , d = (n.property,
            n.executionOrder);
            e("PlayerNode", l("PlayerNode")(i = d(-10)((u = s = function(e) {
                function t() {
                    return e.apply(this, arguments) || this
                }
                return r(t, e),
                t.prototype.onLoad = function() {
                    t.instance = this;
                    var e = this.getComponentInChildren(a);
                    e && (e.IsPlayer = !0)
                }
                ,
                t
            }(c),
            t(s, "instance", void 0),
            i = u)) || i) || i);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MapReader.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(e) {
    "use strict";
    var t, n, r, o, i, a, s, p, c, u, l;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            r = e.initializerDefineProperty,
            o = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            a = e.cclegacy,
            s = e._decorator,
            p = e.JsonAsset,
            c = e.Component
        }
        , function(e) {
            u = e.ProjectEventType
        }
        , function(e) {
            l = e.projectEvent
        }
        ],
        execute: function() {
            var d, f, y, h, m, v;
            a._RF.push({}, "213d1opK19EGZiX39S/xyG+", "MapReader", void 0);
            var j = s.ccclass
              , J = s.property
              , M = s.executionOrder;
            e("MapReader", (d = j("MapReader"),
            f = M(-3),
            y = J({
                type: p
            }),
            d(h = f((v = t((m = function(e) {
                function t() {
                    for (var t, n = arguments.length, a = new Array(n), s = 0; s < n; s++)
                        a[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    r(o(t), "mapJson", v, o(t)),
                    i(o(t), "map", void 0),
                    t
                }
                return n(t, e),
                t.prototype.start = function() {
                    null != this.mapJson && null != this.mapJson.json && (this.map = this.mapJson.json,
                    l.emit(u.MapSetup, this.map))
                }
                ,
                t
            }(c)).prototype, "mapJson", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            h = m)) || h) || h));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MatchAudio.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./AudioManager.ts"], (function(t) {
    "use strict";
    var n, i, a, o, e, r, c, s, h, u, l;
    return {
        setters: [function(t) {
            n = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            a = t.initializerDefineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            e = t.cclegacy,
            r = t._decorator,
            c = t.AudioClip,
            s = t.Component
        }
        , function(t) {
            h = t.ProjectEventType
        }
        , function(t) {
            u = t.projectEvent
        }
        , function(t) {
            l = t.AudioManager
        }
        ],
        execute: function() {
            var p, f, d, M, v, y, m;
            e._RF.push({}, "245d9NTYV9PVYYDAa28osLt", "MatchAudio", void 0);
            var S = r.ccclass
              , b = r.property;
            t("MatchAudio", (p = S("MatchAudio"),
            f = b(c),
            d = b(c),
            p((y = n((v = function(t) {
                function n() {
                    for (var n, i = arguments.length, e = new Array(i), r = 0; r < i; r++)
                        e[r] = arguments[r];
                    return n = t.call.apply(t, [this].concat(e)) || this,
                    a(o(n), "matchStart", y, o(n)),
                    a(o(n), "matchEnd", m, o(n)),
                    n
                }
                i(n, t);
                var e = n.prototype;
                return e.onEnable = function() {
                    u.on(h.MatchTimerStart, this.onMatchStart, this),
                    u.on(h.MatchFinish, this.onMatchFinish, this)
                }
                ,
                e.onDisable = function() {
                    u.off(h.MatchTimerStart, this.onMatchStart, this),
                    u.off(h.MatchFinish, this.onMatchFinish, this)
                }
                ,
                e.onMatchStart = function() {
                    var t;
                    null === (t = l.instance) || void 0 === t || t.playOneShot(this.matchStart)
                }
                ,
                e.onMatchFinish = function() {
                    var t;
                    null === (t = l.instance) || void 0 === t || t.playOneShot(this.matchEnd)
                }
                ,
                n
            }(s)).prototype, "matchStart", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            m = n(v.prototype, "matchEnd", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = v)) || M));
            e._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/GlobalPlayer.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./WeaponEnums.ts", "./Mission.ts", "./RewardedAdOpportunitySaveData.ts"], (function(e) {
    "use strict";
    var a, t, i, r, s, n, d, o, h, l, c, u, m, f, g, p, y, v, w;
    return {
        setters: [function(e) {
            a = e.createForOfIteratorHelperLoose,
            t = e.createClass,
            i = e.defineProperty
        }
        , function(e) {
            r = e.cclegacy,
            s = e.sys,
            n = e.game,
            d = e.Game,
            o = e.resources,
            h = e.JsonAsset
        }
        , function(e) {
            l = e.logger,
            c = e.LogCategory,
            u = e.LogType
        }
        , function(e) {
            m = e.MetagameEvent
        }
        , function(e) {
            f = e.projectEvent
        }
        , function(e) {
            g = e.WeaponType
        }
        , function(e) {
            p = e.Mission,
            y = e.MissionCategory
        }
        , function(e) {
            v = e.RewardedAdAfterMatchData,
            w = e.RewardedAdDailyData
        }
        ],
        execute: function() {
            var D;
            e("CurrencyWinReason", void 0),
            r._RF.push({}, "24817jRm7dIwr2PZkPuM6tB", "GlobalPlayer", void 0),
            function(e) {
                e[e.Sum = 0] = "Sum",
                e[e.Highest = 1] = "Highest"
            }(D || (D = {}));
            var M, A = e("Statistic", function() {
                function e(e) {
                    void 0 === e && (e = D.Sum),
                    i(this, "type", D.Sum),
                    i(this, "allTime", 0),
                    i(this, "current", 0),
                    this.type = e
                }
                return e.add = function(e, a) {
                    e.current += a,
                    e.type == D.Sum ? e.allTime += a : e.type == D.Highest && e.current > e.allTime && (e.allTime = e.current)
                }
                ,
                e.set = function(e, a) {
                    e.current = a,
                    e.type == D.Sum ? e.allTime += a : e.type == D.Highest && e.current > e.allTime && (e.allTime = e.current)
                }
                ,
                e.resetCurrent = function(e) {
                    e.current = 0
                }
                ,
                e
            }()), T = function() {
                function e() {
                    i(this, "previousTime", new Date),
                    i(this, "hasClaimed", !1),
                    i(this, "claimable", !1)
                }
                return e.reset = function(e) {
                    e.hasClaimed = !1,
                    e.claimable = !1
                }
                ,
                e
            }(), R = function() {
                for (var e in i(this, "chestsOpened", new A),
                i(this, "enemyKilledTotal", new A),
                i(this, "enemyKilled", new Map),
                i(this, "damageDealtTotal", new A),
                i(this, "damageDealt", new Map),
                i(this, "inMatchLevel", new A(D.Highest)),
                g) {
                    var a = Number(e);
                    0 == isNaN(a) && (this.enemyKilled.set(a, new A),
                    this.damageDealt.set(a, new A))
                }
            };
            !function(e) {
                e[e.LevelUpReward = 0] = "LevelUpReward",
                e[e.MissionReward = 1] = "MissionReward",
                e[e.FirstWinOfTheDayReward = 2] = "FirstWinOfTheDayReward",
                e[e.Debug = 3] = "Debug",
                e[e.RewardedAdDaily = 4] = "RewardedAdDaily",
                e[e.RewardedAdAfterMatch = 5] = "RewardedAdAfterMatch"
            }(M || (M = e("CurrencyWinReason", {})));
            var C = function() {
                for (var e in i(this, "statistics", new R),
                i(this, "level", 0),
                i(this, "experience", 0),
                i(this, "characterModelId", 0),
                i(this, "characterTextureId", 0),
                i(this, "weaponLevels", new Map),
                i(this, "currency", 0),
                i(this, "victoryTrophies", 0),
                i(this, "missions", new Map),
                i(this, "entitlements", []),
                i(this, "firstWinOfTheDay", new T),
                i(this, "lastMissionGenerationTime", new Date(0)),
                i(this, "lastSelectedArenaIndex", 0),
                i(this, "rewardedAdDaily", new w),
                i(this, "rewardedAdAfterMatch", new v),
                g) {
                    var a = Number(e);
                    0 == isNaN(a) && this.weaponLevels.set(a, 0)
                }
            }
              , x = e("GlobalPlayer", function() {
                function e() {
                    var e = this;
                    i(this, "metagameData", void 0),
                    i(this, "data", new C),
                    n.on(d.EVENT_GAME_INITED, (function() {
                        o.load("metagame/data", h, (function(a, t) {
                            W.load_temp_12334(e,t);
                        }
                        ))
                    }
                    ), this)
                }
                var r = e.prototype;
                return r.save = async function() {
                    var e = JSON.stringify(this.data, this.replacer);
                   await CoinApp.setItem(C.name, e),
                    console.log("Saved " + C.name, c.Metagame)
                }
                ,r.load_temp_12334 = async function(e,t) {
                    e.metagameData = t.json,
                    // console.log("" + JSON.stringify(e.metagameData), c.Metagame),
                    await    W.load(),
                    await    e.onLoadAfterMetagameImport()
                }
                ,
                r.load = async function() {
                    var e =await CoinApp.getItem(C.name);
                    if (e) {
                        var a = JSON.parse(e, this.reviver);
                        Object.assign(this.data, a),
                        this.data.lastMissionGenerationTime = new Date(this.data.lastMissionGenerationTime),
                        this.data.firstWinOfTheDay.previousTime = new Date(this.data.firstWinOfTheDay.previousTime),
                        this.data.rewardedAdDaily.previousTime = new Date(this.data.rewardedAdDaily.previousTime),
                        this.data.rewardedAdAfterMatch.previousTime = new Date(this.data.rewardedAdAfterMatch.previousTime),
                        (isNaN(Number(this.data.characterModelId)) || "string" == typeof this.data.characterModelId) && (this.data.characterModelId = 0),
                        (isNaN(Number(this.data.characterTextureId)) || "string" == typeof this.data.characterTextureId) && (this.data.characterTextureId = 0),
                        console.log("Loaded " + C.name, c.Metagame)
                        // ,
                        // console.log(this.data)
                    } else
                        console.log("ERROR: No player data to load, probably cache cleared or is first time.", c.Metagame, u.Warning)
                }
                ,
                r.onLoadAfterMetagameImport =async function() {
                    if (this.data) {
                     await   this.generateNewMissions(),
                        this.checkFirstWinOfTheDay();
                        for (var e, t = a(this.metagameData.initialEntitlements); !(e = t()).done; ) {
                            var i = e.value;
                            this.unlockEntitlement(i)
                        }
                        this.checkDailyRewardedAd(),
                        this.checkAfterMatchRewardedAd()
                    }
                }
                ,
                r.unlockEntitlement = function(e) {
                    this.hasUnlocked(e) || this.data.entitlements.push(e)
                }
                ,
                r.hasUnlocked = function(e) {
                    return this.data.entitlements.indexOf(e) >= 0
                }
                ,
                r.getCurrentLevelUpTarget = function() {
                    return this.level >= this.metagameData.levelScaling.length ? -1 : this.metagameData.levelScaling[this.level]
                }
                ,
                r.hasFinishedFirstWinOfTheDay = function() {
                    return this.data.firstWinOfTheDay.claimable
                }
                ,
                r.hasClaimedFirstWinOfTheDay = function() {
                    return this.data.firstWinOfTheDay.hasClaimed
                }
                ,
                r.ensureFirstWinData = function() {
                    return null == this.metagameData.firstVictoryOfTheDayReward ? (console.log("firstVictoryOfTheDayReward is undefined", c.Metagame, u.Error),
                    !1) : 0 != this.metagameData.firstVictoryOfTheDayReward.length || (console.log("firstVictoryOfTheDayReward is empty"),
                    !1)
                }
                ,
                r.claimFirstWinOfTheDay = function() {
                    return this.ensureFirstWinData() && this.data.firstWinOfTheDay.claimable && !this.data.firstWinOfTheDay.hasClaimed ? (this.receiveCurrency(this.metagameData.firstVictoryOfTheDayReward[0], M.FirstWinOfTheDayReward),
                    this.data.firstWinOfTheDay.previousTime = new Date,
                    this.data.firstWinOfTheDay.hasClaimed = !0,
                    console.log("Player claimed First Win Of The Day Bonus for " + this.metagameData.firstVictoryOfTheDayReward),
                    this.metagameData.firstVictoryOfTheDayReward[0]) : 0
                }
                ,
                r.getClaimableMissions = function() {
                    for (var e, t = [], i = a(W.missions); !(e = i()).done; ) {
                        var r = e.value[1];
                        p.isMissionRedeemable(r) && t.push(r.difficulty)
                    }
                    return this.data.firstWinOfTheDay.claimable && !this.data.firstWinOfTheDay.hasClaimed && t.push(y.FirstWinOfTheDay),
                    t
                }
                ,
                r.isNextDay = function(e, a) {
                    return a.getFullYear() > e.getFullYear() || a.getMonth() > e.getMonth() || a.getDate() > e.getDate()
                }
                ,
                r.checkAndGenerateMission = function(e) {
                    var a = this.data.missions.get(e)
                      , t = [g.Basic, g.Bazooka, g.AssaultRifle, g.Shotgun];
                    if (!a || a.redeemed) {
                        var i = t[Math.floor(Math.random() * t.length)]
                          , r = this.metagameData.dailyMissionTargetRange[e];
                        a = new p(e,i,r[0] + Math.round(Math.random() * (r[1] - r[0]))),
                        this.data.missions.set(e, a),
                        console.log("Generated new mission " + a)
                    }
                }
                ,
                r.checkFirstWinOfTheDay = function() {
                    var e = new Date;
                    this.isNextDay(this.data.firstWinOfTheDay.previousTime, e) && T.reset(this.data.firstWinOfTheDay)
                }
                ,
                r.generateNewMissions =async function() {
                    var e = new Date;
                    this.isNextDay(this.data.lastMissionGenerationTime, e) ? (this.checkAndGenerateMission(y.Easy),
                    this.checkAndGenerateMission(y.Medium),
                    this.checkAndGenerateMission(y.Hard),
                    this.data.lastMissionGenerationTime = e,
                  await  this.save(),
                    console.log("Generated new missions", c.Metagame)) : console.log("Too soon to generate a new batch of missions", c.Metagame)
                }
                ,
                r.onEnemyKilled = function(e) {
                    for (var t, i = a(this.data.missions); !(t = i()).done; ) {
                        var r = t.value[1];
                        r.weaponType == e && r.progress < r.target && (r.progress++,
                        console.log("Player progressed on " + r.difficulty + " " + r.weaponType + " Mission. " + r.progress + "/" + r.target))
                    }
                }
                ,
                r.getFirstWinOfTheDayReward = function() {
                    return this.ensureFirstWinData() ? this.metagameData.firstVictoryOfTheDayReward[0] : 0
                }
                ,
                r.getMissionReward = function(e) {
                    var a = this.data.missions.get(e.difficulty);
                    return a ? this.metagameData.dailyMissionRewards[a.difficulty] : 0
                }
                ,
                r.redeemMission =async function(e) {
                    var a = this.data.missions.get(e.difficulty);
                    if (a && p.isMissionRedeemable(a)) {
                        var t = this.metagameData.dailyMissionRewards[a.difficulty];
                        return a.redeemed = !0,
                        this.data.missions.set(a.difficulty, a),
                        this.receiveCurrency(t, M.MissionReward),
                     await   this.save(),
                        t
                    }
                    return -1
                }
                ,
                r.completeAllMissions = function() {
                    this.data.firstWinOfTheDay.claimable = !0,
                    this.data.firstWinOfTheDay.hasClaimed = !1;
                    for (var e, t = a(this.data.missions); !(e = t()).done; ) {
                        var i = e.value[1];
                        i.progress = i.target,
                        i.redeemed = !1
                    }
                }
                ,
                r.onMatchEnded =async function(e) {
                    e >= this.metagameData.matchExpReward.length && (console.log("Place " + e + " does not exist in metagame data. Using " + (this.metagameData.matchExpReward.length - 1), c.Metagame, u.Warning),
                    e = this.metagameData.matchExpReward.length - 1);
                    var a = this.metagameData.matchExpReward[e - 1];
                    if (console.log("Match ended with player on " + e + " place, receiving " + a + " exp points, had " + this.experience + " exp previously", c.Metagame),
                    1 != e || this.data.firstWinOfTheDay.hasClaimed || (this.data.firstWinOfTheDay.claimable = !0,
                    console.log("Player received First Win Of The Day Bonus claim", c.Metagame)),
                    this.experience = this.experience + a,
                    this.level < this.metagameData.levelScaling.length) {
                        var t = this.metagameData.levelScaling[this.level];
                        console.log("Ended with " + this.experience + " exp, needs " + t + " exp for next level.", c.Metagame),
                        this.experience >= t && (this.level++,
                        this.experience -= t,
                        console.log("Level up! Player is now Level " + this.level + " with " + this.experience + " experience!", c.Metagame),
                        this.receiveCurrency(this.metagameData.levelUpReward[0], M.LevelUpReward))
                    }
                    1 == e && (console.log("Player won, giving a victory trophy", c.Metagame),
                    this.victoryTrophies++),
               await     this.save()
                }
                ,
                r.receiveCurrency = function(e, a) {
                    this.currency += e,
                    console.log("Player received " + e + " currency for reason " + M[a], c.Metagame)
                }
                ,
                r.getWeaponLevel = function(e) {
                    var a = this.weaponLevels.get(e);
                    return null == a ? 0 : a
                }
                ,
                r.getPlacementXPAward = function(e) {
                    return e - 1 >= this.metagameData.matchExpReward.length ? this.metagameData.matchExpReward[this.metagameData.matchExpReward.length - 1] : this.metagameData.matchExpReward[e - 1]
                }
                ,
                r.isWeaponMaxLevel = function(e) {
                    return this.getWeaponLevel(e) >= this.metagameData.weaponUpgradesDamageModifier.length - 1
                }
                ,
                r.getWeaponUpgradeCost = function(e) {
                    var a = this.data.weaponLevels.get(e);
                    return null == a ? (console.log("Invalid weapon level for weapon " + e, c.Metagame, u.Error),
                    -1) : a >= this.metagameData.weaponUpgradesCosts.length ? this.metagameData.weaponUpgradesCosts.length - 1 : this.metagameData.weaponUpgradesCosts[a]
                }
                ,
                r.canPurchaseWeaponUpgrade = function(e) {
                    var a = this.getWeaponUpgradeCost(e);
                    return this.currency >= a
                }
                ,
                r.purchaseWeaponUpgrade =async function(e) {
                    var a = this.data.weaponLevels.get(e);
                    if (null == a)
                        return console.log("Invalid weapon level for weapon " + e, c.Metagame, u.Error),
                        !1;
                    var t = this.getWeaponUpgradeCost(e);
                    return this.currency >= t && (this.currency -= t,
                    a++,
                    this.data.weaponLevels.set(e, a),
                    f.emit(m.WeaponUpgradePurchaseSuccess, e, a),
                  await  this.save(),
                    !0)
                }
                ,
                r.getWeaponDamageMultiplier = function(e) {
                    var a = this.getWeaponLevel(e);
                    return a >= this.metagameData.weaponUpgradesDamageModifier.length && (a = this.metagameData.weaponUpgradesDamageModifier.length - 1),
                    this.metagameData.weaponUpgradesDamageModifier[a]
                }
                ,
                r.getNextLevelWeaponDamageMultiplier = function(e) {
                    var a = this.getWeaponLevel(e);
                    return ++a >= this.metagameData.weaponUpgradesDamageModifier.length && (a = this.metagameData.weaponUpgradesDamageModifier.length - 1),
                    this.metagameData.weaponUpgradesDamageModifier[a]
                }
                ,
                r.getHighestLevelWeapon = function() {
                    for (var e, t = 1, i = g.AssaultRifle, r = a(this.data.weaponLevels); !(e = r()).done; ) {
                        var s = e.value
                          , n = s[0]
                          , d = s[1];
                        d > t && (t = d,
                        i = n)
                    }
                    return i
                }
                ,
                r.canPurchaseArena = function(e) {
                    return this.victoryTrophies >= e.UnlockCost
                }
                ,
                r.purchaseArena =async function(e) {
                    this.victoryTrophies -= e.UnlockCost,
                    this.unlockEntitlement(e.UnlockId),
                   await this.save()
                }
                ,
                r.purchaseCharacter =async function(e, a) {
                    this.currency -= a,
                    this.unlockEntitlement(e),
                  await  this.save()
                }
                ,
                r.hasDailyRewardedAd = function() {
                    return this.data.rewardedAdDaily.claimable
                }
                ,
                r.hasClaimedDailyRewardedAd = function() {
                    return this.data.rewardedAdDaily.hasClaimed
                }
                ,
                r.getDailyRewardedAdBonus = function() {
                    return this.ensureRewaredAdBonusData() ? this.metagameData.rewardedAdBonus[0] : 0
                }
                ,
                r.claimDailyRewardedAd = function() {
                    if (!this.ensureRewaredAdBonusData())
                        return !1;
                    var e = this.data.rewardedAdDaily;
                    return e.claimable && !e.hasClaimed ? (this.receiveCurrency(this.metagameData.rewardedAdBonus[0], M.RewardedAdDaily),
                    e.previousTime = new Date,
                    e.hasClaimed = !0,
                    e.claimable = !1,
                    console.log("Player claimend daily rewarded ad opportunity.", c.RewardedAd),
                    !0) : (console.log("Daily rewarded ad claimable: " + e.claimable + " hasClaimed: " + e.hasClaimed, c.RewardedAd),
                    !1)
                }
                ,
                r.hasAfterMatchRewardedAd = function() {
                    return console.log("claimed: " + this.data.rewardedAdAfterMatch.claimedCount + " max: " + v.maxClaimCount + " has: " + (this.data.rewardedAdAfterMatch.claimedCount < v.maxClaimCount), c.RewardedAd),
                    this.data.rewardedAdAfterMatch.claimedCount < v.maxClaimCount
                }
                ,
                r.claimAfterMatchRewardedAd = function() {
                    if (!this.ensureRewaredAdBonusData())
                        return !1;
                    var e = this.data.rewardedAdAfterMatch;
                    if (e.claimedCount < v.maxClaimCount) {
                        var a = this.metagameData.rewardedAdBonus[0];
                        return this.receiveCurrency(a, M.RewardedAdAfterMatch),
                        e.previousTime = new Date,
                        e.claimedCount++,
                        console.log("Player claimed " + a + " for after match reward, claimed " + e.claimedCount + " time(s) today of " + v.maxClaimCount + " max"),
                        !0
                    }
                    return console.log("Already reached max after match rewards claim for today."),
                    !1
                }
                ,
                r.setPreviousTimeForDailies = function(e) {
                    this.data.lastMissionGenerationTime = e,
                    this.data.firstWinOfTheDay.previousTime = e,
                    this.data.rewardedAdDaily.previousTime = e,
                    this.data.rewardedAdAfterMatch.previousTime = e
                }
                ,
                r.checkDailyRewardedAd = function() {
                    var e = new Date;
                    this.data.rewardedAdDaily && this.data.rewardedAdDaily.previousTime && this.data.rewardedAdDaily.previousTime.getFullYear ? this.isNextDay(this.data.rewardedAdDaily.previousTime, e) && w.reset(this.data.rewardedAdDaily) : console.log("Invalid state of rewardedAdDaily saved data", c.RewardedAd, u.Error)
                }
                ,
                r.checkAfterMatchRewardedAd = function() {
                    var e = new Date;
                    this.data.rewardedAdAfterMatch && this.data.rewardedAdAfterMatch.previousTime && this.data.rewardedAdAfterMatch.previousTime.getFullYear || console.log("Invalid state of after match rewarded ad saved data", c.RewardedAd, u.Error),
                    this.isNextDay(this.data.rewardedAdAfterMatch.previousTime, e) && v.reset(this.data.rewardedAdAfterMatch)
                }
                ,
                r.ensureRewaredAdBonusData = function() {
                    return null == this.metagameData.rewardedAdBonus ? (console.log("rewardedAdBonus is undefined", c.Metagame, u.Error),
                    !1) : 0 != this.metagameData.rewardedAdBonus.length || (console.log("rewardedAdBonus is empty"),
                    !1)
                }
                ,
                r.replacer = function(e, a) {
                    return a instanceof Map ? {
                        dataType: "Map",
                        value: Array.from(a.entries())
                    } : a
                }
                ,
                r.reviver = function(e, a) {
                    return "object" == typeof a && null !== a && "Map" === a.dataType ? new Map(a.value) : a
                }
                ,
                t(e, [{
                    key: "statistics",
                    get: function() {
                        return this.data.statistics
                    },
                    set: function(e) {
                        this.data.statistics = e
                    }
                }, {
                    key: "missions",
                    get: function() {
                        return this.data.missions
                    }
                }, {
                    key: "victoryTrophies",
                    get: function() {
                        return this.data.victoryTrophies
                    },
                    set: function(e) {
                        var a = this.data.victoryTrophies;
                        this.data.victoryTrophies = e,
                        a != e && f.emit(m.TrophiesChanged, a, e)
                    }
                }, {
                    key: "level",
                    get: function() {
                        return this.data.level
                    },
                    set: function(e) {
                        var a = this.data.level;
                        this.data.level = e,
                        e > a && f.emit(m.LevelUp, a, e),
                        this.data.level = e
                    }
                }, {
                    key: "experience",
                    get: function() {
                        return this.data.experience
                    },
                    set: function(e) {
                        this.data.experience = e
                    }
                }, {
                    key: "weaponLevels",
                    get: function() {
                        return this.data.weaponLevels
                    },
                    set: function(e) {
                        this.data.weaponLevels = e
                    }
                }, {
                    key: "characterModelId",
                    get: function() {
                        return this.data.characterModelId
                    },
                    set: function(e) {
                        this.data.characterModelId = e
                    }
                }, {
                    key: "characterTextureId",
                    get: function() {
                        return this.data.characterTextureId
                    },
                    set: function(e) {
                        this.data.characterTextureId = e
                    }
                }, {
                    key: "lastSelectedArenaIndex",
                    get: function() {
                        return this.data.lastSelectedArenaIndex
                    },
                    set: function(e) {
                        this.data.lastSelectedArenaIndex = e
                    }
                }, {
                    key: "currency",
                    get: function() {
                        return this.data.currency
                    },
                    set: function(e) {
                        var a = this.data.currency;
                        this.data.currency = e,
                        a != e && f.emit(m.CurrencyChanged, a, e)
                    }
                }, {
                    key: "charactersUnlockables",
                    get: function() {
                        return this.metagameData.charactersUnlockables
                    }
                }, {
                    key: "rarityPrices",
                    get: function() {
                        return this.metagameData.rarityPrices
                    }
                }, {
                    key: "levelUpReward",
                    get: function() {
                        return this.metagameData && this.metagameData.levelUpReward && 0 != this.metagameData.levelUpReward.length ? this.metagameData.levelUpReward[0] : -1
                    }
                }]),
                e
            }())
              , W = e("globalPlayer", new x);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CheatKillCharacter.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./CharacterHealthControl.ts"], (function(t) {
    "use strict";
    var e, r, a, n, i, o, c, l, h, s;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            r = t.inheritsLoose,
            a = t.initializerDefineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            i = t.cclegacy,
            o = t._decorator,
            c = t.macro,
            l = t.Component
        }
        , function(t) {
            h = t.EventCharacterAction
        }
        , function(t) {
            s = t.CharacterHealthControl
        }
        ],
        execute: function() {
            var u, p, C, f, y;
            i._RF.push({}, "24a2fMkHZxBWb04vC3VkLDU", "CheatKillCharacter", void 0);
            var v = o.ccclass
              , K = o.property;
            t("CheatKillCharacter", (u = v("CheatKillCharacter"),
            p = K(s),
            u((y = e((f = function(t) {
                function e() {
                    for (var e, r = arguments.length, i = new Array(r), o = 0; o < r; o++)
                        i[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(i)) || this,
                    a(n(e), "characterToKill", y, n(e)),
                    e
                }
                r(e, t);
                var i = e.prototype;
                return i.onEnable = function() {}
                ,
                i.onDisable = function() {}
                ,
                i.onCheatKeyDown = function(t) {
                    t.keyCode == c.KEY.k && null != this.characterToKill && this.characterToKill.node.emit(h.HitReceived, 1e6)
                }
                ,
                e
            }(l)).prototype, "characterToKill", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = f)) || C));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterHealthControl.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var e, a, n, i, h, s, o, l, r, d, c, u, p, v, f;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            a = t.defineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            i = t.cclegacy,
            h = t._decorator,
            s = t.RigidBody,
            o = t.Collider,
            l = t.Component
        }
        , function(t) {
            r = t.logger,
            d = t.LogCategory
        }
        , function(t) {
            c = t.ProjectEventType
        }
        , function(t) {
            u = t.projectEvent
        }
        , function(t) {
            p = t.EventCharacterAction,
            v = t.CharacterState
        }
        , function(t) {
            f = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var g;
            i._RF.push({}, "252b8HV1OhGg45Kj+Ywfs7y", "CharacterHealthControl", void 0);
            var H = h.ccclass;
            h.property,
            t("CharacterHealthControl", H("CharacterHealthControl")(g = function(t) {
                function i() {
                    for (var e, i = arguments.length, h = new Array(i), s = 0; s < i; s++)
                        h[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(h)) || this,
                    a(n(e), "data", void 0),
                    a(n(e), "regenIsOn", !1),
                    e
                }
                e(i, t);
                var h = i.prototype;
                return h.start = function() {
                    this.data = this.node.getComponent(f),
                    this.data.IsTurret || u.emit(c.CharacterSpawn, this.node.parent)
                }
                ,
                h.onEnable = function() {
                    this.node.on(p.HitReceived, this.onHitReceived, this),
                    this.node.on(p.LevelUp, this.onLevelUp, this),
                    this.node.on(p.KilledOther, this.onKilledOther, this),
                    u.on(c.MatchFinish, this.onMatchFinish, this)
                }
                ,
                h.onDisable = function() {
                    this.node.off(p.HitReceived, this.onHitReceived, this),
                    this.node.off(p.LevelUp, this.onLevelUp, this),
                    this.node.off(p.KilledOther, this.onKilledOther, this),
                    u.off(c.MatchFinish, this.onMatchFinish, this)
                }
                ,
                h.update = function(t) {
                    null != this.data && (this.data.state != v.Dying && this.data.state != v.Dead ? 0 == this.data.inCombat && 0 == this.data.inDamageZone && this.data.health < this.data.HealthMax ? (this.sendRegenStartEvent(),
                    this.data.health += this.data.HealthRegenRate * t,
                    this.data.health >= this.data.HealthMax && (this.data.health = this.data.HealthMax,
                    this.sendRegenStopEvent())) : this.regenIsOn && this.sendRegenStopEvent() : this.sendRegenStopEvent())
                }
                ,
                h.onHitReceived = function(t, e) {
                    if (null != this.data) {
                        if (this.data.health -= t,
                        this.data.health <= 0) {
                            var a, n;
                            if (this.data.health = 0,
                            this.node.emit(p.DyingStart),
                            this.node.parent) {
                                var i = this.node.parent.getComponent(s);
                                i && (i.enabled = !1);
                                var h = this.node.parent.getComponent(o);
                                h && (h.enabled = !1),
                                this.scheduleOnce(this.selfDestroyOnDeath, 3)
                            }
                            null != e && e.isValid && e.emit(p.KilledOther),
                            u.emit(c.CharacterDeath, this.node.parent),
                           console.log((null === (a = this.node.parent) || void 0 === a ? void 0 : a.name) + " dead by " + (null == e || null === (n = e.parent) || void 0 === n ? void 0 : n.name), d.Gameplay)
                        }
                        null != e && e.isValid && e.emit(p.DealtDamage, t),
                        this.data.IsPlayer && u.emit(c.PlayerHitReceived),
                        this.sendRegenStopEvent()
                    }
                }
                ,
                h.onLevelUp = function(t) {
                    if (null != this.data) {
                        var e = this.data.initialHealthMax + t * (this.data.HealthLevelMultiplier * this.data.initialHealthMax)
                          , a = e - this.data.HealthMax;
                       console.log("Init health: " + this.data.initialHealthMax + " Old health: " + this.data.HealthMax + " New health: " + e + " Increase: " + a + " Level: " + t, d.Gameplay),
                        this.data.HealthMax = e,
                        this.data.health += a
                    }
                }
                ,
                h.onKilledOther = function() {
                    this.data && this.data.IsPlayer && u.emit(c.PlayerKill)
                }
                ,
                h.onMatchFinish = function() {
                    this.sendRegenStopEvent()
                }
                ,
                h.sendRegenStopEvent = function() {
                    1 == this.regenIsOn && (this.node.emit(p.HealthRegenStop),
                    this.regenIsOn = !1)
                }
                ,
                h.sendRegenStartEvent = function() {
                    0 == this.regenIsOn && (this.node.emit(p.HealthRegenStart),
                    this.regenIsOn = !0)
                }
                ,
                h.selfDestroyOnDeath = function() {
                    var t;
                    null === (t = this.node.parent) || void 0 === t || t.destroy()
                }
                ,
                i
            }(l)) || g);
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIChasingState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./Pathfinding.ts", "./AIState.ts", "./AIEnums.ts"], (function(t) {
    "use strict";
    var i, a, n, e, r, s, o, h, g, d, c, l, u;
    return {
        setters: [function(t) {
            i = t.inheritsLoose,
            a = t.defineProperty,
            n = t.assertThisInitialized,
            e = t.createClass
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator,
            o = t.Vec2
        }
        , function(t) {
            h = t.logger,
            g = t.LogCategory,
            d = t.LogType
        }
        , function(t) {
            c = t.Pathfinding
        }
        , function(t) {
            l = t.AIState
        }
        , function(t) {
            u = t.AIStateList
        }
        ],
        execute: function() {
            var p;
            r._RF.push({}, "253bdrvLd9JzpJ6IJSc08qJ", "AIChasingState", void 0);
            var f = s.ccclass;
            s.property,
            t("AIChasingState", f("AIChasingState")(p = function(t) {
                function r() {
                    for (var i, e = arguments.length, r = new Array(e), s = 0; s < e; s++)
                        r[s] = arguments[s];
                    return i = t.call.apply(t, [this].concat(r)) || this,
                    a(n(i), "pathingUpdateCounter", void 0),
                    i
                }
                i(r, t);
                var s = r.prototype;
                return s.stateEnter = function() {
                    t.prototype.stateEnter.call(this),
                    this.updateChasingPath()
                }
                ,
                s.stateExit = function() {
                    t.prototype.stateExit.call(this)
                }
                ,
                s.stateUpdate = function(i) {
                    t.prototype.stateUpdate.call(this, i);
                    var a = this.aiBlackboard.chaseTarget;
                    if (a != this.aiBlackboard.visionTarget && (
                        // console.log(this.node.name + " - Vision target is different than the chase target. Checking...", g.AI),
                    this.brain.isTargetValid(this.aiBlackboard.visionTarget) ? (this.aiBlackboard.chaseTarget = this.aiBlackboard.visionTarget,
                    // console.log(this.node.name + " - Vision target is valid changing chase target.", g.AI),
                    this.updateChasingPath()) : console.log(this.node.name + " - Vision target is not valid", g.AI)),
                    !this.brain.isTargetValid(a))
                        return 
                        // console.log(this.node.name + " - Invalid chase target " + a + ", reverting to wander", g.AI),
                        this.aiBlackboard.chaseTarget = null,
                        this.brain.setDirection(0, 0),
                        void this.brain.changeState(u.Idle);
                    var n = this.characterBlackboard.target;
                    if (this.brain.isCurrentTargetValid() && n == a && this.brain.isTargetInShootingRange(n))
                        return this.brain.setDirection(0, 0),
                        void this.brain.changeState(u.Attacking);
                    if (this.pathingUpdateCounter--,
                    this.brain.reachedPathingDestination() || this.pathingUpdateCounter <= 0)
                        this.updateChasingPath();
                    else {
                        var e = this.brain.getPathingDirection();
                        this.brain.setDirection(e.x, e.y)
                    }
                }
                ,
                s.updateChasingPath = function() {
                    if (c.instance) {
                        var t = this.aiBlackboard.chaseTarget;
                        if(t){
                        var i = [t.worldPosition.x, t.worldPosition.z];
                        if (c.instance.isPointInsideOfShrinkingArea(i[0], i[1]) && !this.brain.data.chasingData.shouldChaseIntoShrinkingArea)
                            return console.log("Target is inside of shrinking area and I shouldn't chase it.", g.AI),
                            void this.brain.changeState(u.Wandering);
                        var a = c.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, i[0], i[1]);
                        if (0 == a.length) {
                            // console.log(this.node.name + " - Could not find path to chasing target, trying to find a neighbour", g.AI, d.Warning);
                            var n = c.instance.getValidRandomNeighbour(i[0], i[1], 2);
                            n ? a = c.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, n[0], n[1]) : console.log(this.node.name + " - Could not find any valid random neighbour", g.AI, d.Warning)
                        }
                        this.brain.setActivePath(new o(i[0],i[1]), a),
                        this.pathingUpdateCounter = this.brain.data.chasingData.pathingUpdateInterval
                        }
                    }
                }
                ,
                e(r, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return this.brain.data.chasingData.minimumTimeInState
                    }
                }]),
                r
            }(l)) || p);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TrophyRewardWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var n, e, i, r, o, a, s, c, u, h, l, p, d, f;
    return {
        setters: [function(t) {
            n = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            i = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            o = t.defineProperty,
            a = t.createClass,
            s = t.asyncToGenerator
        }
        , function(t) {
            c = t.cclegacy,
            u = t._decorator,
            h = t.UIOpacity,
            l = t.Animation,
            p = t.Component
        }
        , function(t) {
            d = t.ProjectEventType
        }
        , function(t) {
            f = t.projectEvent
        }
        ],
        execute: function() {
            var y, w, v, g, m, b, F;
            c._RF.push({}, "25ab0tw2JdFlb0IWqpMECHd", "TrophyRewardWidget", void 0);
            var R = u.ccclass
              , T = u.property;
            t("TrophyRewardWidget", (y = R("TrophyRewardWidget"),
            w = T(h),
            v = T(l),
            y((b = n((m = function(t) {
                function n() {
                    for (var n, e = arguments.length, a = new Array(e), s = 0; s < e; s++)
                        a[s] = arguments[s];
                    return n = t.call.apply(t, [this].concat(a)) || this,
                    i(r(n), "content", b, r(n)),
                    i(r(n), "animation", F, r(n)),
                    o(r(n), "_shouldShowUp", !1),
                    n
                }
                e(n, t);
                var c = n.prototype;
                return c.onLoad = function() {
                    f.on(d.MatchFinish, this.onMatchFinish, this)
                }
                ,
                c.onDestroy = function() {
                    f.off(d.MatchFinish, this.onMatchFinish, this)
                }
                ,
                c.start = function() {
                    this.content.opacity = 0
                }
                ,
                c.onMatchFinish = function(t) {
                    t <= 1 && (this._shouldShowUp = !0)
                }
                ,
                c.show = function() {
                    var t = s(regeneratorRuntime.mark((function t() {
                        var n;
                        return regeneratorRuntime.wrap((function(t) {
                            for (; ; )
                                switch (t.prev = t.next) {
                                case 0:
                                    if (!this.shouldShowUp) {
                                        t.next = 6;
                                        break
                                    }
                                    return this.animation.play(),
                                    n = 0,
                                    this.duration && (n = this.duration),
                                    t.next = 6,
                                    this.delay(n);
                                case 6:
                                case "end":
                                    return t.stop()
                                }
                        }
                        ), t, this)
                    }
                    )));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                c.delay = function(t) {
                    return new Promise((function(n) {
                        return setTimeout(n, 1e3 * t)
                    }
                    ))
                }
                ,
                a(n, [{
                    key: "shouldShowUp",
                    get: function() {
                        return this._shouldShowUp
                    }
                }, {
                    key: "duration",
                    get: function() {
                        var t;
                        return null === (t = this.animation.defaultClip) || void 0 === t ? void 0 : t.duration
                    }
                }]),
                n
            }(p)).prototype, "content", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            F = n(m.prototype, "animation", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            g = m)) || g));
            c._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestRuntimePlatform.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, o, n, r, s, i;
    return {
        setters: [function(e) {
            t = e.inheritsLoose
        }
        , function(e) {
            o = e.cclegacy,
            n = e._decorator,
            r = e.sys,
            s = e.Component
        }
        , function(e) {
            i = e.logger
        }
        ],
        execute: function() {
            var u;
            o._RF.push({}, "2614eZDSD5KPoDV6lybLD8e", "TestRuntimePlatform", void 0);
            var l = n.ccclass;
            n.property,
            e("TestRuntimePlatform", l("TestRuntimePlatform")(u = function(e) {
                function o() {
                    return e.apply(this, arguments) || this
                }
                return t(o, e),
                o.prototype.start = function() {
                    console.log("Environment info - OS: " + r.os + " isMobile: " + r.isMobile + " isBrowser: " + r.isBrowser + " browser: " + r.browserType + " language: " + r.language),
                    console.log("Raw environment info: " + JSON.stringify(r, null, 2)),
                    console.log(r)
                }
                ,
                o
            }(s)) || u);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestExecutionOrderChild.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(t) {
    "use strict";
    var e, r, o, n, i;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            r = t.cclegacy,
            o = t._decorator,
            n = t.Component
        }
        , function(t) {
            i = t.logger
        }
        ],
        execute: function() {
            var c;
            r._RF.push({}, "26f1aGyw1ZGP6Tkf4gMWRxt", "TestExecutionOrderChild", void 0);
            var s = o.ccclass;
            o.property,
            t("TestExecutionOrderChild", s("TestExecutionOrderChild")(c = function(t) {
                function r() {
                    return t.apply(this, arguments) || this
                }
                return e(r, t),
                r.prototype.start = function() {
                    var t;
                    console.log("Order: Child of " + (null === (t = this.node.parent) || void 0 === t ? void 0 : t.name))
                }
                ,
                r
            }(n)) || c);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotIdleData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./BotStateData.ts"], (function(e) {
    "use strict";
    var t, i, r, a, n, o, l;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            r = e.initializerDefineProperty,
            a = e.assertThisInitialized
        }
        , function(e) {
            n = e.cclegacy,
            o = e._decorator
        }
        , function(e) {
            l = e.BotStateData
        }
        ],
        execute: function() {
            var c, u, s, p, f;
            n._RF.push({}, "276083S8n9KK4p7S3UVQs5v", "BotIdleData", void 0);
            var y = o.ccclass
              , d = o.property;
            e("BotIdleData", y("BotIdleData")((s = t((u = function(e) {
                function t() {
                    for (var t, i = arguments.length, n = new Array(i), o = 0; o < i; o++)
                        n[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(n)) || this,
                    r(a(t), "idleDelayMin", s, a(t)),
                    r(a(t), "idleDelayMax", p, a(t)),
                    r(a(t), "lootingPercentage", f, a(t)),
                    t
                }
                return i(t, e),
                t
            }(l)).prototype, "idleDelayMin", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .25
                }
            }),
            p = t(u.prototype, "idleDelayMax", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 2.5
                }
            }),
            f = t(u.prototype, "lootingPercentage", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            c = u)) || c);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestExecutionOrderDefault.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, r, o, n, u;
    return {
        setters: [function(e) {
            t = e.inheritsLoose
        }
        , function(e) {
            r = e.cclegacy,
            o = e._decorator,
            n = e.Component
        }
        , function(e) {
            u = e.logger
        }
        ],
        execute: function() {
            var c;
            r._RF.push({}, "2bfe3eeJmpCCJK41XdYer3J", "TestExecutionOrderDefault", void 0);
            var s = o.ccclass;
            o.property,
            e("TestExecutionOrderDefault", s("TestExecutionOrderDefault")(c = function(e) {
                function r() {
                    return e.apply(this, arguments) || this
                }
                return t(r, e),
                r.prototype.start = function() {
                    console.log("Order: 0")
                }
                ,
                r
            }(n)) || c);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/EnemySpawner.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./BotData.ts"], (function(e) {
    "use strict";
    var t, n, i, r, o, a, l, s, f, p, u, c, h, d, v, y, g, m, P;
    return {
        setters: [function(e) {
            t = e.defineProperty,
            n = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            r = e.initializerDefineProperty,
            o = e.assertThisInitialized,
            a = e.createForOfIteratorHelperLoose
        }
        , function(e) {
            l = e.cclegacy,
            s = e._decorator,
            f = e.Prefab,
            p = e.director,
            u = e.instantiate,
            c = e.Component
        }
        , function(e) {
            h = e.logger,
            d = e.LogCategory,
            v = e.LogType
        }
        , function(e) {
            y = e.ProjectEventType
        }
        , function(e) {
            g = e.projectEvent
        }
        , function(e) {
            m = e.globalPlayer
        }
        , function(e) {
            P = e.BotData
        }
        ],
        execute: function() {
            var w, b, E, S, R, L, A, M, D, I, z;
            l._RF.push({}, "2cba4YK5ntCCJizPstyW550", "EnemySpawner", void 0);
            var C = s.ccclass
              , _ = s.property
              , j = s.executionOrder;
            e("EnemySpawner", (w = C("EnemySpawner"),
            b = j(0),
            E = _({
                type: [f],
                tooltip: "AI Profile Tiers"
            }),
            S = _({
                type: f,
                tooltip: "Enemy prefab"
            }),
            w(R = b((z = I = function(e) {
                function n() {
                    for (var n, i = arguments.length, a = new Array(i), l = 0; l < i; l++)
                        a[l] = arguments[l];
                    return n = e.call.apply(e, [this].concat(a)) || this,
                    r(o(n), "aiProfiles", A, o(n)),
                    r(o(n), "prefab", M, o(n)),
                    r(o(n), "quantity", D, o(n)),
                    t(o(n), "spawns", void 0),
                    t(o(n), "ready", !1),
                    t(o(n), "validProfiles", []),
                    n
                }
                i(n, e);
                var l = n.prototype;
                return l.onLoad = function() {
                    null == n.instance ? n.instance = this : this.enabled = !1
                }
                ,
                l.onEnable = function() {
                    g.on(y.MapSetup, this.setup, this)
                }
                ,
                l.onDisable = function() {
                    g.off(y.MapSetup, this.setup, this)
                }
                ,
                l.onDestroy = function() {
                    n.instance == this && (n.instance = null)
                }
                ,
                l.setup = function(e) {
                    var t = this;
                    if (this.spawns = new Array,
                    e.layers.forEach((function(e) {
                        if ("Spawns" == e.name)
                            for (var n = 0; n < e.data.length; n++) {
                                var i = e.data[n]
                                  , r = Number(i);
                                if (NaN != r && -1 != r && 5 == r) {
                                    var o = n % e.width
                                      , a = Math.floor(n / e.width);
                                    t.spawns.push([o, a])
                                }
                            }
                    }
                    )),
                    this.aiProfiles && 0 != this.aiProfiles.length) {
                        for (var n, i = a(this.aiProfiles); !(n = i()).done; ) {
                            var r = n.value
                              , o = r.data.getComponent(P);
                            o && m.level >= o.minLevel && m.level < o.maxLevel && (this.validProfiles.push(r),
                            console.log("Adding profile " + r.data.name + " to list of valid profiles [" + o.minLevel + "-" + o.maxLevel + "] - Player lvl " + m.level, d.AI))
                        }
                        0 == this.validProfiles.length && (console.log("No vallid profiles found for player level: " + m.level, d.AI, v.Warning),
                        this.validProfiles.push(this.aiProfiles[0])),
                        0 != this.spawns.length ? (this.shuffle(this.spawns),
                        this.ready = !0) : console.log("ERROR: Some error occurred while trying to get enemy spawns points")
                    } else
                        console.log("No AI profiles configured to enemy spawner.", d.AI, v.Error)
                }
                ,
                l.start = function() {
                    if (this.ready)
                        for (var e = p.getScene(), t = 0; t < this.quantity; t++) {
                            var n = this.getRandomSpawn();
                            if (n) {
                                var i = u(this.prefab);
                                i.setParent(e),
                                i.setPosition(n[0], 0, n[1]),
                                i.name += "_" + t.toFixed(),
                                console.log("Spawning enemy at " + n)
                            } else
                                console.log("Received invalid position")
                        }
                    else
                        console.log("ERROR enemy spawner didn't setup.")
                }
                ,
                l.getRandomAiProfile = function() {
                    return this.validProfiles[Math.floor(Math.random() * this.validProfiles.length)]
                }
                ,
                l.getRandomSpawn = function() {
                    if (this.spawns.length > 0) {
                        var e = this.spawns.pop();
                        return null != e ? e : null
                    }
                    return null
                }
                ,
                l.shuffle = function(e) {
                    for (var t, n, i = e.length; 0 !== i; )
                        n = Math.floor(Math.random() * i),
                        t = e[i -= 1],
                        e[i] = e[n],
                        e[n] = t;
                    return e
                }
                ,
                n
            }(c),
            t(I, "instance", void 0),
            A = n((L = z).prototype, "aiProfiles", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            M = n(L.prototype, "prefab", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            D = n(L.prototype, "quantity", [_], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 9
                }
            }),
            R = L)) || R) || R));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterBlackboard.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./CharacterEnums.ts", "./Weapon.ts"], (function(e) {
    "use strict";
    var t, n, i, a, r, o, l, u, s, c, h, g, f, p, m;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            i = e.initializerDefineProperty,
            a = e.assertThisInitialized,
            r = e.defineProperty,
            o = e.createClass
        }
        , function(e) {
            l = e.cclegacy,
            u = e._decorator,
            s = e.Node,
            c = e.Component
        }
        , function(e) {
            h = e.logger,
            g = e.LogCategory
        }
        , function(e) {
            f = e.WeaponType
        }
        , function(e) {
            p = e.CharacterState
        }
        , function(e) {
            m = e.Weapon
        }
        ],
        execute: function() {
            var _, b, y, k, d, v, M, C, w, x, D, P, W, I, R, z, L, B, S, A, H, N, T, j, O;
            l._RF.push({}, "2d381WhLt9AVqt1KzQBwIZK", "CharacterBlackboard", void 0);
            var U = u.ccclass
              , Z = u.property
              , E = u.executionOrder;
            e("CharacterBlackboard", (_ = U("CharacterBlackboard"),
            b = E(10),
            y = Z(s),
            k = Z({
                min: 10
            }),
            d = Z({
                min: 1
            }),
            v = Z({
                min: 0,
                step: .05,
                range: [0, 1],
                slide: !0
            }),
            M = Z({
                min: .1
            }),
            C = Z({
                min: 0
            }),
            w = Z({
                min: .2
            }),
            x = Z({
                min: .2
            }),
            D = Z({
                min: 0,
                step: .05,
                range: [0, 1],
                slide: !0
            }),
            _(P = b((I = t((W = function(e) {
                function t() {
                    for (var t, n = arguments.length, o = new Array(n), l = 0; l < n; l++)
                        o[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    i(a(t), "isPlayer", I, a(t)),
                    i(a(t), "isTurret", R, a(t)),
                    i(a(t), "uiPivot", z, a(t)),
                    i(a(t), "healthMax", L, a(t)),
                    i(a(t), "healthRegenRate", B, a(t)),
                    i(a(t), "healthLevelMultiplier", S, a(t)),
                    i(a(t), "speed", A, a(t)),
                    i(a(t), "exitCombatCooldown", H, a(t)),
                    i(a(t), "areaDamage", N, a(t)),
                    i(a(t), "areaDamageInterval", T, a(t)),
                    i(a(t), "damageLevelMultiplier", j, a(t)),
                    i(a(t), "canShootWhilePickingUp", O, a(t)),
                    r(a(t), "_charName", "Test"),
                    r(a(t), "_health", 100),
                    r(a(t), "_initialHealthMax", 100),
                    r(a(t), "_ammo", 3),
                    r(a(t), "_ammoMax", 3),
                    r(a(t), "_target", void 0),
                    r(a(t), "_targetBlackboard", void 0),
                    r(a(t), "_state", p.Idle),
                    r(a(t), "_lastState", p.Idle),
                    r(a(t), "_inCombat", !1),
                    r(a(t), "_currentWeapon", f.Basic),
                    r(a(t), "_currentWeaponObject", void 0),
                    r(a(t), "_isReloading", !1),
                    r(a(t), "_level", 1),
                    r(a(t), "_skAnimation", void 0),
                    r(a(t), "_weapons", []),
                    r(a(t), "_isMoving", !1),
                    r(a(t), "_inDamageZone", !1),
                    t
                }
                return n(t, e),
                t.prototype.start = function() {
                    console.log("CharacterBlackboard start", g.AI),
                    this._health = Number(this.healthMax),
                    this._initialHealthMax = Number(this.healthMax)
                }
                ,
                o(t, [{
                    key: "CanShootWhilePickingUp",
                    get: function() {
                        return this.canShootWhilePickingUp
                    }
                }, {
                    key: "IsTurret",
                    get: function() {
                        return this.isTurret
                    }
                }, {
                    key: "weapons",
                    get: function() {
                        return 0 != this._weapons.length && null != this._weapons[0] || (this._weapons = this.node.getComponentsInChildren(m)),
                        this._weapons
                    },
                    set: function(e) {
                        this._weapons = e
                    }
                }, {
                    key: "skAnimation",
                    get: function() {
                        return this._skAnimation
                    },
                    set: function(e) {
                        this._skAnimation = e
                    }
                }, {
                    key: "IsPlayer",
                    get: function() {
                        return this.isPlayer
                    },
                    set: function(e) {
                        this.isPlayer = e
                    }
                }, {
                    key: "UIPivot",
                    get: function() {
                        return this.uiPivot
                    }
                }, {
                    key: "charName",
                    get: function() {
                        return this._charName
                    },
                    set: function(e) {
                        this._charName = e
                    }
                }, {
                    key: "health",
                    get: function() {
                        return this._health
                    },
                    set: function(e) {
                        this._health = e
                    }
                }, {
                    key: "HealthMax",
                    get: function() {
                        return this.healthMax
                    },
                    set: function(e) {
                        this.healthMax = e
                    }
                }, {
                    key: "healthPercentage",
                    get: function() {
                        return this._health / this.healthMax
                    }
                }, {
                    key: "HealthRegenRate",
                    get: function() {
                        return this.healthRegenRate
                    },
                    set: function(e) {
                        this.healthRegenRate = e
                    }
                }, {
                    key: "HealthLevelMultiplier",
                    get: function() {
                        return this.healthLevelMultiplier
                    },
                    set: function(e) {
                        this.healthLevelMultiplier = e
                    }
                }, {
                    key: "initialHealthMax",
                    get: function() {
                        return this._initialHealthMax
                    }
                }, {
                    key: "ammo",
                    get: function() {
                        return this._ammo
                    },
                    set: function(e) {
                        this._ammo = e
                    }
                }, {
                    key: "ammoMax",
                    get: function() {
                        return this._ammoMax
                    },
                    set: function(e) {
                        this._ammoMax = e
                    }
                }, {
                    key: "target",
                    get: function() {
                        return this._target
                    },
                    set: function(e) {
                        this._target = e,
                        null != e && e.isValid ? this._targetBlackboard = e.getComponentInChildren(t) : this._targetBlackboard = null
                    }
                }, {
                    key: "targetBlackboard",
                    get: function() {
                        return this._targetBlackboard
                    }
                }, {
                    key: "state",
                    get: function() {
                        return this._state
                    },
                    set: function(e) {
                        this._state = e
                    }
                }, {
                    key: "lastState",
                    get: function() {
                        return this._lastState
                    },
                    set: function(e) {
                        this._lastState = e
                    }
                }, {
                    key: "inCombat",
                    get: function() {
                        return this._inCombat
                    },
                    set: function(e) {
                        this._inCombat = e
                    }
                }, {
                    key: "inDamageZone",
                    get: function() {
                        return this._inDamageZone
                    },
                    set: function(e) {
                        this._inDamageZone = e
                    }
                }, {
                    key: "currentWeapon",
                    get: function() {
                        return this._currentWeapon
                    },
                    set: function(e) {
                        this._currentWeapon = e
                    }
                }, {
                    key: "currentWeaponObject",
                    get: function() {
                        return this._currentWeaponObject
                    },
                    set: function(e) {
                        this._currentWeaponObject = e
                    }
                }, {
                    key: "Speed",
                    get: function() {
                        return this.speed
                    },
                    set: function(e) {
                        this.speed = e
                    }
                }, {
                    key: "ExitCombatCooldown",
                    get: function() {
                        return this.exitCombatCooldown
                    },
                    set: function(e) {
                        this.exitCombatCooldown = e
                    }
                }, {
                    key: "AreaDamage",
                    get: function() {
                        return this.areaDamage
                    },
                    set: function(e) {
                        this.areaDamage = e
                    }
                }, {
                    key: "AreaDamageInterval",
                    get: function() {
                        return this.areaDamageInterval
                    },
                    set: function(e) {
                        this.areaDamageInterval = e
                    }
                }, {
                    key: "IsAlive",
                    get: function() {
                        return this.state != p.Dying && this.state != p.Dead
                    }
                }, {
                    key: "isReloading",
                    get: function() {
                        return this._isReloading
                    },
                    set: function(e) {
                        this._isReloading = e
                    }
                }, {
                    key: "level",
                    get: function() {
                        return this._level
                    },
                    set: function(e) {
                        this._level = e
                    }
                }, {
                    key: "DamageLevelMultiplier",
                    get: function() {
                        return this.damageLevelMultiplier
                    },
                    set: function(e) {
                        this.damageLevelMultiplier = e
                    }
                }, {
                    key: "isMoving",
                    get: function() {
                        return this._isMoving
                    },
                    set: function(e) {
                        this._isMoving = e
                    }
                }]),
                t
            }(c)).prototype, "isPlayer", [Z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            R = t(W.prototype, "isTurret", [Z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            z = t(W.prototype, "uiPivot", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = t(W.prototype, "healthMax", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 100
                }
            }),
            B = t(W.prototype, "healthRegenRate", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 10
                }
            }),
            S = t(W.prototype, "healthLevelMultiplier", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .1
                }
            }),
            A = t(W.prototype, "speed", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            H = t(W.prototype, "exitCombatCooldown", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 5
                }
            }),
            N = t(W.prototype, "areaDamage", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 10
                }
            }),
            T = t(W.prototype, "areaDamageInterval", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 2
                }
            }),
            j = t(W.prototype, "damageLevelMultiplier", [D], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .1
                }
            }),
            O = t(W.prototype, "canShootWhilePickingUp", [Z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            P = W)) || P) || P));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestUIToasts.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(e) {
    "use strict";
    var t, n, o, r, s, c, i;
    return {
        setters: [function(e) {
            t = e.inheritsLoose
        }
        , function(e) {
            n = e.cclegacy,
            o = e._decorator,
            r = e.Component
        }
        , function(e) {
            s = e.logger
        }
        , function(e) {
            c = e.ProjectEventType
        }
        , function(e) {
            i = e.projectEvent
        }
        ],
        execute: function() {
            var a;
            n._RF.push({}, "2dbc4CUAzVC14kqFrjqp+qj", "TestUIToasts", void 0);
            var l = o.ccclass;
            o.property,
            e("TestUIToasts", l("TestUIToasts")(a = function(e) {
                function n() {
                    return e.apply(this, arguments) || this
                }
                t(n, e);
                var o = n.prototype;
                return o.levelUp = function() {
                    i.emit(c.PlayerLevelUp)
                }
                ,
                o.playerKill = function() {
                    i.emit(c.PlayerKill)
                }
                ,
                o.changeWeaponTo = function(e, t) {
                    var n = Number(t);
                    1 == isNaN(n) && console.log("ERROR: Received wrong value for level index: " + t),
                    i.emit(c.PlayerWeaponChange, n)
                }
                ,
                n
            }(r)) || a);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Panel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectEvent.ts", "./PanelManager.ts", "./PanelEnums.ts"], (function(t) {
    "use strict";
    var i, e, n, o, a, l, r, s, c, p, u, h, d, y, m, f, v, O, b;
    return {
        setters: [function(t) {
            i = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            n = t.initializerDefineProperty,
            o = t.assertThisInitialized,
            a = t.defineProperty,
            l = t.createClass
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator,
            c = t.Enum,
            p = t.Animation,
            u = t.Node,
            h = t.AnimationClip,
            d = t.CCBoolean,
            y = t.UIOpacity,
            m = t.Component
        }
        , function(t) {
            f = t.projectEvent
        }
        , function(t) {
            v = t.PanelManager
        }
        , function(t) {
            O = t.PanelId,
            b = t.EventPanel
        }
        ],
        execute: function() {
            var g, C, P, z, w, S, E, F, A, _, k, D, I, L, j, M;
            r._RF.push({}, "2e50aA9tv1ElLX6TaHJkvJg", "Panel", void 0);
            var x = s.ccclass
              , B = s.property
              , H = s.executionOrder;
            t("Panel", (g = x("Panel"),
            C = H(-4),
            P = B({
                type: c(O)
            }),
            z = B(p),
            w = B({
                type: u,
                tooltip: "Used to disable the panel content so no input is processed when closed"
            }),
            S = B({
                type: h,
                formerlySerializedAs: "clip"
            }),
            E = B(h),
            F = B(d),
            g(A = C((k = i((_ = function(t) {
                function i() {
                    for (var i, e = arguments.length, l = new Array(e), r = 0; r < e; r++)
                        l[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(l)) || this,
                    n(o(i), "id", k, o(i)),
                    n(o(i), "anim", D, o(i)),
                    n(o(i), "content", I, o(i)),
                    n(o(i), "clipOpen", L, o(i)),
                    n(o(i), "clipClose", j, o(i)),
                    n(o(i), "startOpen", M, o(i)),
                    a(o(i), "uiOpacity", void 0),
                    i
                }
                e(i, t);
                var r = i.prototype;
                return r.onLoad = function() {
                    var t;
                    null === (t = v.instance) || void 0 === t || t.register(this),
                    this.uiOpacity = this.node.getComponent(y),
                    null == this.content && this.node.children.length > 0 && (this.content = this.node.children[0])
                }
                ,
                r.start = function() {
                    this.startOpen ? this.open() : (this.uiOpacity && (this.uiOpacity.opacity = 0),
                    this.content && (this.content.active = !1))
                }
                ,
                r.open = function(view_id) {
                    console.log("==打开界面==view_id==");
                    //xz 
                    if(view_id == 6){
                        CoinApp.showBanner();
                    }

                    var t, i, e = this;
                    this.uiOpacity && (this.uiOpacity.opacity = 255),
                    this.content && (this.content.active = !0);
                    var n = null === (t = this.anim) || void 0 === t ? void 0 : t.getState(this.clipOpen.name);
                    n && (n.speed = 1),
                    null === (i = this.anim) || void 0 === i || i.play(this.clipOpen.name),
                    this.node.emit(b.OpenStart),
                    f.emit(b.OpenStart, this.id, this.clipOpen.duration),
                    this.scheduleOnce((function() {
                        e.node.emit(b.OpenFinish),
                        f.emit(b.OpenFinish, e.id)
                    }
                    ), this.clipOpen.duration)
                }
                ,
                r.close = function(view_id) {
                    console.log("==关闭界面==view_id==");
                    if(view_id == 6 || ( view_id.currentTarget &&  view_id.currentTarget.name == "CloseButton")){
                        CoinApp.hideBanner();
                    }
                    
                    var t = this
                      , i = 0;
                    if (null == this.clipClose) {
                        var e, n, o = null === (e = this.anim) || void 0 === e ? void 0 : e.getState(this.clipOpen.name);
                        o && (o.speed = -1),
                        null === (n = this.anim) || void 0 === n || n.play(this.clipOpen.name),
                        i = this.clipOpen.duration
                    } else {
                        var a;
                        null === (a = this.anim) || void 0 === a || a.play(this.clipClose.name),
                        i = this.clipClose.duration
                    }
                    this.node.emit(b.CloseStart),
                    f.emit(b.CloseStart, this.id, i),
                    this.scheduleOnce((function() {
                        t.node.emit(b.CloseFinish),
                        f.emit(b.CloseFinish, t.id),
                        t.uiOpacity && (t.uiOpacity.opacity = 0),
                        t.content && (t.content.active = !1)
                    }
                    ), i)
                }
                ,
                l(i, [{
                    key: "Id",
                    get: function() {
                        return this.id
                    }
                }, {
                    key: "DurationOpen",
                    get: function() {
                        return this.clipOpen.duration
                    }
                }]),
                i
            }(m)).prototype, "id", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return O.None
                }
            }),
            D = i(_.prototype, "anim", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = i(_.prototype, "content", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = i(_.prototype, "clipOpen", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            j = i(_.prototype, "clipClose", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = i(_.prototype, "startOpen", [F], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            A = _)) || A) || A));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/LogCategoryToggle.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, o, r, g, i, n, a, l, c, s, u, y;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            o = e.inheritsLoose,
            r = e.initializerDefineProperty,
            g = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            n = e.cclegacy,
            a = e._decorator,
            l = e.Toggle,
            c = e.Label,
            s = e.Component
        }
        , function(e) {
            u = e.LogCategory,
            y = e.logger
        }
        ],
        execute: function() {
            var p, h, C, f, L, d, b;
            n._RF.push({}, "2e84asO9C1BM4hjnBUrCoWD", "LogCategoryToggle", void 0);
            var v = a.ccclass
              , m = a.property;
            e("LogCategoryToggle", (p = v("LogCategoryToggle"),
            h = m(l),
            C = m(c),
            p((d = t((L = function(e) {
                function t() {
                    for (var t, o = arguments.length, n = new Array(o), a = 0; a < o; a++)
                        n[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(n)) || this,
                    r(g(t), "tgl", d, g(t)),
                    r(g(t), "lCategoryName", b, g(t)),
                    i(g(t), "category", void 0),
                    t
                }
                o(t, e);
                var n = t.prototype;
                return n.setup = function(e) {
                    this.category = e,
                    this.lCategoryName.string = u[e],
                    this.tgl.isChecked = y.getCategoryLogging(e)
                }
                ,
                n.onToggle = function(e, t) {
                    y.setCategoryLogging(this.category, !this.tgl.isChecked)
                }
                ,
                t
            }(s)).prototype, "tgl", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = t(L.prototype, "lCategoryName", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            f = L)) || f));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Mission.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./WeaponEnums.ts"], (function(e) {
    "use strict";
    var i, s, t;
    return {
        setters: [function(e) {
            i = e.defineProperty
        }
        , function(e) {
            s = e.cclegacy
        }
        , function(e) {
            t = e.WeaponType
        }
        ],
        execute: function() {
            var n;
            e("MissionCategory", void 0),
            s._RF.push({}, "2fcfcFxEE1CmZIo+s+vtjfw", "Mission", void 0),
            function(e) {
                e[e.Easy = 0] = "Easy",
                e[e.Medium = 1] = "Medium",
                e[e.Hard = 2] = "Hard",
                e[e.FirstWinOfTheDay = 3] = "FirstWinOfTheDay"
            }(n || (n = e("MissionCategory", {})));
            e("Mission", function() {
                function e(e, s, t) {
                    i(this, "difficulty", void 0),
                    i(this, "weaponType", void 0),
                    i(this, "target", void 0),
                    i(this, "progress", void 0),
                    i(this, "redeemed", void 0),
                    this.difficulty = e,
                    this.weaponType = s,
                    this.target = t,
                    this.progress = 0,
                    this.redeemed = !1
                }
                return e.isMissionRedeemable = function(e) {
                    return !e.redeemed && e.progress >= e.target
                }
                ,
                e.logMission = function(e) {
                    return Object.keys(n)[e.difficulty] + " Mission: " + Object.keys(t)[e.weaponType] + " " + e.progress + "/" + e.target
                }
                ,
                e
            }());
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TurretWeapon.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./CharacterEnums.ts", "./CharacterShoot.ts"], (function(t) {
    "use strict";
    var o, e, n, r, i, a, s, u, h, c, l, p, f, d;
    return {
        setters: [function(t) {
            o = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            n = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            i = t.defineProperty
        }
        , function(t) {
            a = t.cclegacy,
            s = t._decorator,
            u = t.Enum,
            h = t.Component
        }
        , function(t) {
            c = t.logger
        }
        , function(t) {
            l = t.WeaponType,
            p = t.WeaponRarity
        }
        , function(t) {
            f = t.EventCharacterAction
        }
        , function(t) {
            d = t.CharacterShoot
        }
        ],
        execute: function() {
            var y, m, g, b, C, R, W, T, v, S;
            a._RF.push({}, "33edeUzUmJICJE0nqInO9YG", "TurretWeapon", void 0);
            var w = s.ccclass
              , z = s.property
              , E = s.executionOrder;
            t("TurretWeapon", (y = w("TurretWeapon"),
            m = E(20),
            g = z({
                type: u(l)
            }),
            b = z({
                range: [0, 4],
                slide: !0
            }),
            y(C = m((W = o((R = function(t) {
                function o() {
                    for (var o, e = arguments.length, a = new Array(e), s = 0; s < e; s++)
                        a[s] = arguments[s];
                    return o = t.call.apply(t, [this].concat(a)) || this,
                    n(r(o), "useRandomWeapon", W, r(o)),
                    n(r(o), "useThisWeapon", T, r(o)),
                    n(r(o), "useRandomRarity", v, r(o)),
                    n(r(o), "useThisRarity", S, r(o)),
                    i(r(o), "shootControl", null),
                    o
                }
                e(o, t);
                var a = o.prototype;
                return a.onLoad = function() {
                    this.shootControl = this.node.getComponentInChildren(d)
                }
                ,
                a.onEnable = function() {
                    this.shootControl.node.on(f.Shoot, this.onShoot, this)
                }
                ,
                a.onDisable = function() {
                    this.shootControl.node.off(f.Shoot, this.onShoot, this)
                }
                ,
                a.start = function() {
                    if (this.shootControl) {
                        var t = this.useThisWeapon
                          , o = this.useThisRarity;
                        if (this.useRandomWeapon) {
                            var e = 0;
                            do {
                                e = Math.floor(Math.random() * l.Debug)
                            } while (l[e] == l[l.Basic]);
                            t = e
                        }
                        this.useRandomRarity && (o = Math.floor(Math.random() * p.Legendary)),
                       console.log(this.node.name + " Setting up turret with " + l[t] + " with rarity " + o),
                        this.shootControl.changeWeapon(t, o)
                    }
                }
                ,
                a.onShoot = function() {
                    this.shootControl.node.emit(f.ShootFinished)
                }
                ,
                o
            }(h)).prototype, "useRandomWeapon", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !0
                }
            }),
            T = o(R.prototype, "useThisWeapon", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return l.Basic
                }
            }),
            v = o(R.prototype, "useRandomRarity", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !0
                }
            }),
            S = o(R.prototype, "useThisRarity", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            C = R)) || C) || C));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MetagameEnums.ts", ["cc"], (function(e) {
    "use strict";
    var t;
    return {
        setters: [function(e) {
            t = e.cclegacy
        }
        ],
        execute: function() {
            var n;
            e("Rarity", void 0),
            t._RF.push({}, "3434d9OkgJMB52Xx5sEriKe", "MetagameEnums", void 0),
            function(e) {
                e[e.Common = 0] = "Common",
                e[e.Rare = 1] = "Rare",
                e[e.Epic = 2] = "Epic",
                e[e.Legendary = 3] = "Legendary"
            }(n || (n = e("Rarity", {}))),
            t._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterModelManager.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, n, r, a, i, o, s, l, c, u, p;
    return {
        setters: [function(e) {
            t = e.defineProperty,
            n = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            a = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            o = e.createClass
        }
        , function(e) {
            s = e.cclegacy,
            l = e._decorator,
            c = e.Prefab,
            u = e.instantiate,
            p = e.Component
        }
        ],
        execute: function() {
            var f, h, d, g, b, y, M, v;
            s._RF.push({}, "34949T/lJJJFaaUPHASNp+y", "CharacterModelManager", void 0);
            var C = l.ccclass
              , m = l.property
              , P = l.executionOrder;
            e("CharacterModelManager", (f = C("CharacterModelManager"),
            h = P(-8),
            d = m([c]),
            f(g = h((v = M = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), o = 0; o < n; o++)
                        r[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(r)) || this,
                    a(i(t), "prefabs", y, i(t)),
                    t
                }
                r(t, e);
                var n = t.prototype;
                return n.onLoad = function() {
                    null == t.instance && (t.instance = this)
                }
                ,
                n.onDestroy = function() {
                    t.instance == this && (t.instance = null)
                }
                ,
                n.getModel = function(e) {
                    return e < 0 || e >= this.prefabs.length ? null : u(this.prefabs[e])
                }
                ,
                n.getRandomModel = function() {
                    var e = Math.floor(Math.random() * this.prefabs.length);
                    return e < 0 || e >= this.prefabs.length ? null : u(this.prefabs[e])
                }
                ,
                o(t, [{
                    key: "Count",
                    get: function() {
                        return this.prefabs.length
                    }
                }]),
                t
            }(p),
            t(M, "instance", null),
            y = n((b = v).prototype, "prefabs", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            g = b)) || g) || g));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIReloadingState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./Pathfinding.ts", "./AIState.ts", "./AIEnums.ts"], (function(t) {
    "use strict";
    var i, e, a, n, s, o, r, c, h, l, d, g;
    return {
        setters: [function(t) {
            i = t.inheritsLoose,
            e = t.defineProperty,
            a = t.assertThisInitialized,
            n = t.createClass
        }
        , function(t) {
            s = t.cclegacy,
            o = t._decorator,
            r = t.Vec3,
            c = t.Vec2
        }
        , function(t) {
            h = t.logger
        }
        , function(t) {
            l = t.Pathfinding
        }
        , function(t) {
            d = t.AIState
        }
        , function(t) {
            g = t.AIStateList
        }
        ],
        execute: function() {
            var u;
            s._RF.push({}, "359174FEKpOEq1E6eIexf8E", "AIReloadingState", void 0);
            var p = o.ccclass;
            o.property,
            t("AIReloadingState", p("AIReloadingState")(u = function(t) {
                function s() {
                    for (var i, n = arguments.length, s = new Array(n), o = 0; o < n; o++)
                        s[o] = arguments[o];
                    return i = t.call.apply(t, [this].concat(s)) || this,
                    e(a(i), "targetPos", new r),
                    e(a(i), "myPos", new r),
                    e(a(i), "stepPoint", new r),
                    i
                }
                i(s, t);
                var o = s.prototype;
                return o.stateEnter = function() {
                    t.prototype.stateEnter.call(this),
                    this.getSideStepPosition()
                }
                ,
                o.stateUpdate = function(i) {
                    if (t.prototype.stateUpdate.call(this, i),
                    this.brain.reachedPathingDestination())
                        this.brain.setDirection(0, 0),
                        this.brain.changeState(g.Attacking);
                    else if (0 == this.characterBlackboard.isReloading && Math.random() < this.brain.data.reloadingData.interruptToShootPercentage)
                        this.brain.changeState(g.Attacking);
                    else {
                        var e = this.brain.getPathingDirection();
                        this.brain.setDirection(e.x, e.y)
                    }
                }
                ,
                o.getSideStepPosition = function() {
                    if (l.instance && this.characterBlackboard.target && this.characterBlackboard.target.isValid) {
                        this.targetPos.set(this.characterBlackboard.target.worldPosition),
                        this.myPos.set(this.node.worldPosition),
                        this.stepPoint.set(this.myPos),
                        this.stepPoint.subtract(this.targetPos),
                        this.stepPoint.normalize();
                        var t = Math.random() * Math.PI * 2;
                        r.rotateY(this.stepPoint, this.stepPoint, r.ZERO, t),
                        this.stepPoint.add(this.myPos);
                        var i = [Math.ceil(this.stepPoint.x), Math.ceil(this.stepPoint.z)]
                          , e = l.instance.getValidRandomNeighbour(i[0], i[1], this.brain.data.reloadingData.maxAvoidDistance);
                        if (null == e)
                            return console.log("Could not find any valid neighbour, cancelling side step"),
                            void this.brain.changeState(g.Attacking);
                        var a = l.instance.gridToWorld(e[0], e[1])
                          , n = new c(a.x,a.z)
                          , s = l.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, a.x, a.z);
                        s.length > 0 ? this.brain.setActivePath(n, s) : this.brain.changeState(g.Attacking)
                    }
                }
                ,
                n(s, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return this.brain.data.reloadingData.minimumTimeInState
                    }
                }]),
                s
            }(d)) || u);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/VersionLabel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts"], (function(e) {
    "use strict";
    var t, r, n, i, o, a, l, s, c;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            n = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            l = e.Label,
            s = e.Component
        }
        , function(e) {
            c = e.version
        }
        ],
        execute: function() {
            var u, p, b, f, y;
            o._RF.push({}, "373c6QJ+qhCNIynDi7Rbtj/", "VersionLabel", void 0);
            var h = a.ccclass
              , v = a.property;
            e("VersionLabel", (u = h("VersionLabel"),
            p = v(l),
            u((y = t((f = function(e) {
                function t() {
                    for (var t, r = arguments.length, o = new Array(r), a = 0; a < r; a++)
                        o[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    n(i(t), "label", y, i(t)),
                    t
                }
                return r(t, e),
                t.prototype.start = function() {
                  //xz 加载过渡界面
                    // this.label.string = "v" + c;
                    this.label.string = "";
                }
                ,
                t
            }(s)).prototype, "label", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = f)) || b));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterAnimation.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var i, n, e, o, a, s, r, l, h, u, d, c, p, m, g, f, A;
    return {
        setters: [function(t) {
            i = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            e = t.initializerDefineProperty,
            o = t.assertThisInitialized,
            a = t.defineProperty,
            s = t.asyncToGenerator
        }
        , function(t) {
            r = t.cclegacy,
            l = t._decorator,
            h = t.AnimationClip,
            u = t.CCFloat,
            d = t.Component
        }
        , function(t) {
            c = t.logger
        }
        , function(t) {
            p = t.WeaponType
        }
        , function(t) {
            m = t.CharacterState,
            g = t.EventEnterState,
            f = t.EventCharacterAction
        }
        , function(t) {
            A = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var v, S, k, b, y, I, C, E, R, w, T, z, D, M, P, x, O, U, L, _, B;
            r._RF.push({}, "37e33Qu/iVMzqgMWo5sKB8c", "CharacterAnimation", void 0);
            var F = l.ccclass
              , W = l.property;
            t("CharacterAnimation", (v = F("CharacterAnimation"),
            S = W(h),
            k = W(h),
            b = W(h),
            y = W(h),
            I = W(h),
            C = W(h),
            E = W(h),
            R = W(h),
            w = W({
                type: u,
                min: .1
            }),
            v((D = i((z = function(t) {
                function i() {
                    for (var i, n = arguments.length, s = new Array(n), r = 0; r < n; r++)
                        s[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(s)) || this,
                    e(o(i), "idle", D, o(i)),
                    e(o(i), "run", M, o(i)),
                    e(o(i), "shoot", P, o(i)),
                    e(o(i), "rapidShoot", x, o(i)),
                    e(o(i), "shootingIdle", O, o(i)),
                    e(o(i), "transitionShootingIdleToIdle", U, o(i)),
                    e(o(i), "death", L, o(i)),
                    e(o(i), "openChest", _, o(i)),
                    e(o(i), "runSpeedMultiplier", B, o(i)),
                    a(o(i), "skAnimation", void 0),
                    a(o(i), "data", void 0),
                    i
                }
                n(i, t);
                var r = i.prototype;
                return r.onEnable = function() {
                    this.node.on(m.Moving, this.onEnterMove, this),
                    this.node.on(m.Idle, this.onEnterIdle, this),
                    this.node.on(g.ShootingIdle, this.onEnterShootingIdle, this),
                    this.node.on(f.Shoot, this.onShoot, this),
                    this.node.on(m.Dying, this.onDying, this),
                    this.node.on(m.PickingUp, this.onPickingUp, this)
                }
                ,
                r.onDisable = function() {
                    this.node.off(m.Moving, this.onEnterMove, this),
                    this.node.off(m.Idle, this.onEnterIdle, this),
                    this.node.off(g.ShootingIdle, this.onEnterShootingIdle, this),
                    this.node.off(f.Shoot, this.onShoot, this),
                    this.node.off(m.Dying, this.onDying, this),
                    this.node.off(m.PickingUp, this.onPickingUp, this)
                }
                ,
                r.onLoad = function() {
                    var t;
                    if (this.data = this.getComponent(A),
                    this.data) {
                        this.skAnimation = this.data.skAnimation,
                        this.skAnimation ? (this.skAnimation.defaultClip = this.idle,
                        this.skAnimation.playOnLoad = !0,
                        this.validateAnimationClip(this.idle),
                        this.validateAnimationClip(this.run),
                        this.validateAnimationClip(this.shoot),
                        this.validateAnimationClip(this.death),
                        this.validateAnimationClip(this.openChest),
                        this.validateAnimationClip(this.shootingIdle),
                        this.validateAnimationClip(this.transitionShootingIdleToIdle),
                        this.validateAnimationClip(this.rapidShoot)) :console.log("ERROR: Could not find skeleton animation");
                        var i = null === (t = this.skAnimation) || void 0 === t ? void 0 : t.getState(this.run.name);
                        i && (i.speed = this.data.Speed * this.runSpeedMultiplier)
                    }
                }
                ,
                r.onEnterMove = function() {
                    var t;
                    this.unscheduleAllCallbacks(),
                    null === (t = this.skAnimation) || void 0 === t || t.play(this.run.name),
                    this.logAnimationState(this.run.name)
                }
                ,
                r.onEnterIdle = function() {
                    var t = s(regeneratorRuntime.mark((function t() {
                        var i, n, e, o = this;
                        return regeneratorRuntime.wrap((function(t) {
                            for (; ; )
                                switch (t.prev = t.next) {
                                case 0:
                                    if (this.skAnimation) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    if ((null === (i = this.data) || void 0 === i ? void 0 : i.state) != m.PickingUp) {
                                        t.next = 4;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 4:
                                    this.unscheduleAllCallbacks(),
                                    (null === (n = this.data) || void 0 === n ? void 0 : n.lastState) == m.ShootingIdle && null != this.transitionShootingIdleToIdle ? ((e = this.skAnimation.getState(this.transitionShootingIdleToIdle.name)) && (e.speed = 1),
                                    this.skAnimation.play(this.transitionShootingIdleToIdle.name),
                                    this.logAnimationState(this.transitionShootingIdleToIdle.name),
                                    this.scheduleOnce((function() {
                                        var t;
                                        null === (t = o.skAnimation) || void 0 === t || t.play(o.idle.name),
                                        o.logAnimationState(o.idle.name)
                                    }
                                    ), this.transitionShootingIdleToIdle.duration)) : (this.skAnimation.play(this.idle.name),
                                    this.logAnimationState(this.idle.name));
                                case 6:
                                case "end":
                                    return t.stop()
                                }
                        }
                        ), t, this)
                    }
                    )));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                r.onEnterShootingIdle = function() {
                    var t = s(regeneratorRuntime.mark((function t() {
                        var i, n, e = this;
                        return regeneratorRuntime.wrap((function(t) {
                            for (; ; )
                                switch (t.prev = t.next) {
                                case 0:
                                    if (this.skAnimation) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    (null === (i = this.data) || void 0 === i ? void 0 : i.lastState) == m.Idle ? ((n = this.skAnimation.getState(this.transitionShootingIdleToIdle.name)) && (n.speed = -1),
                                    this.skAnimation.play(this.transitionShootingIdleToIdle.name),
                                    this.logAnimationState(this.transitionShootingIdleToIdle.name),
                                    this.scheduleOnce((function() {
                                        var t;
                                        null === (t = e.skAnimation) || void 0 === t || t.play(e.shootingIdle.name),
                                        e.logAnimationState(e.shootingIdle.name)
                                    }
                                    ), this.transitionShootingIdleToIdle.duration)) : (this.skAnimation.play(this.shootingIdle.name),
                                    this.logAnimationState(this.shootingIdle.name));
                                case 3:
                                case "end":
                                    return t.stop()
                                }
                        }
                        ), t, this)
                    }
                    )));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                r.onShoot = function() {
                    var t = s(regeneratorRuntime.mark((function t() {
                        var i, n, e = this;
                        return regeneratorRuntime.wrap((function(t) {
                            for (; ; )
                                switch (t.prev = t.next) {
                                case 0:
                                    if (this.skAnimation) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    this.unscheduleAllCallbacks(),
                                    n = this.shoot,
                                    (null === (i = this.data) || void 0 === i ? void 0 : i.currentWeapon) == p.AssaultRifle && (n = this.rapidShoot),
                                    this.skAnimation.play(n.name),
                                    this.scheduleOnce((function() {
                                        e.node.emit(f.ShootFinished)
                                    }
                                    ), n.duration),
                                    this.logAnimationState(n.name);
                                case 8:
                                case "end":
                                    return t.stop()
                                }
                        }
                        ), t, this)
                    }
                    )));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                r.onDying = function() {
                    this.skAnimation && (this.skAnimation.play(this.death.name),
                    this.scheduleOnce(this.finishDying, this.death.duration))
                }
                ,
                r.finishDying = function() {
                    this.node.emit(f.DyingEnd)
                }
                ,
                r.onPickingUp = function() {
                    this.skAnimation && this.skAnimation.play(this.openChest.name)
                }
                ,
                r.validateAnimationClip = function(t) {
                    null != t ? this.skAnimation && -1 == this.skAnimation.clips.indexOf(t) &&console.log("ERROR: Animation " + t.name + " is not configured on " + this.skAnimation.node.name + ", please add on inspector into the prefab.") :console.log("ERROR:  Clip is null")
                }
                ,
                r.delay = function(t) {
                    return new Promise((function(i) {
                        return setTimeout(i, 1e3 * t)
                    }
                    ))
                }
                ,
                r.logAnimationState = function(t) {}
                ,
                i
            }(d)).prototype, "idle", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = i(z.prototype, "run", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = i(z.prototype, "shoot", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            x = i(z.prototype, "rapidShoot", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            O = i(z.prototype, "shootingIdle", [I], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            U = i(z.prototype, "transitionShootingIdleToIdle", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = i(z.prototype, "death", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            _ = i(z.prototype, "openChest", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            B = i(z.prototype, "runSpeedMultiplier", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .5
                }
            }),
            T = z)) || T));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIUpdateLevelCounter.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, n, r, o, i, l, a, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            r = e.initializerDefineProperty,
            o = e.assertThisInitialized
        }
        , function(e) {
            i = e.cclegacy,
            l = e._decorator,
            a = e.EventHandler,
            u = e.Component
        }
        ],
        execute: function() {
            var p, c, s, d, v, f, y;
            i._RF.push({}, "38faaNX8RBLIZmGbaKLpsOC", "UIUpdateLevelCounter", void 0);
            var L = l.ccclass
              , h = l.property;
            e("UIUpdateLevelCounter", (p = L("UIUpdateLevelCounter"),
            c = h({
                type: [a],
                displayOrder: 20
            }),
            s = h({
                type: [a],
                displayOrder: 20
            }),
            p((f = t((v = function(e) {
                function t() {
                    for (var t, n = arguments.length, i = new Array(n), l = 0; l < n; l++)
                        i[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(i)) || this,
                    r(o(t), "onUpdateCounter", f, o(t)),
                    r(o(t), "onAllowFillNextLevel", y, o(t)),
                    t
                }
                n(t, e);
                var i = t.prototype;
                return i.updateLevelCounter = function() {
                    a.emitEvents(this.onUpdateCounter, this.node)
                }
                ,
                i.continueToFillNextLevel = function() {
                    a.emitEvents(this.onAllowFillNextLevel, this.node)
                }
                ,
                t
            }(u)).prototype, "onUpdateCounter", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            y = t(v.prototype, "onAllowFillNextLevel", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            d = v)) || d));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RotateByInput.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var e, o, n, i, s, u, h, a, r, c, p, _, v, l, T, d, f;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            o = t.inheritsLoose,
            n = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            s = t.defineProperty
        }
        , function(t) {
            u = t.cclegacy,
            h = t._decorator,
            a = t.Vec2,
            r = t.Vec3,
            c = t.Quat,
            p = t.UIMeshRenderer,
            _ = t.Node,
            v = t.systemEvent,
            l = t.SystemEventType,
            T = t.Component
        }
        , function(t) {
            d = t.UIEventType
        }
        , function(t) {
            f = t.projectEvent
        }
        ],
        execute: function() {
            var E, R, D;
            u._RF.push({}, "3994fb/plBKLbwQocmgVIoD", "RotateByInput", void 0);
            var y = h.ccclass
              , O = h.property
              , M = h.executionOrder;
            t("RotateByInput", y("RotateByInput")(E = M(3)((D = e((R = function(t) {
                function e() {
                    for (var e, o = arguments.length, u = new Array(o), h = 0; h < o; h++)
                        u[h] = arguments[h];
                    return e = t.call.apply(t, [this].concat(u)) || this,
                    n(i(e), "speedRotate", D, i(e)),
                    s(i(e), "_targetToRotate", void 0),
                    s(i(e), "_targetNodeToReceiveEvents", void 0),
                    s(i(e), "_isInputDown", !1),
                    s(i(e), "_mousePos", new a),
                    s(i(e), "_mousePosOnDown", new a),
                    s(i(e), "_inputDelta", new a),
                    s(i(e), "_euler", new r),
                    s(i(e), "_quatIdentiy", new c),
                    e
                }
                o(e, t);
                var u = e.prototype;
                return u.onLoad = function() {
                    this._targetToRotate = this.node.children[0];
                    var t = this.node.getComponentInChildren(p);
                    t && (this._targetNodeToReceiveEvents = t.node)
                }
                ,
                u.start = function() {
                    c.identity(this._quatIdentiy)
                }
                ,
                u.onEnable = function() {
                    this._targetNodeToReceiveEvents && (this._targetNodeToReceiveEvents.on(_.EventType.MOUSE_MOVE, this.onMouseMove, this),
                    this._targetNodeToReceiveEvents.on(_.EventType.MOUSE_DOWN, this.onMouseDown, this),
                    this._targetNodeToReceiveEvents.on(_.EventType.MOUSE_UP, this.onMouseUp, this),
                    v.on(l.TOUCH_START, this.onTouchStart, this),
                    v.on(l.TOUCH_MOVE, this.onTouchMove, this),
                    v.on(l.TOUCH_END, this.onTouchEndOrCancel, this),
                    v.on(l.TOUCH_CANCEL, this.onTouchEndOrCancel, this),
                    this.resetRotation(),
                    f.on(d.StopRotateModel, this.onRequestStop, this))
                }
                ,
                u.onDisable = function() {
                    this._isInputDown = !1,
                    this._targetNodeToReceiveEvents && (this._targetNodeToReceiveEvents.off(_.EventType.MOUSE_MOVE, this.onMouseMove, this),
                    this._targetNodeToReceiveEvents.off(_.EventType.MOUSE_DOWN, this.onMouseDown, this),
                    this._targetNodeToReceiveEvents.off(_.EventType.MOUSE_UP, this.onMouseUp, this),
                    v.off(l.TOUCH_START, this.onTouchStart, this),
                    v.off(l.TOUCH_MOVE, this.onTouchMove, this),
                    v.off(l.TOUCH_END, this.onTouchEndOrCancel, this),
                    v.off(l.TOUCH_CANCEL, this.onTouchEndOrCancel, this),
                    f.on(d.StopRotateModel, this.onRequestStop, this))
                }
                ,
                u.onRequestStop = function() {
                    this.onInputUp()
                }
                ,
                u.update = function(t) {
                    this._isInputDown && this.moveBy(this._inputDelta.x, this.speedRotate * t)
                }
                ,
                u.onMouseDown = function(t) {
                    this._isInputDown = !0,
                    t.getLocation(this._mousePosOnDown)
                }
                ,
                u.onMouseMove = function(t) {
                    this._isInputDown && (t.getLocation(this._mousePos),
                    this._inputDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._inputDelta.normalize())
                }
                ,
                u.onMouseUp = function(t) {
                    this.onInputUp()
                }
                ,
                u.onTouchStart = function(t, e) {
                    e && e.getLocation(this._mousePosOnDown),
                    this._isInputDown = !0
                }
                ,
                u.onTouchMove = function(t, e) {
                    e && (e.getLocation(this._mousePos),
                    this._inputDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._inputDelta.normalize())
                }
                ,
                u.onTouchEndOrCancel = function(t, e) {
                    this.onInputUp()
                }
                ,
                u.onInputUp = function() {
                    this._isInputDown = !1,
                    this._inputDelta.set(0, 0)
                }
                ,
                u.moveBy = function(t, e) {
                    this._targetToRotate && this._isInputDown && (this._euler.set(this._targetToRotate.eulerAngles),
                    this._euler.y += t * e,
                    this._targetToRotate.setRotationFromEuler(this._euler))
                }
                ,
                u.resetRotation = function() {
                    var t;
                    null === (t = this._targetToRotate) || void 0 === t || t.setRotation(this._quatIdentiy)
                }
                ,
                e
            }(T)).prototype, "speedRotate", [O], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 500
                }
            }),
            E = R)) || E) || E);
            u._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestRewardedAds.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, r, o, n, d, i, a, s, u, c, l;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            o = e.initializerDefineProperty,
            n = e.assertThisInitialized,
            d = e.defineProperty
        }
        , function(e) {
            i = e.cclegacy,
            a = e._decorator,
            s = e.Node,
            u = e.Component
        }
        , function(e) {
            c = e.logger,
            l = e.LogCategory
        }
        ],
        execute: function() {
            var A, f, p, w, g;
            i._RF.push({}, "39977VfUmRA4rRqstHVEEIC", "TestRewardedAds", void 0);
            var y = a.ccclass
              , R = a.property;
            e("TestRewardedAds", (A = y("TestRewardedAds"),
            f = R(s),
            A((g = t((w = function(e) {
                function t() {
                    for (var t, r = arguments.length, i = new Array(r), a = 0; a < r; a++)
                        i[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(i)) || this,
                    o(n(t), "button", g, n(t)),
                    d(n(t), "showAdFunction", void 0),
                    t
                }
                r(t, e);
                var i = t.prototype;
                return i.start = function() {
                    var e = this;
                    if (c.log("Starting rewarded ad opportunity", l.RewardedAd),
                    this.button.active = !1,
                   console.log("GAMESNACKS stringify: " + JSON.stringify(GAMESNACKS), l.RewardedAd),
                    "undefined" != typeof GAMESNACKS) {
                        var t = {
                            beforeReward: function(t) {
                               console.log("beforeReward " + e + " " + e.button.name + " showAdFn " + t, l.RewardedAd),
                                e.button.active = !0,
                                e.showAdFunction = t
                            },
                            beforeBreak: function() {
                               console.log("beforeBreak " + e, l.RewardedAd)
                            },
                            adComplete: function() {
                               console.log("adComplete " + e, l.RewardedAd)
                            },
                            adDismissed: function() {
                               console.log("adDismissed " + e, l.RewardedAd)
                            },
                            afterBreak: function() {
                               console.log("afterBreak " + e, l.RewardedAd),
                                e.button.active = !1
                            }
                        };
                       console.log("Calling rewardedAdOpportunity " + GAMESNACKS.rewardedAdOpportunity, l.RewardedAd),
                        GAMESNACKS.rewardedAdOpportunity(t)
                    }
                }
                ,
                i.showAd = function() {
                    this.showAdFunction && this.showAdFunction()
                }
                ,
                t
            }(u)).prototype, "button", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            p = w)) || p));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AudioManagerInitializer.ts", ["cc", "./Logger.ts", "./AudioManager.ts", "./AudioData.ts"], (function(a) {
    "use strict";
    var o, i, n, t, e, u, r, d, c, g;
    return {
        setters: [function(a) {
            o = a.cclegacy,
            i = a.game,
            n = a.Game,
            t = a.resources,
            e = a.Prefab
        }
        , function(a) {
            u = a.logger,
            r = a.LogCategory,
            d = a.LogType
        }
        , function(a) {
            c = a.AudioManager
        }
        , function(a) {
            g = a.AudioData
        }
        ],
        execute: function() {
            o._RF.push({}, "39e33XnAQRJhpTBTgQcVQw7", "AudioManagerInitializer", void 0);
            a("audioManagerInitializer", new function() {
                i.on(n.EVENT_GAME_INITED, (function() {
                    t.load("audio/audioData", e, (function(a, o) {
                        if (a)
                            console.log("Could not load audio data. " + a, r.Audio, d.Error);
                        else {
                            var i;
                            console.log("Found prefab for audio data: " + o, r.Audio);
                            var n = o.data.getComponent(g);
                            null === (i = c.instance) || void 0 === i || i.setup(n)
                        }
                    }
                    ))
                }
                ), this)
            }
            );
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuArenaWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./PanelManager.ts", "./PanelEnums.ts"], (function(e) {
    "use strict";
    var n, t, a, r, i, o, l, u, c, s, p, b, g, h, d, y, f;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            a = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            o = e.cclegacy,
            l = e._decorator,
            u = e.Label,
            c = e.Sprite,
            s = e.Node,
            p = e.Button,
            b = e.Component
        }
        , function(e) {
            g = e.UIEventType
        }
        , function(e) {
            h = e.projectEvent
        }
        , function(e) {
            d = e.globalPlayer
        }
        , function(e) {
            y = e.PanelManager
        }
        , function(e) {
            f = e.PanelId
        }
        ],
        execute: function() {
            var P, m, v, A, M, U, k, z, C, w, I, W, L, N, _, j, E;
            o._RF.push({}, "3a83aSlvHBGTpiX7h05RPHK", "MainMenuArenaWidget", void 0);
            var F = l.ccclass
              , B = l.property;
            e("MainMenuArenaWidget", (P = F("MainMenuArenaWidget"),
            m = B(u),
            v = B(c),
            A = B(s),
            M = B(u),
            U = B(s),
            k = B(p),
            z = B(u),
            P((I = n((w = function(e) {
                function n() {
                    for (var n, t = arguments.length, o = new Array(t), l = 0; l < t; l++)
                        o[l] = arguments[l];
                    return n = e.call.apply(e, [this].concat(o)) || this,
                    a(r(n), "arenaNameLabel", I, r(n)),
                    a(r(n), "arenaIcon", W, r(n)),
                    a(r(n), "lockedWidget", L, r(n)),
                    a(r(n), "currencyUpgradeAmount", N, r(n)),
                    a(r(n), "buttonPlay", _, r(n)),
                    a(r(n), "buttonPurchase", j, r(n)),
                    a(r(n), "labelPurchaseCost", E, r(n)),
                    i(r(n), "arena", void 0),
                    n
                }
                t(n, e);
                var o = n.prototype;
                return o.setup = function(e) {
                    this.arenaNameLabel.string = e.Name.toUpperCase(),
                    this.currencyUpgradeAmount.string = e.UnlockCost.toFixed(),
                    this.labelPurchaseCost.string = this.currencyUpgradeAmount.string,
                    this.arenaIcon.spriteFrame = e.Icon;
                    var n = d.hasUnlocked(e.UnlockId);
                    this.lockedWidget.active = !n,
                    this.buttonPlay.active = n,
                    this.buttonPurchase.node.active = !n,
                    this.buttonPurchase.interactable = d.canPurchaseArena(e),
                    this.arena = e
                }
                ,
                o.onClick = function() {
                    var e;
                    h.emit(g.ArenaPurchaseConfirmation, this.arena),
                    null === (e = y.instance) || void 0 === e || e.open(f.ArenaUnlock)
                }
                ,
                n
            }(b)).prototype, "arenaNameLabel", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            W = n(w.prototype, "arenaIcon", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = n(w.prototype, "lockedWidget", [A], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            N = n(w.prototype, "currencyUpgradeAmount", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            _ = n(w.prototype, "buttonPlay", [U], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            j = n(w.prototype, "buttonPurchase", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = n(w.prototype, "labelPurchaseCost", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = w)) || C));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuConfirmWeaponUpgradeOverlay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./PanelManager.ts", "./PanelEnums.ts", "./MetagameWeaponData.ts"], (function(e) {
    "use strict";
    var a, t, n, i, o, r, l, p, s, u, c, g, m, f, b, d, h, v, D;
    return {
        setters: [function(e) {
            a = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            n = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            o = e.defineProperty
        }
        , function(e) {
            r = e.cclegacy,
            l = e._decorator,
            p = e.Prefab,
            s = e.Sprite,
            u = e.Label,
            c = e.Component
        }
        , function(e) {
            g = e.logger,
            m = e.LogCategory
        }
        , function(e) {
            f = e.MetagameEvent
        }
        , function(e) {
            b = e.projectEvent
        }
        , function(e) {
            d = e.globalPlayer
        }
        , function(e) {
            h = e.PanelManager
        }
        , function(e) {
            v = e.PanelId
        }
        , function(e) {
            D = e.MetagameWeaponData
        }
        ],
        execute: function() {
            var W, y, C, M, P, L, x, U, w, I, z, V, F, T, R, B, E;
            r._RF.push({}, "3b3b0iHOxtB24iCMfAewt9+", "MainMenuConfirmWeaponUpgradeOverlay", void 0);
            var N = l.ccclass
              , O = l.property;
            e("MainMenuConfirmUpgradeOverlay", (W = N("MainMenuConfirmUpgradeOverlay"),
            y = O(p),
            C = O(s),
            M = O(u),
            P = O(u),
            L = O(u),
            x = O(u),
            U = O(u),
            W((z = a((I = function(e) {
                function a() {
                    for (var a, t = arguments.length, r = new Array(t), l = 0; l < t; l++)
                        r[l] = arguments[l];
                    return a = e.call.apply(e, [this].concat(r)) || this,
                    n(i(a), "metagameWeaponDataPrefab", z, i(a)),
                    n(i(a), "sptIcon", V, i(a)),
                    n(i(a), "lName", F, i(a)),
                    n(i(a), "lLevel", T, i(a)),
                    n(i(a), "lBaseDmgValue", R, i(a)),
                    n(i(a), "lUpgradeCostValue", B, i(a)),
                    n(i(a), "lWeaponIncreaseValue", E, i(a)),
                    o(i(a), "metagameWeaponData", void 0),
                    o(i(a), "weapon", void 0),
                    a
                }
                t(a, e);
                var r = a.prototype;
                return r.onLoad = function() {
                    this.metagameWeaponData = this.metagameWeaponDataPrefab.data.getComponent(D)
                }
                ,
                r.onEnable = function() {
                    b.on(f.WeaponUpgradePurchaseConfirmation, this.onRequestConfirmation, this)
                }
                ,
                r.onDisable = function() {
                    b.off(f.WeaponUpgradePurchaseConfirmation, this.onRequestConfirmation, this)
                }
                ,
                r.onRequestConfirmation = function(e) {
                    var a;
                    this.weapon = e,
                    this.sptIcon.spriteFrame = this.metagameWeaponData.getWeaponIcon(e);
                    var t = this.metagameWeaponData.getWeaponName(e);
                    this.setLabelText(this.lName, t);
                    var n = d.getWeaponLevel(e);
                    if (null != n) {
                        var i = n + 2;
                        this.setLabelText(this.lLevel, i.toFixed())
                    }
                    var o = d.getWeaponUpgradeCost(e);
                    null != o && this.setLabelText(this.lUpgradeCostValue, o.toFixed());
                    var r = this.metagameWeaponData.getWeaponData(e);
                    if (null != r) {
                        var l = d.getWeaponDamageMultiplier(e)
                          , p = d.getNextLevelWeaponDamageMultiplier(e)
                          , s = r.Damage * p
                          , u = r.Damage * l
                          , c = s - u
                          , f = c / u
                          , b = "+" + (f *= 100).toFixed() + "%";
                        console.log(this.node.name + " baseDamage: " + r.Damage + " currentMultiplier: " + l + " nextMultiplier " + p + " currentDmg: " + u + " nextDmg: " + s + " difference: " + c + " increase percentage: " + f, m.UI),
                        this.setLabelText(this.lBaseDmgValue, s.toFixed()),
                        this.setLabelText(this.lWeaponIncreaseValue, b)
                    }
                    null === (a = h.instance) || void 0 === a || a.open(v.ConfirmWeaponUpgrade)
                }
                ,
                r.confirmPurchase =async function() {
                    var e;
                   await d.purchaseWeaponUpgrade(this.weapon),
                    null === (e = h.instance) || void 0 === e || e.close(v.ConfirmWeaponUpgrade)
                }
                ,
                r.close = function(){
                    console.log("=====");
                },
                r.setLabelText = function(e, a) {
                    e.string = a,
                    e.updateRenderData(!0)
                }
                ,
                a
            }(c)).prototype, "metagameWeaponDataPrefab", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            V = a(I.prototype, "sptIcon", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            F = a(I.prototype, "lName", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            T = a(I.prototype, "lLevel", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            R = a(I.prototype, "lBaseDmgValue", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            B = a(I.prototype, "lUpgradeCostValue", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = a(I.prototype, "lWeaponIncreaseValue", [U], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            w = I)) || w));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PreTutorial.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./PanelManager.ts", "./PanelEnums.ts", "./Loading.ts"], (function(n) {
    "use strict";
    var e, o, t, i, a, l, r, s, u, c, d, g, f, h, P, v;
    return {
        setters: [function(n) {
            e = n.inheritsLoose,
            o = n.defineProperty,
            t = n.assertThisInitialized
        }
        , function(n) {
            i = n.cclegacy,
            a = n._decorator,
            l = n.director,
            r = n.assetManager,
            s = n.Component
        }
        , function(n) {
            u = n.logger
        }
        , function(n) {
            c = n.SceneNames,
            d = n.BundleNames
        }
        , function(n) {
            g = n.projectEvent
        }
        , function(n) {
            f = n.PanelManager
        }
        , function(n) {
            h = n.EventPanel,
            P = n.PanelId
        }
        , function(n) {
            v = n.Loading
        }
        ],
        execute: function() {
            var T;
            i._RF.push({}, "3c311hyVKJLpZyPCBc18M6D", "PreTutorial", void 0);
            var p = a.ccclass;
            a.property,
            n("PreTutorial", p("PreTutorial")(T = function(n) {
                function i() {
                    for (var e, i = arguments.length, a = new Array(i), r = 0; r < i; r++)
                        a[r] = arguments[r];
                    return e = n.call.apply(n, [this].concat(a)) || this,
                    o(t(e), "onTutorialBundleLoaded", (function(n, o) {
                        console.log("Finished loading bundle. " + o.name + ", loading scene"),
                        o.loadScene(c.Tutorial, e.onSceneLoaded)
                    }
                    )),
                    o(t(e), "onSceneLoaded", (function(n, o) {
                        console.log("Finished loading scene: " + o.name + ", starting it."),
                        e.scheduleOnce((function() {
                            l.runScene(o)
                        }
                        ), 2)
                    }
                    )),
                    e
                }
                e(i, n);
                var a = i.prototype;
                return a.start = function() {
                    console.log("Starting to load " + d.Tutorial + " bundle."),
                    r.getBundle(d.Tutorial) || (console.log("Bundle invalid, loading it"),
                    r.loadBundle(d.Tutorial))
                }
                ,
                a.onEnable = function() {
                    g.on(h.CloseFinish, this.onPanelCloseFinish, this)
                }
                ,
                a.onDisable = function() {
                    g.off(h.CloseFinish, this.onPanelCloseFinish, this)
                }
                ,
                a.continueToTutorial = function() {
                    var n;
                    null === (n = f.instance) || void 0 === n || n.close(P.PreTutorial)
                }
                ,
                a.onPanelCloseFinish = function(n) {
                    var e;
                    console.log(P[n] + " finished close"),
                    null === (e = v.instance) || void 0 === e || e.show();
                    var o = r.getBundle(d.Tutorial);
                    o ? o.loadScene(c.Tutorial, this.onSceneLoaded) : (console.log("Bundle invalid, loading it"),
                    r.loadBundle(d.Tutorial, this.onTutorialBundleLoaded))
                }
                ,
                i
            }(s)) || T);
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuMissionWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./WeaponEnums.ts", "./GlobalPlayer.ts"], (function(i) {
    "use strict";
    var e, s, t, n, r, a, o, l, g, m, p, u, c, h, y, b, d, f, w, P, L;
    return {
        setters: [function(i) {
            e = i.applyDecoratedDescriptor,
            s = i.inheritsLoose,
            t = i.initializerDefineProperty,
            n = i.assertThisInitialized,
            r = i.defineProperty,
            a = i.createClass
        }
        , function(i) {
            o = i.cclegacy,
            l = i._decorator,
            g = i.Label,
            m = i.ProgressBar,
            p = i.Animation,
            u = i.Node,
            c = i.EventHandler,
            h = i.tween,
            y = i.instantiate,
            b = i.Component
        }
        , function(i) {
            d = i.UIEventType,
            f = i.CurrencyRewardTweenMode
        }
        , function(i) {
            w = i.projectEvent
        }
        , function(i) {
            P = i.WeaponType
        }
        , function(i) {
            L = i.globalPlayer
        }
        ],
        execute: function() {
            var M, R, T, v, B, C, D, E, F, A, W, O, z, _, j, U, k;
            o._RF.push({}, "3d990RntmJC07O6eavqUhZ8", "MainMenuMissionWidget", void 0);
            var H = l.ccclass
              , I = l.property;
            i("MainMenuMissionWidget", (M = H("MainMenuMissionWidget"),
            R = I(g),
            T = I(g),
            v = I(m),
            B = I(p),
            C = I(g),
            D = I(u),
            E = I({
                type: [c],
                displayOrder: 20
            }),
            M((W = e((A = function(i) {
                function e() {
                    for (var e, s = arguments.length, a = new Array(s), o = 0; o < s; o++)
                        a[o] = arguments[o];
                    return e = i.call.apply(i, [this].concat(a)) || this,
                    t(n(e), "missionTitleLabel", W, n(e)),
                    t(n(e), "missionProgressLabel", O, n(e)),
                    t(n(e), "missionProgressBar", z, n(e)),
                    t(n(e), "animation", _, n(e)),
                    t(n(e), "missionRewardLabel", j, n(e)),
                    t(n(e), "missionRewardLayout", U, n(e)),
                    t(n(e), "onMissionComplete", k, n(e)),
                    r(n(e), "waitingForAnimation", !1),
                    r(n(e), "progressBarTarget", void 0),
                    r(n(e), "animationRatio", 0),
                    r(n(e), "_animationDelay", void 0),
                    e
                }
                s(e, i);
                var o = e.prototype;
                return o.setupAsMission = function(i, e) {
                    this.missionTitleLabel.string = "Defeat " + i.target + " Players with " + P[i.weaponType] + " Weapon",
                    this.missionRewardLabel.string = "+" + L.getMissionReward(i),
                    i.redeemed ? (this.missionProgressLabel.string = "COMPLETE",
                    this.missionProgressBar.progress = 1) : (this.waitingForAnimation = !0,
                    this.animationRatio = i.progress / i.target,
                    this.progressBarTarget = i.target,
                    e ? (this.missionProgressLabel.string = "0/" + i.target,
                    this.missionProgressBar.progress = 0) : (this.missionProgressLabel.string = i.progress + "/" + i.target,
                    this.missionProgressBar.progress = i.progress / i.target))
                }
                ,
                o.playEntryAnimation = function() {
                    this.animation.play()
                }
                ,
                o.animateBar = function() {
                    this.waitingForAnimation && (this.waitingForAnimation = !1,
                    this.scheduleOnce(this.doBarAnimation, this._animationDelay))
                }
                ,
                o.doBarAnimation = function() {
                    var i = this;
                    w.emit(d.MissionComplete),
                    h(this.missionProgressBar).to(.33, {
                        progress: this.animationRatio
                    }, {
                        easing: "linear",
                        onUpdate: function(e, s) {
                            var t = e.progress;
                            i.missionProgressLabel.string = Math.floor(t * i.progressBarTarget) + "/" + i.progressBarTarget
                        }
                    }).repeat(1).start(),
                    this.scheduleOnce((function() {
                        if (i.animationRatio >= 1) {
                            i.missionProgressLabel.string = "COMPLETE",
                            c.emitEvents(i.onMissionComplete, i.node);
                            var e = y(i.missionRewardLayout);
                            e.setParent(i.missionRewardLayout.parent),
                            i.missionRewardLayout.active = !1,
                            w.emit(d.CurrencyRewardSpawned, e, f.Mission)
                        }
                    }
                    ), .34)
                }
                ,
                o.setupAsFirstWinOfTheDay = function(i) {
                  //xz 每日成就 单个渲染
                    this.missionTitleLabel.string = "First Win of the Day",
                    this.missionRewardLabel.string = "+" + L.getFirstWinOfTheDayReward(),
                    this.waitingForAnimation = i,
                    this.animationRatio = L.hasFinishedFirstWinOfTheDay() ? 1 : 0,
                    this.progressBarTarget = 1,
                    i ? (this.missionProgressBar.progress = 0,
                    this.missionProgressLabel.string = "0/1") : (this.missionProgressBar.progress = this.animationRatio,
                    this.missionProgressLabel.string = L.hasClaimedFirstWinOfTheDay() ? "COMPLETE" : "0/1")
                }
                ,
                a(e, [{
                    key: "animationDelay",
                    set: function(i) {
                        this._animationDelay = i
                    }
                }]),
                e
            }(b)).prototype, "missionTitleLabel", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            O = e(A.prototype, "missionProgressLabel", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            z = e(A.prototype, "missionProgressBar", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            _ = e(A.prototype, "animation", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            j = e(A.prototype, "missionRewardLabel", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            U = e(A.prototype, "missionRewardLayout", [D], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            k = e(A.prototype, "onMissionComplete", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            F = A)) || F));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestCustomGlobalEventListener.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var e, n, o, s, i, r;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            n = t.cclegacy,
            o = t._decorator,
            s = t.Component
        }
        , function(t) {
            i = t.ProjectEventType
        }
        , function(t) {
            r = t.projectEvent
        }
        ],
        execute: function() {
            var c;
            n._RF.push({}, "41eaaME2KRFNLl0/BIoO3Cu", "TestCustomGlobalEventListener", void 0);
            var u = o.ccclass;
            o.property,
            t("TestCustomGlobalEventListener", u("TestCustomGlobalEventListener")(c = function(t) {
                function n() {
                    return t.apply(this, arguments) || this
                }
                e(n, t);
                var o = n.prototype;
                return o.onLoad = function() {
                    r.on(i.MatchFinish, this.onMatchFinish, this)
                }
                ,
                o.onMatchFinish = function() {
                    logger.log("Received global event")
                }
                ,
                n
            }(s)) || c);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterShoot.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./WeaponEnums.ts", "./CharacterEnums.ts", "./GameplayEnums.ts", "./CharacterBlackboard.ts", "./MatchController.ts", "./Target.ts"], (function(t) {
    "use strict";
    var a, e, n, o, i, r, s, h, c, d, l, u, p, f, g, m, v, y, w, C, W, S;
    return {
        setters: [function(t) {
            a = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            n = t.initializerDefineProperty,
            o = t.assertThisInitialized,
            i = t.defineProperty
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator,
            h = t.Node,
            c = t.Vec3,
            d = t.macro,
            l = t.Component
        }
        , function(t) {
            u = t.logger
        }
        , function(t) {
            p = t.ProjectEventType
        }
        , function(t) {
            f = t.projectEvent
        }
        , function(t) {
            g = t.WeaponType
        }
        , function(t) {
            m = t.EventEnterState,
            v = t.EventCharacterAction,
            y = t.CharacterState
        }
        , function(t) {
            w = t.MatchState
        }
        , function(t) {
            C = t.CharacterBlackboard
        }
        , function(t) {
            W = t.MatchController
        }
        , function(t) {
            S = t.Target
        }
        ],
        execute: function() {
            var R, b, E, T, D, P;
            r._RF.push({}, "42dabNTpLJIar192Y8lygAK", "CharacterShoot", void 0);
            var I = s.ccclass
              , j = s.property
              , k = s.executionOrder;
            t("CharacterShoot", (R = I("CharacterShoot"),
            b = k(10),
            E = j(h),
            R(T = b((P = a((D = function(t) {
                function a() {
                    for (var a, e = arguments.length, r = new Array(e), s = 0; s < e; s++)
                        r[s] = arguments[s];
                    return a = t.call.apply(t, [this].concat(r)) || this,
                    n(o(a), "pivot", P, o(a)),
                    i(o(a), "bulletCost", 1),
                    i(o(a), "direction", new c),
                    i(o(a), "data", void 0),
                    i(o(a), "cooldownTimer", 0),
                    i(o(a), "weapons", []),
                    a
                }
                e(a, t);
                var r = a.prototype;
                return r.onEnable = function() {
                    this.node.on(m.ShootingIdle, this.onShootStart, this),
                    this.node.on(v.DyingStart, this.onDyingStart, this)
                }
                ,
                r.onDisable = function() {
                    this.node.off(m.ShootingIdle, this.onShootStart, this),
                    this.node.off(v.DyingStart, this.onDyingStart, this)
                }
                ,
                r.onDyingStart = function() {
                    null != this.data && (this.weapons[this.data.currentWeapon].node.active = !1)
                }
                ,
                r.start = function() {
                    var t = this
                      , a = this.node.getComponent(C);
                    if (a) {
                        this.data = a;
                        var e = this.data.weapons;
                        e ? (this.weapons = e,
                        this.weapons.forEach((function(a) {
                            t.node.parent && a.setup(t.node.parent, t.data, t.pivot),
                            a.node.active = !1
                        }
                        ))) : console.log("ERROR: Could not find skeleton animation")
                    } else
                        console.log("ERROR: Could not setup weapons");
                    this.changeWeapon(this.data.currentWeapon, this.getCurrentWeaponRarity())
                }
                ,
                r.update = function(t) {
                    var a;
                    if ((null === (a = W.instance) || void 0 === a ? void 0 : a.state) == w.Runing && null != this.data && this.data.state != y.Dying && this.data.state != y.Dead)
                        if (this.data.ammo < this.data.ammoMax && (this.data.ammo += this.weapons[this.data.currentWeapon].AmmoRecoverRate * t),
                        this.cooldownTimer <= 0 && this.data.state == y.ShootingIdle) {
                            if (null == this.data)
                                return;
                            if (null == this.node.parent || null == this.data.target || !this.data.target.isValid)
                                return;
                            if (this.data.currentWeapon >= this.weapons.length)
                                return void console.log("Error: Invalid current weapon value: " + this.data.currentWeapon);
                            var e = this.weapons[this.data.currentWeapon]
                              , n = this.node.worldPosition.subtract(this.data.target.worldPosition).length();
                            this.data.ammo > this.bulletCost && n <= e.Range && (S.direction(this.direction, this.node.parent, this.data.target),
                            e.shoot(this.direction),
                            this.data.ammo -= this.bulletCost,
                            this.node.emit(v.Shoot, this.direction),
                            this.cooldownTimer = this.weapons[this.data.currentWeapon].Cooldown,
                            this.data.IsPlayer && f.emit(p.PlayerShoot, this.data.currentWeapon),
                            this.data.isReloading = !0)
                        } else
                            this.cooldownTimer -= t,
                            this.cooldownTimer <= 0 && this.data.ammo >= this.bulletCost && (this.data.isReloading = !1)
                }
                ,
                r.onShootStart = function(t) {
                    null != this.data && (this.data.target = t)
                }
                ,
                r.onCheatKeyDown = function(t) {
                    if (t.keyCode == d.KEY.f10) {
                        var a = this.data.currentWeapon + 1;
                        a == Object.keys(g).length && (a = g.Basic),
                        this.changeWeapon(a, 0)
                    }
                }
                ,
                r.getCurrentWeaponType = function() {
                    return this.weapons[this.data.currentWeapon].Type
                }
                ,
                r.getCurrentWeaponRarity = function() {
                    return this.weapons[this.data.currentWeapon].weaponRarity
                }
                ,
                r.changeWeapon = function(t, a) {
                    var e, n = this;
                    this.weapons[this.data.currentWeapon].node.active = !1,
                    this.data.currentWeapon = t,
                    this.data.currentWeaponObject = this.weapons[t],
                    this.weapons[t].node.active = !0,
                    this.weapons[t].weaponRarity = a,
                    null === (e = this.node.parent) || void 0 === e || e.children.forEach((function(t) {
                        t.emit(v.WeaponChange, n.weapons[n.data.currentWeapon])
                    }
                    )),
                    this.data.IsPlayer && f.emit(p.PlayerWeaponChange, t)
                }
                ,
                a
            }(l)).prototype, "pivot", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            T = D)) || T) || T));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Bullet.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./WeaponEnums.ts", "./BulletPools.ts", "./CharacterEnums.ts", "./Pathfinding.ts", "./BulletEnums.ts"], (function(t) {
    "use strict";
    var i, e, s, n, o, a, r, l, h, c, u, d, y, f, p, v, g, R, P, m, w;
    return {
        setters: [function(t) {
            i = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            s = t.defineProperty,
            n = t.assertThisInitialized,
            o = t.initializerDefineProperty,
            a = t.createClass
        }
        , function(t) {
            r = t.cclegacy,
            l = t._decorator,
            h = t.CCFloat,
            c = t.Vec3,
            u = t.ParticleSystem,
            d = t.geometry,
            y = t.PhysicsSystem,
            f = t.Component
        }
        , function(t) {
            p = t.logger
        }
        , function(t) {
            v = t.PHY_GROUP
        }
        , function(t) {
            g = t.WeaponBulletType
        }
        , function(t) {
            R = t.BulletPools
        }
        , function(t) {
            P = t.EventCharacterAction
        }
        , function(t) {
            m = t.Pathfinding
        }
        , function(t) {
            w = t.BulletEvent
        }
        ],
        execute: function() {
            var C, k, b, D, A;
            r._RF.push({}, "458c87SeOVJmqdcApfG0SMo", "Bullet", void 0);
            var B = l.ccclass
              , H = l.property;
            t("Bullet", (C = B("Bullet"),
            k = H({
                type: h,
                tooltip: "Bullet collision radius"
            }),
            C((A = i((D = function(t) {
                function i() {
                    for (var i, e = arguments.length, a = new Array(e), r = 0; r < e; r++)
                        a[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(a)) || this,
                    s(n(i), "_type", g.Basic),
                    o(n(i), "radius", A, n(i)),
                    s(n(i), "damage", 20),
                    s(n(i), "owner", void 0),
                    s(n(i), "lifetime", 3),
                    s(n(i), "worldPos", new c),
                    s(n(i), "shootDirection", new c),
                    s(n(i), "translateValue", new c),
                    s(n(i), "speed", void 0),
                    s(n(i), "leftRay", void 0),
                    s(n(i), "rightRay", void 0),
                    s(n(i), "backRay", void 0),
                    s(n(i), "framesToCheckBack", 30),
                    s(n(i), "backRayFrameCount", 0),
                    s(n(i), "particles", []),
                    s(n(i), "reverseDirection", new c),
                    i
                }
                e(i, t);
                var r = i.prototype;
                return r.setup = function(t, i, e, s, n) {
                    this.owner = t,
                    this.damage = i,
                    this.shootDirection.set(e),
                    this.reverseDirection.set(e),
                    this.reverseDirection.negative(),
                    this.lifetime = s,
                    this.speed = n,
                    this.scheduleOnce(this.onFinishLifetime, this.lifetime),
                    this.node.getWorldPosition(this.worldPos),
                    this.particles.forEach((function(t) {
                        t.clear()
                    }
                    )),
                    this.backRayFrameCount = 0
                }
                ,
                r.onLoad = function() {
                    this.particles = this.node.getComponentsInChildren(u),
                    this.leftRay = new d.Ray(this.worldPos.x,this.worldPos.y,this.worldPos.z,0,0,-1),
                    this.rightRay = new d.Ray(this.worldPos.x,this.worldPos.y,this.worldPos.z,0,0,-1),
                    this.backRay = new d.Ray(this.worldPos.x,this.worldPos.y,this.worldPos.z,0,0,1)
                }
                ,
                r.reuse = function() {}
                ,
                r.unuse = function() {
                    this.owner = null,
                    this.unscheduleAllCallbacks(),
                    this.particles.forEach((function(t) {
                        t.stop()
                    }
                    ))
                }
                ,
                r.update = function(t) {
                    var i, e;
                    if (null != this.owner)
                        if (this.translateValue.set(this.shootDirection),
                        this.translateValue.multiplyScalar(t),
                        this.translateValue.multiplyScalar(this.speed),
                        this.node.translate(this.translateValue),
                        null != this.leftRay && null != this.rightRay) {
                            var s = new c(-this.shootDirection.z,0,this.shootDirection.x);
                            s.normalize(),
                            s.multiplyScalar(this.radius),
                            this.node.getWorldPosition(this.worldPos),
                            this.leftRay.o.set(this.worldPos),
                            this.leftRay.o.add(s),
                            this.leftRay.d.set(this.shootDirection),
                            s.multiplyScalar(-1),
                            this.rightRay.o.set(this.worldPos),
                            this.rightRay.o.add(s),
                            this.rightRay.d.set(this.shootDirection);
                            var n = this.testRaycast(this.leftRay);
                            if ((null === (i = n) || void 0 === i ? void 0 : i.isValid) || (n = this.testRaycast(this.rightRay)),
                            null === (e = n) || void 0 === e ? void 0 : e.isValid)
                                this.onHitPlayer(n);
                            else {
                                if (this.backRayFrameCount < this.framesToCheckBack && (this.backRayFrameCount++,
                                this.backRay.o.set(this.worldPos),
                                this.backRay.d.set(this.reverseDirection),
                                this.backRay)) {
                                    var o = this.testRaycast(this.backRay, .6);
                                    if (null == o ? void 0 : o.isValid)
                                        return void this.onHitPlayer(o)
                                }
                                this.raycastAgainstTileMap()
                            }
                        } else
                            console.log("A bullet ray is null")
                }
                ,
                r.onHitAnything = function() {}
                ,
                r.testRaycast = function(t, i) {
                    if (void 0 === i && (i = .175),
                    y.instance.raycastClosest(t, v.PLAYER, i, !1)) {
                        var e = y.instance.raycastClosestResult;
                        if (e.collider.node != this.owner) {
                            var s = e.collider.node.children[0];
                            if (null != s)
                                return s
                        }
                    }
                    return null
                }
                ,
                r.raycastAgainstTileMap = function() {
                    var t, i = [this.worldPos.x, this.worldPos.z], e = [this.shootDirection.x, this.shootDirection.z];
                    0 != (null === (t = m.instance) || void 0 === t ? void 0 : t.raycastOnOriginalMap(i, e, 1)) && this.onHitAnythingInternal(!1)
                }
                ,
                r.onHitPlayer = function(t) {
                    var i;
                    t.emit(P.HitReceived, this.damage, null === (i = this.owner) || void 0 === i ? void 0 : i.children[0]),
                    this.node.emit(w.HitPlayer),
                    this.onHitAnythingInternal(!0)
                }
                ,
                r.onHitAnythingInternal = function(t) {
                    var i;
                    t || this.node.emit(w.HitAnything),
                    this.onHitAnything(),
                    null === (i = R.instance) || void 0 === i || i.put(this._type, this.node)
                }
                ,
                r.onFinishLifetime = function() {
                    var t;
                    null === (t = R.instance) || void 0 === t || t.put(this._type, this.node)
                }
                ,
                a(i, [{
                    key: "type",
                    get: function() {
                        return this._type
                    }
                }]),
                i
            }(f)).prototype, "radius", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .25
                }
            }),
            b = D)) || b));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Logger.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var g, o;
    return {
        setters: [function(e) {
            g = e.defineProperty
        }
        , function(e) {
            o = e.cclegacy
        }
        ],
        execute: function() {
            var r, n;
            e({
                LogCategory: void 0,
                LogType: void 0
            }),
            o._RF.push({}, "46e063+EuZIZL/iJQhAf/jc", "Logger", void 0),
            function(e) {
                e[e.Info = 0] = "Info",
                e[e.Warning = 1] = "Warning",
                e[e.Error = 2] = "Error"
            }(r || (r = e("LogType", {}))),
            function(e) {
                e[e.Generic = 0] = "Generic",
                e[e.Gameplay = 1] = "Gameplay",
                e[e.AI = 2] = "AI",
                e[e.Metagame = 3] = "Metagame",
                e[e.UI = 4] = "UI",
                e[e.GameSnacksAPI = 5] = "GameSnacksAPI",
                e[e.RewardedAd = 6] = "RewardedAd",
                e[e.Audio = 7] = "Audio"
            }(n || (n = e("LogCategory", {})));
            var t = e("Logger", function() {
                function e() {
                    for (var e in g(this, "currentLoggingLevel", r.Info),
                    g(this, "categoryLogging", new Map),
                    n) {
                        var o = Number(e);
                        isNaN(o) || this.categoryLogging.set(o, !0)
                    }
                }
                var o = e.prototype;
                return o.setLoggingLevel = function(e) {
                    console.log("[Logging] Changing log level to: " + r[e]),
                    this.currentLoggingLevel = e
                }
                ,
                o.getLoggingLevel = function() {
                    return this.currentLoggingLevel
                }
                ,
                o.setCategoryLogging = function(e, g) {
                    this.categoryLogging.set(e, g)
                }
                ,
                o.getCategoryLogging = function(e) {
                    if (this.categoryLogging.has(e)) {
                        var g = this.categoryLogging.get(e);
                        return g || !1
                    }
                    return !1
                }
                ,
                o.log = function(e, g, o) {
                  console.log("===log====",e, g, o);
                  return;
                  if (void 0 === g && (g = n.Generic),
                    void 0 === o && (o = r.Info),
                    this.categoryLogging.get(g) && !(o < this.currentLoggingLevel)) {
                        var t = n[g];
                        switch (o) {
                        case r.Info:
                            console.log("[" + t + "] " + e);
                            break;
                        case r.Warning:
                            console.warn("[" + t + "] " + e);
                            break;
                        case r.Error:
                            console.error("[" + t + "] " + e)
                        }
                        r.Error
                    }
                }
                ,
                e
            }());
            e("logger", new t).setLoggingLevel(r.Error),
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/ToggleProfiler.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, r, o, i, l, n, s, c, a;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            r = t.inheritsLoose,
            o = t.initializerDefineProperty,
            i = t.assertThisInitialized
        }
        , function(t) {
            l = t.cclegacy,
            n = t._decorator,
            s = t.Toggle,
            c = t.profiler,
            a = t.Component
        }
        ],
        execute: function() {
            var g, u, p, f, h;
            l._RF.push({}, "479bdsgvRtA2ITTopRQs2Pm", "ToggleProfiler", void 0);
            var y = n.ccclass
              , d = n.property;
            t("ToggleProfiler", (g = y("ToggleProfiler"),
            u = d(s),
            g((h = e((f = function(t) {
                function e() {
                    for (var e, r = arguments.length, l = new Array(r), n = 0; n < r; n++)
                        l[n] = arguments[n];
                    return e = t.call.apply(t, [this].concat(l)) || this,
                    o(i(e), "tgl", h, i(e)),
                    e
                }
                r(e, t);
                var l = e.prototype;
                return l.start = function() {
                    this.tgl.setIsCheckedWithoutNotify(c.isShowingStats())
                }
                ,
                l.onToggle = function(t, e) {
                    this.tgl.isChecked ? c.showStats() : c.hideStats()
                }
                ,
                e
            }(a)).prototype, "tgl", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            p = f)) || p));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestCollisionEvents.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(o) {
    "use strict";
    var n, t, i, l, s;
    return {
        setters: [function(o) {
            n = o.inheritsLoose
        }
        , function(o) {
            t = o.cclegacy,
            i = o._decorator,
            l = o.Collider,
            s = o.Component
        }
        ],
        execute: function() {
            var e;
            t._RF.push({}, "4bdd1niYjdA+IhLfX0lfjY8", "TestCollisionEvents", void 0);
            var r = i.ccclass;
            i.property,
            o("TestCollisionEvents", r("TestCollisionEvents")(e = function(o) {
                function t() {
                    return o.apply(this, arguments) || this
                }
                n(t, o);
                var i = t.prototype;
                return i.start = function() {
                    logger.log("Start of test collision events");
                    var o = this.getComponentInChildren(l);
                    logger.log("collier is: " + o),
                    null == o || o.on("onCollisionEnter", this.onCollision, this),
                    null == o || o.on("onCollisionStay", this.onCollision, this),
                    null == o || o.on("onCollisionExit", this.onCollision, this)
                }
                ,
                i.onCollision = function(o) {}
                ,
                t
            }(s)) || e);
            t._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterCombatDetection.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var e, i, o, a, n, r, s, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            i = t.defineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            n = t._decorator,
            r = t.Component
        }
        , function(t) {
            s = t.EventCharacterAction
        }
        , function(t) {
            c = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var h;
            a._RF.push({}, "4be53HxPSZHwLgMgEFc8EJu", "CharacterCombatDetection", void 0);
            var d = n.ccclass;
            n.property,
            t("CharacterCombatDetection", d("CharacterCombatDetection")(h = function(t) {
                function a() {
                    for (var e, a = arguments.length, n = new Array(a), r = 0; r < a; r++)
                        n[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(n)) || this,
                    i(o(e), "data", void 0),
                    i(o(e), "timer", 0),
                    e
                }
                e(a, t);
                var n = a.prototype;
                return n.onEnable = function() {
                    this.node.on(s.Shoot, this.enterCombat, this),
                    this.node.on(s.HitReceived, this.enterCombat, this)
                }
                ,
                n.onDisable = function() {
                    this.node.off(s.Shoot, this.enterCombat, this),
                    this.node.off(s.HitReceived, this.enterCombat, this)
                }
                ,
                n.start = function() {
                    this.data = this.node.getComponent(c)
                }
                ,
                n.update = function(t) {
                    this.data && (this.timer += t,
                    this.timer >= this.data.ExitCombatCooldown && this.exitCombat())
                }
                ,
                n.enterCombat = function() {
                    this.data && (0 == this.data.inCombat && (this.data.inCombat = !0,
                    this.node.emit(s.EnterCombat)),
                    this.timer = 0)
                }
                ,
                n.exitCombat = function() {
                    this.data && this.data.inCombat && (this.data.inCombat = !1,
                    this.node.emit(s.ExitCombat))
                }
                ,
                a
            }(r)) || h);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotCharacterOverridesData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, i, r, a, n;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.createClass,
            r = e.initializerDefineProperty
        }
        , function(e) {
            a = e.cclegacy,
            n = e._decorator
        }
        ],
        execute: function() {
            var l, o, u, h, s, c, p, g, f, m, b, d, v, y, D, w, M, C, k, z;
            a._RF.push({}, "4d7f06KNkNMZ5GocK9w8Fce", "BotCharacterOverridesData", void 0);
            var R = n.ccclass
              , x = n.property;
            e("BotCharacterOverridesData", (l = R("BotCharacterOverridesData"),
            o = x({
                min: 10
            }),
            u = x({
                min: 1
            }),
            h = x({
                min: 0,
                step: .05,
                range: [0, 1],
                slide: !0
            }),
            s = x({
                min: .1
            }),
            c = x({
                min: 0
            }),
            p = x({
                min: .2
            }),
            g = x({
                min: .2
            }),
            f = x({
                min: 0,
                step: .05,
                range: [0, 1],
                slide: !0
            }),
            l((d = t((b = function() {
                function e() {
                    r(this, "shouldOverride", d, this),
                    r(this, "healthMax", v, this),
                    r(this, "healthRegenRate", y, this),
                    r(this, "healthLevelMultiplier", D, this),
                    r(this, "speed", w, this),
                    r(this, "exitCombatCooldown", M, this),
                    r(this, "areaDamage", C, this),
                    r(this, "areaDamageInterval", k, this),
                    r(this, "damageLevelMultiplier", z, this)
                }
                return i(e, [{
                    key: "ShouldOverride",
                    get: function() {
                        return this.shouldOverride
                    }
                }, {
                    key: "HealthMax",
                    get: function() {
                        return this.healthMax
                    }
                }, {
                    key: "HealthRegenRate",
                    get: function() {
                        return this.healthRegenRate
                    }
                }, {
                    key: "HealthLevelMultiplier",
                    get: function() {
                        return this.healthLevelMultiplier
                    }
                }, {
                    key: "Speed",
                    get: function() {
                        return this.speed
                    }
                }, {
                    key: "ExitCombatCooldown",
                    get: function() {
                        return this.exitCombatCooldown
                    }
                }, {
                    key: "AreaDamage",
                    get: function() {
                        return this.areaDamage
                    }
                }, {
                    key: "AreaDamageInterval",
                    get: function() {
                        return this.areaDamageInterval
                    }
                }, {
                    key: "DamageLevelMultiplier",
                    get: function() {
                        return this.damageLevelMultiplier
                    }
                }]),
                e
            }()).prototype, "shouldOverride", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            v = t(b.prototype, "healthMax", [o], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1e3
                }
            }),
            y = t(b.prototype, "healthRegenRate", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 75
                }
            }),
            D = t(b.prototype, "healthLevelMultiplier", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .15
                }
            }),
            w = t(b.prototype, "speed", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3.5
                }
            }),
            M = t(b.prototype, "exitCombatCooldown", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 5
                }
            }),
            C = t(b.prototype, "areaDamage", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 120
                }
            }),
            k = t(b.prototype, "areaDamageInterval", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1.25
                }
            }),
            z = t(b.prototype, "damageLevelMultiplier", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .1
                }
            }),
            m = b)) || m));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIAttackingState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./AIState.ts", "./AIEnums.ts"], (function(t) {
    "use strict";
    var a, e, i, r, n, c, o, s, h, l, g;
    return {
        setters: [function(t) {
            a = t.inheritsLoose,
            e = t.defineProperty,
            i = t.assertThisInitialized,
            r = t.createClass
        }
        , function(t) {
            n = t.cclegacy,
            c = t._decorator,
            o = t.Vec3
        }
        , function(t) {
            s = t.logger,
            h = t.LogCategory
        }
        , function(t) {
            l = t.AIState
        }
        , function(t) {
            g = t.AIStateList
        }
        ],
        execute: function() {
            var d;
            n._RF.push({}, "4de2cmtNQdNopj4mTH1Hgti", "AIAttackingState", void 0);
            var u = c.ccclass;
            c.property,
            t("AIAttackingState", u("AIAttackingState")(d = function(t) {
                function n() {
                    for (var a, r = arguments.length, n = new Array(r), c = 0; c < r; c++)
                        n[c] = arguments[c];
                    return a = t.call.apply(t, [this].concat(n)) || this,
                    e(i(a), "currentHealth", void 0),
                    e(i(a), "originalTarget", void 0),
                    a
                }
                a(n, t);
                var c = n.prototype;
                return c.stateEnter = function() {
                    var a;
                    t.prototype.stateEnter.call(this),
                    this.originalTarget = this.characterBlackboard.target,
                    this.currentHealth = this.characterBlackboard.health
                    // console.log(this.node.name + " Decided to attack  " + (null === (a = this.originalTarget) || void 0 === a ? void 0 : a.name) + "!", h.AI)
                }
                ,
                c.stateUpdate = function(a) {
                    t.prototype.stateUpdate.call(this, a);
                    var e = this.characterBlackboard.target
                      , i = this.characterBlackboard.currentWeaponObject.Range - this.brain.data.genericData.minimumConfrontationDistance
                      , r = !1;
                    if (this.brain.isTargetValid(e)) {
                        var n = new o(this.node.worldPosition);
                        if (r = new o(e.worldPosition).subtract(n).length() > i,
                        this.minimumTimeHasElapsed()) {
                            if (this.characterBlackboard.health < this.currentHealth && Math.random() < this.brain.data.attackingData.fleeingPercentage)
                                return void this.brain.changeState(g.Fleeing);
                            if (this.characterBlackboard.isReloading && Math.random() < this.brain.data.attackingData.sideStepPercentage)
                                return void this.brain.changeState(g.Reloading);
                            if (e != this.originalTarget || r)
                                return this.aiBlackboard.chaseTarget || Math.random() < this.brain.data.attackingData.chasePercentage ? (this.aiBlackboard.chaseTarget = this.originalTarget,
                                void this.brain.changeState(g.Chasing)) : (console.log("Target to far away and god said to not chase. Going to idle", h.AI),
                                void this.brain.changeState(g.Idle))
                        }
                        this.currentHealth = this.characterBlackboard.health,
                        this.brain.setDirection(0, 0)
                    } else
                        this.brain.changeState(g.Idle)
                }
                ,
                r(n, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return this.brain.data.attackingData.minimumTimeInState
                    }
                }]),
                n
            }(l)) || d);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/GSGameReady.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, n, o, r, i;
    return {
        setters: [function(e) {
            t = e.inheritsLoose
        }
        , function(e) {
            n = e.cclegacy,
            o = e._decorator,
            r = e.Component
        }
        , function(e) {
            i = e.logger
        }
        ],
        execute: function() {
            var a;
            n._RF.push({}, "4e629xfplpBipI21h+W6bER", "GSGameReady", void 0);
            var c = o.ccclass;
            o.property,
            e("GSGameReady", c("GSGameReady")(a = function(e) {
                function n() {
                    return e.apply(this, arguments) || this
                }
                return t(n, e),
                n.prototype.start = function() {
                    if ("undefined" != typeof GAMESNACKS) {
                        var e = GAMESNACKS.gameReady();
                        console.log(e),
                        console.log(JSON.stringify(e))
                    }
                }
                ,
                n
            }(r)) || a);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuWeaponUpgradesPanel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./WeaponEnums.ts", "./WeaponUpgradeWidget.ts"], (function(e) {
    "use strict";
    var t, n, i, a, o, r, s, p, u, c, g, d, l, f;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            i = e.initializerDefineProperty,
            a = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            r = e._decorator,
            s = e.Component
        }
        , function(e) {
            p = e.logger,
            u = e.LogCategory,
            c = e.LogType
        }
        , function(e) {
            g = e.MetagameEvent
        }
        , function(e) {
            d = e.projectEvent
        }
        , function(e) {
            l = e.WeaponType
        }
        , function(e) {
            f = e.WeaponUpgradeWidget
        }
        ],
        execute: function() {
            var h, W, y, v, w;
            o._RF.push({}, "4e951pElDNEY74GBFX7pD1f", "MainMenuWeaponUpgradesPanel", void 0);
            var M = r.ccclass
              , P = r.property;
            e("MainMenuWeaponUpgradesPanel", (h = M("MainMenuWeaponUpgradesPanel"),
            W = P([f]),
            h((w = t((v = function(e) {
                function t() {
                    for (var t, n = arguments.length, o = new Array(n), r = 0; r < n; r++)
                        o[r] = arguments[r];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    i(a(t), "weaponWidgets", w, a(t)),
                    t
                }
                n(t, e);
                var o = t.prototype;
                return o.start = function() {
                  //xz 武器升级界面
                    this.updateWidgets(),
                    d.on(g.WeaponUpgradePurchaseSuccess, this.updateWidgets, this),
                    d.on(g.CurrencyChanged, this.updateWidgets, this)
                }
                ,
                o.onDestroy = function() {
                    d.off(g.WeaponUpgradePurchaseSuccess, this.updateWidgets, this),
                    d.off(g.CurrencyChanged, this.updateWidgets, this)
                }
                ,
                o.updateWidgets = function() {
                    if (null != this.weaponWidgets && 0 != this.weaponWidgets.length) {
                        var e = 0
                          , t = 0;
                        for (var n in l) {
                            if ("Debug" != n && "Basic" != n) {
                                if (null == this.weaponWidgets[e]) {
                                    console.log("Missing weapon widget: " + e, u.UI, c.Error);
                                    continue
                                }
                                this.weaponWidgets[e].setup(t),
                                e++
                            }
                            t++
                        }
                    } else
                        console.log("Invalid weapon widgets", u.UI, c.Error)
                }
                ,
                t
            }(s)).prototype, "weaponWidgets", [W], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            y = v)) || y));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CurrencyRewardWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(e) {
    "use strict";
    var n, t, i, r, o, a, c, s, l, u, d, p, y, f, g;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            i = e.initializerDefineProperty,
            r = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            c = e.Label,
            s = e.Animation,
            l = e.instantiate,
            u = e.director,
            d = e.Canvas,
            p = e.Component
        }
        , function(e) {
            y = e.UIEventType,
            f = e.CurrencyRewardTweenMode
        }
        , function(e) {
            g = e.projectEvent
        }
        ],
        execute: function() {
            var v, w, b, m, h, C, R;
            o._RF.push({}, "4f4c1U2g69P1bb47LNZf29U", "CurrencyRewardWidget", void 0);
            var L = a.ccclass
              , P = a.property;
            e("CurrencyRewardWidget", (v = L("CurrencyRewardWidget"),
            w = P(c),
            b = P({
                type: s,
                tooltip: "Used when not going to currency widget."
            }),
            v((C = n((h = function(e) {
                function n() {
                    for (var n, t = arguments.length, o = new Array(t), a = 0; a < t; a++)
                        o[a] = arguments[a];
                    return n = e.call.apply(e, [this].concat(o)) || this,
                    i(r(n), "missionRewardLabel", C, r(n)),
                    i(r(n), "animationLocal", R, r(n)),
                    n
                }
                return t(n, e),
                n.spawn = function(e, t, i, r, o) {
                    void 0 === r && (r = !1),
                    void 0 === o && (o = null);
                    var a = l(e);
                    if (!o) {
                        var c = u.getScene()
                          , s = null == c ? void 0 : c.getComponentsInChildren(d);
                        s && s.forEach((function(e) {
                            e && e.enabled && (o = e.node)
                        }
                        ))
                    }
                    a.setParent(o),
                    a.setWorldPosition(i);
                    var p = a.getComponent(n);
                    p && p.setup(t, !r),
                    r && g.emit(y.CurrencyRewardSpawned, a, f.Generic)
                }
                ,
                n.prototype.setup = function(e, n) {
                    void 0 === n && (n = !1),
                    this.missionRewardLabel.string = "+" + e.toFixed(),
                    n && this.animationLocal.play()
                }
                ,
                n
            }(p)).prototype, "missionRewardLabel", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            R = n(h.prototype, "animationLocal", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            m = h)) || m));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestTriggerEvents.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(t) {
    "use strict";
    var e, r, n, o, i, s;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            r = t.cclegacy,
            n = t._decorator,
            o = t.Collider,
            i = t.Component
        }
        , function(t) {
            s = t.logger
        }
        ],
        execute: function() {
            var g;
            r._RF.push({}, "50318TE2pVJ8IUWMYpzFHQe", "TestTriggerEvents", void 0);
            var c = n.ccclass;
            n.property,
            t("TestTriggerEvents", c("TestTriggerEvents")(g = function(t) {
                function r() {
                    return t.apply(this, arguments) || this
                }
                e(r, t);
                var n = r.prototype;
                return n.start = function() {
                    console.log("Start of test trigger events");
                    var t = this.getComponent(o);
                    console.log("collier is: " + t),
                    null == t || t.on("onTriggerEnter", this.onTrigger, this),
                    null == t || t.on("onTriggerExit", this.onTrigger, this)
                }
                ,
                n.onTrigger = function(t) {}
                ,
                r
            }(i)) || g);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TweenNodeScale.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenBase.ts"], (function(e) {
    "use strict";
    var t, a, i, r, s, n, o, l, c;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            a = e.inheritsLoose,
            i = e.initializerDefineProperty,
            r = e.assertThisInitialized
        }
        , function(e) {
            s = e.cclegacy,
            n = e._decorator,
            o = e.Vec3,
            l = e.tween
        }
        , function(e) {
            c = e.TweenBase
        }
        ],
        execute: function() {
            var u, h, p, d, y, v, S, w;
            s._RF.push({}, "51797SLCtRNZoTdnkNUn4SF", "TweenNodeScale", void 0);
            var f = n.ccclass
              , g = n.property
              , b = n.menu;
            e("TweenNodeScale", (u = f("TweenNodeScale"),
            h = b("Tween/Scale"),
            p = g({
                type: o
            }),
            d = g({
                type: o
            }),
            u(y = h((S = t((v = function(e) {
                function t() {
                    for (var t, a = arguments.length, s = new Array(a), n = 0; n < a; n++)
                        s[n] = arguments[n];
                    return t = e.call.apply(e, [this].concat(s)) || this,
                    i(r(t), "valueStart", S, r(t)),
                    i(r(t), "valueEnd", w, r(t)),
                    t
                }
                a(t, e);
                var s = t.prototype;
                return s.onLoad = function() {
                    e.prototype.onLoad.call(this),
                    this.useCustomStartValue ? this.target.setScale(this.valueStart) : this.valueStart.set(this.target.scale),
                    this.useRelativeValue ? (this.tweenCache = l(this.target).delay(this.delay).by(this.duration, {
                        scale: this.valueEnd
                    }, this.options).repeat(1),
                    this.tweenReverseCache = l(this.target).delay(this.delay).by(this.duration, {
                        scale: this.valueStart
                    }, this.options).repeat(1)) : (this.tweenCache = l(this.target).delay(this.delay).to(this.duration, {
                        scale: this.valueEnd
                    }, this.options).repeat(1),
                    this.tweenReverseCache = l(this.target).delay(this.delay).to(this.duration, {
                        scale: this.valueStart
                    }, this.options).repeat(1))
                }
                ,
                s.reset = function() {
                    this.target.setScale(this.valueStart)
                }
                ,
                t
            }(c)).prototype, "valueStart", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new o
                }
            }),
            w = t(v.prototype, "valueEnd", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new o(1,1,1)
                }
            }),
            y = v)) || y) || y));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/IMap.ts", ["cc"], (function() {
    "use strict";
    var t;
    return {
        setters: [function(e) {
            t = e.cclegacy
        }
        ],
        execute: function() {
            t._RF.push({}, "54e7dp6lR1JzpJHbB080fTv", "IMap", void 0),
            t._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TweenNodePosition.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenBase.ts"], (function(t) {
    "use strict";
    var e, i, n, o, s, a, r, u, l;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            s = t.cclegacy,
            a = t._decorator,
            r = t.Vec3,
            u = t.tween
        }
        , function(t) {
            l = t.TweenBase
        }
        ],
        execute: function() {
            var h, c, p, d, y, v, w, f;
            s._RF.push({}, "56c57iTiNFFxrpOPI0QZn+c", "TweenNodePosition", void 0);
            var g = a.ccclass
              , P = a.property
              , b = a.menu;
            t("TweenNodePosition", (h = g("TweenNodePosition"),
            c = b("Tween/Position"),
            p = P({
                type: r
            }),
            d = P(r),
            h(y = c((w = e((v = function(t) {
                function e() {
                    for (var e, i = arguments.length, s = new Array(i), a = 0; a < i; a++)
                        s[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(s)) || this,
                    n(o(e), "valueStart", w, o(e)),
                    n(o(e), "valueEnd", f, o(e)),
                    e
                }
                i(e, t);
                var s = e.prototype;
                return s.onLoad = function() {
                    t.prototype.onLoad.call(this),
                    this.useCustomStartValue ? this.target.setPosition(this.valueStart) : this.valueStart.set(this.target.position),
                    this.useRelativeValue ? (this.tweenCache = u(this.target).delay(this.delay).by(this.duration, {
                        position: this.valueEnd
                    }, this.options).repeat(1),
                    this.tweenReverseCache = u(this.target).delay(this.delay).by(this.duration, {
                        position: this.valueStart
                    }, this.options).repeat(1)) : (this.tweenCache = u(this.target).delay(this.delay).to(this.duration, {
                        position: this.valueEnd
                    }, this.options).repeat(1),
                    this.tweenReverseCache = u(this.target).delay(this.delay).to(this.duration, {
                        position: this.valueStart
                    }, this.options).repeat(1))
                }
                ,
                s.reset = function() {
                    this.target.setPosition(this.valueStart)
                }
                ,
                e
            }(l)).prototype, "valueStart", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new r
                }
            }),
            f = e(v.prototype, "valueEnd", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new r(1,1,1)
                }
            }),
            y = v)) || y) || y));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletShotgun.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./WeaponEnums.ts", "./Bullet.ts"], (function(t) {
    "use strict";
    var e, n, u, r, o, l, s, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            n = t.defineProperty,
            u = t.assertThisInitialized,
            r = t.createClass
        }
        , function(t) {
            o = t.cclegacy,
            l = t._decorator
        }
        , function(t) {
            s = t.WeaponBulletType
        }
        , function(t) {
            c = t.Bullet
        }
        ],
        execute: function() {
            var i;
            o._RF.push({}, "5789dC8oP1GKKJADd1VwG2U", "BulletShotgun", void 0);
            var a = l.ccclass;
            l.property,
            t("BulletShotgun", a("BulletShotgun")(i = function(t) {
                function o() {
                    for (var e, r = arguments.length, o = new Array(r), l = 0; l < r; l++)
                        o[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    n(u(e), "_type", s.Shotgun),
                    e
                }
                return e(o, t),
                r(o, [{
                    key: "type",
                    get: function() {
                        return this._type
                    }
                }]),
                o
            }(c)) || i);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TutorialStepBase.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./TweenCollection.ts", "./UITrackWorldNode.ts"], (function(e) {
    "use strict";
    var i, t, n, o, r, a, l, u, c, s, p, d, h;
    return {
        setters: [function(e) {
            i = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            n = e.initializerDefineProperty,
            o = e.assertThisInitialized
        }
        , function(e) {
            r = e.cclegacy,
            a = e._decorator,
            l = e.Node,
            u = e.Component
        }
        , function(e) {
            c = e.logger,
            s = e.LogCategory,
            p = e.LogType
        }
        , function(e) {
            d = e.TweenCollection
        }
        , function(e) {
            h = e.UITrackWorldNode
        }
        ],
        execute: function() {
            var w, f, T, v, g, y, b, S, C;
            r._RF.push({}, "582cb302aRE8py+4Nj/jLDg", "TutorialStepBase", void 0);
            var m = a.ccclass
              , N = a.property;
            e("TutorialStepBase", (w = m("TutorialStepBase"),
            f = N(l),
            T = N({
                type: d,
                formerlySerializedAs: "uiTween"
            }),
            v = N(d),
            w((b = i((y = function(e) {
                function i() {
                    for (var i, t = arguments.length, r = new Array(t), a = 0; a < t; a++)
                        r[a] = arguments[a];
                    return i = e.call.apply(e, [this].concat(r)) || this,
                    n(o(i), "uiContainer", b, o(i)),
                    n(o(i), "uiTweenShow", S, o(i)),
                    n(o(i), "uiTweenHide", C, o(i)),
                    i
                }
                t(i, e);
                var r = i.prototype;
                return r.onLoad = function() {
                    this.uiTweenShow ||console.log("Not configured tutorial volume UI.", s.Generic, p.Error),
                    this.setNodesActive(!1)
                }
                ,
                r.activate = function() {
                    var e;
                    this.setNodesActive(!0),
                    null === (e = this.uiTweenShow) || void 0 === e || e.play();
                    var i = this.uiTweenShow.getComponentInChildren(h);
                    i && (i.enabled = !0)
                }
                ,
                r.deactivate = function() {
                    var e, i = this.uiTweenShow.getComponentInChildren(h);
                    i && (i.enabled = !1),
                    this.uiTweenHide ? this.uiTweenHide.play() : null === (e = this.uiTweenShow) || void 0 === e || e.playReverse()
                }
                ,
                r.setNodesActive = function(e) {
                    this.node.children.forEach((function(i) {
                        i.active = e
                    }
                    )),
                    this.uiContainer.active = e
                }
                ,
                i
            }(u)).prototype, "uiContainer", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            S = i(y.prototype, "uiTweenShow", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = i(y.prototype, "uiTweenHide", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            g = y)) || g));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIFleeState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./Pathfinding.ts", "./AIState.ts", "./AIEnums.ts"], (function(t) {
    "use strict";
    var e, i, n, a, s, o, r, l, c, h, g;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            i = t.createClass
        }
        , function(t) {
            n = t.cclegacy,
            a = t._decorator,
            s = t.Vec2
        }
        , function(t) {
            o = t.logger,
            r = t.LogCategory,
            l = t.LogType
        }
        , function(t) {
            c = t.Pathfinding
        }
        , function(t) {
            h = t.AIState
        }
        , function(t) {
            g = t.AIStateList
        }
        ],
        execute: function() {
            var u;
            n._RF.push({}, "58a97b3TINONpIL0I8DM0Bs", "AIFleeState", void 0);
            var d = a.ccclass;
            a.property,
            t("AIFleeState", d("AIFleeState")(u = function(t) {
                function n() {
                    return t.apply(this, arguments) || this
                }
                e(n, t);
                var a = n.prototype;
                return a.stateEnter = function() {
                    t.prototype.stateEnter.call(this),
                    this.getFleeingPosition()
                }
                ,
                a.stateExit = function() {
                    t.prototype.stateExit.call(this)
                }
                ,
                a.stateUpdate = function(e) {
                    if (t.prototype.stateUpdate.call(this, e),
                    this.brain.reachedPathingDestination())
                        this.brain.setDirection(0, 0),
                        this.brain.changeState(g.Idle);
                    else {
                        var i = this.brain.getPathingDirection();
                        this.brain.setDirection(i.x, i.y)
                    }
                }
                ,
                a.getFleeingPosition = function() {
                    if (c.instance) {
                        var t = new s(this.node.worldPosition.x,this.node.worldPosition.z)
                          , e = new s
                          , i = new s
                          , n = 0;
                        do {
                            var a = c.instance.getValidRandomPoint();
                            i.set(a.x, a.z),
                            e.set(t.x, t.y),
                            e.subtract(i),
                            c.instance.isPointInsideOfShrinkingArea(a.x, a.z) && (o.log("Flee point is inside of shrinking area", r.AI, l.Warning),
                            e.multiplyScalar(99)),
                            e.length() < this.brain.data.fleeData.mininumFleeingDistance && (this.brain.data.fleeData.mininumFleeingDistance -= 1,
                            this.brain.data.fleeData.mininumFleeingDistance < 1 && (this.brain.data.fleeData.mininumFleeingDistance = 1)),
                            n++
                        } while (e.length() < this.brain.data.fleeData.mininumFleeingDistance && n < 100);
                        if (n >= 100)
                            return o.log("No more valid flee points.", r.AI, l.Error),
                            void this.brain.changeState(g.Wandering);
                        var h = c.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, i.x, i.y);
                        this.brain.setActivePath(i, h)
                    }
                }
                ,
                i(n, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return this.brain.data.fleeData.minimumTimeInState
                    }
                }]),
                n
            }(h)) || u);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PickupEnums.ts", ["cc"], (function(c) {
    "use strict";
    var t;
    return {
        setters: [function(c) {
            t = c.cclegacy
        }
        ],
        execute: function() {
            var e;
            c("EventPickup", void 0),
            t._RF.push({}, "5a136J8lVxJrI+hBhxNLSL3", "PickupEnums", void 0),
            function(c) {
                c.Collected = "pickup-collected"
            }(e || (e = c("EventPickup", {}))),
            t._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Weapon.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./WeaponEnums.ts", "./GlobalPlayer.ts", "./BulletPools.ts", "./CharacterEnums.ts", "./Bullet.ts"], (function(e) {
    "use strict";
    var t, i, n, r, o, a, l, u, s, p, c, h, m, f, g, b, y, w, d, v, B, R, D, P;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            n = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            o = e.defineProperty,
            a = e.createClass,
            l = e.asyncToGenerator
        }
        , function(e) {
            u = e.cclegacy,
            s = e._decorator,
            p = e.Enum,
            c = e.CCInteger,
            h = e.Vec3,
            m = e.director,
            f = e.Component
        }
        , function(e) {
            g = e.logger,
            b = e.LogCategory
        }
        , function(e) {
            y = e.ProjectEventType
        }
        , function(e) {
            w = e.projectEvent
        }
        , function(e) {
            d = e.WeaponType,
            v = e.WeaponBulletType
        }
        , function(e) {
            B = e.globalPlayer
        }
        , function(e) {
            R = e.BulletPools
        }
        , function(e) {
            D = e.EventCharacterAction
        }
        , function(e) {
            P = e.Bullet
        }
        ],
        execute: function() {
            var M, k, T, z, C, L, x, E, W, _, I, S, j, O, A, F, H, N, Z, G, J, U, V, Y, q, K, Q, X, $;
            u._RF.push({}, "5aa95OoNZNJpbRZTsj+8NvU", "Weapon", void 0);
            var ee = s.ccclass
              , te = s.property;
            e("Weapon", (M = ee("Weapon"),
            k = te({
                type: p(d)
            }),
            T = te({
                type: p(v)
            }),
            z = te({
                type: [c]
            }),
            C = te({
                min: 0
            }),
            L = te({
                min: 1,
                max: 100,
                tooltip: "Force to apply on impulse."
            }),
            x = te({
                min: .1,
                step: .05
            }),
            E = te({
                min: .1,
                step: .05
            }),
            W = te({
                range: [1, 12],
                slide: !0
            }),
            _ = te({
                range: [0, 1],
                slide: !0
            }),
            I = te({
                range: [0, 5],
                slide: !0,
                tooltip: "Cooldown between each shot routine"
            }),
            S = te({
                min: 1,
                tooltip: "How many bullet are shot for each ammo used"
            }),
            j = te({
                range: [0, 1],
                step: .05,
                slide: !0,
                tooltip: "If this weapon use more than one bullet for ammo, this will define the delay between them."
            }),
            O = te({
                min: 0,
                tooltip: "How much "
            }),
            M((H = t((F = function(e) {
                function t() {
                    for (var t, i = arguments.length, a = new Array(i), l = 0; l < i; l++)
                        a[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    n(r(t), "type", H, r(t)),
                    n(r(t), "bulletType", N, r(t)),
                    n(r(t), "rarityModifiers", Z, r(t)),
                    n(r(t), "damage", G, r(t)),
                    n(r(t), "bulletSpeed", J, r(t)),
                    n(r(t), "bulletLifetime", U, r(t)),
                    n(r(t), "ammoRecoverRate", V, r(t)),
                    n(r(t), "range", Y, r(t)),
                    n(r(t), "prepareTime", q, r(t)),
                    n(r(t), "cooldown", K, r(t)),
                    n(r(t), "bulletCount", Q, r(t)),
                    n(r(t), "timeBetweenBullets", X, r(t)),
                    n(r(t), "angleBetweenBullets", $, r(t)),
                    o(r(t), "owner", void 0),
                    o(r(t), "ownerData", void 0),
                    o(r(t), "pivot", void 0),
                    o(r(t), "scene", void 0),
                    o(r(t), "shootDirection", new h),
                    o(r(t), "metagameDamageMultiplier", 1),
                    o(r(t), "_weaponRarity", 0),
                    t
                }
                i(t, e);
                var u = t.prototype;
                return u.setup = function(e, t, i) {
                    if (this.owner = e,
                    this.ownerData = t,
                    this.pivot = i,
                    t.IsPlayer)
                        this.metagameDamageMultiplier = B.getWeaponDamageMultiplier(this.type);
                    else {
                        var n = B.getHighestLevelWeapon();
                        this.metagameDamageMultiplier = B.getWeaponDamageMultiplier(n)
                        // console.log("Found highest level weapon as " + d[n] + " with dmg multiplier " + this.metagameDamageMultiplier, b.AI)
                    }
                }
                ,
                u.onLoad = function() {
                    this.scene = m.getScene()
                }
                ,
                u.shoot = function() {
                    var e = l(regeneratorRuntime.mark((function e(t) {
                        var i, n, r, o;
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    if (null != R.instance) {
                                        e.next = 3;
                                        break
                                    }
                                    return console.log("ERROR: BulletPools is null"),
                                    e.abrupt("return");
                                case 3:
                                    if (null != this.owner) {
                                        e.next = 6;
                                        break
                                    }
                                    return console.log("ERROR: Owner is not setup in weapon."),
                                    e.abrupt("return");
                                case 6:
                                    if (!(this.prepareTime > 0)) {
                                        e.next = 9;
                                        break
                                    }
                                    return e.next = 9,
                                    this.delay(this.prepareTime);
                                case 9:
                                    i = 0;
                                case 10:
                                    if (!(i < this.bulletCount)) {
                                        e.next = 24;
                                        break
                                    }
                                    if (!(null === (n = this.ownerData) || void 0 === n ? void 0 : n.isMoving)) {
                                        e.next = 13;
                                        break
                                    }
                                    return e.abrupt("break", 24);
                                case 13:
                                    return r = this.angleBetweenBullets * Math.ceil(i / 2),
                                    i % 2 == 0 && (r = -r),
                                    r *= Math.PI / 180,
                                    h.rotateY(this.shootDirection, t, h.ZERO, r),
                                    this.shotBullet(),
                                    (this.timeBetweenBullets > 0 || 0 == i) && (this.owner.children[0].emit(D.ShootBullet, this.shootDirection),
                                    (null === (o = this.ownerData) || void 0 === o ? void 0 : o.IsPlayer) && w.emit(y.PlayerShootBullet, this.type)),
                                    e.next = 21,
                                    this.delay(this.timeBetweenBullets);
                                case 21:
                                    i++,
                                    e.next = 10;
                                    break;
                                case 24:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e, this)
                    }
                    )));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                u.shotBullet = function() {
                    if (null != R.instance && null != this.owner && null != this.ownerData) {
                        var e = R.instance.get(this.bulletType)
                          , t = e.getComponent(P);
                        if (!t)
                            return console.log("ERROR: Could not get Bullet component"),
                            R.instance.put(this.bulletType, e),
                            !1;
                        var i = this.rarityModifiers[this._weaponRarity]
                          , n = this.Damage * (1 + .05 * i + this.ownerData.DamageLevelMultiplier * this.ownerData.level);
                        this.type != d.Basic && (n *= this.metagameDamageMultiplier),
                        n = Math.round(n),
                        e.setWorldPosition(this.pivot.worldPosition),
                        t.setup(this.owner, n, this.shootDirection, this.bulletLifetime, this.bulletSpeed)
                    }
                }
                ,
                u.delay = function(e) {
                    return new Promise((function(t) {
                        return setTimeout(t, 1e3 * e)
                    }
                    ))
                }
                ,
                a(t, [{
                    key: "Damage",
                    get: function() {
                        return this.damage
                    }
                }, {
                    key: "Range",
                    get: function() {
                        return null != this.ownerData && 0 == this.ownerData.IsPlayer && this.type == d.Shotgun ? this.range + 3 : this.range
                    }
                }, {
                    key: "Cooldown",
                    get: function() {
                        return this.cooldown
                    }
                }, {
                    key: "Type",
                    get: function() {
                        return this.type
                    }
                }, {
                    key: "AmmoRecoverRate",
                    get: function() {
                        return this.ammoRecoverRate
                    }
                }, {
                    key: "BulletLifetime",
                    get: function() {
                        return this.bulletLifetime
                    }
                }, {
                    key: "weaponRarity",
                    get: function() {
                        return this._weaponRarity
                    },
                    set: function(e) {
                        e < this.rarityModifiers.length && (this._weaponRarity = e)
                    }
                }]),
                t
            }(f)).prototype, "type", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return d.Basic
                }
            }),
            N = t(F.prototype, "bulletType", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return v.Basic
                }
            }),
            Z = t(F.prototype, "rarityModifiers", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            G = t(F.prototype, "damage", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 20
                }
            }),
            J = t(F.prototype, "bulletSpeed", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 5
                }
            }),
            U = t(F.prototype, "bulletLifetime", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3
                }
            }),
            V = t(F.prototype, "ammoRecoverRate", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .4
                }
            }),
            Y = t(F.prototype, "range", [W], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 6
                }
            }),
            q = t(F.prototype, "prepareTime", [_], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .2
                }
            }),
            K = t(F.prototype, "cooldown", [I], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .4
                }
            }),
            Q = t(F.prototype, "bulletCount", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            X = t(F.prototype, "timeBetweenBullets", [j], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            $ = t(F.prototype, "angleBetweenBullets", [O], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            A = F)) || A));
            u._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponRarityData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(r) {
    "use strict";
    var t, o, e, a, n, i, c, l, s, p, u;
    return {
        setters: [function(r) {
            t = r.applyDecoratedDescriptor,
            o = r.inheritsLoose,
            e = r.initializerDefineProperty,
            a = r.assertThisInitialized
        }
        , function(r) {
            n = r.cclegacy,
            i = r._decorator,
            c = r.Color,
            l = r.Component
        }
        , function(r) {
            s = r.logger,
            p = r.LogCategory,
            u = r.LogType
        }
        ],
        execute: function() {
            var y, g, f, h, d;
            n._RF.push({}, "5b87c8bdOpJ04JEAXYPdyVT", "WeaponRarityData", void 0);
            var v = i.ccclass
              , D = i.property;
            r("WeaponRarityData", (y = v("WeaponRarityData"),
            g = D([c]),
            y((d = t((h = function(r) {
                function t() {
                    for (var t, o = arguments.length, n = new Array(o), i = 0; i < o; i++)
                        n[i] = arguments[i];
                    return t = r.call.apply(r, [this].concat(n)) || this,
                    e(a(t), "colors", d, a(t)),
                    t
                }
                return o(t, r),
                t.prototype.getColor = function(r) {
                    return r >= this.colors.length ? (console.log("Invalid rarity", p.Gameplay, u.Error),
                    c.WHITE) : this.colors[r]
                }
                ,
                t
            }(l)).prototype, "colors", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            f = h)) || f));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestGlobalPlayerData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./GlobalPlayer.ts"], (function(t) {
    "use strict";
    var e, a, o, s, l, n;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            a = t.cclegacy,
            o = t._decorator,
            s = t.Component
        }
        , function(t) {
            l = t.globalPlayer,
            n = t.Statistic
        }
        ],
        execute: function() {
            var r;
            a._RF.push({}, "5feaeb98w5EC4IebQphx1/q", "TestGlobalPlayerData", void 0);
            var c = o.ccclass;
            o.property,
            t("TestGlobalPlayerData", c("TestGlobalPlayerData")(r = function(t) {
                function a() {
                    return t.apply(this, arguments) || this
                }
                e(a, t);
                var o = a.prototype;
                return o.save = function() {
                    l.save()
                }
                ,
                o.load = function() {
                    l.load()
                }
                ,
                o.logGlobalData = function() {
                    logger.log(l)
                }
                ,
                o.addChestOpened = function() {
                    n.add(l.statistics.chestsOpened, 1),
                    logger.log(l)
                }
                ,
                o.resetCurrentChestOpened = function() {
                    n.resetCurrent(l.statistics.chestsOpened),
                    logger.log(l)
                }
                ,
                a
            }(s)) || r);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, i, a, n, r, s, o;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            i = t.defineProperty,
            a = t.assertThisInitialized,
            n = t.createClass
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator,
            o = t.Component
        }
        ],
        execute: function() {
            var c;
            r._RF.push({}, "5ffdf1MAWBOlY+GiawmBgLa", "AIState", void 0);
            var u = s.ccclass;
            s.property,
            t("AIState", u("AIState")(c = function(t) {
                function r() {
                    for (var e, n = arguments.length, r = new Array(n), s = 0; s < n; s++)
                        r[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(r)) || this,
                    i(a(e), "brain", void 0),
                    i(a(e), "characterBlackboard", void 0),
                    i(a(e), "aiBlackboard", void 0),
                    i(a(e), "stateTimer", void 0),
                    e
                }
                e(r, t);
                var s = r.prototype;
                return s.init = function(t, e, i) {
                    this.aiBlackboard = t,
                    this.characterBlackboard = e,
                    this.brain = i
                }
                ,
                s.onStateEnter = function() {
                    this.stateEnter(),
                    this.stateTimer = 0
                }
                ,
                s.onStateUpdate = function(t) {
                    this.stateTimer += t,
                    this.stateUpdate(t)
                }
                ,
                s.onStateExit = function() {
                    this.stateExit()
                }
                ,
                s.minimumTimeHasElapsed = function() {
                    return this.stateTimer >= this.minimumTimeInState
                }
                ,
                s.stateEnter = function() {}
                ,
                s.stateUpdate = function(t) {}
                ,
                s.stateExit = function() {}
                ,
                n(r, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return 0
                    }
                }]),
                r
            }(o)) || c);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletBazooka.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./Bullet.ts", "./PrefabPool.ts", "./BulletExplosion.ts"], (function(e) {
    "use strict";
    var o, t, n, i, a, l, r, s, p, u, c, f, g, h, d, y;
    return {
        setters: [function(e) {
            o = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            n = e.defineProperty,
            i = e.assertThisInitialized,
            a = e.initializerDefineProperty,
            l = e.createClass
        }
        , function(e) {
            r = e.cclegacy,
            s = e._decorator,
            p = e.Prefab,
            u = e.CCFloat
        }
        , function(e) {
            c = e.logger,
            f = e.LogCategory
        }
        , function(e) {
            g = e.WeaponBulletType
        }
        , function(e) {
            h = e.Bullet
        }
        , function(e) {
            d = e.PrefabPool
        }
        , function(e) {
            y = e.BulletExplosion
        }
        ],
        execute: function() {
            var b, B, v, m, P, x, z;
            r._RF.push({}, "60756LTWodAx4RULRPZndY5", "BulletBazooka", void 0);
            var E = s.ccclass
              , k = s.property;
            e("BulletBazooka", (b = E("BulletBazooka"),
            B = k(p),
            v = k({
                type: u,
                range: [0, 1],
                slide: !0
            }),
            b((x = o((P = function(e) {
                function o() {
                    for (var o, t = arguments.length, l = new Array(t), r = 0; r < t; r++)
                        l[r] = arguments[r];
                    return o = e.call.apply(e, [this].concat(l)) || this,
                    n(i(o), "_type", g.Bazooka),
                    a(i(o), "prefabExplosion", x, i(o)),
                    a(i(o), "explosionDamagePercentage", z, i(o)),
                    o
                }
                t(o, e);
                var r = o.prototype;
                return r.onLoad = function() {
                    var o;
                    (e.prototype.onLoad.call(this),
                    this.prefabExplosion) && (c.log("Initializing prefab pool with prefab: " + this.prefabExplosion.name + " and script name: " + y.name),
                    null === (o = d.instance) || void 0 === o || o.initialize(this.prefabExplosion, y.name))
                }
                ,
                r.onHitAnything = function() {
                    var e;
                   console.log("BulletBazooka - bullet hit something", f.Gameplay);
                    var o = null === (e = d.instance) || void 0 === e ? void 0 : e.getInScene(this.prefabExplosion);
                    if (o) {
                        var t;
                        o.setWorldPosition(this.node.worldPosition);
                        var n = o.getComponent(y);
                        null == n || n.setup(this.owner, this.damage * this.explosionDamagePercentage),
                        null === (t = d.instance) || void 0 === t || t.schedulePut(this.prefabExplosion, o, .1)
                    }
                }
                ,
                l(o, [{
                    key: "type",
                    get: function() {
                        return this._type
                    }
                }]),
                o
            }(h)).prototype, "prefabExplosion", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            z = o(P.prototype, "explosionDamagePercentage", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .3
                }
            }),
            m = P)) || m));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotGenericData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./WeaponEnums.ts"], (function(t) {
    "use strict";
    var e, i, n, o, a, r, s;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.initializerDefineProperty
        }
        , function(t) {
            n = t.cclegacy,
            o = t._decorator,
            a = t.CCFloat,
            r = t.Enum
        }
        , function(t) {
            s = t.WeaponRarity
        }
        ],
        execute: function() {
            var c, u, m, l, p, f, g, b, y, d, h;
            n._RF.push({}, "62bdaotg7xMTpjFDP99rQPp", "BotGenericData", void 0);
            var D = o.ccclass
              , w = o.property;
            t("BotGenericData", (c = D("BotGenericData"),
            u = w({
                type: a,
                tooltip: "Minimum distance to engage in confrontation. (Raw Distance from target)",
                unit: "meters"
            }),
            m = w({
                type: a,
                tooltip: "Maximum distance required to engage in confrontation. (Negative offset from weapon range)",
                unit: "meters"
            }),
            l = w({
                type: a,
                tooltip: "Minimum time spent looking for weapons before engaging in chasing after opponents",
                unit: "seconds"
            }),
            p = w({
                type: r(s),
                tooltip: "Bot will look for a weapon with at least this rarity before actively engaging in combat"
            }),
            c((b = e((g = function() {
                i(this, "minimumConfrontationDistance", b, this),
                i(this, "maximumConfrontationDistanceOffset", y, this),
                i(this, "combatReadinessCooldown", d, this),
                i(this, "minimumWeaponRarityForCombat", h, this)
            }
            ).prototype, "minimumConfrontationDistance", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1.5
                }
            }),
            y = e(g.prototype, "maximumConfrontationDistanceOffset", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            d = e(g.prototype, "combatReadinessCooldown", [l], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 10
                }
            }),
            h = e(g.prototype, "minimumWeaponRarityForCombat", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return s.Common
                }
            }),
            f = g)) || f));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PickupCollectionFeedback.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenCollection.ts", "./UITrackWorldNode.ts"], (function(e) {
    "use strict";
    var t, o, i, n, l, c, r, a, s, p, u, h;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            o = e.inheritsLoose,
            i = e.initializerDefineProperty,
            n = e.assertThisInitialized,
            l = e.defineProperty
        }
        , function(e) {
            c = e.cclegacy,
            r = e._decorator,
            a = e.ProgressBar,
            s = e.Node,
            p = e.Component
        }
        , function(e) {
            u = e.TweenCollection
        }
        , function(e) {
            h = e.UITrackWorldNode
        }
        ],
        execute: function() {
            var d, g, C, f, w, b, k, y, v, m, P;
            c._RF.push({}, "647c46uNSJHZ45gkOiSQK28", "PickupCollectionFeedback", void 0);
            var F = r.ccclass
              , S = r.property;
            e("PickupCollectionFeedback", (d = F("PickupCollectionFeedback"),
            g = S(a),
            C = S(s),
            f = S(u),
            w = S(u),
            d((y = t((k = function(e) {
                function t() {
                    for (var t, o = arguments.length, c = new Array(o), r = 0; r < o; r++)
                        c[r] = arguments[r];
                    return t = e.call.apply(e, [this].concat(c)) || this,
                    i(n(t), "pgCollection", y, n(t)),
                    i(n(t), "content", v, n(t)),
                    i(n(t), "tweenCollectionShow", m, n(t)),
                    i(n(t), "tweenCollectionHide", P, n(t)),
                    l(n(t), "tracking", void 0),
                    t
                }
                o(t, e);
                var c = t.prototype;
                return c.onLoad = function() {
                    this.tracking = this.node.getComponent(h),
                    this.content.active = !1,
                    this.pgCollection.progress = 0
                }
                ,
                c.setup = function(e) {
                    var t;
                    this.tracking || (this.tracking = this.node.getComponent(h)),
                    null === (t = this.tracking) || void 0 === t || t.setup(e)
                }
                ,
                c.show = function() {
                    this.content.active = !0,
                    this.tweenCollectionHide.stop(),
                    this.tweenCollectionShow.play()
                }
                ,
                c.hide = function() {
                    this.tweenCollectionShow.stop(),
                    this.tweenCollectionHide.play()
                }
                ,
                c.setFillRate = function(e) {
                    this.pgCollection.progress = e
                }
                ,
                t
            }(p)).prototype, "pgCollection", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = t(k.prototype, "content", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            m = t(k.prototype, "tweenCollectionShow", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = t(k.prototype, "tweenCollectionHide", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = k)) || b));
            c._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIMatchProgressBarTotalLength.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, n, o, r, i, s, a, h;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            n = t.defineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            i = t._decorator,
            s = t.ProgressBar,
            a = t.UITransform,
            h = t.Component
        }
        ],
        execute: function() {
            var c;
            r._RF.push({}, "64acdiBGL1NeZ9iWf/xO+PY", "UIMatchProgressBarTotalLength", void 0);
            var g, u = i.ccclass, p = (i.property,
            i.requireComponent), L = i.executionOrder;
            !function(t) {
                t[t.HORIZONTAL = 0] = "HORIZONTAL",
                t[t.VERTICAL = 1] = "VERTICAL",
                t[t.FILLED = 2] = "FILLED"
            }(g || (g = {}));
            t("UIMatchProgressBarTotalLength", u("UIMatchProgressBarTotalLength")(c = p(s)(c = L(310)(c = function(t) {
                function r() {
                    for (var e, r = arguments.length, i = new Array(r), s = 0; s < r; s++)
                        i[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(i)) || this,
                    n(o(e), "pg", void 0),
                    n(o(e), "uiTransform", void 0),
                    e
                }
                e(r, t);
                var i = r.prototype;
                return i.onLoad = function() {
                    this.pg = this.node.getComponent(s),
                    this.uiTransform = this.node.getComponent(a)
                }
                ,
                i.update = function() {
                    this.updateTotalLength()
                }
                ,
                i.updateTotalLength = function() {
                    this.pg && this.uiTransform && (this.pg.mode == g.HORIZONTAL ? this.uiTransform.contentSize.width != this.pg.totalLength && (this.pg.totalLength = this.uiTransform.contentSize.width) : this.pg.mode == g.VERTICAL && this.uiTransform.contentSize.height != this.pg.totalLength && (this.pg.totalLength = this.uiTransform.contentSize.height))
                }
                ,
                r
            }(h)) || c) || c) || c);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestScreenSize.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, i, o, r, a, n, l, s, c, u, p, h, g, d;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            o = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            a = e.defineProperty
        }
        , function(e) {
            n = e.cclegacy,
            l = e._decorator,
            s = e.Node,
            c = e.Camera,
            u = e.Canvas,
            p = e.Vec3,
            h = e.view,
            g = e.Component
        }
        , function(e) {
            d = e.logger
        }
        ],
        execute: function() {
            var m, y, S, w, f, z, b, v, P, I, T, N, U;
            n._RF.push({}, "692ffxWP/lL/4pH1/knM2VH", "TestScreenSize", void 0);
            var G = l.ccclass
              , C = l.property;
            e("TestScreenSize", (m = G("TestScreenSize"),
            y = C({
                type: s
            }),
            S = C({
                type: s
            }),
            w = C({
                type: c
            }),
            f = C({
                type: c
            }),
            z = C({
                type: u
            }),
            m((P = t((v = function(e) {
                function t() {
                    for (var t, i = arguments.length, n = new Array(i), l = 0; l < i; l++)
                        n[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(n)) || this,
                    o(r(t), "target", P, r(t)),
                    o(r(t), "uiNode", I, r(t)),
                    o(r(t), "camGameplay", T, r(t)),
                    o(r(t), "camUI", N, r(t)),
                    o(r(t), "canvas", U, r(t)),
                    a(r(t), "out", new p),
                    t
                }
                i(t, e);
                var n = t.prototype;
                return n.start = function() {
                    this.logSizesAndPositions(),
                    h.setResizeCallback(this.logSizesAndPositions.bind(this))
                }
                ,
                n.logSizesAndPositions = function() {
                    null != this.camGameplay && null != this.target && null != this.uiNode && null != this.uiNode.parent && (console.log("Gameplay " + this.camGameplay.screenScale + " - UI " + this.camUI.screenScale),
                   console.log("canvas size: " + h.getCanvasSize() + " getFrameSize: " + h.getFrameSize()),
                    this.camGameplay.worldToScreen(this.target.worldPosition, this.out),
                   console.log("camGameplay.worldToScreen: " + this.target.worldPosition + " - " + this.out),
                    this.camUI.worldToScreen(this.target.worldPosition, this.out),
                   console.log("camUI.worldToScreen : " + this.target.worldPosition + " - " + this.out),
                    this.camGameplay.convertToUINode(this.target.worldPosition, this.uiNode.parent, this.out),
                   console.log("camGameplay.convertToUINode : " + this.target.worldPosition + " - " + this.out),
                    this.camUI.convertToUINode(this.target.worldPosition, this.uiNode.parent, this.out),
                   console.log("camUI.convertToUINode : " + this.target.worldPosition + " - " + this.out),
                    this.uiNode.position = this.out)
                }
                ,
                t
            }(g)).prototype, "target", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = t(v.prototype, "uiNode", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            T = t(v.prototype, "camGameplay", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            N = t(v.prototype, "camUI", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            U = t(v.prototype, "canvas", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = v)) || b));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RewardedAdOpportunitySaveData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, a;
    return {
        setters: [function(e) {
            t = e.defineProperty
        }
        , function(e) {
            a = e.cclegacy
        }
        ],
        execute: function() {
            a._RF.push({}, "6de0fqRvbRG16YMinQM/CVe", "RewardedAdOpportunitySaveData", void 0);
            e("RewardedAdDailyData", function() {
                function e() {
                    t(this, "previousTime", new Date),
                    t(this, "hasClaimed", !1),
                    t(this, "claimable", !0)
                }
                return e.reset = function(e) {
                    e.hasClaimed = !1,
                    e.claimable = !0
                }
                ,
                e
            }());
            var i = e("RewardedAdAfterMatchData", function() {
                function e() {
                    t(this, "previousTime", new Date),
                    t(this, "claimedCount", 0)
                }
                return e.reset = function(e) {
                    e.claimedCount = 0
                }
                ,
                e
            }());
            t(i, "matchsPlayedInCurrentSession", 0),
            t(i, "maxClaimCount", 2),
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterModelSetup.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./GlobalPlayer.ts", "./CharacterModel.ts", "./CharacterBlackboard.ts", "./CharacterModelManager.ts"], (function(e) {
    "use strict";
    var t, a, o, r, n, i, l, c, s, d, u, p, h, f, g;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            a = e.inheritsLoose,
            o = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            n = e.defineProperty
        }
        , function(e) {
            i = e.cclegacy,
            l = e._decorator,
            c = e.Node,
            s = e.Vec3,
            d = e.Component
        }
        , function(e) {
            u = e.logger
        }
        , function(e) {
            p = e.globalPlayer
        }
        , function(e) {
            h = e.CharacterModel
        }
        , function(e) {
            f = e.CharacterBlackboard
        }
        , function(e) {
            g = e.CharacterModelManager
        }
        ],
        execute: function() {
            var v, y, C, M, P, m;
            i._RF.push({}, "6e48fzdjwVPZp4PKc3hcUP2", "CharacterModelSetup", void 0);
            var b = l.ccclass
              , k = l.property
              , S = l.executionOrder;
            e("CharacterModelSetup", (v = b("CharacterModelSetup"),
            y = S(-5),
            C = k(c),
            v(M = y((m = t((P = function(e) {
                function t() {
                    for (var t, a = arguments.length, i = new Array(a), l = 0; l < a; l++)
                        i[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(i)) || this,
                    o(r(t), "modelPivot", m, r(t)),
                    n(r(t), "data", void 0),
                    t
                }
                return a(t, e),
                t.prototype.onLoad = function() {
                    var e, t, a;
                    if (this.data = this.node.getComponent(f),
                    this.data && g.instance) {
                        var o = null;
                        if (this.data.IsPlayer) {
                            var r = p.characterModelId;
                            o = g.instance.getModel(r)
                        } else
                            o = g.instance.getRandomModel();
                        null == o && (o = g.instance.getModel(0),
                        console.log("Could not find correct model using first one.")),
                        null === (e = o) || void 0 === e || e.setParent(this.modelPivot),
                        null === (t = o) || void 0 === t || t.setPosition(s.ZERO);
                        var n = null === (a = o) || void 0 === a ? void 0 : a.getComponent(h);
                        n ? (this.data.skAnimation = n.SkAnimation,
                        this.data.weapons = n.Weapons,
                        this.data.IsPlayer ? n.applyTexture(p.characterTextureId) : n.applyRandomTexture()) : console.log("Could not setup model references to blackboard")
                    }
                }
                ,
                t
            }(d)).prototype, "modelPivot", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = P)) || M) || M));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuConfirmCharacterPurchaseOverlay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./PanelManager.ts", "./PanelEnums.ts", "./MetagameUICharacterModelData.ts"], (function(e) {
    "use strict";
    var t, a, r, n, i, o, l, c, s, u, h, f, m, d, p, b;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            a = e.inheritsLoose,
            r = e.initializerDefineProperty,
            n = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            o = e.cclegacy,
            l = e._decorator,
            c = e.Prefab,
            s = e.Label,
            u = e.Button,
            h = e.Component
        }
        , function(e) {
            f = e.MetagameEvent
        }
        , function(e) {
            m = e.projectEvent
        }
        , function(e) {
            d = e.PanelManager
        }
        , function(e) {
            p = e.PanelId
        }
        , function(e) {
            b = e.MetagameUICharacterModelData
        }
        ],
        execute: function() {
            var P, C, v, y, g, M, D, I, x, R, z, L, w;
            o._RF.push({}, "7068a8c5VlOQ5HSZtWTWBgb", "MainMenuConfirmCharacterPurchaseOverlay", void 0);
            var E = l.ccclass
              , O = l.property;
            e("MainMenuConfirmCharacterPurchaseOverlay", (P = E("MainMenuConfirmCharacterPurchaseOverlay"),
            C = O(c),
            v = O(s),
            y = O(s),
            g = O(s),
            M = O(u),
            P((x = t((I = function(e) {
                function t() {
                    for (var t, a = arguments.length, o = new Array(a), l = 0; l < a; l++)
                        o[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    r(n(t), "uiCharacterModelDataPrefab", x, n(t)),
                    r(n(t), "lName", R, n(t)),
                    r(n(t), "lRarity", z, n(t)),
                    r(n(t), "lPriceValue", L, n(t)),
                    r(n(t), "btnPurchase", w, n(t)),
                    i(n(t), "modelsData", void 0),
                    i(n(t), "modelId", 0),
                    i(n(t), "textureId", 0),
                    t
                }
                a(t, e);
                var o = t.prototype;
                return o.onLoad = function() {
                    this.modelsData = this.uiCharacterModelDataPrefab.data.getComponent(b)
                }
                ,
                o.onEnable = function() {
                    m.on(f.CharacterPurchaseConfirmation, this.onRequestConfirmation, this)
                }
                ,
                o.onDisable = function() {
                    m.off(f.CharacterPurchaseConfirmation, this.onRequestConfirmation, this)
                }
                ,
                o.onRequestConfirmation = function(e, t) {
                    var a;
                    this.modelId = e,
                    this.textureId = t;
                    var r = this.modelsData.getName(e, t);
                    this.setLabelText(this.lName, r);
                    var n = this.modelsData.getPrice(e, t);
                    this.setLabelText(this.lPriceValue, n.toFixed()),
                    this.btnPurchase.interactable = this.modelsData.canPurchase(e, t),
                    null === (a = d.instance) || void 0 === a || a.open(p.ConfirmCharacterPurchase)
                }
                ,
                o.confirmPurchase =async function() {
                    var e;
                  await  this.modelsData.purchase(this.modelId, this.textureId),
                    m.emit(f.CharacterPurchaseSuccess),
                    null === (e = d.instance) || void 0 === e || e.close(p.ConfirmCharacterPurchase)
                }
                ,
                o.setLabelText = function(e, t) {
                    e.string = t,
                    e.updateRenderData(!0)
                }
                ,
                t
            }(h)).prototype, "uiCharacterModelDataPrefab", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            R = t(I.prototype, "lName", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            z = t(I.prototype, "lRarity", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = t(I.prototype, "lPriceValue", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            w = t(I.prototype, "btnPurchase", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            D = I)) || D));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayerSpawner.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(e) {
    "use strict";
    var t, n, r, a, i, o, s, l, p, c, u, f, h, y, d, g;
    return {
        setters: [function(e) {
            t = e.defineProperty,
            n = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            a = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            s = e._decorator,
            l = e.Prefab,
            p = e.director,
            c = e.instantiate,
            u = e.Component
        }
        , function(e) {
            f = e.logger,
            h = e.LogCategory,
            y = e.LogType
        }
        , function(e) {
            d = e.ProjectEventType
        }
        , function(e) {
            g = e.projectEvent
        }
        ],
        execute: function() {
            var w, v, P, m, b, S, E;
            o._RF.push({}, "7368aVXIctPjYzexAqatz0E", "PlayerSpawner", void 0);
            var R = s.ccclass
              , j = s.property;
            e("PlayerSpawner", (w = R("PlayerSpawner"),
            v = j({
                type: l,
                tooltip: "Player prefab"
            }),
            w((E = S = function(e) {
                function n() {
                    for (var n, r = arguments.length, o = new Array(r), s = 0; s < r; s++)
                        o[s] = arguments[s];
                    return n = e.call.apply(e, [this].concat(o)) || this,
                    a(i(n), "prefab", b, i(n)),
                    t(i(n), "spawns", void 0),
                    t(i(n), "ready", !1),
                    n
                }
                r(n, e);
                var o = n.prototype;
                return o.onLoad = function() {
                    null == n.instance ? n.instance = this : this.enabled = !1
                }
                ,
                o.onDestroy = function() {
                    n.instance == this && (n.instance = null)
                }
                ,
                o.onEnable = function() {
                    g.on(d.MapSetup, this.setup, this)
                }
                ,
                o.onDisable = function() {
                    g.off(d.MapSetup, this.setup, this)
                }
                ,
                o.setup = function(e) {
                    var t = this;
                    this.spawns = new Array,
                    e.layers.forEach((function(e) {
                        if ("Spawns" == e.name)
                            for (var n = 0; n < e.data.length; n++) {
                                var r = e.data[n]
                                  , a = Number(r);
                                if (NaN != a && -1 != a && 8 == a) {
                                    var i = n % e.width
                                      , o = Math.floor(n / e.width);
                                    t.spawns.push([i, o])
                                }
                            }
                    }
                    )),
                    0 != this.spawns.length ? (this.shuffle(this.spawns),
                    this.ready = !0) : console.log("ERROR: Some error occurred while trying to get player spawns points", h.Gameplay, y.Error)
                }
                ,
                o.start = function() {
                    if (this.ready) {
                        var e = p.getScene()
                          , t = this.getRandomSpawn();
                        if (t) {
                            var n = c(this.prefab);
                            n.setParent(e),
                            n.setPosition(t[0], 0, t[1]),
                            console.log("Spawning player at " + t, h.Gameplay)
                        } else
                            console.log("Received invalid position", h.Gameplay, y.Error)
                    } else
                        console.log("ERROR enemy spawner didn't setup.", h.Gameplay, y.Error)
                }
                ,
                o.getRandomSpawn = function() {
                    if (this.spawns.length > 0) {
                        var e = this.spawns.pop();
                        return null != e ? e : null
                    }
                    return null
                }
                ,
                o.shuffle = function(e) {
                    for (var t, n, r = e.length; 0 !== r; )
                        n = Math.floor(Math.random() * r),
                        t = e[r -= 1],
                        e[r] = e[n],
                        e[n] = t;
                    return e
                }
                ,
                n
            }(u),
            t(S, "instance", void 0),
            b = n((m = E).prototype, "prefab", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = m)) || P));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MetagameUICharacterModelData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./GlobalPlayer.ts", "./CharacterModel.ts", "./MetagameEnums.ts"], (function(e) {
    "use strict";
    var t, r, n, a, l, o, i, c, u, d, s, g, h, f, v, I, y, p, U, m, k;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            n = e.initializerDefineProperty,
            a = e.assertThisInitialized,
            l = e.defineProperty,
            o = e.createForOfIteratorHelperLoose,
            i = e.createClass
        }
        , function(e) {
            c = e.cclegacy,
            u = e._decorator,
            d = e.CCInteger,
            s = e.Prefab,
            g = e.instantiate,
            h = e.MeshRenderer,
            f = e.UIMeshRenderer,
            v = e.Component
        }
        , function(e) {
            I = e.logger,
            y = e.LogCategory,
            p = e.LogType
        }
        , function(e) {
            U = e.globalPlayer
        }
        , function(e) {
            m = e.CharacterModel
        }
        , function(e) {
            k = e.Rarity
        }
        ],
        execute: function() {
            var b, M, C, x, L, P, B;
            c._RF.push({}, "74b3fZixIpIkZZyWacIwJAK", "MetagameUICharacterModelData", void 0);
            var E = u.ccclass
              , R = u.property;
            e("MetagameUICharacterModelData", (b = E("MetagameUICharacterModelData"),
            M = R({
                type: d,
                min: 1
            }),
            C = R(s),
            b((P = t((L = function(e) {
                function t() {
                    for (var t, r = arguments.length, o = new Array(r), i = 0; i < r; i++)
                        o[i] = arguments[i];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    n(a(t), "defaultModelScale", P, a(t)),
                    n(a(t), "prefabs", B, a(t)),
                    l(a(t), "errorValue", 99999),
                    t
                }
                r(t, e);
                var c = t.prototype;
                return c.getEntitlementId = function(e, t) {
                    var r = this.getUnlockable(e, t);
                    return null == r ? (console.log("Invalid index received to get UICharacter model entitlement.", y.UI, p.Error),
                    "") : r.entitlementId
                }
                ,
                c.getName = function(e, t) {
                    var r = this.getUnlockable(e, t);
                    return null == r ? (console.log("Invalid index received to get UICharacter model name.", y.UI, p.Error),
                    "") : r.name
                }
                ,
                c.getRarity = function(e, t) {
                    var r = this.getUnlockable(e, t);
                    return null == r ? (console.log("Invalid index received to get UICharacter model rarity.", y.UI, p.Error),
                    k.Common) : r.rarity
                }
                ,
                c.getTextureIdByRarity = function(e, t) {
                    var r = this.getUnlockableByRarity(e, t);
                    return null == r ? (console.log("Invalid index received to get UICharacter texture Id by rarity.", y.UI, p.Error),
                    0) : r.textureId
                }
                ,
                c.getModelInstance = function(e) {
                    if (e < 0 || e >= this.prefabs.length)
                        return console.log("Invalid index received to get UICharacter model instance.", y.UI, p.Error),
                        null;
                    var t = g(this.prefabs[e]);
                    return t.setScale(this.defaultModelScale, this.defaultModelScale, this.defaultModelScale),
                    t.layer = 23,
                    t.getComponentsInChildren(h).forEach((function(e) {
                        e.getComponent(f) || e.addComponent(f)
                    }
                    )),
                    t
                }
                ,
                c.getPlayerUIModelInstance = function() {
                    var e = U.characterModelId
                      , t = U.characterTextureId
                      , r = this.getModelInstance(e)
                      , n = null == r ? void 0 : r.getComponent(m);
                    return null == n || n.applyTexture(t),
                    r
                }
                ,
                c.isUnlocked = function(e, t) {
                    return true;
                    var r = this.getUnlockable(e, t);
                    return null == r ? (console.log("Invalid index received to check model is locked.", y.UI, p.Error),
                    !1) : !(U.level < r.unlockToBuyAtLevel) && U.hasUnlocked(r.entitlementId)
                }
                ,
                c.isLockedByLevel = function(e, t) {
                    var r = this.getUnlockable(e, t);
                    return null == r ? (console.log("Invalid index received to check isModelLockedByLevel.", y.UI, p.Error),
                    !1) : U.level < r.unlockToBuyAtLevel
                }
                ,
                c.getUnlockToBuyLevel = function(e, t) {
                    var r = this.getUnlockable(e, t);
                    return null == r ? (console.log("Invalid index received to check isModelLockedByLevel.", y.UI, p.Error),
                    this.errorValue) : r.unlockToBuyAtLevel
                }
                ,
                c.getPrice = function(e, t) {
                    var r = this.getUnlockable(e, t);
                    return null == r ? (console.log("Invalid index received to get model price.", y.UI, p.Error),
                    this.errorValue) : this.getPriceByRarity(r.rarity)
                }
                ,
                c.canPurchase = function(e, t) {
                    return U.currency > this.getPrice(e, t)
                }
                ,
                c.purchase =async function(e, t) {
                  await  U.purchaseCharacter(this.getEntitlementId(e, t), this.getPrice(e, t))
                }
                ,
                c.getUnlockable = function(e, t) {
                    for (var r, n = o(U.charactersUnlockables); !(r = n()).done; ) {
                        var a = r.value;
                        if (a.modelId == e && a.textureId == t)
                            return a
                    }
                    return null
                }
                ,
                c.getUnlockableByRarity = function(e, t) {
                    for (var r, n = o(U.charactersUnlockables); !(r = n()).done; ) {
                        var a = r.value;
                        if (a.modelId == e && a.rarity == t)
                            return a
                    }
                    return null
                }
                ,
                c.getPriceByRarity = function(e) {
                    return this.prices[e]
                }
                ,
                i(t, [{
                    key: "ModelCount",
                    get: function() {
                        return this.prefabs.length
                    }
                }, {
                    key: "TotalCount",
                    get: function() {
                        return U.charactersUnlockables.length
                    }
                }, {
                    key: "prices",
                    get: function() {
                        return U.rarityPrices
                    }
                }]),
                t
            }(v)).prototype, "defaultModelScale", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 300
                }
            }),
            B = t(L.prototype, "prefabs", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            x = L)) || x));
            c._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CheatFinishMatch.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GameplayEnums.ts", "./CharacterBlackboard.ts", "./MatchController.ts"], (function(t) {
    "use strict";
    var e, a, n, i, c, s, r, h, o, l, f, u, C;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            a = t.defineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            i = t.cclegacy,
            c = t._decorator,
            s = t.macro,
            r = t.Component
        }
        , function(t) {
            h = t.logger
        }
        , function(t) {
            o = t.ProjectEventType
        }
        , function(t) {
            l = t.projectEvent
        }
        , function(t) {
            f = t.MatchState
        }
        , function(t) {
            u = t.CharacterBlackboard
        }
        , function(t) {
            C = t.MatchController
        }
        ],
        execute: function() {
            var m;
            i._RF.push({}, "75f3b8nsXpIlr6ODFFX3tRE", "CheatFinishMatch", void 0);
            var p = c.ccclass
              , b = (c.property,
            c.executionOrder);
            t("CheatFinishMatch", p("CheatFinishMatch")(m = b(-10)(m = function(t) {
                function i() {
                    for (var e, i = arguments.length, c = new Array(i), s = 0; s < i; s++)
                        c[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(c)) || this,
                    a(n(e), "allCharacters", []),
                    a(n(e), "bots", []),
                    a(n(e), "player", void 0),
                    e
                }
                e(i, t);
                var c = i.prototype;
                return c.onEnable = function() {}
                ,
                c.onDisable = function() {}
                ,
                c.onCharacterSpawn = function(t) {
                    null == this.allCharacters && (this.allCharacters = new Array),
                    null == this.bots && (this.bots = new Array),
                    this.allCharacters.push(t);
                    var e = t.getComponentInChildren(u);
                    (null == e ? void 0 : e.IsPlayer) ? this.player = t : this.bots.push(t)
                }
                ,
                c.finishAtPlacement = function(t, e) {
                    var a = Number(e);
                    1 != isNaN(a) ? this.finishMatchAtPlacement(a) : console.log("ERROR: Not configured correctly.")
                }
                ,
                c.onCheatKeyDown = function(t) {
                    switch (t.keyCode) {
                    case s.KEY[1]:
                        this.finishMatchAtPlacement(1);
                        break;
                    case s.KEY[2]:
                        this.finishMatchAtPlacement(2);
                        break;
                    case s.KEY[3]:
                        this.finishMatchAtPlacement(3);
                        break;
                    case s.KEY[4]:
                        this.finishMatchAtPlacement(4);
                        break;
                    case s.KEY[5]:
                        this.finishMatchAtPlacement(5);
                        break;
                    case s.KEY[6]:
                        this.finishMatchAtPlacement(6);
                        break;
                    case s.KEY[7]:
                        this.finishMatchAtPlacement(7);
                        break;
                    case s.KEY[8]:
                        this.finishMatchAtPlacement(8);
                        break;
                    case s.KEY[9]:
                        this.finishMatchAtPlacement(9);
                        break;
                    case s.KEY[0]:
                        this.finishMatchAtPlacement(10)
                    }
                    if (t.keyCode == s.KEY.o)
                        for (var e = 0; e < this.allCharacters.length; e++)
                            l.emit(o.CharacterDeath, this.allCharacters[e])
                }
                ,
                c.finishMatchAtPlacement = function(t) {
                    if (C.instance && C.instance.state == f.Runing) {
                        for (var e = this.allCharacters.length - t, a = 0; a < e; a++)
                            l.emit(o.CharacterDeath, this.bots[a]);
                        1 != t && l.emit(o.CharacterDeath, this.player)
                    } else
                        console.log("Can not cheat to finish match when it is not running.")
                }
                ,
                i
            }(r)) || m) || m);
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponPickupCollectionFeedback.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./PickupCollectionFeedback.ts"], (function(e) {
    "use strict";
    var r, t, o, i, n, l, a, s, c, u, p, h, b, w, f;
    return {
        setters: [function(e) {
            r = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            o = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            n = e.createForOfIteratorHelperLoose
        }
        , function(e) {
            l = e.cclegacy,
            a = e._decorator,
            s = e.Label,
            c = e.Sprite,
            u = e.Node,
            p = e.Color
        }
        , function(e) {
            h = e.logger
        }
        , function(e) {
            b = e.WeaponRarity,
            w = e.WeaponNames
        }
        , function(e) {
            f = e.PickupCollectionFeedback
        }
        ],
        execute: function() {
            var d, g, v, y, k, L, C, P, F, W, m, R, z, B, I, S, A, E, H;
            e("PowerLevelFeedback", void 0),
            l._RF.push({}, "774efyA43dJcJ+ZzChLRUcQ", "WeaponPickupCollectionFeedback", void 0);
            var T, D = a.ccclass, _ = a.property;
            !function(e) {
                e[e.Hide = 0] = "Hide",
                e[e.ShowBetter = 1] = "ShowBetter",
                e[e.ShowWorse = 2] = "ShowWorse"
            }(T || (T = e("PowerLevelFeedback", {})));
            e("WeaponPickupCollectionFeedback", (d = D("WeaponPickupCollectionFeedback"),
            g = _(s),
            v = _(c),
            y = _([u]),
            k = _([p]),
            L = _(u),
            C = _(c),
            P = _(p),
            F = _(p),
            d((R = r((m = function(e) {
                function r() {
                    for (var r, t = arguments.length, n = new Array(t), l = 0; l < t; l++)
                        n[l] = arguments[l];
                    return r = e.call.apply(e, [this].concat(n)) || this,
                    o(i(r), "lTitle", R, i(r)),
                    o(i(r), "sptBackground", z, i(r)),
                    o(i(r), "stars", B, i(r)),
                    o(i(r), "rarityColors", I, i(r)),
                    o(i(r), "powerLevelContainer", S, i(r)),
                    o(i(r), "sptPowerLevelArrow", A, i(r)),
                    o(i(r), "colorIsBetter", E, i(r)),
                    o(i(r), "colorIsWorse", H, i(r)),
                    r
                }
                return t(r, e),
                r.prototype.setupWeaponPickupUI = function(e, r, t) {
                    if (void 0 === t && (t = T.Hide),
                    0 == this.stars.length || this.stars.length - 1 > b.Legendary) {
                        console.log("ERROR: Miss configured stars in weapon pickup collection feedback");
                        for (var o, i = n(this.stars); !(o = i()).done; ) {
                            o.value.active = !1
                        }
                    } else
                        for (var l = 0; l < this.stars.length; l++)
                            this.stars[l].active = l <= e;
                    if (this.lTitle) {
                        var a = w[r];
                        this.lTitle.string = a,
                        this.lTitle.updateRenderData(!0)
                    }
                    switch (this.sptBackground && (0 == this.rarityColors.length || this.rarityColors.length - 1 > b.Legendary ? console.log("ERROR: Miss configured rarity colors") : this.sptBackground.color = this.rarityColors[e]),
                    t) {
                    case T.ShowBetter:
                        this.powerLevelContainer.active = !0,
                        this.powerLevelContainer.setRotationFromEuler(0, 0, 0),
                        this.sptPowerLevelArrow.color = this.colorIsBetter;
                        break;
                    case T.ShowWorse:
                        this.powerLevelContainer.active = !0,
                        this.powerLevelContainer.setRotationFromEuler(0, 0, 180),
                        this.sptPowerLevelArrow.color = this.colorIsWorse;
                        break;
                    case T.Hide:
                    default:
                        this.powerLevelContainer.active = !1
                    }
                }
                ,
                r
            }(f)).prototype, "lTitle", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            z = r(m.prototype, "sptBackground", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            B = r(m.prototype, "stars", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            I = r(m.prototype, "rarityColors", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            S = r(m.prototype, "powerLevelContainer", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            A = r(m.prototype, "sptPowerLevelArrow", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = r(m.prototype, "colorIsBetter", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new p("8ED850")
                }
            }),
            H = r(m.prototype, "colorIsWorse", [F], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new p("F93636")
                }
            }),
            W = m)) || W));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuPlayPanel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./PanelManager.ts", "./PanelEnums.ts", "./MainMenuArenaWidget.ts", "./MetagameArenaData.ts"], (function(e) {
    "use strict";
    var n, t, a, r, i, o, s, u, c, l, h, d, p, f, g, A, P, b, I;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            a = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            o = e.cclegacy,
            s = e._decorator,
            u = e.Prefab,
            c = e.Button,
            l = e.tween,
            h = e.Vec3,
            d = e.Component
        }
        , function(e) {
            p = e.UIEventType
        }
        , function(e) {
            f = e.projectEvent
        }
        , function(e) {
            g = e.globalPlayer
        }
        , function(e) {
            A = e.PanelManager
        }
        , function(e) {
            P = e.PanelId
        }
        , function(e) {
            b = e.MainMenuArenaWidget
        }
        , function(e) {
            I = e.MetagameArenaData
        }
        ],
        execute: function() {
            var y, v, x, M, m, B, C, w, D, U, k;
            o._RF.push({}, "7775axZlIlK16GnJI+i5v7O", "MainMenuPlayPanel", void 0);
            var E = s.ccclass
              , z = s.property;
            e("MainMenuPlayPanel", (y = E("MainMenuPlayPanel"),
            v = z(b),
            x = z(u),
            M = z(c),
            m = z(c),
            y((w = n((C = function(e) {
                function n() {
                    for (var n, t = arguments.length, o = new Array(t), s = 0; s < t; s++)
                        o[s] = arguments[s];
                    return n = e.call.apply(e, [this].concat(o)) || this,
                    a(r(n), "widget", w, r(n)),
                    a(r(n), "arenaData", D, r(n)),
                    a(r(n), "btnPrevious", U, r(n)),
                    a(r(n), "btnNext", k, r(n)),
                    i(r(n), "arenas", []),
                    i(r(n), "currentArenaIndex", 0),
                    n
                }
                t(n, e);
                var o = n.prototype;
                return o.onEnable = function() {
                    f.on(p.ArenaPurchaseSucccess, this.onArenaPurchaseConfirmation, this)
                }
                ,
                o.onDisable = function() {
                    f.off(p.ArenaPurchaseSucccess, this.onArenaPurchaseConfirmation, this)
                }
                ,
                o.start =async function() {
                  //xz 选关界面
                    var e = this.arenaData.data.getComponent(I);
                    this.arenas = e.Arenas,
                    this.currentArenaIndex = g.lastSelectedArenaIndex,
                  await  this.updateUI();

                    let content = cc.find("Content",this.node);
                    let top = cc.find("Top",content);
                    let button_Missions = cc.find("Button_Missions",top);
                    let Button_DebugMenu = cc.find("Button_DebugMenu",top);
                 
                    // button_Missions.active = true;
                    // // Button_DebugMenu.active = true;
                    // let soundbtn = cc.instantiate(button_Missions);
                    // soundbtn.name = "soundbtn";
                    // soundbtn.setParent(top);
                    // soundbtn.active = true;
                    // let sound_icon = soundbtn.children[0];
                    
                    // let temp = sound_icon._components[1];

                  //   cc.resources.load("test.png", cc.SpriteFrame, function (err, spriteFrame) {
                  //     if (err) return console.error(err);
                  //     temp.spriteFrame = spriteFrame;
                  // });

                //   cc.assetManager.loadRemote("assets/resources/test.png", cc.Texture2D, (err, texture) => {
                //     if (err) return console.error(err);
                //     // @ts-ignore
                //     let spriteFrame = new cc.SpriteFrame(texture);
                //     temp.spriteFrame =spriteFrame;
                //     // targetNode && (targetNode.getComponent(cc.Sprite).spriteFrame = spriteFrame);
                   
                // });

                    // let mission_pos = button_Missions.position;

                    // setTimeout(() => {
                    //   soundbtn.setPosition(-mission_pos.x,mission_pos.y,mission_pos.z);

                    // }, 1);

                    window.pocketBattleIsMute =await CoinApp.getItem("pocketBattleIsMute") ? JSON.parse(await CoinApp.getItem("pocketBattleIsMute")) : false;
                    
                    let sound_icon = window.document.getElementById('sound_icon');
                    if(sound_icon){
                      sound_icon.style.display = "block";
                      sound_icon.onclick = ()=>{
                        this.onclickSoundBtn();
                      }
                    let sound_icon_on = window.document.getElementById('sound_icon_on');
                    let sound_icon_off = window.document.getElementById('sound_icon_off');
                    sound_icon_on.style.display = "none";
                    sound_icon_off.style.display = "none";
                    if(window.pocketBattleIsMute){
                      sound_icon_off.style.display = "block";
                    }else{
                      sound_icon_on.style.display = "block";
                    }
                    }
                }
                ,
                o.onclickSoundBtn =async function(){
                  console.log("===onclickSoundBtn==");
                  let sound_icon = window.document.getElementById('sound_icon');
                  if(sound_icon){
                    
                  let sound_icon_on = window.document.getElementById('sound_icon_on');
                  let sound_icon_off = window.document.getElementById('sound_icon_off');
                  sound_icon_on.style.display = "none";
                  sound_icon_off.style.display = "none";

                  window.pocketBattleIsMute = !window.pocketBattleIsMute;

                  if(window.pocketBattleIsMute){
                    sound_icon_off.style.display = "block";
                  }else{
                    sound_icon_on.style.display = "block";
                  }
                  }
                await  CoinApp.setItem("pocketBattleIsMute",window.pocketBattleIsMute)
                },
                
                o.hideSoundBtn = function(){
                  let sound_icon = window.document.getElementById('sound_icon');
                  if(sound_icon){
                    sound_icon.style.display = "none";
                  }
                },
                o.showSoundBtn = function(){
                  let sound_icon = window.document.getElementById('sound_icon');
                  if(sound_icon){
                    sound_icon.style.display = "block";
                  }
                },
                o.onArenaPurchaseConfirmation =async function(e) {
                    var n;
                 await   g.purchaseArena(e),
                    null === (n = A.instance) || void 0 === n || n.close(P.ArenaUnlock),
                    this.updateUI()
                }
                ,
                o.nextArena = function() {
                    this.currentArenaIndex++,
                    this.updateUI()
                }
                ,
                o.previousArena = function() {
                    this.currentArenaIndex--,
                    this.updateUI()
                }
                ,
                o.onPlayButtonClicked = function() {
                  this.hideSoundBtn();
                    f.emit(p.ButtonClickPlay)
                }
                ,
                o.onMissionsButtonClicked = function(e) {
                  // if(e.name == "soundbtn"){
                  //   // CoinApp.

                  //   return;
                  // }
                    f.emit(p.ButtonClickMissions)
                }
                ,
                o.updateUI =async function() {
                    this.updateWidget(),
                   await this.selectArena(),
                    this.updateChangeArenaButtons()
                }
                ,
                o.selectArena =async function() {
                    var e = this.arenas[this.currentArenaIndex];
                    g.hasUnlocked(e.UnlockId) && (g.lastSelectedArenaIndex = this.currentArenaIndex,
                    f.emit(p.ArenaSelected, e),
                   await g.save())
                }
                ,
                o.updateWidget = function() {
                    this.widget.setup(this.arenas[this.currentArenaIndex])
                }
                ,
                o.updateChangeArenaButtons = function() {
                    0 == this.currentArenaIndex && this.toggleButton(this.btnPrevious, !1),
                    1 == this.currentArenaIndex && this.toggleButton(this.btnPrevious, !0),
                    this.currentArenaIndex == this.arenas.length - 1 && this.toggleButton(this.btnNext, !1),
                    this.currentArenaIndex == this.arenas.length - 2 && this.toggleButton(this.btnNext, !0)
                }
                ,
                o.toggleButton = function(e, n) {
                    e.interactable = n,
                    n ? l(e.node).to(.1, {
                        scale: h.ONE
                    }).repeat(1).start() : l(e.node).to(.1, {
                        scale: h.ZERO
                    }).repeat(1).start()
                }
                ,
                n
            }(d)).prototype, "widget", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            D = n(C.prototype, "arenaData", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            U = n(C.prototype, "btnPrevious", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            k = n(C.prototype, "btnNext", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            B = C)) || B));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TurretSpawner.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var e, r, n, i, a, o, s, p, u, l, f, c, h, g, y, d, w;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            r = t.inheritsLoose,
            n = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            a = t.defineProperty
        }
        , function(t) {
            o = t.cclegacy,
            s = t._decorator,
            p = t.Prefab,
            u = t.director,
            l = t.instantiate,
            f = t.Component
        }
        , function(t) {
            c = t.logger,
            h = t.LogCategory,
            g = t.LogType
        }
        , function(t) {
            y = t.ProjectEventType,
            d = t.MapTile
        }
        , function(t) {
            w = t.projectEvent
        }
        ],
        execute: function() {
            var v, b, m, S, R, T;
            o._RF.push({}, "78119WOhFpANb1eY5uFiBuR", "TurretSpawner", void 0);
            var P = s.ccclass
              , E = s.property;
            t("TurretSpawner", (v = P("TurretSpawner"),
            b = E({
                type: p,
                tooltip: "Turret prefab"
            }),
            v((R = e((S = function(t) {
                function e() {
                    for (var e, r = arguments.length, o = new Array(r), s = 0; s < r; s++)
                        o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    n(i(e), "prefab", R, i(e)),
                    n(i(e), "quantity", T, i(e)),
                    a(i(e), "spawns", void 0),
                    a(i(e), "ready", !1),
                    e
                }
                r(e, t);
                var o = e.prototype;
                return o.onEnable = function() {
                    w.on(y.MapSetup, this.setup, this)
                }
                ,
                o.onDisable = function() {
                    w.off(y.MapSetup, this.setup, this)
                }
                ,
                o.setup = function(t) {
                    var e = this;
                    this.spawns = new Array,
                    t.layers.forEach((function(t) {
                        if ("Spawns" == t.name)
                            for (var r = 0; r < t.data.length; r++) {
                                var n = t.data[r]
                                  , i = Number(n);
                                if (NaN != i && -1 != i && i == d.SpawnTurret) {
                                    var a = r % t.width
                                      , o = Math.floor(r / t.width);
                                    e.spawns.push([a, o])
                                }
                            }
                    }
                    )),
                    0 != this.spawns.length ? (this.shuffle(this.spawns),
                    this.ready = !0) :console.log("ERROR: Some error occurred while trying to get enemy spawns points")
                }
                ,
                o.start = function() {
                    if (this.ready)
                        if (this.prefab)
                            for (var t = u.getScene(), e = 0; e < this.quantity; e++) {
                                var r = this.getRandomSpawn();
                                if (r) {
                                    var n = l(this.prefab);
                                    n.setParent(t),
                                    n.setPosition(r[0], 0, r[1]),
                                    n.name += "_" + e.toFixed(),
                                   console.log("Spawning enemy at " + r)
                                } else
                                   console.log("Received invalid position")
                            }
                        else
                           console.log("Not configured turret prefab.", h.AI, g.Error);
                    else
                       console.log("ERROR enemy spawner didn't setup.")
                }
                ,
                o.getRandomSpawn = function() {
                    if (this.spawns.length > 0) {
                        var t = this.spawns.pop();
                        return null != t ? t : null
                    }
                    return null
                }
                ,
                o.shuffle = function(t) {
                    for (var e, r, n = t.length; 0 !== n; )
                        r = Math.floor(Math.random() * n),
                        e = t[n -= 1],
                        t[n] = t[r],
                        t[r] = e;
                    return t
                }
                ,
                e
            }(f)).prototype, "prefab", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            T = e(S.prototype, "quantity", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 9
                }
            }),
            m = S)) || m));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AnimationPlayProxy.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(i) {
    "use strict";
    var n, t, e, o, a, r, l, s, p, c, u;
    return {
        setters: [function(i) {
            n = i.applyDecoratedDescriptor,
            t = i.inheritsLoose,
            e = i.defineProperty,
            o = i.assertThisInitialized,
            a = i.initializerDefineProperty
        }
        , function(i) {
            r = i.cclegacy,
            l = i._decorator,
            s = i.Animation,
            p = i.AnimationClip,
            c = i.EventHandler,
            u = i.Component
        }
        ],
        execute: function() {
            var y, m, h, d, f, P, b, g, v;
            r._RF.push({}, "7b5ddv8HBRFxJ6cGX9JoHMN", "AnimationPlayProxy", void 0);
            var A = l.ccclass
              , C = l.property;
            i("AnimationPlayProxy", (y = A("AnimationPlayProxy"),
            m = C(s),
            h = C(p),
            d = C({
                type: [c],
                displayOrder: 20
            }),
            y((b = n((P = function(i) {
                function n() {
                    for (var n, t = arguments.length, r = new Array(t), l = 0; l < t; l++)
                        r[l] = arguments[l];
                    return n = i.call.apply(i, [this].concat(r)) || this,
                    e(o(n), "isPlaying", void 0),
                    a(o(n), "animation", b, o(n)),
                    a(o(n), "clip", g, o(n)),
                    a(o(n), "onComplete", v, o(n)),
                    n
                }
                t(n, i);
                var r = n.prototype;
                return r.playAnimation = function(i, n) {
                    this.isPlaying || (this.isPlaying = !0,
                    null != this.clip ? this.animation.play(this.clip.name) : this.animation.play(),
                    this.scheduleOnce(this.onAnimationComplete, this.clip.duration))
                }
                ,
                r.onAnimationComplete = function() {
                    c.emitEvents(this.onComplete, this.node),
                    this.isPlaying = !1
                }
                ,
                n
            }(u)).prototype, "animation", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            g = n(P.prototype, "clip", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = n(P.prototype, "onComplete", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            f = P)) || f));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterSoundEffects.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./CharacterEnums.ts", "./GameplayEnums.ts", "./CharacterBlackboard.ts", "./MatchController.ts", "./AudioManager.ts"], (function(t) {
    "use strict";
    var e, o, i, n, a, s, r, h, l, u, p, d, f, c, g, m, S;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            o = t.inheritsLoose,
            i = t.initializerDefineProperty,
            n = t.assertThisInitialized,
            a = t.defineProperty
        }
        , function(t) {
            s = t.cclegacy,
            r = t._decorator,
            h = t.AudioClip,
            l = t.AudioSource,
            u = t.CCFloat,
            p = t.Component
        }
        , function(t) {
            d = t.logger
        }
        , function(t) {
            f = t.EventCharacterAction
        }
        , function(t) {
            c = t.MatchState
        }
        , function(t) {
            g = t.CharacterBlackboard
        }
        , function(t) {
            m = t.MatchController
        }
        , function(t) {
            S = t.AudioManager
        }
        ],
        execute: function() {
            var v, R, y, b, T, M, C, w, F, O, I, P, z, E, A, B, x, H, V, K, W, _, D, N, k, L, G;
            s._RF.push({}, "7d9404SIwNGf6MPqZnUzZbu", "CharacterSoundEffects", void 0);
            var Z = r.ccclass
              , j = r.property;
            t("CharacterSoundEffects", (v = Z("CharacterSoundEffects"),
            R = j([h]),
            y = j([h]),
            b = j([h]),
            T = j(l),
            M = j({
                type: u,
                min: 0,
                unit: "sec"
            }),
            C = j([h]),
            w = j({
                type: u,
                min: 0,
                unit: "sec"
            }),
            F = j({
                type: u,
                min: 0,
                unit: "sec"
            }),
            O = j({
                type: u,
                min: 0,
                max: 1
            }),
            I = j({
                type: u,
                min: 0,
                max: 1
            }),
            P = j(h),
            z = j({
                type: u,
                min: 0,
                max: 1
            }),
            v((B = e((A = function(t) {
                function e() {
                    for (var e, o = arguments.length, s = new Array(o), r = 0; r < o; r++)
                        s[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(s)) || this,
                    i(n(e), "gunShots", B, n(e)),
                    i(n(e), "hitReceived", x, n(e)),
                    i(n(e), "weaponChange", H, n(e)),
                    i(n(e), "healthRegenAudioSource", V, n(e)),
                    i(n(e), "healthRegenFade", K, n(e)),
                    i(n(e), "footsteps", W, n(e)),
                    i(n(e), "footstepsIntervalMin", _, n(e)),
                    i(n(e), "footstepsIntervalMax", D, n(e)),
                    i(n(e), "footstepsPlayerVolume", N, n(e)),
                    i(n(e), "footstepsBotVolume", k, n(e)),
                    i(n(e), "playerKill", L, n(e)),
                    i(n(e), "botVolume", G, n(e)),
                    a(n(e), "data", void 0),
                    a(n(e), "regenFadeInTimer", -1),
                    a(n(e), "regenFadeOutTimer", -1),
                    a(n(e), "footstepsTimer", -1),
                    a(n(e), "footstepsTimerTarget", 1),
                    e
                }
                o(e, t);
                var s = e.prototype;
                return s.start = function() {
                    this.data = this.node.getComponent(g)
                }
                ,
                s.onEnable = function() {
                    this.node.on(f.ShootBullet, this.onShotBullet, this),
                    this.node.on(f.HitReceived, this.onHitReceived, this),
                    this.node.on(f.KilledOther, this.onKilledOther, this),
                    this.node.on(f.WeaponChange, this.onWeaponChange, this),
                    this.node.on(f.HealthRegenStart, this.onRegenStart, this),
                    this.node.on(f.HealthRegenStop, this.onRegenStop, this),
                    this.node.on(f.StartMove, this.onStartMove, this),
                    this.node.on(f.StopMove, this.onStopMove, this)
                }
                ,
                s.onDisable = function() {
                    this.node.off(f.ShootBullet, this.onShotBullet, this),
                    this.node.off(f.HitReceived, this.onHitReceived, this),
                    this.node.off(f.KilledOther, this.onKilledOther, this),
                    this.node.off(f.WeaponChange, this.onWeaponChange, this),
                    this.node.off(f.HealthRegenStart, this.onRegenStart, this),
                    this.node.off(f.HealthRegenStop, this.onRegenStop, this),
                    this.node.off(f.StartMove, this.onStartMove, this),
                    this.node.off(f.StopMove, this.onStopMove, this)
                }
                ,
                s.update = function(t) {
                    var e;
                    (null === (e = m.instance) || void 0 === e ? void 0 : e.state) == c.Runing && (this.regenFadeInTimer > -1 && (this.regenFadeInTimer += t,
                    this.healthRegenAudioSource.volume += t,
                    this.regenFadeInTimer > this.healthRegenFade && (this.regenFadeInTimer = -1)),
                    this.regenFadeOutTimer > -1 && (this.regenFadeOutTimer += t,
                    this.healthRegenAudioSource.volume -= t,
                    this.regenFadeOutTimer > this.healthRegenFade && (this.healthRegenAudioSource.stop(),
                    this.regenFadeOutTimer = -1)),
                    this.footstepsTimer > -1 && (this.footstepsTimer += t,
                    this.footstepsTimer > this.footstepsTimerTarget && (this.updateFootstepsTimerTarget(),
                    this.playFootstep())))
                }
                ,
                s.onShotBullet = function() {
                    var t;
                    if (null != this.gunShots)
                        if (0 != this.gunShots.length) {
                            var e = Math.floor(Math.random() * this.gunShots.length);
                            null != this.gunShots[e] ? this.data && (null === (t = S.instance) || void 0 === t || t.playSpatialSoundOneShot(this.gunShots[e], this.node.parent.worldPosition, this.data.IsPlayer ? 1 : this.botVolume)) :console.log("ERROR: null gun shot sound")
                        } else
                           console.log("ERROR: Not configured gun shots sfx")
                }
                ,
                s.onHitReceived = function() {
                    var t;
                    if (null != this.hitReceived)
                        if (0 != this.hitReceived.length) {
                            var e = Math.floor(Math.random() * this.hitReceived.length);
                            null != this.hitReceived[e] ? this.data && (null === (t = S.instance) || void 0 === t || t.playSpatialSoundOneShot(this.hitReceived[e], this.node.parent.worldPosition, this.data.IsPlayer ? 1 : this.botVolume)) :console.log("ERROR: null gun shot sound")
                        } else
                           console.log("ERROR: Not configured gun shots sfx")
                }
                ,
                s.onKilledOther = function() {
                    var t;
                    this.data && this.data.IsPlayer && (null === (t = S.instance) || void 0 === t || t.playSpatialSoundOneShot(this.playerKill, this.node.parent.worldPosition))
                }
                ,
                s.onWeaponChange = function(t) {
                    if (this.data && this.data.IsPlayer && this.weaponChange && 0 != this.weaponChange.length && !(this.weaponChange.length < t.Type - 1)) {
                        var e = this.weaponChange[t.Type];
                        S.instance.playOneShot(e, .7)
                    }
                }
                ,
                s.onRegenStart = function() {
                    this.data && this.data.IsPlayer && S.instance.isAudioEnabled && (this.healthRegenAudioSource.volume = 0,
                    this.healthRegenAudioSource.play(),
                    this.regenFadeInTimer = 0)
                }
                ,
                s.onRegenStop = function() {
                    this.regenFadeOutTimer = 0
                }
                ,
                s.onStartMove = function() {
                    this.data && (this.footstepsTimer = 0)
                }
                ,
                s.onStopMove = function() {
                    this.footstepsTimer = -1
                }
                ,
                s.updateFootstepsTimerTarget = function() {
                    this.footstepsTimerTarget = this.footstepsIntervalMin + Math.random() * this.footstepsIntervalMax,
                    -1 != this.footstepsTimer && (this.footstepsTimer = 0)
                }
                ,
                s.playFootstep = function() {
                    var t;
                    if (null != this.footsteps)
                        if (0 != this.footsteps.length) {
                            var e = Math.floor(Math.random() * this.footsteps.length);
                            null != this.footsteps[e] ? this.data && (null === (t = S.instance) || void 0 === t || t.playSpatialSoundOneShot(this.footsteps[e], this.node.parent.worldPosition, this.data.IsPlayer ? this.footstepsPlayerVolume : this.footstepsBotVolume)) :console.log("ERROR: null gun shot sound")
                        } else
                           console.log("ERROR: Not configured gun shots sfx")
                }
                ,
                e
            }(p)).prototype, "gunShots", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            x = e(A.prototype, "hitReceived", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            H = e(A.prototype, "weaponChange", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            V = e(A.prototype, "healthRegenAudioSource", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            K = e(A.prototype, "healthRegenFade", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .3
                }
            }),
            W = e(A.prototype, "footsteps", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            _ = e(A.prototype, "footstepsIntervalMin", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .2
                }
            }),
            D = e(A.prototype, "footstepsIntervalMax", [F], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .2
                }
            }),
            N = e(A.prototype, "footstepsPlayerVolume", [O], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .3
                }
            }),
            k = e(A.prototype, "footstepsBotVolume", [I], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .12
                }
            }),
            L = e(A.prototype, "playerKill", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            G = e(A.prototype, "botVolume", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .3
                }
            }),
            E = A)) || E));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayerUIModel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./MetagameUICharacterModelData.ts", "./RotateCharacterModel.ts"], (function(e) {
    "use strict";
    var t, a, r, o, i, n, l, c, s, u, p;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            a = e.inheritsLoose,
            r = e.initializerDefineProperty,
            o = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            n = e.cclegacy,
            l = e._decorator,
            c = e.Prefab,
            s = e.Component
        }
        , function(e) {
            u = e.MetagameUICharacterModelData
        }
        , function(e) {
            p = e.RotateCharacterModel
        }
        ],
        execute: function() {
            var d, f, h, y, M, v, P;
            n._RF.push({}, "7f99c2bBNZHZroIQiZNkKoX", "PlayerUIModel", void 0);
            var b = l.ccclass
              , g = l.property;
            e("PlayerUIModel", (d = b("PlayerUIModel"),
            f = g(c),
            h = g(p),
            d((v = t((M = function(e) {
                function t() {
                    for (var t, a = arguments.length, n = new Array(a), l = 0; l < a; l++)
                        n[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(n)) || this,
                    r(o(t), "uiCharacterModelDataPrefab", v, o(t)),
                    r(o(t), "pivot", P, o(t)),
                    i(o(t), "modelsData", void 0),
                    t
                }
                a(t, e);
                var n = t.prototype;
                return n.onLoad = function() {
                    this.modelsData = this.uiCharacterModelDataPrefab.data.getComponent(u)
                }
                ,
                n.setup = function() {
                    var e = this.modelsData.getPlayerUIModelInstance();
                    null == e || e.setParent(this.pivot.node),
                    this.pivot.targetToRotate = e
                }
                ,
                t
            }(s)).prototype, "uiCharacterModelDataPrefab", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = t(M.prototype, "pivot", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = M)) || y));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/GSOnMatchFinish.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(n) {
    "use strict";
    var t, e, i, o, s, c;
    return {
        setters: [function(n) {
            t = n.inheritsLoose
        }
        , function(n) {
            e = n.cclegacy,
            i = n._decorator,
            o = n.Component
        }
        , function(n) {
            s = n.ProjectEventType
        }
        , function(n) {
            c = n.projectEvent
        }
        ],
        execute: function() {
            var h;
            e._RF.push({}, "7fd34bSu+VGn5RWZN51aRtH", "GSOnMatchFinish", void 0);
            var r = i.ccclass;
            i.property,
            n("GSOnMatchFinish", r("GSOnMatchFinish")(h = function(n) {
                function e() {
                    return n.apply(this, arguments) || this
                }
                t(e, n);
                var i = e.prototype;
                return i.onEnable = function() {
                    c.on(s.MatchFinish, this.onMatchFinish, this),
                    c.on(s.PlayerWinMatch, this.onPlayerWin, this),
                    c.on(s.PlayerLoseMatch, this.onPlayerLose, this)
                }
                ,
                i.onDisable = function() {
                    c.off(s.MatchFinish, this.onMatchFinish, this),
                    c.off(s.PlayerWinMatch, this.onPlayerWin, this),
                    c.off(s.PlayerLoseMatch, this.onPlayerLose, this)
                }
                ,
                i.onPlayerWin = function() {
                    "undefined" != typeof GAMESNACKS && GAMESNACKS.levelComplete(0)
                }
                ,
                i.onPlayerLose = function() {
                    "undefined" != typeof GAMESNACKS && GAMESNACKS.gameOver()
                }
                ,
                i.onMatchFinish = function(n) {
                    "undefined" != typeof GAMESNACKS && GAMESNACKS.sendScore(n)
                }
                ,
                e
            }(o)) || h);
            e._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/DebugVisualizeTile.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, r, i, a, n, l, s, o, u, c;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            i = e.initializerDefineProperty,
            a = e.assertThisInitialized,
            n = e.defineProperty
        }
        , function(e) {
            l = e.cclegacy,
            s = e._decorator,
            o = e.MeshRenderer,
            u = e.Material,
            c = e.Component
        }
        ],
        execute: function() {
            var p, b, h, d, y, f, m, g, z, v, w;
            l._RF.push({}, "8101byhsatCx5icS+OV4Sar", "DebugVisualizeTile", void 0);
            var D = s.ccclass
              , S = s.property;
            e("DebugVisualizeTile", (p = D("DebugVisualizeTile"),
            b = S(o),
            h = S(u),
            d = S(u),
            y = S(u),
            p((g = t((m = function(e) {
                function t() {
                    for (var t, r = arguments.length, l = new Array(r), s = 0; s < r; s++)
                        l[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(l)) || this,
                    i(a(t), "renderer", g, a(t)),
                    i(a(t), "matWalkable", z, a(t)),
                    i(a(t), "matObstacle", v, a(t)),
                    i(a(t), "matSpawn", w, a(t)),
                    n(a(t), "type", -1),
                    t
                }
                return r(t, e),
                t.prototype.setup = function(e) {
                    if (e != this.type)
                        switch (this.type = e,
                        this.type) {
                        case 0:
                            this.renderer.node.active = !1;
                            break;
                        case 5:
                            this.renderer.node.active = !0,
                            this.renderer.material = this.matSpawn;
                            break;
                        default:
                            this.renderer.node.active = !0,
                            this.renderer.material = this.matObstacle
                        }
                }
                ,
                t
            }(c)).prototype, "renderer", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            z = t(m.prototype, "matWalkable", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = t(m.prototype, "matObstacle", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            w = t(m.prototype, "matSpawn", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            f = m)) || f));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CameraGameplay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./PlayerNode.ts"], (function(t) {
    "use strict";
    var e, i, n, o, a, s, r, h, c, l, u, p, y, f, d, g, m, P, v, k;
    return {
        setters: [function(t) {
            e = t.defineProperty,
            i = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            o = t.initializerDefineProperty,
            a = t.assertThisInitialized,
            s = t.createForOfIteratorHelperLoose,
            r = t.createClass
        }
        , function(t) {
            h = t.cclegacy,
            c = t._decorator,
            l = t.Vec3,
            u = t.Vec2,
            p = t.Camera,
            y = t.Component,
            f = t.tween
        }
        , function(t) {
            d = t.logger,
            g = t.LogCategory,
            m = t.LogType
        }
        , function(t) {
            P = t.ProjectEventType
        }
        , function(t) {
            v = t.projectEvent
        }
        , function(t) {
            k = t.PlayerNode
        }
        ],
        execute: function() {
            var w, R, S, b, C, E, M, _, O, L, G, j;
            h._RF.push({}, "81efcb2WsRGU7ZmVchLIUj2", "CameraGameplay", void 0);
            var x = c.ccclass
              , z = c.property
              , D = c.executionOrder
              , F = function() {
                function t(t, i) {
                    e(this, "intensity", void 0),
                    e(this, "tweenPos", void 0),
                    e(this, "shakePos1", void 0),
                    e(this, "shakePos2", void 0),
                    this.intensity = i,
                    this.shakePos1 = new l(Math.random() * this.intensity.x,Math.random() * this.intensity.y,0),
                    this.shakePos2 = new l(Math.random() * this.intensity.x,Math.random() * this.intensity.y,0),
                    this.tweenPos = f(t).to(.1, {
                        position: this.shakePos1
                    }, {
                        easing: "elasticOut"
                    }).to(.1, {
                        position: this.shakePos2
                    }, {
                        easing: "elasticOut"
                    }).to(.1, {
                        position: l.ZERO
                    }, {
                        easing: "elasticOut"
                    }).repeat(1)
                }
                return t.prototype.play = function() {
                    this.shakePos1.set(Math.random() * this.intensity.x, Math.random() * this.intensity.y, 0),
                    this.shakePos2.set(Math.random() * this.intensity.x, Math.random() * this.intensity.y, 0),
                    this.tweenPos.start()
                }
                ,
                t
            }();
            t("CameraGameplay", (w = x("CameraGameplay"),
            R = D(3),
            S = z(l),
            b = z(l),
            C = z({
                type: [u],
                slide: !0,
                range: [0, 1],
                step: .05,
                tooltip: "Basic = 0,\nAssaultRifle = 1,\nShotgun = 2,\nBazooka = 3,\nDebug = 4,"
            }),
            w(E = R((j = G = function(t) {
                function i() {
                    for (var i, n = arguments.length, s = new Array(n), r = 0; r < n; r++)
                        s[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(s)) || this,
                    o(a(i), "offset", _, a(i)),
                    o(a(i), "startRotation", O, a(i)),
                    o(a(i), "weaponShakes", L, a(i)),
                    e(a(i), "shakeSetting", void 0),
                    e(a(i), "target", void 0),
                    e(a(i), "targetPos", new l),
                    e(a(i), "_camera", void 0),
                    i
                }
                n(i, t);
                var h = i.prototype;
                return h.onLoad = function() {
                    this._camera = this.node.getComponentInChildren(p),
                    i.instance = this
                }
                ,
                h.start = function() {
                    if (k.instance && (this.target = k.instance.node),
                    this.target)
                        if (this._camera) {
                            this.node.setRotationFromEuler(this.startRotation),
                            this.shakeSetting = new Array;
                            for (var t, e = s(this.weaponShakes); !(t = e()).done; ) {
                                var i = t.value;
                                this.shakeSetting.push(new F(this._camera.node,i))
                            }
                        } else
                           console.log("ERROR: Could not find camera", g.Gameplay, m.Error);
                    else
                       console.log("ERROR: Could not find player", g.Gameplay, m.Warning)
                }
                ,
                h.onEnable = function() {
                    v.on(P.PlayerShoot, this.onPlayerShoot, this)
                }
                ,
                h.onDisable = function() {
                    v.off(P.PlayerShoot, this.onPlayerShoot, this)
                }
                ,
                h.onPlayerShoot = function(t) {
                    if (t >= this.shakeSetting.length)
                        throw "ERROR: Miss configured shake settings for weapon: " + t;
                    this.shakeSetting[t].play()
                }
                ,
                h.update = function() {
                    var t;
                    1 == (null === (t = this.target) || void 0 === t ? void 0 : t.isValid) && (this.target.getWorldPosition(this.targetPos),
                    this.targetPos.add(this.offset),
                    this.node.setWorldPosition(this.targetPos))
                }
                ,
                r(i, [{
                    key: "camera",
                    get: function() {
                        return this._camera
                    }
                }]),
                i
            }(y),
            e(G, "instance", void 0),
            _ = i((M = j).prototype, "offset", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new l
                }
            }),
            O = i(M.prototype, "startRotation", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new l(-57,0,0)
                }
            }),
            L = i(M.prototype, "weaponShakes", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            E = M)) || E) || E));
            h._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Loading.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./PanelManager.ts", "./PanelEnums.ts", "./PlayerUIModel.ts"], (function(n) {
    "use strict";
    var e, a, i, t, r, o, l, s, c, u, p, d;
    return {
        setters: [function(n) {
            e = n.defineProperty,
            a = n.applyDecoratedDescriptor,
            i = n.inheritsLoose,
            t = n.initializerDefineProperty,
            r = n.assertThisInitialized
        }
        , function(n) {
            o = n.cclegacy,
            l = n._decorator,
            s = n.Canvas,
            c = n.Component
        }
        , function(n) {
            u = n.PanelManager
        }
        , function(n) {
            p = n.PanelId
        }
        , function(n) {
            d = n.PlayerUIModel
        }
        ],
        execute: function() {
            var f, v, y, h, g, b, M, P, L;
            o._RF.push({}, "84a8bd7KiZMerOpzluHn+Oe", "Loading", void 0);
            var I = l.ccclass
              , m = l.property;
            n("Loading", (f = I("Loading"),
            v = m(s),
            y = m(d),
            f((L = P = function(n) {
                function e() {
                    for (var e, a = arguments.length, i = new Array(a), o = 0; o < a; o++)
                        i[o] = arguments[o];
                    return e = n.call.apply(n, [this].concat(i)) || this,
                    t(r(e), "canvas", b, r(e)),
                    t(r(e), "playerUIModel", M, r(e)),
                    e
                }
                i(e, n);
                var a = e.prototype;
                return a.onLoad = function() {
                    e.instance = this
                }
                ,
                a.start = function() {
                    this.canvas.enabled = !1
                }
                ,
                a.show = function() {
                    var n, e;
                    null === (n = this.playerUIModel) || void 0 === n || n.setup(),
                    this.canvas.enabled = !0,
                    u.instance && (null === (e = u.instance) || void 0 === e || e.open(p.LoadingGeneric))
                }
                ,
                a.hide = function() {
                    this.canvas.enabled = !1
                }
                ,
                e
            }(c),
            e(P, "instance", void 0),
            b = a((g = L).prototype, "canvas", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = a(g.prototype, "playerUIModel", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            h = g)) || h));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TweenUIOpacity.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./TweenBase.ts"], (function(t) {
    "use strict";
    var e, i, a, n, o, r, s, p, c, u, l, h, y, d;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            a = t.initializerDefineProperty,
            n = t.assertThisInitialized,
            o = t.defineProperty
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator,
            p = t.CCInteger,
            c = t.UIOpacity,
            u = t.tween
        }
        , function(t) {
            l = t.logger,
            h = t.LogCategory,
            y = t.LogType
        }
        , function(t) {
            d = t.TweenBase
        }
        ],
        execute: function() {
            var v, g, f, O, w, m, b, C;
            r._RF.push({}, "851dcowZvtAo6+QTNsyCdC7", "TweenUIOpacity", void 0);
            var I = s.ccclass
              , T = s.property
              , S = (s.requireComponent,
            s.menu);
            t("TweenUIOpacity", (v = I("TweenUIOpacity"),
            g = S("Tween/UIOpacity"),
            f = T({
                type: p,
                range: [0, 255],
                step: 1,
                slide: !0
            }),
            O = T({
                type: p,
                range: [0, 255],
                step: 1,
                slide: !0
            }),
            v(w = g((b = e((m = function(t) {
                function e() {
                    for (var e, i = arguments.length, r = new Array(i), s = 0; s < i; s++)
                        r[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(r)) || this,
                    a(n(e), "valueStart", b, n(e)),
                    a(n(e), "valueEnd", C, n(e)),
                    o(n(e), "uiOpacity", void 0),
                    e
                }
                i(e, t);
                var r = e.prototype;
                return r.onLoad = function() {
                    if (t.prototype.onLoad.call(this),
                    this.target && this.target.isValid) {
                        var e;
                        if (this.uiOpacity = this.target.getComponent(c),
                        !this.uiOpacity)
                            console.log((null === (e = this.node.parent) || void 0 === e ? void 0 : e.name) + "/" + this.node.name + " - target: '" + this.target.name + "' does not have UIOpacity, adding it, please add at edit time because it is probably better than adding at runtime", h.UI, y.Warning),
                            this.uiOpacity = this.target.addComponent(c);
                        this.useCustomStartValue ? this.uiOpacity.opacity = this.valueStart : this.valueStart = this.uiOpacity.opacity,
                        this.useRelativeValue ? (this.tweenCache = u(this.uiOpacity).delay(this.delay).by(this.duration, {
                            opacity: this.valueEnd
                        }, this.options).repeat(1),
                        this.tweenReverseCache = u(this.uiOpacity).delay(this.delay).by(this.duration, {
                            opacity: this.valueStart
                        }, this.options).repeat(1)) : (this.tweenCache = u(this.uiOpacity).delay(this.delay).to(this.duration, {
                            opacity: this.valueEnd
                        }, this.options).repeat(1),
                        this.tweenReverseCache = u(this.uiOpacity).delay(this.delay).to(this.duration, {
                            opacity: this.valueStart
                        }, this.options).repeat(1))
                    } else {
                        var i;
                        console.log("Target is invalid in tween UIOpacity of object: " + (null === (i = this.node.parent) || void 0 === i ? void 0 : i.name) + "/" + this.node.name)
                    }
                }
                ,
                r.reset = function() {
                    this.uiOpacity && (this.uiOpacity.opacity = this.valueStart)
                }
                ,
                e
            }(d)).prototype, "valueStart", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            C = e(m.prototype, "valueEnd", [O], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 255
                }
            }),
            w = m)) || w) || w));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletBasic.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./WeaponEnums.ts", "./Bullet.ts"], (function(t) {
    "use strict";
    var e, n, c, r, s, i, l, u;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            n = t.defineProperty,
            c = t.assertThisInitialized,
            r = t.createClass
        }
        , function(t) {
            s = t.cclegacy,
            i = t._decorator
        }
        , function(t) {
            l = t.WeaponBulletType
        }
        , function(t) {
            u = t.Bullet
        }
        ],
        execute: function() {
            var o;
            s._RF.push({}, "866b9TR3zRPyYEY2Po/Bc/p", "BulletBasic", void 0);
            var a = i.ccclass;
            i.property,
            t("BulletBasic", a("BulletBasic")(o = function(t) {
                function s() {
                    for (var e, r = arguments.length, s = new Array(r), i = 0; i < r; i++)
                        s[i] = arguments[i];
                    return e = t.call.apply(t, [this].concat(s)) || this,
                    n(c(e), "_type", l.Basic),
                    e
                }
                return e(s, t),
                r(s, [{
                    key: "type",
                    get: function() {
                        return this._type
                    }
                }]),
                s
            }(u)) || o);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./BotStateData.ts", "./BotFleeData.ts", "./BotIdleData.ts", "./BotGenericData.ts", "./BotAttackingData.ts", "./BotChasingData.ts", "./BotReloadingData.ts", "./BotVisionData.ts", "./BotCharacterOverridesData.ts"], (function(t) {
    "use strict";
    var a, e, i, n, r, o, l, u, c, D, s, p, b, f, g, B;
    return {
        setters: [function(t) {
            a = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            i = t.initializerDefineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            o = t._decorator,
            l = t.Component
        }
        , function(t) {
            u = t.BotStateData
        }
        , function(t) {
            c = t.BotFleeData
        }
        , function(t) {
            D = t.BotIdleData
        }
        , function(t) {
            s = t.BotGenericData
        }
        , function(t) {
            p = t.BotAttackingData
        }
        , function(t) {
            b = t.BotChasingData
        }
        , function(t) {
            f = t.BotReloadingData
        }
        , function(t) {
            g = t.BotVisionData
        }
        , function(t) {
            B = t.BotCharacterOverridesData
        }
        ],
        execute: function() {
            var d, y, m, v, h, w, z, L, k, C, G, _, x, F, O, R, A, I, S, P, V, j, q, H, M;
            r._RF.push({}, "8682avarpxGsqNLkGr1X6Gg", "BotData", void 0);
            var N = o.ccclass
              , T = o.property;
            t("BotData", (d = N("BotData"),
            y = T(s),
            m = T(B),
            v = T(D),
            h = T(p),
            w = T(b),
            z = T(c),
            L = T(f),
            k = T(u),
            C = T(u),
            G = T(g),
            d((F = a((x = function(t) {
                function a() {
                    for (var a, e = arguments.length, r = new Array(e), o = 0; o < e; o++)
                        r[o] = arguments[o];
                    return a = t.call.apply(t, [this].concat(r)) || this,
                    i(n(a), "minLevel", F, n(a)),
                    i(n(a), "maxLevel", O, n(a)),
                    i(n(a), "genericData", R, n(a)),
                    i(n(a), "characterOverrideData", A, n(a)),
                    i(n(a), "idleData", I, n(a)),
                    i(n(a), "attackingData", S, n(a)),
                    i(n(a), "chasingData", P, n(a)),
                    i(n(a), "fleeData", V, n(a)),
                    i(n(a), "reloadingData", j, n(a)),
                    i(n(a), "lootingData", q, n(a)),
                    i(n(a), "wanderData", H, n(a)),
                    i(n(a), "visionData", M, n(a)),
                    a
                }
                return e(a, t),
                a
            }(l)).prototype, "minLevel", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            O = a(x.prototype, "maxLevel", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 999
                }
            }),
            R = a(x.prototype, "genericData", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            A = a(x.prototype, "characterOverrideData", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = a(x.prototype, "idleData", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            S = a(x.prototype, "attackingData", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = a(x.prototype, "chasingData", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            V = a(x.prototype, "fleeData", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            j = a(x.prototype, "reloadingData", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            q = a(x.prototype, "lootingData", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            H = a(x.prototype, "wanderData", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = a(x.prototype, "visionData", [G], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            _ = x)) || _));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/GameSnacksAPITest.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(t) {
    "use strict";
    var e, n, s, o, r;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            n = t.cclegacy,
            s = t._decorator,
            o = t.Component
        }
        , function(t) {
            r = t.logger
        }
        ],
        execute: function() {
            var a;
            n._RF.push({}, "86c821Z1PRFPKdaKY01bYMJ", "GameSnacksAPITest", void 0);
            var c = s.ccclass;
            s.property,
            t("GameSnacksAPITest", c("GameSnacksAPITest")(a = function(t) {
                function n() {
                    return t.apply(this, arguments) || this
                }
                return e(n, t),
                n.prototype.start = function() {
                   console.log("GameSnacksAPITest - Start"),
                   console.log(GAMESNACKS.isAudioEnabled());
                    var t = GAMESNACKS.gameReady();
                   console.log(t),
                   console.log(JSON.stringify(t))
                }
                ,
                n
            }(o)) || a);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TweenNodeRotation.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenBase.ts"], (function(e) {
    "use strict";
    var t, i, a, n, r, s, o, l, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            a = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            r = e.cclegacy,
            s = e._decorator,
            o = e.Vec3,
            l = e.tween
        }
        , function(e) {
            u = e.TweenBase
        }
        ],
        execute: function() {
            var h, c, p, d, y, v, g, w;
            r._RF.push({}, "86c92LInnNB+4JJ6px+5e9J", "TweenNodeRotation", void 0);
            var f = s.ccclass
              , R = s.property
              , b = s.menu;
            e("TweenNodeRotation", (h = f("TweenNodeRotation"),
            c = b("Tween/Rotation"),
            p = R({
                type: o
            }),
            d = R(o),
            h(y = c((g = t((v = function(e) {
                function t() {
                    for (var t, i = arguments.length, r = new Array(i), s = 0; s < i; s++)
                        r[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(r)) || this,
                    a(n(t), "valueStart", g, n(t)),
                    a(n(t), "valueEnd", w, n(t)),
                    t
                }
                i(t, e);
                var r = t.prototype;
                return r.onLoad = function() {
                    e.prototype.onLoad.call(this),
                    this.useCustomStartValue ? this.target.eulerAngles.set(this.valueStart) : this.valueStart = this.target.eulerAngles,
                    this.useRelativeValue ? (this.tweenCache = l(this.target).delay(this.delay).by(this.duration, {
                        eulerAngles: this.valueEnd
                    }, this.options).repeat(1),
                    this.tweenReverseCache = l(this.target).delay(this.delay).by(this.duration, {
                        eulerAngles: this.valueStart
                    }, this.options).repeat(1)) : (this.tweenCache = l(this.target).delay(this.delay).to(this.duration, {
                        eulerAngles: this.valueEnd
                    }, this.options).repeat(1),
                    this.tweenReverseCache = l(this.target).delay(this.delay).to(this.duration, {
                        eulerAngles: this.valueStart
                    }, this.options).repeat(1))
                }
                ,
                r.reset = function() {
                    this.target.eulerAngles.set(this.valueStart)
                }
                ,
                t
            }(u)).prototype, "valueStart", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new o
                }
            }),
            w = t(v.prototype, "valueEnd", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return new o(1,1,1)
                }
            }),
            y = v)) || y) || y));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletAssaultRifle.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./WeaponEnums.ts", "./Bullet.ts"], (function(t) {
    "use strict";
    var e, l, s, u, n, i, r, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            l = t.defineProperty,
            s = t.assertThisInitialized,
            u = t.createClass
        }
        , function(t) {
            n = t.cclegacy,
            i = t._decorator
        }
        , function(t) {
            r = t.WeaponBulletType
        }
        , function(t) {
            c = t.Bullet
        }
        ],
        execute: function() {
            var o;
            n._RF.push({}, "86cdediiB1IuLLJ076GfoHP", "BulletAssaultRifle", void 0);
            var a = i.ccclass;
            i.property,
            t("BulletAssaultRifle", a("BulletAssaultRifle")(o = function(t) {
                function n() {
                    for (var e, u = arguments.length, n = new Array(u), i = 0; i < u; i++)
                        n[i] = arguments[i];
                    return e = t.call.apply(t, [this].concat(n)) || this,
                    l(s(e), "_type", r.AssaultRifle),
                    e
                }
                return e(n, t),
                u(n, [{
                    key: "type",
                    get: function() {
                        return this._type
                    }
                }]),
                n
            }(c)) || o);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIBrain.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./Pathfinding.ts", "./GameplayEnums.ts", "./CharacterBlackboard.ts", "./MatchController.ts", "./AIState.ts", "./AIEnums.ts", "./AIChasingState.ts", "./BotData.ts", "./EnemySpawner.ts", "./AIReloadingState.ts", "./AIAttackingState.ts", "./AIFleeState.ts", "./CharacterInterfaces.ts", "./AIBlackboard.ts", "./AIIdleState.ts", "./AILootingState.ts", "./AIWanderState.ts", "./AIVision.ts"], (function(t) {
    "use strict";
    var a, e, i, r, n, o, c, s, l, h, d, u, g, b, p, v, f, m, S, k, I, B, A, D, P, C, w, y, R, T, O, _, x, z, M, V, W, L;
    return {
        setters: [function(t) {
            a = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            i = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            n = t.defineProperty,
            o = t.createClass
        }
        , function(t) {
            c = t.cclegacy,
            s = t._decorator,
            l = t.Prefab,
            h = t.CCFloat,
            d = t.Vec3,
            u = t.director,
            g = t.instantiate,
            b = t.Vec2
        }
        , function(t) {
            p = t.logger,
            v = t.LogCategory,
            f = t.LogType
        }
        , function(t) {
            m = t.WeaponType,
            S = t.WeaponRarity
        }
        , function(t) {
            k = t.Pathfinding
        }
        , function(t) {
            I = t.MatchState
        }
        , function(t) {
            B = t.CharacterBlackboard
        }
        , function(t) {
            A = t.MatchController
        }
        , function(t) {
            D = t.AIState
        }
        , function(t) {
            P = t.AIStateList,
            C = t.AIEvent
        }
        , function(t) {
            w = t.AIChasingState
        }
        , function(t) {
            y = t.BotData
        }
        , function(t) {
            R = t.EnemySpawner
        }
        , function(t) {
            T = t.AIReloadingState
        }
        , function(t) {
            O = t.AIAttackingState
        }
        , function(t) {
            _ = t.AIFleeState
        }
        , function(t) {
            x = t.CharacterInputBase
        }
        , function(t) {
            z = t.AIBlackboard
        }
        , function(t) {
            M = t.AIIdleState
        }
        , function(t) {
            V = t.AILootingState
        }
        , function(t) {
            W = t.AIWanderState
        }
        , function(t) {
            L = t.AIVision
        }
        ],
        execute: function() {
            var E, H, F, j, U, G, J, K, X, q, N, Q, Y, Z, $;
            c._RF.push({}, "87d5cpk5LRDio7nlTpJKyX0", "AIBrain", void 0);
            var tt = s.ccclass
              , at = s.property
              , et = s.executionOrder;
            t("AIBrain", (E = tt("AIBrain"),
            H = et(-5),
            F = at({
                type: l
            }),
            j = at({
                type: h,
                min: 0
            }),
            U = at({
                tab: "Debug"
            }),
            G = at({
                type: l,
                tooltip: "Prefabs to visualize",
                tab: "Debug/"
            }),
            J = at({
                type: l,
                tooltip: "Set to override automatic profile selection, leave null otherwise"
            }),
            E(K = H((q = a((X = function(t) {
                function a() {
                    for (var a, e = arguments.length, o = new Array(e), c = 0; c < e; c++)
                        o[c] = arguments[c];
                    return a = t.call.apply(t, [this].concat(o)) || this,
                    i(r(a), "useRandomProfile", q, r(a)),
                    i(r(a), "dataPrefab", N, r(a)),
                    i(r(a), "pathingTolerance", Q, r(a)),
                    i(r(a), "showDebugPath", Y, r(a)),
                    i(r(a), "pathingDebugPrefab", Z, r(a)),
                    i(r(a), "debugDataPrefab", $, r(a)),
                    n(r(a), "characterBlackboard", void 0),
                    n(r(a), "aiBlackboard", void 0),
                    n(r(a), "aiVision", void 0),
                    n(r(a), "idleState", void 0),
                    n(r(a), "wanderState", void 0),
                    n(r(a), "attackingState", void 0),
                    n(r(a), "chasingState", void 0),
                    n(r(a), "fleeingState", void 0),
                    n(r(a), "lootingState", void 0),
                    n(r(a), "reloadingState", void 0),
                    n(r(a), "currentState", void 0),
                    n(r(a), "scene", void 0),
                    n(r(a), "pathVisualization", void 0),
                    n(r(a), "currentPos", new d),
                    n(r(a), "combatReadinessCooldown", 5),
                    n(r(a), "_data", void 0),
                    n(r(a), "previousStateType", P.Idle),
                    n(r(a), "currentStateType", P.Idle),
                    n(r(a), "newSameStateCounter", 0),
                    a
                }
                e(a, t);
                var c = a.prototype;
                return c.start = function() {
                    console.log("AIBrain start", v.AI),
                    null != k.instance && (this.scene = u.getScene(),
                    this.pathVisualization = new Array),
                    this.showDebugPath = !1
                }
                ,
                c.onEnable = function() {
                    var t, a = this;
                    (
                        // console.log("AIBrain onEnable", v.AI),
                    R.instance && this.useRandomProfile && (this.dataPrefab = R.instance.getRandomAiProfile()),
                    this._data = this.dataPrefab.data.getComponent(y),
                    this.aiBlackboard = this.node.getComponent(z),
                    this.characterBlackboard = this.node.getComponentInChildren(B),
                    this.aiVision = this.node.getComponent(L),
                    this.characterBlackboard && this.aiBlackboard) && (null === (t = this.aiVision) || void 0 === t || t.init(this.aiBlackboard, this.characterBlackboard, this));
                    this.node.getComponents(D).forEach((function(t) {
                        a.characterBlackboard && a.aiBlackboard && t.init(a.aiBlackboard, a.characterBlackboard, a)
                    }
                    )),
                    this.idleState = this.node.getComponent(M),
                    this.wanderState = this.node.getComponent(W),
                    this.attackingState = this.node.getComponent(O),
                    this.chasingState = this.node.getComponent(w),
                    this.fleeingState = this.node.getComponent(_),
                    this.lootingState = this.node.getComponent(V),
                    this.reloadingState = this.node.getComponent(T),
                    this.combatReadinessCooldown = this.data.genericData.combatReadinessCooldown,
                    this.applyCharacterOverrides(),
                    this.changeState(P.Idle)
                }
                ,
                c.update = function(t) {
                    var a, e, i;
                    (null === (a = A.instance) || void 0 === a ? void 0 : a.state) == I.Runing && (this.combatReadinessCooldown > 0 && (this.combatReadinessCooldown -= t),
                    null === (e = this.aiVision) || void 0 === e || e.onUpdate(t),
                    null === (i = this.currentState) || void 0 === i || i.onStateUpdate(t))
                }
                ,
                c.onDestroy = function() {
                    this.clearPathVisualization()
                }
                ,
                c.changeState = function(t) {
                    var a;
                    switch (
                      // console.log(
                      //   this.node.name + " - Changing state from " + this.previousStateType + " to " + t, v.AI
                      //   ),
                    t) {
                    case P.Idle:
                        this.currentState = this.idleState;
                        break;
                    case P.Wandering:
                        this.currentState = this.wanderState;
                        break;
                    case P.Attacking:
                        this.currentState = this.attackingState;
                        break;
                    case P.Chasing:
                        this.currentState = this.chasingState;
                        break;
                    case P.Fleeing:
                        this.currentState = this.fleeingState;
                        break;
                    case P.Looting:
                        this.currentState = this.lootingState;
                        break;
                    case P.Reloading:
                        this.currentState = this.reloadingState
                    }
                    null === (a = this.currentState) || void 0 === a || a.onStateEnter(),
                    this.node.emit(C.StateChanged, t),
                    t == this.previousStateType && (this.newSameStateCounter++,
                    this.newSameStateCounter >= 3 && (
                        // console.log(this.node.name + " Changing state from " + this.previousStateType + " to " + t + " - Probably locked in a state loop", v.AI, f.Error),
                    this.newSameStateCounter = 0)),
                    this.previousStateType = this.currentStateType,
                    this.currentStateType = t
                }
                ,
                c.setDirection = function(t, a) {
                    this.horizontal != t && (this.horizontal = t),
                    this.vertical != a && (this.vertical = -a)
                }
                ,
                c.setActivePath = function(t, a) {
                    var e = this;
                    if (this.aiBlackboard) {
                        if (0 == a.length)
                            return console.log(this.node.name + " - Invalid path received, fallback to idle.", v.AI),
                            void this.changeState(P.Idle);
                        this.aiBlackboard.currentPath = a,
                        this.aiBlackboard.currentMovementIndex = 0,
                        this.aiBlackboard.currentPathingTarget = t,
                        null != this.pathingDebugPrefab && this.showDebugPath && (this.clearPathVisualization(),
                        this.pathVisualization = new Array,
                        this.aiBlackboard.currentPath.forEach((function(t) {
                            var a = g(e.pathingDebugPrefab)
                              , i = 1 / k.instance.mapImportScaleFactor;
                            a.setParent(e.scene),
                            a.setPosition(k.instance.gridToWorld(t[0], t[1])),
                            a.setWorldScale(new d(i,i,i)),
                            e.pathVisualization.push(a)
                        }
                        )))
                    }
                }
                ,
                c.clearPathVisualization = function() {
                    this.pathVisualization.length > 0 && this.pathVisualization.forEach((function(t) {
                        t.destroy()
                    }
                    ))
                }
                ,
                c.getPathingDirection = function() {
                    if (!this.aiBlackboard)
                        return new b(0,0);
                    if (!this.aiBlackboard.currentPath)
                        return new b(0,0);
                    var t = this.calculateDistanceToIndex(this.aiBlackboard.currentMovementIndex);
                    if (t.length() < this.pathingTolerance) {
                        if (this.aiBlackboard.currentMovementIndex >= this.aiBlackboard.currentPath.length - 1)
                            return new b(0,0);
                        this.aiBlackboard.currentMovementIndex++,
                        t = this.calculateDistanceToIndex(this.aiBlackboard.currentMovementIndex)
                    }
                    return t.normalize(),
                    t
                }
                ,
                c.calculateDistanceToIndex = function(t) {
                    if (!this.aiBlackboard)
                        return new b(0,0);
                    if (!this.aiBlackboard.currentPath)
                        return new b(0,0);
                    var a = this.aiBlackboard.currentPath[t];
                    return a ? this.calculateDistanceToPoint(a) : new b(0,0)
                }
                ,
                c.calculateDistanceToPosition = function(t) {
                    this.node.getWorldPosition(this.currentPos);
                    var a = new b;
                    return a.set(this.currentPos.x, this.currentPos.z),
                    a.subtract(new b(t[0],t[1])),
                    a
                }
                ,
                c.calculateDistanceToPoint = function(t) {
                    this.node.getWorldPosition(this.currentPos);
                    var a = k.instance.gridToWorld(t[0], t[1]);
                    return a.subtract(this.currentPos),
                    new b(a.x,a.z)
                }
                ,
                c.reachedPathingDestination = function() {
                    return null != this.aiBlackboard && (null != this.aiBlackboard.currentPathingTarget && (k.instance.isPointInsideOfShrinkingArea(this.node.worldPosition.x, this.node.worldPosition.z) && this.currentStateType != P.Wandering && (console.log(this.node.name + " " + a.name + ": I'm inside of the danger zone, OMG what should I do?????", v.AI, f.Error),
                    this.changeState(P.Wandering)),
                    this.calculateDistanceToPosition([this.aiBlackboard.currentPathingTarget.x, this.aiBlackboard.currentPathingTarget.y]).length() <= this.pathingTolerance))
                }
                ,
                c.isTargetValid = function(t) {
                    if (null == t)
                        return 
                        // console.log(this.node.name + " target not valid because: '" + t + "' is null", v.AI),
                        !1;
                    if (!t.isValid)
                        return console.log(this.node.name + " target not valid because: '" + t + "'.isValid=" + t.isValid + " ", v.AI),
                        !1;
                    var a = t.getComponentInChildren(B);
                    return !(null == a || a.health <= 0) || (console.log(this.node.name + " target not valid because: bb==null:" + (null == a), v.AI),
                    // console.log(this.node.name + " target not valid because: bb.health=" + (null == a ? void 0 : a.health), v.AI),
                    !1)
                }
                ,
                c.isCurrentTargetValid = function() {
                    var t, a, e = null === (t = this.characterBlackboard) || void 0 === t ? void 0 : t.target, i = null === (a = this.characterBlackboard) || void 0 === a ? void 0 : a.targetBlackboard;
                    return null != e && (!!e.isValid && !(null == i || i.health <= 0))
                }
                ,
                c.isTargetInShootingRange = function(t) {
                    var a = new d(this.node.worldPosition)
                      , e = new d(t.worldPosition).subtract(a).length();
                    return e < this.characterBlackboard.currentWeaponObject.Range - this.data.genericData.maximumConfrontationDistanceOffset && e > this.data.genericData.minimumConfrontationDistance
                }
                ,
                c.isCombatReady = function() {
                    if (!this.characterBlackboard || !this.aiBlackboard)
                        return !1;
                    var t = this.characterBlackboard.currentWeapon == m.Basic
                      , a = this.characterBlackboard.currentWeaponObject.weaponRarity >= this.data.genericData.minimumWeaponRarityForCombat;
                    return this.combatReadinessCooldown < 0 || !t && a
                }
                ,
                c.isWeaponAnUpgrade = function(t) {
                    if (!this.characterBlackboard || !this.aiBlackboard)
                        return !1;
                    var a = this.characterBlackboard.currentWeapon == m.Basic || t.getRarity() > this.characterBlackboard.currentWeaponObject.weaponRarity
                      , e = this.characterBlackboard.currentWeaponObject;
                    return a
                    // console.log("current: " + m[e.Type] + ":" + S[e.weaponRarity] + " - pickup: " + m[t.targetWeapon] + ":" + S[t.getRarity()] + " isWeaponAnUpgrade: " + a, v.AI),
                    // a
                }
                ,
                c.applyCharacterOverrides = function() {
                    var t;
                    this.characterBlackboard && (null != this._data.characterOverrideData && (this._data.characterOverrideData.ShouldOverride ? (console.log("Applying character overrides.", v.AI),
                    console.log("HealthMax " + (null === (t = this.characterBlackboard) || void 0 === t ? void 0 : t.HealthMax) + "->" + this._data.characterOverrideData.HealthMax, v.AI),
                    this.characterBlackboard.HealthMax = this._data.characterOverrideData.HealthMax,
                    console.log("HealthRegenRate " + this.characterBlackboard.HealthRegenRate + "->" + this._data.characterOverrideData.HealthRegenRate, v.AI),
                    this.characterBlackboard.HealthRegenRate = this._data.characterOverrideData.HealthRegenRate,
                    console.log("HealthLevelMultiplier " + this.characterBlackboard.HealthLevelMultiplier + "->" + this._data.characterOverrideData.HealthLevelMultiplier, v.AI),
                    this.characterBlackboard.HealthLevelMultiplier = this._data.characterOverrideData.HealthLevelMultiplier,
                    console.log("Speed " + this.characterBlackboard.Speed + "->" + this._data.characterOverrideData.Speed, v.AI),
                    this.characterBlackboard.Speed = this._data.characterOverrideData.Speed,
                    console.log("ExitCombatCooldown " + this.characterBlackboard.ExitCombatCooldown + "->" + this._data.characterOverrideData.ExitCombatCooldown, v.AI),
                    this.characterBlackboard.ExitCombatCooldown = this._data.characterOverrideData.ExitCombatCooldown,
                    console.log("AreaDamage " + this.characterBlackboard.AreaDamage + "->" + this._data.characterOverrideData.AreaDamage, v.AI),
                    this.characterBlackboard.AreaDamage = this._data.characterOverrideData.AreaDamage,
                    console.log("AreaDamageInterval " + this.characterBlackboard.AreaDamageInterval + "->" + this._data.characterOverrideData.AreaDamageInterval, v.AI),
                    this.characterBlackboard.AreaDamageInterval = this._data.characterOverrideData.AreaDamageInterval,
                    console.log("DamageLevelMultiplier " + this.characterBlackboard.DamageLevelMultiplier + "->" + this._data.characterOverrideData.DamageLevelMultiplier, v.AI),
                    this.characterBlackboard.DamageLevelMultiplier = this._data.characterOverrideData.DamageLevelMultiplier) : console.log("Ignoring character overrides.")))
                }
                ,
                o(a, [{
                    key: "data",
                    get: function() {
                        return this._data
                    }
                }]),
                a
            }(x)).prototype, "useRandomProfile", [at], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !0
                }
            }),
            N = a(X.prototype, "dataPrefab", [F], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Q = a(X.prototype, "pathingTolerance", [j], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .5
                }
            }),
            Y = a(X.prototype, "showDebugPath", [U], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !0
                }
            }),
            Z = a(X.prototype, "pathingDebugPrefab", [G], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            $ = a(X.prototype, "debugDataPrefab", [J], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            K = X)) || K) || K));
            c._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponPickupRarityEffect.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./WeaponRarityData.ts"], (function(e) {
    "use strict";
    var t, r, a, i, o, n, l, s, c, p, y, u, f, h, g, d, P;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            a = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            o = e.defineProperty,
            n = e.createForOfIteratorHelperLoose
        }
        , function(e) {
            l = e.cclegacy,
            s = e._decorator,
            c = e.MeshRenderer,
            p = e.Prefab,
            y = e.Node,
            u = e.ParticleSystem,
            f = e.Color,
            h = e.Component
        }
        , function(e) {
            g = e.logger
        }
        , function(e) {
            d = e.WeaponRarity
        }
        , function(e) {
            P = e.WeaponRarityData
        }
        ],
        execute: function() {
            var v, b, R, m, w, M, D, C, N, W, L, k;
            l._RF.push({}, "892c8MZLCRPL5J0v7kFAk4w", "WeaponPickupRarityEffect", void 0);
            var z = s.ccclass
              , E = s.property
              , _ = s.executionOrder;
            e("WeaponPickupRarityEffect", (v = z("WeaponPickupRarityEffect"),
            b = _(-1),
            R = E(c),
            m = E(c),
            w = E(p),
            M = E({
                type: [y],
                tooltip: "WeaponRarity\nCommon = 0,\nUncommon = 1,\nRare = 2,\nEpic = 3,\nLegendary = 4"
            }),
            v(D = b((N = t((C = function(e) {
                function t() {
                    for (var t, r = arguments.length, n = new Array(r), l = 0; l < r; l++)
                        n[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(n)) || this,
                    a(i(t), "beaconMesh", N, i(t)),
                    a(i(t), "glowMesh", W, i(t)),
                    a(i(t), "weaponRarityDataPrefab", L, i(t)),
                    a(i(t), "rarityParticlesNodes", k, i(t)),
                    o(i(t), "weaponRarityData", void 0),
                    o(i(t), "rarityParticles", new Map),
                    t
                }
                r(t, e);
                var l = t.prototype;
                return l.onLoad = function() {
                    this.weaponRarityData = this.weaponRarityDataPrefab.data.getComponent(P);
                    for (var e = 0; e < this.rarityParticlesNodes.length; e++) {
                        var t = this.rarityParticlesNodes[e].getComponentsInChildren(u);
                        this.rarityParticles.set(e, t)
                    }
                }
                ,
                l.onSetRarity = function(e) {
                    var t, r, a, i, o = this.weaponRarityData.getColor(e), l = "mainColor", s = null === (t = this.glowMesh.material) || void 0 === t ? void 0 : t.getProperty(l), c = new f(o.r,o.g,o.b,s.a), p = null === (r = this.beaconMesh.material) || void 0 === r ? void 0 : r.getProperty(l), y = new f(o.r,o.g,o.b,p.a);
                    if (null === (a = this.beaconMesh.material) || void 0 === a || a.setProperty(l, y),
                    null === (i = this.glowMesh.material) || void 0 === i || i.setProperty(l, c),
                    e >= this.rarityParticlesNodes.length)
                        console.log("Not enough particles rarity configured for rarity " + d[e]);
                    else {
                        for (var u = 0; u < this.rarityParticlesNodes.length; u++)
                            this.rarityParticlesNodes[u].active = !1;
                        this.rarityParticlesNodes[e].active = !0;
                        var h = this.rarityParticles.get(e);
                        if (h)
                            for (var P, v = n(h); !(P = v()).done; ) {
                                P.value.startColor.color = o
                            }
                    }
                }
                ,
                t
            }(h)).prototype, "beaconMesh", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            W = t(C.prototype, "glowMesh", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = t(C.prototype, "weaponRarityDataPrefab", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            k = t(C.prototype, "rarityParticlesNodes", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            D = C)) || D) || D));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotStateData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, a, i, r, n;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            a = t.initializerDefineProperty
        }
        , function(t) {
            i = t.cclegacy,
            r = t._decorator,
            n = t.CCFloat
        }
        ],
        execute: function() {
            var o, c, s, u, l;
            i._RF.push({}, "894c1SqKxFIJ4ysVZcBwA9b", "BotStateData", void 0);
            var p = r.ccclass
              , m = r.property;
            t("BotStateData", (o = p("BotStateData"),
            c = m({
                type: n,
                tooltip: "The AI won't change state unless this timer has elapsed"
            }),
            o((l = e((u = function() {
                a(this, "minimumTimeInState", l, this)
            }
            ).prototype, "minimumTimeInState", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .5
                }
            }),
            s = u)) || s));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PanelEnums.ts", ["cc"], (function(e) {
    "use strict";
    var n;
    return {
        setters: [function(e) {
            n = e.cclegacy
        }
        ],
        execute: function() {
            var a, r;
            e({
                EventPanel: void 0,
                PanelId: void 0
            }),
            n._RF.push({}, "8b3edgXZadK4Lxacf0H30hG", "PanelEnums", void 0),
            function(e) {
                e[e.MatchStart = 0] = "MatchStart",
                e[e.MatchEnd = 1] = "MatchEnd",
                e[e.LoadingGeneric = 2] = "LoadingGeneric",
                e[e.LoadingMatch = 3] = "LoadingMatch",
                e[e.MissionOverlay = 4] = "MissionOverlay",
                e[e.ArenaSelector = 5] = "ArenaSelector",
                e[e.ConfirmWeaponUpgrade = 6] = "ConfirmWeaponUpgrade",
                e[e.ArenaUnlock = 7] = "ArenaUnlock",
                e[e.DebugMenu = 8] = "DebugMenu",
                e[e.PreTutorial = 9] = "PreTutorial",
                e[e.ConfirmCharacterPurchase = 10] = "ConfirmCharacterPurchase",
                e[e.None = 11] = "None"
            }(a || (a = e("PanelId", {}))),
            function(e) {
                e.OpenStart = "panel-open-start",
                e.OpenFinish = "panel-open-finish",
                e.CloseStart = "panel-close-start",
                e.CloseFinish = "panel-close-finish"
            }(r || (r = e("EventPanel", {}))),
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIToastAreaDamage.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./UIToast.ts"], (function(t) {
    "use strict";
    var e, n, o, a, r, s, i, c, u;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            n = t.defineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            r = t._decorator,
            s = t.Component
        }
        , function(t) {
            i = t.ProjectEventType
        }
        , function(t) {
            c = t.projectEvent
        }
        , function(t) {
            u = t.UIToast
        }
        ],
        execute: function() {
            var l;
            a._RF.push({}, "8cf96EZBuVORap2lx4uLSkX", "UIToastAreaDamage", void 0);
            var f = r.ccclass;
            r.property,
            t("UIToastAreaDamage", f("UIToastAreaDamage")(l = function(t) {
                function a() {
                    for (var e, a = arguments.length, r = new Array(a), s = 0; s < a; s++)
                        r[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(r)) || this,
                    n(o(e), "toast", void 0),
                    e
                }
                e(a, t);
                var r = a.prototype;
                return r.onLoad = function() {
                    this.toast = this.node.getComponent(u)
                }
                ,
                r.onEnable = function() {
                    c.on(i.PlayerEnterDamageZone, this.onPlayerEnterDamageZone, this)
                }
                ,
                r.onDisable = function() {
                    c.off(i.PlayerEnterDamageZone, this.onPlayerEnterDamageZone, this)
                }
                ,
                r.onPlayerEnterDamageZone = function() {
                    var t;
                    null === (t = this.toast) || void 0 === t || t.show()
                }
                ,
                a
            }(s)) || l);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CanvasGameplay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(n) {
    "use strict";
    var t, e, a, s, i, o, c, r, u;
    return {
        setters: [function(n) {
            t = n.defineProperty,
            e = n.inheritsLoose,
            a = n.createClass
        }
        , function(n) {
            s = n.cclegacy,
            i = n._decorator,
            o = n.Canvas,
            c = n.Component
        }
        , function(n) {
            r = n.ProjectEventType
        }
        , function(n) {
            u = n.projectEvent
        }
        ],
        execute: function() {
            var h, l, p;
            s._RF.push({}, "8d051GjOHRK6au6jqZ7qkOg", "CanvasGameplay", void 0);
            var v = i.ccclass
              , f = (i.property,
            i.executionOrder);
            n("CanvasGameplay", v("CanvasGameplay")(h = f(-1)((p = l = function(n) {
                function t() {
                    return n.apply(this, arguments) || this
                }
                e(t, n);
                var s = t.prototype;
                return s.onLoad = function() {
                    null == t.instance && (t.instance = this,
                    this._canvas = this.node.getComponent(o))
                }
                ,
                s.onDestroy = function() {
                    t.instance == this && (t.instance = null)
                }
                ,
                s.onEnable = function() {
                    u.on(r.MatchFinish, this.onMatchFinish, this)
                }
                ,
                s.onDisable = function() {
                    u.off(r.MatchFinish, this.onMatchFinish, this)
                }
                ,
                s.onMatchFinish = function() {
                    this._canvas && (this._canvas.enabled = !1)
                }
                ,
                a(t, [{
                    key: "canvas",
                    get: function() {
                        return this._canvas
                    }
                }]),
                t
            }(c),
            t(l, "instance", void 0),
            h = p)) || h) || h);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIWanderState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./Pathfinding.ts", "./AIState.ts", "./AIEnums.ts"], (function(t) {
    "use strict";
    var i, n, e, a, o, r, s, h, d, g, c, l, u;
    return {
        setters: [function(t) {
            i = t.inheritsLoose,
            n = t.defineProperty,
            e = t.assertThisInitialized,
            a = t.createClass
        }
        , function(t) {
            o = t.cclegacy,
            r = t._decorator,
            s = t.Vec2
        }
        , function(t) {
            h = t.logger,
            d = t.LogCategory,
            g = t.LogType
        }
        , function(t) {
            c = t.Pathfinding
        }
        , function(t) {
            l = t.AIState
        }
        , function(t) {
            u = t.AIStateList
        }
        ],
        execute: function() {
            var f;
            o._RF.push({}, "8ec89tg0JRGC78s5p0ezkKK", "AIWanderState", void 0);
            var P = r.ccclass;
            r.property,
            t("AIWanderState", P("AIWanderState")(f = function(t) {
                function o() {
                    for (var i, a = arguments.length, o = new Array(a), r = 0; r < a; r++)
                        o[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(o)) || this,
                    n(e(i), "targetPosition", void 0),
                    i
                }
                i(o, t);
                var r = o.prototype;
                return r.stateEnter = function() {
                    t.prototype.stateEnter.call(this),
                    this.getWanderTarget()
                    // console.log(this.node.name + " Entered wander state, found path " + this.aiBlackboard.currentPath, d.AI)
                }
                ,
                r.stateExit = function() {
                    t.prototype.stateExit.call(this)
                }
                ,
                r.stateUpdate = function(i) {
                    var n, e;
                    if (t.prototype.stateUpdate.call(this, i),
                    c.instance) {
                        var a = null === (n = c.instance) || void 0 === n ? void 0 : n.isPointInsideOfShrinkingArea(this.targetPosition.x, this.targetPosition.z)
                          , o = null === (e = c.instance) || void 0 === e ? void 0 : e.isPointInsideOfShrinkingArea(this.node.worldPosition.x, this.node.worldPosition.z);
                        if (a && o)
                            console.log(this.node.name + " Wander path is now in danger zone, getting a new one.", d.AI, g.Error),
                            this.getWanderTarget();
                        else if (!o) {
                            var r = this.characterBlackboard.target;
                            if (this.brain.isCurrentTargetValid() && this.brain.isTargetInShootingRange(r))
                                return this.brain.setDirection(0, 0),
                                void this.brain.changeState(u.Attacking);
                            var s = this.aiBlackboard.visionTarget;
                            if ((null == s ? void 0 : s.isValid) && this.brain.isCombatReady()) {
                                if (
                                    // console.log(this.node.name + " Found target " + s.name + " in vision range, chasing after it", d.AI),
                                this.brain.isTargetValid(s))
                                    return this.aiBlackboard.chaseTarget = s,
                                    this.brain.setDirection(0, 0),
                                    void this.brain.changeState(u.Chasing);
                                // console.log(this.node.name + " Vision target is not valid, not chasing.", d.AI)
                            }
                        }
                        if (this.brain.reachedPathingDestination())
                            this.brain.setDirection(0, 0),
                            this.brain.changeState(u.Idle);
                        else {
                            var l = this.brain.getPathingDirection();
                            this.brain.setDirection(l.x, l.y)
                        }
                    }
                }
                ,
                r.getWanderTarget = function() {
                    if (c.instance) {
                        c.instance.isPointInsideOfShrinkingArea(this.node.worldPosition.x, this.node.worldPosition.z) ? (this.targetPosition = c.instance.getMapCenterPoint()
                        // console.log(this.node.name + " - Inside of danger zone, going to center of the map.", d.AI, g.Warning)
                        ) : this.targetPosition = c.instance.getValidRandomPoint();
                        var t = c.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, this.targetPosition.x, this.targetPosition.z);
                        // console.log(this.node.name + " Found valid wander point " + this.targetPosition + " path: " + t, d.AI),
                        this.brain.setActivePath(new s(this.targetPosition.x,this.targetPosition.z), t)
                    }
                }
                ,
                a(o, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return this.brain.data.wanderData.minimumTimeInState
                    }
                }]),
                o
            }(l)) || f);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIClickSFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./AudioManager.ts"], (function(e) {
    "use strict";
    var t, i, n, r, o, c, a, l, s, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            n = e.initializerDefineProperty,
            r = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            c = e._decorator,
            a = e.Button,
            l = e.Prefab,
            s = e.Component
        }
        , function(e) {
            u = e.AudioManager
        }
        ],
        execute: function() {
            var p, y, f, h, k, d;
            o._RF.push({}, "9173aMkALVIoLKQ9YSJ5EVS", "UIClickSFX", void 0);
            var v = c.ccclass
              , C = c.property
              , g = c.requireComponent;
            e("UIClickSFX", (p = v("UIClickSFX"),
            y = g(a),
            f = C(l),
            p(h = y((d = t((k = function(e) {
                function t() {
                    for (var t, i = arguments.length, o = new Array(i), c = 0; c < i; c++)
                        o[c] = arguments[c];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    n(r(t), "key", d, r(t)),
                    t
                }
                i(t, e);
                var o = t.prototype;
                return o.onLoad = function() {
                    this.node.on(a.EventType.CLICK, this.onclick, this)
                }
                ,
                o.onclick = function() {
                    var e;
                    this.key && (null === (e = u.instance) || void 0 === e || e.playByKey(this.key))
                }
                ,
                t
            }(s)).prototype, "key", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            h = k)) || h) || h));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestCameraPosition.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, i, o, n, s, r, a, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            i = t.defineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            n = t.cclegacy,
            s = t._decorator,
            r = t.Vec3,
            a = t.director,
            c = t.Component
        }
        ],
        execute: function() {
            var u;
            n._RF.push({}, "93812VageFIv78AczjKEBLQ", "TestCameraPosition", void 0);
            var p = s.ccclass;
            s.property,
            t("TestCameraPosition", p("TestCameraPosition")(u = function(t) {
                function n() {
                    for (var e, n = arguments.length, s = new Array(n), a = 0; a < n; a++)
                        s[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(s)) || this,
                    i(o(e), "_position", new r),
                    e
                }
                e(n, t);
                var s = n.prototype;
                return s.start = function() {}
                ,
                s.update = function() {
                    this.node.getPosition(this._position),
                    this._position.x += a.getDeltaTime(),
                    this.node.setPosition(this._position)
                }
                ,
                n
            }(c)) || u);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestHitEffect.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./CharacterHealthControl.ts"], (function(t) {
    "use strict";
    var e, r, i, a, n, o, c, l, s, u;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            r = t.inheritsLoose,
            i = t.initializerDefineProperty,
            a = t.assertThisInitialized
        }
        , function(t) {
            n = t.cclegacy,
            o = t._decorator,
            c = t.macro,
            l = t.Component
        }
        , function(t) {
            s = t.EventCharacterAction
        }
        , function(t) {
            u = t.CharacterHealthControl
        }
        ],
        execute: function() {
            var f, h, p, d, y, b;
            n._RF.push({}, "93ed49A/UVNjYs8JpZkza3Q", "TestHitEffect", void 0);
            var g = o.ccclass
              , C = o.property;
            t("TestHitEffect", (f = g("TestHitEffect"),
            h = C(u),
            f((y = e((d = function(t) {
                function e() {
                    for (var e, r = arguments.length, n = new Array(r), o = 0; o < r; o++)
                        n[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(n)) || this,
                    i(a(e), "characterToKill", y, a(e)),
                    i(a(e), "damage", b, a(e)),
                    e
                }
                r(e, t);
                var n = e.prototype;
                return n.onEnable = function() {}
                ,
                n.onDisable = function() {}
                ,
                n.onCheatKeyDown = function(t) {
                    t.keyCode == c.KEY.k && this.debugHitCharacter()
                }
                ,
                n.debugHitCharacter = function() {
                    null != this.characterToKill && this.characterToKill.node.emit(s.HitReceived, this.damage)
                }
                ,
                e
            }(l)).prototype, "characterToKill", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = e(d.prototype, "damage", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            p = d)) || p));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponPickupManager.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./WeaponEnums.ts", "./Pathfinding.ts", "./CharacterShoot.ts", "./WeaponPickup.ts"], (function(n) {
    "use strict";
    var e, t, i, o, a, r, s, p, u, c, l, h, f, P, d, g, v, y, k, w;
    return {
        setters: [function(n) {
            e = n.defineProperty,
            t = n.applyDecoratedDescriptor,
            i = n.inheritsLoose,
            o = n.initializerDefineProperty,
            a = n.assertThisInitialized
        }
        , function(n) {
            r = n.cclegacy,
            s = n._decorator,
            p = n.Prefab,
            u = n.NodePool,
            c = n.instantiate,
            l = n.director,
            h = n.Vec2,
            f = n.Component
        }
        , function(n) {
            P = n.logger
        }
        , function(n) {
            d = n.ProjectEventType
        }
        , function(n) {
            g = n.projectEvent
        }
        , function(n) {
            v = n.WeaponType
        }
        , function(n) {
            y = n.Pathfinding
        }
        , function(n) {
            k = n.CharacterShoot
        }
        , function(n) {
            w = n.WeaponPickup
        }
        ],
        execute: function() {
            var b, C, m, W, D, S, T, z, M;
            r._RF.push({}, "95cd5JOkGlCqJv8YgSuceEz", "WeaponPickupManager", void 0);
            var E = s.ccclass
              , R = s.property;
            n("WeaponPickupManager", (b = E("WeaponPickupManager"),
            C = R({
                type: [p],
                tooltip: "Must be in the enum order!\nBasic = 0,\nAssaultRifle = 1,\nShotgun = 2,\nBazooka = 3,\nDebug = 4,"
            }),
            b((M = z = function(n) {
                function t() {
                    for (var t, i = arguments.length, r = new Array(i), s = 0; s < i; s++)
                        r[s] = arguments[s];
                    return t = n.call.apply(n, [this].concat(r)) || this,
                    o(a(t), "weaponPickupPrefabs", D, a(t)),
                    o(a(t), "initCount", S, a(t)),
                    o(a(t), "isTutorial", T, a(t)),
                    e(a(t), "weaponTypes", []),
                    e(a(t), "pickupsInScene", []),
                    e(a(t), "pools", []),
                    t
                }
                i(t, n);
                var r = t.prototype;
                return r.onLoad = function() {
                    null == t.instance ? t.instance = this : console.log("Error: WeaponPickupManager instance already exists");
                    var n = 0
                      , e = v[v.Debug];
                    for (var i in v)
                        if (i != e) {
                            for (var o = new u(w.name), a = 0; a < this.initCount; a++) {
                                var r = c(this.weaponPickupPrefabs[n]);
                                o.put(r)
                            }
                            this.pools.push(o),
                            this.weaponTypes.push(n),
                            n++
                        }
                }
                ,
                r.onDestroy = function() {
                    t.instance == this && (t.instance = null)
                }
                ,
                r.onEnable = function() {
                    this.isTutorial || g.on(d.CharacterDeath, this.onCharacterDeath, this)
                }
                ,
                r.onDisable = function() {
                    this.isTutorial || g.off(d.CharacterDeath, this.onCharacterDeath, this)
                }
                ,
                r.onCharacterDeath = function(n) {
                    var e, i = n.getComponentInChildren(k), o = null == i ? void 0 : i.getCurrentWeaponType(), a = null == i ? void 0 : i.getCurrentWeaponRarity();
                    null != o && null != a && (null === (e = t.instance) || void 0 === e || e.spawnSpecificWeapon(o, a, n.worldPosition))
                }
                ,
                r.spawnRandomWeapon = function(n) {
                    var e = 0;
                    do {
                        e = Math.floor(Math.random() * this.weaponPickupPrefabs.length)
                    } while (this.weaponTypes[e] == v.Basic);
                    var t = this.spawnPickup(e, n).getComponent(w);
                    null == t || t.randomizeRarity()
                }
                ,
                r.spawnSpecificWeapon = function(n, e, t) {
                    var i = 0;
                    for (i = 0; i < this.weaponPickupPrefabs.length && this.weaponTypes[i] != n; i++)
                        ;
                    if (i < this.weaponPickupPrefabs.length) {
                        var o = this.spawnPickup(i, t).getComponent(w);
                        null == o || o.setRarity(e)
                    }
                }
                ,
                r.spawnPickup = function(n, e) {
                    var t, i = l.getScene(), o = null;
                    null == (o = this.pools[n].get()) && (o = c(this.weaponPickupPrefabs[n])),
                    o.setParent(i);
                    var a = null === (t = y.instance) || void 0 === t ? void 0 : t.getValidRandomNeighbour(e.x, e.z, 1);
                    if (a)
                        o.setWorldPosition(a[0], 0, a[1]);
                    else {
                        var r = new h(2 * Math.random() - 1,2 * Math.random() - 1);
                        r.normalize(),
                        o.setWorldPosition(e.x + r.x, 0, e.z + r.y)
                    }
                    var s = o.getComponent(w);
                    return s && this.onWeaponPickupSpawned(s),
                    o
                }
                ,
                r.put = function(n, e) {
                    if (n >= this.pools.length)
                        console.log("Error invalid bullet type, pool does not exist");
                    else {
                        var t = e.getComponent(w);
                        t && this.onWeaponPickupDestroyed(t),
                        this.pools[n].put(e)
                    }
                }
                ,
                r.onWeaponPickupSpawned = function(n) {
                    this.pickupsInScene.push(n)
                }
                ,
                r.onWeaponPickupDestroyed = function(n) {
                    var e = this.pickupsInScene.indexOf(n);
                    -1 != e && this.pickupsInScene.splice(e, 1)
                }
                ,
                t
            }(f),
            e(z, "instance", void 0),
            D = t((W = M).prototype, "weaponPickupPrefabs", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            S = t(W.prototype, "initCount", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3
                }
            }),
            T = t(W.prototype, "isTutorial", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            m = W)) || m));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponEnums.ts", ["cc"], (function(e) {
    "use strict";
    var a;
    return {
        setters: [function(e) {
            a = e.cclegacy
        }
        ],
        execute: function() {
            var o;
            e({
                WeaponBulletType: void 0,
                WeaponBulletTypeName: void 0,
                WeaponRarity: void 0,
                WeaponType: void 0
            }),
            a._RF.push({}, "97944zhEnpOuKGuQ44PhKYR", "WeaponEnums", void 0),
            function(e) {
                e[e.Basic = 0] = "Basic",
                e[e.AssaultRifle = 1] = "AssaultRifle",
                e[e.Shotgun = 2] = "Shotgun",
                e[e.Bazooka = 3] = "Bazooka",
                e[e.Debug = 4] = "Debug"
            }(o || (o = e("WeaponType", {})));
            var n, t, u;
            e("WeaponNames", ["Basic", "Assault Rifle", "Shotgun", "Bazooka"]);
            !function(e) {
                e.BulletBasic = "BulletBasic",
                e.BulletAssaultRifle = "BulletAssaultRifle",
                e.BulletShotgun = "BulletShotgun",
                e.BulletBazooka = "BulletBazooka"
            }(n || (n = e("WeaponBulletTypeName", {}))),
            function(e) {
                e[e.Basic = 0] = "Basic",
                e[e.AssaultRifle = 1] = "AssaultRifle",
                e[e.Shotgun = 2] = "Shotgun",
                e[e.Bazooka = 3] = "Bazooka"
            }(t || (t = e("WeaponBulletType", {}))),
            function(e) {
                e[e.Common = 0] = "Common",
                e[e.Uncommon = 1] = "Uncommon",
                e[e.Rare = 2] = "Rare",
                e[e.Epic = 3] = "Epic",
                e[e.Legendary = 4] = "Legendary"
            }(u || (u = e("WeaponRarity", {}))),
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIToastLevelUp.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./UIToast.ts"], (function(t) {
    "use strict";
    var e, o, n, r, i, s, a, c, l, p, u;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            o = t.inheritsLoose,
            n = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            i = t.defineProperty
        }
        , function(t) {
            s = t.cclegacy,
            a = t._decorator,
            c = t.Component
        }
        , function(t) {
            l = t.ProjectEventType
        }
        , function(t) {
            p = t.projectEvent
        }
        , function(t) {
            u = t.UIToast
        }
        ],
        execute: function() {
            var v, f, h;
            s._RF.push({}, "987efFH9T9CRa+72cQqROij", "UIToastLevelUp", void 0);
            var y = a.ccclass
              , U = a.property
              , L = a.requireComponent;
            t("UIToastLevelUp", y("UIToastLevelUp")(v = L(u)((h = e((f = function(t) {
                function e() {
                    for (var e, o = arguments.length, s = new Array(o), a = 0; a < o; a++)
                        s[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(s)) || this,
                    n(r(e), "text", h, r(e)),
                    i(r(e), "toast", void 0),
                    e
                }
                o(e, t);
                var s = e.prototype;
                return s.onLoad = function() {
                    this.toast = this.node.getComponent(u)
                }
                ,
                s.onEnable = function() {
                    p.on(l.PlayerLevelUp, this.onPlayerLevelUp, this)
                }
                ,
                s.onDisable = function() {
                    p.off(l.PlayerLevelUp, this.onPlayerLevelUp, this)
                }
                ,
                s.onPlayerLevelUp = function() {
                    var t;
                    null === (t = this.toast) || void 0 === t || t.show(this.text)
                }
                ,
                e
            }(c)).prototype, "text", [U], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return "LEVEL UP!"
                }
            }),
            v = f)) || v) || v);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterMovement.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./Pathfinding.ts", "./GameplayEnums.ts", "./CharacterBlackboard.ts", "./MatchController.ts", "./Target.ts", "./CharacterInterfaces.ts"], (function(t) {
    "use strict";
    var i, n, e, s, o, a, r, h, l, u, c, d, p, f, g, v, M, m, C;
    return {
        setters: [function(t) {
            i = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            e = t.initializerDefineProperty,
            s = t.assertThisInitialized,
            o = t.defineProperty
        }
        , function(t) {
            a = t.cclegacy,
            r = t._decorator,
            h = t.Vec3,
            l = t.RigidBody,
            u = t.Component
        }
        , function(t) {
            c = t.EventEnterState,
            d = t.CharacterState,
            p = t.EventCharacterAction
        }
        , function(t) {
            f = t.Pathfinding
        }
        , function(t) {
            g = t.MatchState
        }
        , function(t) {
            v = t.CharacterBlackboard
        }
        , function(t) {
            M = t.MatchController
        }
        , function(t) {
            m = t.Target
        }
        , function(t) {
            C = t.CharacterInputBase
        }
        ],
        execute: function() {
            var P, y, S, V;
            a._RF.push({}, "98a6afydAJBSa//BlYnCaKz", "CharacterMovement", void 0);
            var T = r.ccclass
              , b = r.property;
            t("CharacterMovement", T("CharacterMovement")((S = i((y = function(t) {
                function i() {
                    for (var i, n = arguments.length, a = new Array(n), r = 0; r < n; r++)
                        a[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(a)) || this,
                    e(s(i), "characterRadius", S, s(i)),
                    e(s(i), "numberOfPointsToCheckMapCollision", V, s(i)),
                    o(s(i), "rigidBody", void 0),
                    o(s(i), "input", void 0),
                    o(s(i), "data", void 0),
                    o(s(i), "isMoving", !1),
                    o(s(i), "lastAngle", 0),
                    o(s(i), "nextTile", new h),
                    o(s(i), "direction", new h),
                    o(s(i), "currentPos", new h),
                    o(s(i), "inputValues", new h),
                    o(s(i), "collisionPoint", new h),
                    o(s(i), "modifiedInput", new h),
                    o(s(i), "collisionCheckDirections", []),
                    o(s(i), "collisionCheckDirectionsCollisionModifier", []),
                    i
                }
                n(i, t);
                var a = i.prototype;
                return a.onEnable = function() {
                    this.node.on(c.ShootingIdle, this.onShootStart, this)
                }
                ,
                a.onDisable = function() {
                    this.node.off(c.ShootingIdle, this.onShootStart, this)
                }
                ,
                a.start = function() {
                    if (this.data = this.node.getComponent(v),
                    null != this.node.parent) {
                        this.rigidBody = this.node.parent.getComponent(l),
                        this.input = this.node.parent.getComponent(C);
                        for (var t = 0; t < this.numberOfPointsToCheckMapCollision; t++) {
                            var i = t * (2 * Math.PI / this.numberOfPointsToCheckMapCollision);
                            this.collisionCheckDirections.push(new h(Math.cos(i) * this.characterRadius,0,Math.sin(i) * this.characterRadius));
                            var n = new h(this.collisionCheckDirections[t]);
                            n.normalize(),
                            n.multiplyScalar(-1),
                            this.collisionCheckDirectionsCollisionModifier.push(n)
                        }
                    }
                }
                ,
                a.update = function(t) {
                    var i, n;
                    if (null != this.node.parent && null != this.data && null != this.input && ((null === (i = M.instance) || void 0 === i ? void 0 : i.state) == g.Finished && this.isMoving && this.stopMoving(),
                    (null === (n = M.instance) || void 0 === n ? void 0 : n.state) == g.Runing && this.data.state != d.Dying && this.data.state != d.Dead)) {
                        if (this.inputValues.set(this.input.horizontal, 0, -1 * this.input.vertical),
                        this.inputValues.length() > 0) {
                            this.inputValues.normalize();
                            var e = 180 * Math.atan2(this.inputValues.x, this.inputValues.z) / Math.PI;
                            if (e != this.lastAngle) {
                                var s, o = new h(0,e,0);
                                null === (s = this.node.parent) || void 0 === s || s.setRotationFromEuler(o),
                                this.lastAngle = e
                            }
                            if (this.node.parent.getWorldPosition(this.currentPos),
                            this.nextTile.set(this.currentPos),
                            this.nextTile.add(this.inputValues),
                            !f.instance)
                                return;
                            var a = new h(this.inputValues);
                            a.normalize(),
                            a.multiplyScalar(this.data.Speed),
                            a.multiplyScalar(t),
                            a.add(this.node.worldPosition),
                            this.modifiedInput.set(this.inputValues);
                            for (var r = 0; r < this.collisionCheckDirections.length; r++) {
                                var l = this.collisionCheckDirections[r]
                                  , u = this.collisionCheckDirectionsCollisionModifier[r];
                                this.collisionPoint.set(a),
                                this.collisionPoint.add(l),
                                f.instance.isPointWalkable(this.collisionPoint) || this.modifiedInput.add(u)
                            }
                            if (Math.sign(this.modifiedInput.x) != Math.sign(this.inputValues.x) && Math.abs(this.inputValues.x) > .05 && (this.modifiedInput.x = 0),
                            Math.sign(this.modifiedInput.z) != Math.sign(this.inputValues.z) && Math.abs(this.inputValues.z) > .05 && (this.modifiedInput.z = 0),
                            this.inputValues.set(this.modifiedInput),
                            this.inputValues.lengthSqr() < .01)
                                return;
                            0 == this.isMoving && (this.node.emit(p.StartMove),
                            this.isMoving = !0),
                            this.inputValues.normalize(),
                            this.inputValues.multiplyScalar(this.data.Speed),
                            this.inputValues.multiplyScalar(t),
                            this.node.parent.translate(this.inputValues, 1)
                        } else
                            this.rotateToTarget(),
                            this.stopMoving();
                        this.data.isMoving = this.isMoving
                    }
                }
                ,
                a.lateUpdate = function() {
                    null != this.node.parent && null != this.data && this.input
                }
                ,
                a.onShootStart = function(t) {
                    this.rotateToTarget()
                }
                ,
                a.rotateToTarget = function() {
                    if (null != this.node.parent && null != this.data && null != this.input && null != this.data.target) {
                        m.direction(this.direction, this.node.parent, this.data.target);
                        var t = 180 * Math.atan2(this.direction.x, this.direction.z) / Math.PI
                          , i = new h(0,t,0);
                        this.node.parent.setRotationFromEuler(i)
                    }
                }
                ,
                a.stopMoving = function() {
                    this.isMoving && (this.node.emit(p.StopMove),
                    this.isMoving = !1)
                }
                ,
                a.stayOnGround = function() {
                    null != this.node.parent && (this.node.parent.getWorldPosition(this.currentPos),
                    this.nextTile.set(this.currentPos),
                    this.nextTile.y = 0,
                    this.node.parent.setWorldPosition(this.nextTile))
                }
                ,
                i
            }(u)).prototype, "characterRadius", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .5
                }
            }),
            V = i(y.prototype, "numberOfPointsToCheckMapCollision", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 8
                }
            }),
            P = y)) || P);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIVision.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./env", "./Logger.ts", "./Pathfinding.ts", "./MatchController.ts", "./EnemySensor.ts"], (function(i) {
    "use strict";
    var e, a, n, t, o, r, s, l, c, d, u, h, g, b, v, f, I, p;
    return {
        setters: [function(i) {
            e = i.applyDecoratedDescriptor,
            a = i.inheritsLoose,
            n = i.initializerDefineProperty,
            t = i.assertThisInitialized,
            o = i.defineProperty,
            r = i.createForOfIteratorHelperLoose
        }
        , function(i) {
            s = i.cclegacy,
            l = i._decorator,
            c = i.CCBoolean,
            d = i.Node,
            u = i.Vec3,
            h = i.Component
        }
        , function(i) {
            g = i.DEBUG
        }
        , function(i) {
            b = i.logger,
            v = i.LogCategory
        }
        , function(i) {
            f = i.Pathfinding
        }
        , function(i) {
            I = i.MatchController
        }
        , function(i) {
            p = i.EnemySensor
        }
        ],
        execute: function() {
            var y, S, k, w, R, D, P, m, A, B, z, C;
            s._RF.push({}, "9926ck0mwxIjIZeqMidd8jz", "AIVision", void 0);
            var T = l.ccclass
              , V = l.property
              , O = l.executionOrder;
            i("AIVision", (y = T("AIVision"),
            S = O(-1),
            k = V(c),
            w = V(d),
            R = V(d),
            D = V(d),
            y(P = S((A = e((m = function(i) {
                function e() {
                    for (var e, a = arguments.length, r = new Array(a), s = 0; s < a; s++)
                        r[s] = arguments[s];
                    return e = i.call.apply(i, [this].concat(r)) || this,
                    n(t(e), "showDebug", A, t(e)),
                    n(t(e), "debugScaleNode", B, t(e)),
                    n(t(e), "debugScaleRay1", z, t(e)),
                    n(t(e), "debugScaleRay2", C, t(e)),
                    o(t(e), "brain", void 0),
                    o(t(e), "characterBlackboard", void 0),
                    o(t(e), "aiBlackboard", void 0),
                    o(t(e), "sensor", void 0),
                    e
                }
                a(e, i);
                var s = e.prototype;
                return s.init = function(i, e, a) {
                    this.aiBlackboard = i,
                    this.characterBlackboard = e,
                    this.brain = a,
                    this.sensor = this.node.getComponentInChildren(p);
                    var n = this.brain.data.visionData.visionRadius
                      , t = this.brain.data.visionData.visionDistance;
                    this.debugScaleNode.active = this.showDebug && g,
                    this.debugScaleRay1.setScale(1, 1, t),
                    this.debugScaleRay2.setScale(1, 1, t),
                    this.debugScaleRay1.setRotationFromEuler(this.debugScaleRay1.eulerAngles.x, -n / 2, this.debugScaleRay1.eulerAngles.z),
                    this.debugScaleRay2.setRotationFromEuler(this.debugScaleRay2.eulerAngles.x, n / 2, this.debugScaleRay2.eulerAngles.z)
                }
                ,
                s.onUpdate = function(i) {
                    var e;
                    (null === (e = this.aiBlackboard.visionTarget) || void 0 === e ? void 0 : e.isValid) ? (this.checkIfTargetIsOnVisionRange(this.aiBlackboard.visionTarget) || (this.aiBlackboard.visionTarget = null),
                    this.checkIfTargetIsInsideOfShrinkingArea(this.aiBlackboard.visionTarget) && !this.brain.data.chasingData.shouldChaseIntoShrinkingArea && (this.aiBlackboard.visionTarget = null)) : this.findClosestInVision()
                }
                ,
                s.findClosestInVision = function() {
                    for (var i, e = null, a = 999, n = r(I.instance.characters); !(i = n()).done; ) {
                        var t = i.value;
                        if (t != this.node) {
                            var o = this.brain.data.visionData.visionRadius
                              , s = u.distance(t.worldPosition, this.node.worldPosition);
                            if (s <= this.brain.data.visionData.visionDistance) {
                                var l = new u(this.node.worldPosition);
                                l.subtract(t.worldPosition),
                                l.normalize();
                                var c, d = u.angle(l, this.node.forward) * (180 / Math.PI);
                                if (d > -o / 2 && d < o / 2)
                                    if (s < a)
                                        if (this.checkIfTargetIsInsideOfShrinkingArea(t) && !this.brain.data.chasingData.shouldChaseIntoShrinkingArea)
                                            ;
                                        else
                                          //  console.log(this.node.name + " Vision selected " + t.name + " because it is closer than " + (null === (c = e) || void 0 === c ? void 0 : c.name), v.AI),
                                            a = s,
                                            e = t
                            }
                        }
                    }
                    this.aiBlackboard.visionTarget = e
                }
                ,
                s.checkIfTargetIsOnVisionRange = function(i) {
                    var e = this.brain.data.visionData.visionRadius;
                    if (u.distance(i.worldPosition, this.node.worldPosition) <= this.brain.data.visionData.visionDistance) {
                        var a = new u(this.node.worldPosition);
                        a.subtract(i.worldPosition),
                        a.normalize();
                        var n = u.angle(a, this.node.forward) * (180 / Math.PI);
                        if (n > -e / 2 && n < e / 2)
                            return !0
                    }
                    return !1
                }
                ,
                s.checkIfTargetIsInsideOfShrinkingArea = function(i) {
                    var e, a;
                    return null != i && (null !== (e = null === (a = f.instance) || void 0 === a ? void 0 : a.isPointInsideOfShrinkingArea(i.worldPosition.x, i.worldPosition.z)) && void 0 !== e && e)
                }
                ,
                e
            }(h)).prototype, "showDebug", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            B = e(m.prototype, "debugScaleNode", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            z = e(m.prototype, "debugScaleRay1", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = e(m.prototype, "debugScaleRay2", [D], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            P = m)) || P) || P));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/EnemySensor.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./Pathfinding.ts", "./CharacterBlackboard.ts", "./Target.ts"], (function(t) {
    "use strict";
    var e, i, n, r, a, o, s, c, l, h, d, u, g, f, v, T, p, C;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            a = t.defineProperty
        }
        , function(t) {
            o = t.cclegacy,
            s = t._decorator,
            c = t.Node,
            l = t.CCFloat,
            h = t.CCInteger,
            d = t.Vec3,
            u = t.SphereCollider,
            g = t.macro,
            f = t.Component
        }
        , function(t) {
            v = t.EventCharacterAction
        }
        , function(t) {
            T = t.Pathfinding
        }
        , function(t) {
            p = t.CharacterBlackboard
        }
        , function(t) {
            C = t.Target
        }
        ],
        execute: function() {
            var w, y, b, m, P, k, E, D, R, A, S;
            o._RF.push({}, "9b9eepGXjVGwZ/F18PAuPp0", "EnemySensor", void 0);
            var W = s.ccclass
              , G = s.property
              , V = s.executionOrder;
            t("EnemySensor", (w = W("EnemySensor"),
            y = V(-1),
            b = G(c),
            m = G({
                type: l
            }),
            P = G({
                type: h
            }),
            w(k = y((D = e((E = function(t) {
                function e() {
                    for (var e, i = arguments.length, o = new Array(i), s = 0; s < i; s++)
                        o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    n(r(e), "view", D, r(e)),
                    n(r(e), "stickDistance", R, r(e)),
                    n(r(e), "coverGracePeriod", A, r(e)),
                    n(r(e), "alwaysSwapToClosestEnemy", S, r(e)),
                    a(r(e), "target", void 0),
                    a(r(e), "lastTarget", void 0),
                    a(r(e), "targets", []),
                    a(r(e), "collider", void 0),
                    a(r(e), "worldPos", new d),
                    a(r(e), "directionToTarget", new d),
                    a(r(e), "coverGraceCounter", 0),
                    a(r(e), "stickDistanceTotal", 0),
                    a(r(e), "data", null),
                    e
                }
                i(e, t);
                var o = e.prototype;
                return o.onLoad = function() {
                    this.collider = this.node.getComponent(u)
                }
                ,
                o.onEnable = function() {
                    this.node.on(v.Detected, this.onDetected, this),
                    this.node.on(v.Undetected, this.onUndetected, this),
                    this.node.on(v.WeaponChange, this.onWeaponChange, this)
                }
                ,
                o.onDisable = function() {
                    this.node.off(v.Detected, this.onDetected, this),
                    this.node.off(v.Undetected, this.onUndetected, this),
                    this.node.off(v.WeaponChange, this.onWeaponChange, this)
                }
                ,
                o.start = function() {
                    var t;
                    this.node.getWorldPosition(this.worldPos),
                    this.node.parent && (this.data = null === (t = this.node.parent) || void 0 === t ? void 0 : t.getComponentInChildren(p)),
                    this.schedule(this.validateTargetRoutine, .5, g.REPEAT_FOREVER, Math.random())
                }
                ,
                o.onDestroy = function() {
                    this.unscheduleAllCallbacks()
                }
                ,
                o.validateTargetRoutine = function() {
                    var t, e;
                    if (null === (t = this.target) || void 0 === t ? void 0 : t.isValid) {
                        var i, n, r = this.distanceToTarget(this.target);
                        0 == (null === (i = this.data) || void 0 === i || null === (n = i.targetBlackboard) || void 0 === n ? void 0 : n.IsAlive) || r > this.stickDistanceTotal ? this.untrackCurrentTarget() : this.isTargetBehindAWall(this.target) ? (this.coverGraceCounter--,
                        this.coverGraceCounter <= 0 && this.untrackCurrentTarget()) : this.coverGraceCounter = this.coverGracePeriod
                    }
                    if (this.alwaysSwapToClosestEnemy) {
                        var a = this.findClosestTarget();
                        (null == a ? void 0 : a.isValid) && a != this.target && (this.untrackCurrentTarget(),
                        this.trackTarget(a))
                    }
                    null != this.target && this.target.isValid || (this.acquireNewTarget(),
                    null == this.lastTarget || null != this.target && this.target.isValid || null === (e = this.node.parent) || void 0 === e || e.children.forEach((function(t) {
                        t.emit(v.TargetLost)
                    }
                    )));
                    this.lastTarget = this.target
                }
                ,
                o.isTargetBehindAWall = function(t) {
                    var e;
                    if (!t)
                        return !1;
                    if (0 == t.isValid)
                        return !1;
                    C.direction(this.directionToTarget, this.node, t),
                    this.node.getWorldPosition(this.worldPos);
                    var i = [this.worldPos.x, this.worldPos.z]
                      , n = [this.directionToTarget.x, this.directionToTarget.z]
                      , r = []
                      , a = null === (e = T.instance) || void 0 === e ? void 0 : e.raycastOnOriginalMap(i, n, this.stickDistanceTotal, r, [])
                      , o = C.distance(this.node, t);
                    return new d(r[0],0,r[1]).subtract(this.worldPos).length() < o && 0 != a
                }
                ,
                o.onWeaponChange = function(t) {
                    this.collider && this.view && (this.collider.radius = t.Range,
                    this.stickDistanceTotal = t.Range + this.stickDistance,
                    this.view.setScale(2 * t.Range, 2 * t.Range, 1))
                }
                ,
                o.onDetected = function(t) {
                    -1 == this.targets.indexOf(t) && this.targets.push(t),
                    null == this.target && this.acquireNewTarget()
                }
                ,
                o.onUndetected = function(t) {
                    var e = this.targets.indexOf(t);
                    e > -1 && this.targets.splice(e, 1)
                }
                ,
                o.distanceToTarget = function(t) {
                    var e = new d(this.node.worldPosition);
                    return new d(t.worldPosition).subtract(e).length()
                }
                ,
                o.findClosestTarget = function() {
                    for (var t = 999, e = null, i = 0; i < this.targets.length; i++) {
                        var n = this.targets[i]
                          , r = this.distanceToTarget(n);
                        r < t && !this.isTargetBehindAWall(n) && (t = r,
                        e = n)
                    }
                    return e
                }
                ,
                o.acquireNewTarget = function() {
                    var t = this.findClosestTarget();
                    (null == t ? void 0 : t.isValid) && this.trackTarget(t)
                }
                ,
                o.trackTarget = function(t) {
                    var e, i, n = this, r = null === (e = this.node.parent) || void 0 === e ? void 0 : e.children[0];
                    t.children.forEach((function(t) {
                        t.emit(v.Targeted, r)
                    }
                    )),
                    this.target = t,
                    null === (i = this.node.parent) || void 0 === i || i.children.forEach((function(t) {
                        t.emit(v.TargetAquired, n.target)
                    }
                    ))
                }
                ,
                o.untrackCurrentTarget = function() {
                    this.target && (this.target.children.forEach((function(t) {
                        t.emit(v.Untargeted)
                    }
                    )),
                    this.target = null)
                }
                ,
                e
            }(f)).prototype, "view", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            R = e(E.prototype, "stickDistance", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 2
                }
            }),
            A = e(E.prototype, "coverGracePeriod", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3
                }
            }),
            S = e(E.prototype, "alwaysSwapToClosestEnemy", [G], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            k = E)) || k) || k));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuArenaSelector.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./PanelManager.ts", "./PanelEnums.ts", "./MainMenuArenaWidget.ts", "./MetagameArenaData.ts", "./MainMenuArenaUnlockPanel.ts"], (function(e) {
    "use strict";
    var n, a, t, r, o, i, l, c, s, u, f, d, p, g, h, A, P, v, y, M, b, m, S;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            a = e.inheritsLoose,
            t = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            o = e.defineProperty,
            i = e.createForOfIteratorHelperLoose
        }
        , function(e) {
            l = e.cclegacy,
            c = e._decorator,
            s = e.Prefab,
            u = e.Layout,
            f = e.instantiate,
            d = e.Component
        }
        , function(e) {
            p = e.logger,
            g = e.LogCategory,
            h = e.LogType
        }
        , function(e) {
            A = e.UIEventType
        }
        , function(e) {
            P = e.projectEvent
        }
        , function(e) {
            v = e.globalPlayer
        }
        , function(e) {
            y = e.PanelManager
        }
        , function(e) {
            M = e.PanelId
        }
        , function(e) {
            b = e.MainMenuArenaWidget
        }
        , function(e) {
            m = e.MetagameArenaData
        }
        , function(e) {
            S = e.MainMenuArenaUnlockPanel
        }
        ],
        execute: function() {
            var D, L, k, U, W, C, w, z, E, I, _;
            l._RF.push({}, "9bc21L9kM1D8pNHoOQ4dJZV", "MainMenuArenaSelector", void 0);
            var j = c.ccclass
              , F = c.property;
            e("MainMenuArenaSelector", (D = j("MainMenuArenaSelector"),
            L = F(s),
            k = F(u),
            U = F(S),
            W = F(s),
            D((z = n((w = function(e) {
                function n() {
                    for (var n, a = arguments.length, i = new Array(a), l = 0; l < a; l++)
                        i[l] = arguments[l];
                    return n = e.call.apply(e, [this].concat(i)) || this,
                    t(r(n), "arenaWidgetPrefab", z, r(n)),
                    t(r(n), "arenaWidgetLayout", E, r(n)),
                    t(r(n), "arenaUnlockPanel", I, r(n)),
                    t(r(n), "arenaData", _, r(n)),
                    o(r(n), "canvas", void 0),
                    o(r(n), "widgets", void 0),
                    n
                }
                a(n, e);
                var l = n.prototype;
                return l.onEnable = function() {
                    P.on(A.ArenaPurchaseSucccess, this.onArenaPurchaseConfirmation, this)
                }
                ,
                l.onDisable = function() {
                    P.off(A.ArenaPurchaseSucccess, this.onArenaPurchaseConfirmation, this)
                }
                ,
                l.start = function() {
                    this.arenaData ? this.setup() : console.log("Could not find MetagameArenaData!", g.UI, h.Error)
                }
                ,
                l.setup = function() {
                    this.clearWidgets();
                    for (var e, n = this.arenaData.data.getComponent(m), a = i(n.Arenas); !(e = a()).done; ) {
                        var t = e.value
                          , r = f(this.arenaWidgetPrefab);
                        r.setParent(this.arenaWidgetLayout.node);
                        var o = r.getComponent(b);
                        o.setup(t),
                        this.widgets.push(o),
                        r.on(A.ArenaSelected, this.onArenaSelected, this)
                    }
                }
                ,
                l.onArenaSelected = function(e) {
                    var n, a;
                    v.hasUnlocked(e.UnlockId) ? null === (n = y.instance) || void 0 === n || n.close(M.ArenaSelector) : (this.arenaUnlockPanel.setup(e),
                    null === (a = y.instance) || void 0 === a || a.open(M.ArenaUnlock))
                }
                ,
                l.onArenaPurchaseConfirmation = function(e) {
                    var n;
                    v.purchaseArena(e),
                    null === (n = y.instance) || void 0 === n || n.close(M.ArenaUnlock),
                    this.setup()
                }
                ,
                l.clearWidgets = function() {
                    for (var e, n = i(this.arenaWidgetLayout.node.children); !(e = n()).done; ) {
                        var a = e.value;
                        a.off(A.ArenaSelected, this.onArenaSelected),
                        a.destroy()
                    }
                    this.widgets = []
                }
                ,
                n
            }(d)).prototype, "arenaWidgetPrefab", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = n(w.prototype, "arenaWidgetLayout", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = n(w.prototype, "arenaUnlockPanel", [U], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            _ = n(w.prototype, "arenaData", [W], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = w)) || C));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterUI.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./CharacterEnums.ts", "./UITrackWorldNode.ts"], (function(t) {
    "use strict";
    var e, a, i, r, o, n, l, s, c, h, p, u, d;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            a = t.inheritsLoose,
            i = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            o = t.defineProperty
        }
        , function(t) {
            n = t.cclegacy,
            l = t._decorator,
            s = t.ProgressBar,
            c = t.Label,
            h = t.Component
        }
        , function(t) {
            p = t.logger
        }
        , function(t) {
            u = t.EventCharacterAction
        }
        , function(t) {
            d = t.UITrackWorldNode
        }
        ],
        execute: function() {
            var g, f, v, m, b, y, U, L, I, k, C;
            n._RF.push({}, "9bc31DSWRBKLapMJ2FWUrJL", "CharacterUI", void 0);
            var H = l.ccclass
              , P = l.property;
            t("CharacterUI", (g = H("CharacterUI"),
            f = P(s),
            v = P(s),
            m = P(c),
            b = P(c),
            g((L = e((U = function(t) {
                function e() {
                    for (var e, a = arguments.length, n = new Array(a), l = 0; l < a; l++)
                        n[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(n)) || this,
                    i(r(e), "pgHealth", L, r(e)),
                    i(r(e), "pgAmmo", I, r(e)),
                    i(r(e), "lHealth", k, r(e)),
                    i(r(e), "lLevel", C, r(e)),
                    o(r(e), "data", void 0),
                    o(r(e), "track", void 0),
                    e
                }
                a(e, t);
                var n = e.prototype;
                return n.start = function() {
                    this.track = this.node.getComponent(d)
                }
                ,
                n.update = function() {
                    null != this.data && (this.pgHealth.progress = this.data.health / this.data.HealthMax,
                    this.data.IsPlayer && (this.lHealth.string = this.data.health.toFixed()),
                    this.pgAmmo.progress = this.data.ammo / this.data.ammoMax)
                }
                ,
                n.setup = function(t) {
                    this.data = t,
                    this.track || (this.track = this.node.getComponent(d)),
                    this.track && (t.UIPivot ? this.track.setup(t.UIPivot) : console.log("Could not setup character UI tracking")),
                    this.lHealth.node.active = t.IsPlayer,
                    this.data.node.on(u.LevelUp, this.onLevelUp, this)
                }
                ,
                n.onDisable = function() {
                    this.data && this.data.node.off(u.LevelUp, this.onLevelUp, this)
                }
                ,
                n.onLevelUp = function(t) {
                    this.lLevel.string = t.toFixed()
                }
                ,
                e
            }(h)).prototype, "pgHealth", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = e(U.prototype, "pgAmmo", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            k = e(U.prototype, "lHealth", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = e(U.prototype, "lLevel", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = U)) || y));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TreasurePickup.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts", "./PickupEnums.ts", "./BasePickup.ts", "./WeaponPickupManager.ts"], (function(t) {
    "use strict";
    var e, n, o, i, c, r, a, s, u, l;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            n = t.cclegacy,
            o = t._decorator
        }
        , function(t) {
            i = t.ProjectEventType
        }
        , function(t) {
            c = t.projectEvent
        }
        , function(t) {
            r = t.EventCharacterAction
        }
        , function(t) {
            a = t.CharacterBlackboard
        }
        , function(t) {
            s = t.EventPickup
        }
        , function(t) {
            u = t.BasePickup
        }
        , function(t) {
            l = t.WeaponPickupManager
        }
        ],
        execute: function() {
            var p;
            n._RF.push({}, "9c0a2WODRtCTbRFPBcJlVNW", "TreasurePickup", void 0);
            var d = o.ccclass;
            o.property,
            t("TreasurePickup", d("TreasurePickup")(p = function(t) {
                function n() {
                    return t.apply(this, arguments) || this
                }
                return e(n, t),
                n.prototype.handlePickupCollection = function() {
                    var e, n, o;
                    this.node.emit(s.Collected),
                    null === (e = l.instance) || void 0 === e || e.spawnRandomWeapon(this.node.worldPosition),
                    null === (n = this.originalCollector) || void 0 === n || null === (o = n.children[0]) || void 0 === o || o.emit(r.CollectedChest);
                    var u = this.originalCollector.children[0].getComponent(a);
                    (null == u ? void 0 : u.IsPlayer) && c.emit(i.PlayerCollectedChest),
                    this.node.isValid && (t.prototype.unuse.call(this),
                    this.node.active = !1)
                }
                ,
                n
            }(u)) || p);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MapSpawner.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var e, r, n, a, i, o, s, p, c, u, f;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            r = t.inheritsLoose,
            n = t.initializerDefineProperty,
            a = t.assertThisInitialized
        }
        , function(t) {
            i = t.cclegacy,
            o = t._decorator,
            s = t.Prefab,
            p = t.instantiate,
            c = t.Component
        }
        , function(t) {
            u = t.ProjectEventType
        }
        , function(t) {
            f = t.projectEvent
        }
        ],
        execute: function() {
            var l, h, v, y, b;
            i._RF.push({}, "9dd63flawBOfK0yrp6snLDc", "MapSpawner", void 0);
            var d = o.ccclass
              , w = o.property;
            t("MapSpawner", (l = d("MapSpawner"),
            h = w({
                type: [s],
                tooltip: "This array must match the tileset configuration, so configure with empty positions where needed."
            }),
            l((b = e((y = function(t) {
                function e() {
                    for (var e, r = arguments.length, i = new Array(r), o = 0; o < r; o++)
                        i[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(i)) || this,
                    n(a(e), "prefabs", b, a(e)),
                    e
                }
                r(e, t);
                var i = e.prototype;
                return i.onEnable = function() {
                    f.on(u.MapSetup, this.setup, this)
                }
                ,
                i.onDisable = function() {
                    f.off(u.MapSetup, this.setup, this)
                }
                ,
                i.setup = function(t) {
                    var e = this
                      , r = t.width;
                    t.layers.forEach((function(t) {
                        var n = 0;
                        t.data.forEach((function(t) {
                            var a = Number(t);
                            if (NaN != a && -1 != a && a >= 0 && a < e.prefabs.length && e.prefabs[a]) {
                                var i = p(e.prefabs[a]);
                                i.setParent(e.node);
                                var o = n % r
                                  , s = Math.floor(n / r);
                                i.setPosition(o, 0, s)
                            }
                            n += 1
                        }
                        ))
                    }
                    ))
                }
                ,
                e
            }(c)).prototype, "prefabs", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            v = y)) || v));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AudioItem.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, i, r, n, u, o, l, s;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.createClass,
            r = e.initializerDefineProperty
        }
        , function(e) {
            n = e.cclegacy,
            u = e._decorator,
            o = e.Prefab,
            l = e.CCFloat,
            s = e.AudioClip
        }
        ],
        execute: function() {
            var a, c, p, f, y, b, m, h, d;
            n._RF.push({}, "9e1e3rX0ktE9pKy3qyrVu/Z", "AudioItem", void 0);
            var g = u.ccclass
              , k = u.property;
            e("AudioItem", (a = g("AudioItem"),
            c = k({
                type: o,
                serializable: !0
            }),
            p = k({
                type: l,
                slide: !0,
                range: [0, 1]
            }),
            f = k({
                type: [s],
                serializable: !0
            }),
            a((m = t((b = function() {
                function e() {
                    r(this, "key", m, this),
                    r(this, "volume", h, this),
                    r(this, "sfxs", d, this)
                }
                return i(e, [{
                    key: "Key",
                    get: function() {
                        return this.key
                    }
                }, {
                    key: "Volume",
                    get: function() {
                        return this.volume
                    }
                }, {
                    key: "SFXs",
                    get: function() {
                        return this.sfxs
                    }
                }]),
                e
            }()).prototype, "key", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return null
                }
            }),
            h = t(b.prototype, "volume", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            d = t(b.prototype, "sfxs", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            y = b)) || y));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponEffects.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts"], (function(t) {
    "use strict";
    var o, e, n, i, a, r, l, s, h;
    return {
        setters: [function(t) {
            o = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            n = t.initializerDefineProperty,
            i = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            r = t._decorator,
            l = t.ParticleSystem,
            s = t.Component
        }
        , function(t) {
            h = t.EventCharacterAction
        }
        ],
        execute: function() {
            var c, u, p, f, S, y, d, v, b;
            a._RF.push({}, "9eaa80FzNhAzJaXeCATcyGW", "WeaponEffects", void 0);
            var m = r.ccclass
              , P = r.property;
            t("WeaponEffects", (c = m("WeaponEffects"),
            u = P(l),
            p = P(l),
            f = P(l),
            c((d = o((y = function(t) {
                function o() {
                    for (var o, e = arguments.length, a = new Array(e), r = 0; r < e; r++)
                        a[r] = arguments[r];
                    return o = t.call.apply(t, [this].concat(a)) || this,
                    n(i(o), "onShotParticle", d, i(o)),
                    n(i(o), "onShotSmoke", v, i(o)),
                    n(i(o), "onShotFlash", b, i(o)),
                    o
                }
                e(o, t);
                var a = o.prototype;
                return a.onEnable = function() {
                    this.node.on(h.Shoot, this.playOnShot, this),
                    this.node.on(h.ShootBullet, this.playOnShot, this)
                }
                ,
                a.onDisable = function() {
                    this.node.off(h.Shoot, this.playOnShot, this),
                    this.node.off(h.ShootBullet, this.playOnShot, this)
                }
                ,
                a.playOnShot = function(t) {
                    var o, e, n;
                    if (this.onShotParticle) {
                        var i = Math.atan2(t.x, t.z);
                        this.onShotParticle.startRotationY.constant = i,
                        null === (o = this.onShotParticle) || void 0 === o || o.play(),
                        null === (e = this.onShotSmoke) || void 0 === e || e.play(),
                        null === (n = this.onShotFlash) || void 0 === n || n.play()
                    }
                }
                ,
                a.delay = function(t) {
                    return new Promise((function(o) {
                        return setTimeout(o, 1e3 * t)
                    }
                    ))
                }
                ,
                o
            }(s)).prototype, "onShotParticle", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = o(y.prototype, "onShotSmoke", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = o(y.prototype, "onShotFlash", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            S = y)) || S));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/OverlayButton.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./TweenCollection.ts"], (function(t) {
    "use strict";
    var e, n, i, o, r, a, s, c, l, u, p;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            i = t.initializerDefineProperty,
            o = t.assertThisInitialized,
            r = t.defineProperty
        }
        , function(t) {
            a = t.cclegacy,
            s = t._decorator,
            c = t.Button,
            l = t.Component
        }
        , function(t) {
            u = t.logger
        }
        , function(t) {
            p = t.TweenCollection
        }
        ],
        execute: function() {
            var h, f, v, b, y, O, g;
            a._RF.push({}, "9fa8fiObhxLYoBtWsgTpXSZ", "OverlayButton", void 0);
            var w = s.ccclass
              , d = s.property;
            t("OverlayButton", (h = w("OverlayButton"),
            f = d(c),
            v = d(p),
            h((O = e((y = function(t) {
                function e() {
                    for (var e, n = arguments.length, a = new Array(n), s = 0; s < n; s++)
                        a[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    i(o(e), "button", O, o(e)),
                    i(o(e), "activationTween", g, o(e)),
                    r(o(e), "isOn", !1),
                    e
                }
                n(e, t);
                var a = e.prototype;
                return a.onLoad = function() {
                    var t = this;
                    this.node.children[1].active = false;

                    this.button.interactable = !1,
                    this.scheduleOnce((function() {
                        t.isOn || (t.button.interactable = !0)
                    }
                    ), .33),
                    console.log("test")
                }
                ,
                a.reset = function() {
                    this.activationTween.reset(),
                    this.isOn = !1
                }
                ,
                a.activate = function() {
                    this.isOn || (this.button.interactable = !1,
                    this.activationTween.play(),
                    this.isOn = !0)
                }
                ,
                a.deactivate = function() {
                    this.isOn && (this.button.interactable = !0,
                    this.activationTween.playReverse(),
                    this.isOn = !1)
                }
                ,
                e
            }(l)).prototype, "button", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            g = e(y.prototype, "activationTween", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = y)) || b));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotReloadingData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./BotStateData.ts"], (function(t) {
    "use strict";
    var e, a, r, i, n, o, c;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            a = t.inheritsLoose,
            r = t.initializerDefineProperty,
            i = t.assertThisInitialized
        }
        , function(t) {
            n = t.cclegacy,
            o = t._decorator
        }
        , function(t) {
            c = t.BotStateData
        }
        ],
        execute: function() {
            var l, s, u, p, f, g;
            n._RF.push({}, "a17baSXMfhAs6cixjqBwW0D", "BotReloadingData", void 0);
            var d = o.ccclass
              , D = o.property;
            t("BotReloadingData", (l = d("BotReloadingData"),
            s = D({
                range: [0, 1],
                step: .05,
                slide: !0
            }),
            l((f = e((p = function(t) {
                function e() {
                    for (var e, a = arguments.length, n = new Array(a), o = 0; o < a; o++)
                        n[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(n)) || this,
                    r(i(e), "maxAvoidDistance", f, i(e)),
                    r(i(e), "interruptToShootPercentage", g, i(e)),
                    e
                }
                return a(e, t),
                e
            }(c)).prototype, "maxAvoidDistance", [D], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            g = e(p.prototype, "interruptToShootPercentage", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .25
                }
            }),
            u = p)) || u));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterEnums.ts", ["cc"], (function(t) {
    "use strict";
    var e;
    return {
        setters: [function(t) {
            e = t.cclegacy
        }
        ],
        execute: function() {
            var n, o, a, i;
            t({
                CharacterState: void 0,
                EventCharacterAction: void 0,
                EventEnterState: void 0,
                EventExitState: void 0
            }),
            e._RF.push({}, "a2540sMD9FJ6Z5QN+LvSJxB", "CharacterEnums", void 0),
            function(t) {
                t.Shoot = "shoot",
                t.ShootBullet = "shoot-bullet",
                t.ShootFinished = "shoot-finished",
                t.Detected = "detected",
                t.Undetected = "undetected",
                t.Targeted = "targeted",
                t.Untargeted = "untargeted",
                t.TargetAquired = "target-aquired",
                t.TargetLost = "target-lost",
                t.StartMove = "start-move",
                t.StopMove = "stop-move",
                t.HitReceived = "hit-received",
                t.DyingStart = "dying-start",
                t.DyingEnd = "dying-end",
                t.EnterCombat = "enter-combat",
                t.ExitCombat = "exit-combat",
                t.WeaponChange = "weapon-change",
                t.StartPicking = "start-picking",
                t.StopPicking = "stop-picking",
                t.HealthRegenStart = "health-regen-start",
                t.HealthRegenStop = "health-regen-stop",
                t.EnterDamageZone = "enter-damage-zone",
                t.ExitDamageZone = "exit-damage-zone",
                t.LevelUp = "level-up",
                t.CollectedChest = "collected-chest",
                t.KilledOther = "killed-other",
                t.DealtDamage = "dealt-damage"
            }(n || (n = t("EventCharacterAction", {}))),
            function(t) {
                t.Idle = "idle",
                t.Moving = "moving",
                t.ShootingIdle = "shooting-idle",
                t.Shooting = "shooting",
                t.PickingUp = "pickingup",
                t.Dying = "dying",
                t.Dead = "dead"
            }(o || (o = t("CharacterState", {}))),
            function(t) {
                t.ShootingIdle = "enter-shooting-idle"
            }(a || (a = t("EventEnterState", {}))),
            function(t) {
                t.ShootingIdle = "exit-shooting-idle"
            }(i || (i = t("EventExitState", {}))),
            e._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuOverlay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./OverlayButton.ts", "./UIMatchPageViewToScreenWidth.ts"], (function(t) {
    "use strict";
    var e, i, n, a, s, o, r, l, c, h, u, g, p, b, f;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            a = t.assertThisInitialized,
            s = t.defineProperty
        }
        , function(t) {
            o = t.cclegacy,
            r = t._decorator,
            l = t.Label,
            c = t.PageView,
            h = t.Component
        }
        , function(t) {
            u = t.MetagameEvent
        }
        , function(t) {
            g = t.projectEvent
        }
        , function(t) {
            p = t.globalPlayer
        }
        , function(t) {
            b = t.OverlayButton
        }
        , function(t) {
            f = t.EventPageView
        }
        ],
        execute: function() {
            var v, d, y, P, w, T, B, V, L, M;
            o._RF.push({}, "a31dbytrXNMULO/nyAxOoLZ", "MainMenuOverlay", void 0);
            var z = r.ccclass
              , C = r.property;
            t("MainMenuOverlay", (v = z("MainMenuOverlay"),
            d = C(l),
            y = C(c),
            P = C([b]),
            v((B = e((T = function(t) {
                function e() {
                    for (var e, i = arguments.length, o = new Array(i), r = 0; r < i; r++)
                        o[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    n(a(e), "trophiesLabel", B, a(e)),
                    n(a(e), "startPage", V, a(e)),
                    n(a(e), "pageView", L, a(e)),
                    n(a(e), "tabsButtons", M, a(e)),
                    s(a(e), "canvas", void 0),
                    e
                }
                i(e, t);
                var o = e.prototype;
                return o.start = function() {
                  //xz 主界面
                    var t;
                    this.setLabelText(this.trophiesLabel, p.victoryTrophies.toFixed()),
                    this.tabsButtons.forEach((function(t) {
                        t.reset()
                    }
                    )),
                    null === (t = this.pageView) || void 0 === t || t.node.on("page-turning", this.onPageChanged, this),
                    this.pageView.cancelInnerEvents = !1,
                    this.activateTabInstantly(this.startPage)
                }
                ,
                o.onEnable = function() {
                    g.on(u.TrophiesChanged, this.onTrophiesChanged, this),
                    g.on(f.FinishedResize, this.onPageViewFinishResize, this)
                }
                ,
                o.onDisable = function() {
                    g.off(u.TrophiesChanged, this.onTrophiesChanged, this),
                    g.off(f.FinishedResize, this.onPageViewFinishResize, this)
                }
                ,
                o.onTrophiesChanged = function(t, e) {
                    this.setLabelText(this.trophiesLabel, e.toFixed())
                }
                ,
                o.onPageViewFinishResize = function() {
                    this.activateTab(this.startPage)
                }
                ,
                o.onPageChanged = function() {
                    for (var t = this.pageView.getCurrentPageIndex(), e = 0; e < this.tabsButtons.length; e++)
                        e == t ? this.tabsButtons[e].activate() : this.tabsButtons[e].deactivate()
                }
                ,
                o.tabClick = function(t, e) {
                    if (t.target)
                        for (var i = 0; i < this.tabsButtons.length; i++)
                            if (this.tabsButtons[i].node == t.target) {
                                this.activateTab(i);
                                break
                            }
                }
                ,
                o.activateTab = function(t) {
                    this.tabsButtons[t].activate(),
                    this.pageView.scrollToPage(t, .2)
                }
                ,
                o.activateTabInstantly = function(t) {
                    this.tabsButtons[t].activate(),
                    this.pageView.scrollToPage(t, .1)
                }
                ,
                o.setLabelText = function(t, e) {
                    t.string = e,
                    t.updateRenderData(!0)
                }
                ,
                e
            }(h)).prototype, "trophiesLabel", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            V = e(T.prototype, "startPage", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            L = e(T.prototype, "pageView", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = e(T.prototype, "tabsButtons", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            w = T)) || w));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayerMissionHook.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./GlobalPlayer.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var n, o, e, a, i, r, s, l, c;
    return {
        setters: [function(t) {
            n = t.inheritsLoose,
            o = t.defineProperty,
            e = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            i = t._decorator,
            r = t.Component
        }
        , function(t) {
            s = t.globalPlayer
        }
        , function(t) {
            l = t.EventCharacterAction
        }
        , function(t) {
            c = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var h;
            a._RF.push({}, "a733890I6FL8p1PR+F7KfGq", "PlayerMissionHook", void 0);
            var d = i.ccclass;
            i.property,
            t("PlayerMissionHook", d("PlayerMissionHook")(h = function(t) {
                function a() {
                    for (var n, a = arguments.length, i = new Array(a), r = 0; r < a; r++)
                        i[r] = arguments[r];
                    return n = t.call.apply(t, [this].concat(i)) || this,
                    o(e(n), "data", void 0),
                    n
                }
                n(a, t);
                var i = a.prototype;
                return i.onLoad = function() {
                    this.data = this.getComponentInChildren(c)
                }
                ,
                i.onEnable = function() {
                    this.data && this.data.node.on(l.KilledOther, this.onKilledOther, this)
                }
                ,
                i.onDisable = function() {
                    this.data && this.data.node.off(l.KilledOther, this.onKilledOther, this)
                }
                ,
                i.onKilledOther = function() {
                    this.data && s.onEnemyKilled(this.data.currentWeapon)
                }
                ,
                a
            }(r)) || h);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/ShrinkingAreaManager.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./CharacterEnums.ts", "./GameplayEnums.ts", "./MatchController.ts"], (function(t) {
    "use strict";
    var i, e, o, s, r, n, a, h, l, u, d, c, p, g, f, m, R, C, b, y, v;
    return {
        setters: [function(t) {
            i = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            o = t.initializerDefineProperty,
            s = t.assertThisInitialized,
            r = t.defineProperty
        }
        , function(t) {
            n = t.cclegacy,
            a = t._decorator,
            h = t.Node,
            l = t.CCFloat,
            u = t.Vec3,
            d = t.BoxCollider,
            c = t.Component
        }
        , function(t) {
            p = t.logger,
            g = t.LogCategory
        }
        , function(t) {
            f = t.ProjectEventType,
            m = t.PHY_GROUP,
            R = t.OnTrigger
        }
        , function(t) {
            C = t.projectEvent
        }
        , function(t) {
            b = t.EventCharacterAction
        }
        , function(t) {
            y = t.MatchState
        }
        , function(t) {
            v = t.MatchController
        }
        ],
        execute: function() {
            var T, Y, M, X, S, L, w, B, P, k, z, G, E, A, F, x, D, H, W, _, j, O, V, I, Z, q, N, Q, U, J;
            n._RF.push({}, "a7595wYLGdIqb8SgpVHcBoQ", "ShrinkingAreaManager", void 0);
            var K = a.ccclass
              , $ = a.property;
            t("ShrinkingAreaManager", (T = K("ShrinkingAreaManager"),
            Y = $(h),
            M = $(h),
            X = $(h),
            S = $(h),
            L = $(h),
            w = $(h),
            B = $(h),
            P = $(h),
            k = $({
                min: .001
            }),
            z = $({
                min: .001
            }),
            G = $({
                min: 1
            }),
            E = $({
                min: 1
            }),
            A = $({
                type: l,
                min: 0
            }),
            T((D = i((x = function(t) {
                function i() {
                    for (var i, e = arguments.length, n = new Array(e), a = 0; a < e; a++)
                        n[a] = arguments[a];
                    return i = t.call.apply(t, [this].concat(n)) || this,
                    o(s(i), "sideTop", D, s(i)),
                    o(s(i), "sideBottom", H, s(i)),
                    o(s(i), "sideRight", W, s(i)),
                    o(s(i), "sideLeft", _, s(i)),
                    o(s(i), "cornerTopRight", j, s(i)),
                    o(s(i), "cornerTopLeft", O, s(i)),
                    o(s(i), "cornerBottomRight", V, s(i)),
                    o(s(i), "cornerBottomLeft", I, s(i)),
                    o(s(i), "speedX", Z, s(i)),
                    o(s(i), "speedY", q, s(i)),
                    o(s(i), "minRadiusX", N, s(i)),
                    o(s(i), "minRadiusY", Q, s(i)),
                    o(s(i), "startDelayAfterMatchStart", U, s(i)),
                    o(s(i), "heightFromGround", J, s(i)),
                    r(s(i), "map", void 0),
                    r(s(i), "posTop", new u),
                    r(s(i), "posBottom", new u),
                    r(s(i), "posLeft", new u),
                    r(s(i), "posRight", new u),
                    r(s(i), "posCornerTopRight", new u),
                    r(s(i), "posCornerTopLeft", new u),
                    r(s(i), "posCornerBottomRight", new u),
                    r(s(i), "posCornerBottomLeft", new u),
                    r(s(i), "currentRadiusX", 0),
                    r(s(i), "currentRadiusY", 0),
                    r(s(i), "lastRadiusX", 0),
                    r(s(i), "lastRadiusY", 0),
                    r(s(i), "shrinkedCountX", 0),
                    r(s(i), "shrinkedCountY", 0),
                    r(s(i), "reachedMinWidth", !1),
                    r(s(i), "reachedMinHeight", !1),
                    r(s(i), "isOn", !1),
                    r(s(i), "scaleX", 1),
                    r(s(i), "scaleY", 1),
                    r(s(i), "delayTilesX", 0),
                    r(s(i), "delayTilesY", 0),
                    i
                }
                e(i, t);
                var n = i.prototype;
                return n.onEnable = function() {
                    C.on(f.MatchStart, this.onMatchStart, this),
                    C.on(f.MapSetup, this.setup, this)
                }
                ,
                n.onDisable = function() {
                    C.off(f.MatchStart, this.onMatchStart, this),
                    C.off(f.MapSetup, this.setup, this)
                }
                ,
                n.setup = function(t) {
                    this.map = t;
                    var i = this.map.width
                      , e = this.map.height
                      , o = i / 2
                      , s = e / 2;
                    this.node.setWorldPosition(o, 0, s);
                    var r = this.startDelayAfterMatchStart * this.speedX
                      , n = this.startDelayAfterMatchStart * this.speedY
                      , a = o + r
                      , h = s + n;
                    this.currentRadiusX = a,
                    this.currentRadiusY = h,
                    this.lastRadiusX = Math.floor(this.currentRadiusX),
                    this.lastRadiusY = Math.floor(this.currentRadiusY),
                    this.scaleX = i + 2 * r,
                    this.scaleY = e + 2 * n,
                    this.delayTilesX = Math.ceil(r) + 1,
                    this.delayTilesY = Math.ceil(n) + 1,
                    this.posTop.set(0, this.heightFromGround, -h),
                    this.posBottom.set(0, this.heightFromGround, h),
                    this.posLeft.set(-a, this.heightFromGround, 0),
                    this.posRight.set(a, this.heightFromGround, 0),
                    this.posCornerTopRight.set(a, this.heightFromGround, -h),
                    this.posCornerTopLeft.set(-a, this.heightFromGround, -h),
                    this.posCornerBottomRight.set(a, this.heightFromGround, h),
                    this.posCornerBottomLeft.set(-a, this.heightFromGround, h),
                    this.setupCollidersCallbacks(this.sideTop),
                    this.setupCollidersCallbacks(this.sideBottom),
                    this.setupCollidersCallbacks(this.sideLeft),
                    this.setupCollidersCallbacks(this.sideRight),
                    this.updateSidesPositions(),
                    this.updateSidesScales(),
                    this.updateCornerPositions(),
                    console.log("Setup of shrinking area: w:" + i + " h:" + e + ", center X:" + o + " Y:" + s + ", delay start: (" + a + "," + h + ")", g.Gameplay)
                }
                ,
                n.update = function(t) {
                    var i;
                    if ((null === (i = v.instance) || void 0 === i ? void 0 : i.state) == y.Runing && this.isOn && (!this.reachedMinWidth || !this.reachedMinHeight)) {
                        if (!this.reachedMinWidth) {
                            var e = this.speedX * t;
                            this.currentRadiusX -= e,
                            this.currentRadiusX < this.minRadiusX ? (this.reachedMinWidth = !0,
                            console.log("currentRadiusX: " + this.currentRadiusX + " / minWidth: " + this.minRadiusX + " Reached shrinking area min width", g.Gameplay)) : Math.floor(this.currentRadiusX) < this.lastRadiusX && (this.lastRadiusX = Math.floor(this.currentRadiusX),
                            this.shrinkedCountX++,
                            this.shrinkedCountX > this.delayTilesX && C.emit(f.MapAreaShrinkedX, this.shrinkedCountX - this.delayTilesX)),
                            this.posLeft.x += e,
                            this.posRight.x -= e,
                            this.scaleX -= 2 * e,
                            this.posCornerTopRight.x -= e,
                            this.posCornerTopLeft.x += e,
                            this.posCornerBottomRight.x -= e,
                            this.posCornerBottomLeft.x += e
                        }
                        if (!this.reachedMinHeight) {
                            var o = this.speedY * t;
                            this.currentRadiusY -= o,
                            this.currentRadiusY < this.minRadiusY ? (this.reachedMinHeight = !0,
                            console.log("currentRadiusY: " + this.currentRadiusY + " / minHeight: " + this.minRadiusY + " Reached shrinking area min height", g.Gameplay)) : Math.floor(this.currentRadiusY) < this.lastRadiusY && (this.lastRadiusY = Math.floor(this.currentRadiusY),
                            this.shrinkedCountY++,
                            this.shrinkedCountY > this.delayTilesY && C.emit(f.MapAreaShrinkedY, this.shrinkedCountY - this.delayTilesY)),
                            this.posTop.z += o,
                            this.posBottom.z -= o,
                            this.scaleY -= 2 * o,
                            this.posCornerTopRight.z += o,
                            this.posCornerTopLeft.z += o,
                            this.posCornerBottomRight.z -= o,
                            this.posCornerBottomLeft.z -= o
                        }
                        this.updateSidesPositions(),
                        this.updateSidesScales(),
                        this.updateCornerPositions()
                    }
                }
                ,
                n.onTriggerEnter = function(t) {
                    var i;
                    null != t.otherCollider && t.otherCollider.node.isValid && t.otherCollider.getGroup() == m.PLAYER && (null === (i = t.otherCollider.node.children[0]) || void 0 === i || i.emit(b.EnterDamageZone))
                }
                ,
                n.onTriggerExit = function(t) {
                    var i;
                    null != t.otherCollider && t.otherCollider.node.isValid && t.otherCollider.getGroup() == m.PLAYER && (null === (i = t.otherCollider.node.children[0]) || void 0 === i || i.emit(b.ExitDamageZone))
                }
                ,
                n.onMatchStart = function() {
                    this.isOn = !0,
                    console.log("Match started, starting shrinking area with delay distance", g.Gameplay)
                    CoinApp.showBanner();
                }
                ,
                n.setupCollidersCallbacks = function(t) {
                    var i = null == t ? void 0 : t.getComponent(d);
                    i && (i.isTrigger = !0,
                    null == i || i.on(R.Enter, this.onTriggerEnter, this),
                    null == i || i.on(R.Exit, this.onTriggerExit, this))
                }
                ,
                n.updateSidesPositions = function() {
                    var t, i, e, o;
                    null === (t = this.sideTop) || void 0 === t || t.setPosition(this.posTop),
                    null === (i = this.sideBottom) || void 0 === i || i.setPosition(this.posBottom),
                    null === (e = this.sideLeft) || void 0 === e || e.setPosition(this.posLeft),
                    null === (o = this.sideRight) || void 0 === o || o.setPosition(this.posRight)
                }
                ,
                n.updateSidesScales = function() {
                    var t, i, e, o, s, r, n, a;
                    null === (t = this.sideTop) || void 0 === t || null === (i = t.children[0]) || void 0 === i || i.setScale(this.scaleX, 1, 1),
                    null === (e = this.sideBottom) || void 0 === e || null === (o = e.children[0]) || void 0 === o || o.setScale(this.scaleX, 1, 1),
                    null === (s = this.sideLeft) || void 0 === s || null === (r = s.children[0]) || void 0 === r || r.setScale(this.scaleY, 1, 1),
                    null === (n = this.sideRight) || void 0 === n || null === (a = n.children[0]) || void 0 === a || a.setScale(this.scaleY, 1, 1)
                }
                ,
                n.updateCornerPositions = function() {
                    var t, i, e, o;
                    null === (t = this.cornerTopRight) || void 0 === t || t.setPosition(this.posCornerTopRight),
                    null === (i = this.cornerTopLeft) || void 0 === i || i.setPosition(this.posCornerTopLeft),
                    null === (e = this.cornerBottomRight) || void 0 === e || e.setPosition(this.posCornerBottomRight),
                    null === (o = this.cornerBottomLeft) || void 0 === o || o.setPosition(this.posCornerBottomLeft)
                }
                ,
                i
            }(c)).prototype, "sideTop", [Y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            H = i(x.prototype, "sideBottom", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            W = i(x.prototype, "sideRight", [X], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            _ = i(x.prototype, "sideLeft", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            j = i(x.prototype, "cornerTopRight", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            O = i(x.prototype, "cornerTopLeft", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            V = i(x.prototype, "cornerBottomRight", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = i(x.prototype, "cornerBottomLeft", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Z = i(x.prototype, "speedX", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .3
                }
            }),
            q = i(x.prototype, "speedY", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .3
                }
            }),
            N = i(x.prototype, "minRadiusX", [G], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 4
                }
            }),
            Q = i(x.prototype, "minRadiusY", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 4
                }
            }),
            U = i(x.prototype, "startDelayAfterMatchStart", [A], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3
                }
            }),
            J = i(x.prototype, "heightFromGround", [$], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 2.5
                }
            }),
            F = x)) || F));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CompassIndicator.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenCollection.ts"], (function(e) {
    "use strict";
    var t, n, i, o, r, s, l, a, c;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            i = e.initializerDefineProperty,
            o = e.assertThisInitialized,
            r = e.defineProperty
        }
        , function(e) {
            s = e.cclegacy,
            l = e._decorator,
            a = e.Component
        }
        , function(e) {
            c = e.TweenCollection
        }
        ],
        execute: function() {
            var u, p, h, d, w, f, v;
            s._RF.push({}, "a7bab4tYglEsoQnf45VLc1a", "CompassIndicator", void 0);
            var y = l.ccclass
              , b = l.property;
            e("CompassIndicator", (u = y("CompassIndicator"),
            p = b(c),
            h = b(c),
            u((f = t((w = function(e) {
                function t() {
                    for (var t, n = arguments.length, s = new Array(n), l = 0; l < n; l++)
                        s[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(s)) || this,
                    i(o(t), "tweenShow", f, o(t)),
                    i(o(t), "tweenHide", v, o(t)),
                    r(o(t), "isOn", !1),
                    t
                }
                n(t, e);
                var s = t.prototype;
                return s.start = function() {}
                ,
                s.show = function() {
                    var e, t;
                    this.isOn = !0,
                    null === (e = this.tweenHide) || void 0 === e || e.stop(),
                    null === (t = this.tweenShow) || void 0 === t || t.play()
                }
                ,
                s.lookAt = function(e) {
                    this.isOn && this.node.lookAt(e)
                }
                ,
                s.hide = function() {
                    var e, t;
                    this.isOn = !1,
                    null === (e = this.tweenShow) || void 0 === e || e.stop(),
                    null === (t = this.tweenHide) || void 0 === t || t.play()
                }
                ,
                t
            }(a)).prototype, "tweenShow", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = t(w.prototype, "tweenHide", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            d = w)) || d));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/ProjectEvent.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, n, r, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            n = t.cclegacy,
            r = t.Event,
            c = t.EventTarget
        }
        ],
        execute: function() {
            n._RF.push({}, "aac6e5GeFpA6KwA7hgZwV/r", "ProjectEvent", void 0);
            t("EventGlobal", function(t) {
                function n() {
                    return t.apply(this, arguments) || this
                }
                return e(n, t),
                n
            }(r));
            var o = t("ProjectEvent", function(t) {
                function n() {
                    return t.call(this) || this
                }
                return e(n, t),
                n
            }(c));
            t("projectEvent", new o);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AudioData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./AudioItem.ts"], (function(t) {
    "use strict";
    var e, i, r, n, o, a, u, c;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            r = t.initializerDefineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            o = t.cclegacy,
            a = t._decorator,
            u = t.Component
        }
        , function(t) {
            c = t.AudioItem
        }
        ],
        execute: function() {
            var s, l, p, f, d;
            o._RF.push({}, "aaf09Ao+q5OhKsNi2Dc5zdI", "AudioData", void 0);
            var y = a.ccclass
              , h = a.property;
            t("AudioData", (s = y("AudioData"),
            l = h([c]),
            s((d = e((f = function(t) {
                function e() {
                    for (var e, i = arguments.length, o = new Array(i), a = 0; a < i; a++)
                        o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    r(n(e), "items", d, n(e)),
                    e
                }
                return i(e, t),
                e.prototype.getItem = function(t) {
                    var e = this.items.find((function(e) {
                        return e.Key == t
                    }
                    ));
                    return e || null
                }
                ,
                e
            }(u)).prototype, "items", [l], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            p = f)) || p));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AudioProxy.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./AudioManager.ts"], (function(e) {
    "use strict";
    var r, t, i, o, n, a, c, u, s;
    return {
        setters: [function(e) {
            r = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            i = e.initializerDefineProperty,
            o = e.assertThisInitialized
        }
        , function(e) {
            n = e.cclegacy,
            a = e._decorator,
            c = e.Prefab,
            u = e.Component
        }
        , function(e) {
            s = e.AudioManager
        }
        ],
        execute: function() {
            var l, p, y, d, f;
            n._RF.push({}, "ac879rTendCEbpZWFz/jexs", "AudioProxy", void 0);
            var h = a.ccclass
              , v = a.property;
            e("AudioProxy", (l = h("AudioProxy"),
            p = v(c),
            l((f = r((d = function(e) {
                function r() {
                    for (var r, t = arguments.length, n = new Array(t), a = 0; a < t; a++)
                        n[a] = arguments[a];
                    return r = e.call.apply(e, [this].concat(n)) || this,
                    i(o(r), "key", f, o(r)),
                    r
                }
                return t(r, e),
                r.prototype.playSFX = function(e, r) {
                    var t;
                    this.key && (null === (t = s.instance) || void 0 === t || t.playByKey(this.key))
                }
                ,
                r
            }(u)).prototype, "key", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = d)) || y));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterLevelControl.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var e, o, n, r, a, i, l, c, s, h, d;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            o = t.defineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            a = t._decorator,
            i = t.Component
        }
        , function(t) {
            l = t.logger
        }
        , function(t) {
            c = t.ProjectEventType
        }
        , function(t) {
            s = t.projectEvent
        }
        , function(t) {
            h = t.EventCharacterAction
        }
        , function(t) {
            d = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var u;
            r._RF.push({}, "acc60zD9zpCDZdZCrcpY4of", "CharacterLevelControl", void 0);
            var p = a.ccclass;
            a.property,
            t("CharacterLevelControl", p("CharacterLevelControl")(u = function(t) {
                function r() {
                    for (var e, r = arguments.length, a = new Array(r), i = 0; i < r; i++)
                        a[i] = arguments[i];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    o(n(e), "data", void 0),
                    e
                }
                e(r, t);
                var a = r.prototype;
                return a.onLoad = function() {
                    this.data = this.node.getComponent(d),
                    null == this.data && console.log("Could not find character blackboard")
                }
                ,
                a.onEnable = function() {
                    this.node.on(h.CollectedChest, this.levelUp, this),
                    this.node.on(h.KilledOther, this.levelUp, this)
                }
                ,
                a.onDisable = function() {
                    this.node.off(h.CollectedChest, this.levelUp, this),
                    this.node.off(h.KilledOther, this.levelUp, this)
                }
                ,
                a.levelUp = function() {
                    this.data && (this.data.level += 1,
                    this.node.emit(h.LevelUp, this.data.level),
                    this.data.IsPlayer && s.emit(c.PlayerLevelUp))
                }
                ,
                r
            }(i)) || u);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TutorialController.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(e) {
    "use strict";
    var t, o, n, a, i, r, l, s, c, u, d, h, g, y, f, p, v, P, L;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            o = e.inheritsLoose,
            n = e.initializerDefineProperty,
            a = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            r = e.cclegacy,
            l = e._decorator,
            s = e.Node,
            c = e.director,
            u = e.assetManager,
            d = e.sys,
            h = e.Component
        }
        , function(e) {
            g = e.logger,
            y = e.LogCategory
        }
        , function(e) {
            f = e.SceneNames,
            p = e.ProjectEventType,
            v = e.BundleNames,
            P = e.StorageKey
        }
        , function(e) {
            L = e.projectEvent
        }
        ],
        execute: function() {
            var M, T, C, m, S;
            r._RF.push({}, "b0174oQNtxCILW5VDtmelGI", "TutorialController", void 0);
            var b = l.ccclass
              , B = l.property;
            e("TutorialController", (M = b("TutorialController"),
            T = B(s),
            M((S = t((m = function(e) {
                function t() {
                    for (var t, o = arguments.length, r = new Array(o), l = 0; l < o; l++)
                        r[l] = arguments[l];
                    return t = e.call.apply(e, [this].concat(r)) || this,
                    n(a(t), "tutorialCanvas", S, a(t)),
                    i(a(t), "onTutorialBundleLoaded", (function(e, o) {
                        console.log("Finished loading bundle. " + o.name + ", loading scene"),
                        o.loadScene(f.Tutorial, t.onSceneLoaded)
                    }
                    )),
                    i(a(t), "onSceneLoaded", (function(e, t) {
                        console.log("Finished loading scene: " + t.name + ", starting it."),
                        c.runScene(t)
                    }
                    )),
                    t
                }
                o(t, e);
                var r = t.prototype;
                return r.onEnable = function() {
                    L.on(p.PlayerLoseMatch, this.onPlayerLoseMatch, this),
                    L.on(p.PlayerWinMatch, this.onPlayerWinMatch, this)
                }
                ,
                r.onDisable = function() {
                    L.off(p.PlayerLoseMatch, this.onPlayerLoseMatch, this),
                    L.off(p.PlayerWinMatch, this.onPlayerWinMatch, this)
                }
                ,
                r.onPlayerLoseMatch = function() {
                    var e = u.getBundle(v.Tutorial);
                    e ? e.loadScene(f.Tutorial, this.onSceneLoaded) : (console.log("Bundle invalid, loading it"),
                    u.loadBundle(v.Tutorial, this.onTutorialBundleLoaded))
                }
                ,
                r.onPlayerWinMatch =async function() {
                   await CoinApp.setItem(P.FinishedTutorial, !0),
                    this.tutorialCanvas && (this.tutorialCanvas.active = !1),
                    console.log("Finished tutorial", y.Metagame)
                }
                ,
                t
            }(h)).prototype, "tutorialCanvas", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = m)) || C));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterFSM.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var i, n, o, e, a, h, s, r, d, c, g;
    return {
        setters: [function(t) {
            i = t.inheritsLoose,
            n = t.defineProperty,
            o = t.assertThisInitialized
        }
        , function(t) {
            e = t.cclegacy,
            a = t._decorator,
            h = t.Component
        }
        , function(t) {
            s = t.EventCharacterAction,
            r = t.CharacterState,
            d = t.EventExitState,
            c = t.EventEnterState
        }
        , function(t) {
            g = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var S;
            e._RF.push({}, "b05131N8wBJ8qOmKbfzgtto", "CharacterFSM", void 0);
            var l = a.ccclass;
            a.property,
            t("CharacterFSM", l("CharacterFSM")(S = function(t) {
                function e() {
                    for (var i, e = arguments.length, a = new Array(e), h = 0; h < e; h++)
                        a[h] = arguments[h];
                    return i = t.call.apply(t, [this].concat(a)) || this,
                    n(o(i), "pickingUp", !1),
                    i
                }
                i(e, t);
                var a = e.prototype;
                return a.onEnable = function() {
                    this.node.on(s.StartMove, this.onStartMove, this),
                    this.node.on(s.StopMove, this.onStopMove, this),
                    this.node.on(s.TargetAquired, this.onTargetAquired, this),
                    this.node.on(s.TargetLost, this.onTargetLost, this),
                    this.node.on(s.DyingStart, this.onDyingStart, this),
                    this.node.on(s.DyingEnd, this.onDyingEnd, this),
                    this.node.on(s.StartPicking, this.onStartPicking, this),
                    this.node.on(s.StopPicking, this.onStopPicking, this),
                    this.node.on(s.Shoot, this.onShoot, this),
                    this.node.on(s.ShootFinished, this.onShootFinished, this)
                }
                ,
                a.onDisable = function() {
                    this.node.off(s.StartMove, this.onStartMove, this),
                    this.node.off(s.StopMove, this.onStopMove, this),
                    this.node.off(s.TargetAquired, this.onTargetAquired, this),
                    this.node.off(s.TargetLost, this.onTargetLost, this),
                    this.node.off(s.DyingStart, this.onDyingStart, this),
                    this.node.off(s.DyingEnd, this.onDyingEnd, this),
                    this.node.off(s.StartPicking, this.onStartPicking, this),
                    this.node.off(s.StopPicking, this.onStopPicking, this),
                    this.node.off(s.Shoot, this.onShoot, this),
                    this.node.off(s.ShootFinished, this.onShootFinished, this)
                }
                ,
                a.start = function() {
                    this.data = this.node.getComponent(g)
                }
                ,
                a.onStartMove = function() {
                    this.changeStateTo(r.Moving)
                }
                ,
                a.onStopMove = function() {
                    null != this.data && (null == this.data.target || this.pickingUp && !this.data.CanShootWhilePickingUp ? this.pickingUp ? this.changeStateTo(r.PickingUp) : this.changeStateTo(r.Idle) : this.changeStateTo(r.ShootingIdle))
                }
                ,
                a.onTargetAquired = function(t) {
                    null != this.data && (this.data.target = t,
                    (this.data.state == r.Idle || this.data.state == r.PickingUp && this.data.CanShootWhilePickingUp) && this.changeStateTo(r.ShootingIdle))
                }
                ,
                a.onTargetLost = function() {
                    null != this.data && (this.data.target = null,
                    this.data.state == r.ShootingIdle && this.changeStateTo(r.Idle))
                }
                ,
                a.onDyingStart = function() {
                    this.changeStateTo(r.Dying)
                }
                ,
                a.onDyingEnd = function() {
                    this.changeStateTo(r.Dead)
                }
                ,
                a.onStartPicking = function() {
                    this.pickingUp = !0
                }
                ,
                a.onStopPicking = function() {
                    var t;
                    this.pickingUp = !1,
                    (null === (t = this.data) || void 0 === t ? void 0 : t.state) == r.PickingUp && (null != this.data.target ? this.changeStateTo(r.ShootingIdle) : this.changeStateTo(r.Idle))
                }
                ,
                a.onShoot = function() {
                    this.changeStateTo(r.Shooting)
                }
                ,
                a.onShootFinished = function() {
                    this.onStopMove()
                }
                ,
                a.changeStateTo = function(t) {
                    null != this.data && (this.data.state == r.Dying && t != r.Dead || (this.data.state == r.ShootingIdle && this.node.emit(d.ShootingIdle),
                    this.data.lastState = this.data.state,
                    this.data.state = t,
                    this.node.emit(this.data.state),
                    this.data.state == r.ShootingIdle && null != this.data.target && null != this.node.parent && this.node.emit(c.ShootingIdle, this.data.target)))
                }
                ,
                e
            }(h)) || S);
            e._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestPlayAnimation.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts"], (function(t) {
    "use strict";
    var e, n, o, i, r, a, s, c, l, u, y, p;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            o = t.initializerDefineProperty,
            i = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            a = t._decorator,
            s = t.Node,
            c = t.systemEvent,
            l = t.SystemEventType,
            u = t.macro,
            y = t.Component
        }
        , function(t) {
            p = t.EventCharacterAction
        }
        ],
        execute: function() {
            var h, f, m, v, D;
            r._RF.push({}, "b15adKQL+FK0ZUEH1uXNsXD", "TestPlayAnimation", void 0);
            var E = a.ccclass
              , d = a.property;
            t("TestPlayAnimation", (h = E("TestPlayAnimation"),
            f = d(s),
            h((D = e((v = function(t) {
                function e() {
                    for (var e, n = arguments.length, r = new Array(n), a = 0; a < n; a++)
                        r[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(r)) || this,
                    o(i(e), "target", D, i(e)),
                    e
                }
                n(e, t);
                var r = e.prototype;
                return r.onEnable = function() {
                    c.on(l.KEY_DOWN, this.onCheatKeyDown, this)
                }
                ,
                r.onDisable = function() {
                    c.off(l.KEY_DOWN, this.onCheatKeyDown, this)
                }
                ,
                r.onCheatKeyDown = function(t) {
                    t.keyCode == u.KEY.f && this.target.emit(p.Shoot)
                }
                ,
                e
            }(y)).prototype, "target", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            m = v)) || m));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/DebugMenu.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./GlobalPlayer.ts", "./LoadingPrepareMatch.ts"], (function(e) {
    "use strict";
    var o, n, a, t, l, i, s, d, c, r, u, v, g, h, f, T;
    return {
        setters: [function(e) {
            o = e.inheritsLoose,
            n = e.defineProperty,
            a = e.assertThisInitialized
        }
        , function(e) {
            t = e.cclegacy,
            l = e._decorator,
            i = e.director,
            s = e.assetManager,
            d = e.sys,
            c = e.Component
        }
        , function(e) {
            r = e.logger
        }
        , function(e) {
            u = e.SceneLevels,
            v = e.BundleNames,
            g = e.SceneNames
        }
        , function(e) {
            h = e.globalPlayer,
            f = e.CurrencyWinReason
        }
        , function(e) {
            T = e.LoadingPrepareMatch
        }
        ],
        execute: function() {
            var p;
            t._RF.push({}, "b1c97sWFY9GfZBSTh2vw3Xr", "DebugMenu", void 0);
            var L = l.ccclass;
            l.property,
            e("DebugMenu", L("DebugMenu")(p = function(e) {
                function t() {
                    for (var o, t = arguments.length, l = new Array(t), s = 0; s < t; s++)
                        l[s] = arguments[s];
                    return o = e.call.apply(e, [this].concat(l)) || this,
                    n(a(o), "levelToLoadIndex", 0),
                    n(a(o), "onGameBundleLoaded", (function(e, n) {
                       console.log("Finished loading bundle. " + n.name + ", loading scene"),
                        n.loadScene(u[o.levelToLoadIndex], o.onSceneLoaded)
                    }
                    )),
                    n(a(o), "onSceneLoaded", (function(e, o) {
                       console.log("Finished loading scene " + o.name + ", starting it."),
                        i.runScene(o)
                    }
                    )),
                    o
                }
                o(t, e);
                var l = t.prototype;
                return l.loadLevel = function(e, o) {
                    var n;
                    this.levelToLoadIndex = Number(o),
                    1 == isNaN(this.levelToLoadIndex) &&console.log("ERROR: Received wrong value for level index: " + o),
                    (this.levelToLoadIndex < 0 || this.levelToLoadIndex >= u.length) &&console.log("ERROR: Invalid level index received"),
                   console.log("Received request to load level: " + this.levelToLoadIndex),
                    null === (n = T.instance) || void 0 === n || n.show(),
                   console.log("Get game bundle to load prototype scene");
                    var a = s.getBundle(v.Game);
                    if (a) {
                        var t = u[this.levelToLoadIndex];
                        a.loadScene(t, this.onSceneLoaded)
                    } else
                       console.log("Bundle invalid, loading it"),
                        s.loadBundle(v.Game, this.onGameBundleLoaded)
                }
                ,
                l.loadAudioTest = function() {
                    this.load("Test_Audio")
                }
                ,
                l.loadTutorial = function() {
                    this.load(g.Tutorial)
                }
                ,
                l.loadPathTest = function() {
                    this.load("Test_Pathfinding")
                }
                ,
                l.loadRewardedAdTest = function() {
                    this.load("Test_RewardedAds")
                }
                ,
                l.loadAIReactionTest = function() {
                    this.load("Test_AIReaction")
                }
                ,
                l.cheatCurrency = function() {
                    h.receiveCurrency(1e4, f.Debug),
                    h.save()
                }
                ,
                l.cheatTrophy = function() {
                    h.victoryTrophies += 100,
                    h.save()
                }
                ,
                l.clearLocalStorage = function() {
                    d.localStorage.clear(),
                    location.reload()
                }
                ,
                l.cheatCompleteMissions = function() {
                    h.completeAllMissions(),
                    h.save(),
                    location.reload()
                }
                ,
                l.cheatLevelUp = function() {
                    h.level++,
                    h.save()
                }
                ,
                l.cheatResetDailies = function() {
                    var e = new Date((new Date).setDate((new Date).getDate() - 1));
                    h.setPreviousTimeForDailies(e),
                    h.save(),
                    location.reload()
                }
                ,
                l.load = function(e) {
                    var o;
                    null === (o = T.instance) || void 0 === o || o.show(),
                    i.loadScene(e)
                }
                ,
                t
            }(c)) || p);
            t._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotVisionData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(i) {
    "use strict";
    var t, e, n, o, r;
    return {
        setters: [function(i) {
            t = i.applyDecoratedDescriptor,
            e = i.initializerDefineProperty
        }
        , function(i) {
            n = i.cclegacy,
            o = i._decorator,
            r = i.CCFloat
        }
        ],
        execute: function() {
            var a, s, c, u, l, p, f;
            n._RF.push({}, "b1d9bOdN+FPNJSPMF6QRYek", "BotVisionData", void 0);
            var b = o.ccclass
              , v = o.property;
            i("BotVisionData", (a = b("BotVisionData"),
            s = v(r),
            c = v(r),
            a((p = t((l = function() {
                e(this, "visionDistance", p, this),
                e(this, "visionRadius", f, this)
            }
            ).prototype, "visionDistance", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 10
                }
            }),
            f = t(l.prototype, "visionRadius", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 60
                }
            }),
            u = l)) || u));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayerCompass.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts", "./CompassIndicator.ts", "./PlayerInput.ts"], (function(t) {
    "use strict";
    var o, i, e, a, s, n, r, h, c, l, p, u, d, m, v, g;
    return {
        setters: [function(t) {
            o = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            e = t.initializerDefineProperty,
            a = t.assertThisInitialized,
            s = t.defineProperty
        }
        , function(t) {
            n = t.cclegacy,
            r = t._decorator,
            h = t.Vec3,
            c = t.Component
        }
        , function(t) {
            l = t.logger,
            p = t.LogCategory,
            u = t.LogType
        }
        , function(t) {
            d = t.EventCharacterAction
        }
        , function(t) {
            m = t.CharacterBlackboard
        }
        , function(t) {
            v = t.CompassIndicator
        }
        , function(t) {
            g = t.PlayerInput
        }
        ],
        execute: function() {
            var f, y, M, T, b, C, E, L, S;
            n._RF.push({}, "b2ccfWtzidFUJIx4exJ93nc", "PlayerCompass", void 0);
            var P = r.ccclass
              , w = r.property;
            t("PlayerCompass", (f = P("PlayerCompass"),
            y = w(g),
            M = w(v),
            T = w(v),
            f((E = o((C = function(t) {
                function o() {
                    for (var o, i = arguments.length, n = new Array(i), r = 0; r < i; r++)
                        n[r] = arguments[r];
                    return o = t.call.apply(t, [this].concat(n)) || this,
                    e(a(o), "input", E, a(o)),
                    e(a(o), "compassEnemy", L, a(o)),
                    e(a(o), "compassMovement", S, a(o)),
                    s(a(o), "data", void 0),
                    s(a(o), "movDir", new h),
                    s(a(o), "hasTarget", !1),
                    s(a(o), "isMoving", !1),
                    o
                }
                i(o, t);
                var n = o.prototype;
                return n.onLoad = function() {
                    this.data = this.getComponentInChildren(m)
                }
                ,
                n.start = function() {
                    this.compassEnemy ? this.compassMovement || console.log("Missconfigured direction compass on player", p.Gameplay, u.Error) : console.log("ERROR: Misconfigured compass on player", p.Gameplay, u.Error)
                }
                ,
                n.onEnable = function() {
                    this.data && (this.data.node.on(d.TargetAquired, this.onTargetAquired, this),
                    this.data.node.on(d.TargetLost, this.onTargetLost, this),
                    this.data.node.on(d.StartMove, this.onStartMove, this),
                    this.data.node.on(d.StopMove, this.onStopMove, this))
                }
                ,
                n.onDisable = function() {
                    this.data && (this.data.node.off(d.TargetAquired, this.onTargetAquired, this),
                    this.data.node.off(d.TargetLost, this.onTargetLost, this),
                    this.data.node.off(d.StartMove, this.onStartMove, this),
                    this.data.node.off(d.StopMove, this.onStopMove, this))
                }
                ,
                n.onTargetAquired = function() {
                    var t, o;
                    this.hasTarget = !0,
                    null === (t = this.compassEnemy) || void 0 === t || t.show(),
                    null === (o = this.compassMovement) || void 0 === o || o.hide()
                }
                ,
                n.onTargetLost = function() {
                    var t, o;
                    this.hasTarget = !1,
                    null === (t = this.compassEnemy) || void 0 === t || t.hide(),
                    this.isMoving && (null === (o = this.compassMovement) || void 0 === o || o.show())
                }
                ,
                n.onStartMove = function() {
                    var t;
                    this.isMoving = !0,
                    this.hasTarget || null === (t = this.compassMovement) || void 0 === t || t.show()
                }
                ,
                n.onStopMove = function() {
                    var t;
                    this.isMoving = !1,
                    this.hasTarget || null === (t = this.compassMovement) || void 0 === t || t.hide()
                }
                ,
                n.lateUpdate = function() {
                    var t;
                    this.data && this.compassEnemy && this.data.target && this.data.target.isValid && this.input && (this.compassEnemy.lookAt(this.data.target.worldPosition),
                    this.movDir.set(this.input.horizontal, 0, this.input.vertical),
                    null === (t = this.compassMovement) || void 0 === t || t.lookAt(this.movDir))
                }
                ,
                o
            }(c)).prototype, "input", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = o(C.prototype, "compassEnemy", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            S = o(C.prototype, "compassMovement", [T], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = C)) || b));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Pathfinding.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./index2.js", "./index.mjs_cjs=&original=2.js", "./index.js", "./index.mjs_cjs=&original=.js", "./DebugVisualizeTile.ts"], (function(i) {
    "use strict";
    var t, r, a, n, e, o, s, h, l, u, d, g, c, f, p, v, b, m, y, k, w, A;
    return {
        setters: [function(i) {
            t = i.defineProperty,
            r = i.applyDecoratedDescriptor,
            a = i.inheritsLoose,
            n = i.initializerDefineProperty,
            e = i.assertThisInitialized,
            o = i.createForOfIteratorHelperLoose
        }
        , function(i) {
            s = i.cclegacy,
            h = i._decorator,
            l = i.Prefab,
            u = i.Vec2,
            d = i.instantiate,
            g = i.math,
            c = i.Vec3,
            f = i.Component
        }
        , function(i) {
            p = i.logger,
            v = i.LogCategory,
            b = i.LogType
        }
        , function(i) {
            m = i.ProjectEventType
        }
        , function(i) {
            y = i.projectEvent
        }
        , function(i) {
            k = i.default
        }
        , null, function(i) {
            w = i.default
        }
        , null, function(i) {
            A = i.DebugVisualizeTile
        }
        ],
        execute: function() {
            var z, T, S, P, F, M, V, I, x, G, C;
            s._RF.push({}, "b48dffAzi5Jd5wFX8X0AzNz", "Pathfinding", void 0);
            var E = h.ccclass
              , R = h.property
              , j = h.executionOrder;
            i("Pathfinding", (z = E("Pathfinding"),
            T = j(-2),
            S = R({
                type: l,
                tooltip: "Prefab to visualize"
            }),
            z(P = T((C = G = function(i) {
                function r() {
                    for (var r, a = arguments.length, o = new Array(a), s = 0; s < a; s++)
                        o[s] = arguments[s];
                    return r = i.call.apply(i, [this].concat(o)) || this,
                    n(e(r), "mapImportScaleFactor", M, e(r)),
                    n(e(r), "unwalkableRadius", V, e(r)),
                    n(e(r), "prefabDebugVisualizeTile", I, e(r)),
                    n(e(r), "visualize", x, e(r)),
                    t(e(r), "byakugan", void 0),
                    t(e(r), "ready", !1),
                    t(e(r), "height", 0),
                    t(e(r), "width", 0),
                    t(e(r), "obstaclesForRaycast", new Set([1, 2, 4])),
                    t(e(r), "originalGrid", void 0),
                    t(e(r), "shrinkingAreaTileValue", 6),
                    t(e(r), "visualizeTiles", void 0),
                    t(e(r), "shrinkedCount", new u),
                    r
                }
                a(r, i);
                var s = r.prototype;
                return s.onLoad = function() {
                    null == r.instance ? r.instance = this : (console.log("Error: Pathfinding instance already exists"),
                    this.enabled = !1)
                }
                ,
                s.onDestroy = function() {
                    r.instance == this && (r.instance = null)
                }
                ,
                s.onEnable = function() {
                    y.on(m.MapAreaShrinkedX, this.onMapAreaShrinkedX, this),
                    y.on(m.MapAreaShrinkedY, this.onMapAreaShrinkedY, this),
                    y.on(m.MapSetup, this.setup, this)
                }
                ,
                s.onDisable = function() {
                    y.off(m.MapAreaShrinkedX, this.onMapAreaShrinkedX, this),
                    y.off(m.MapAreaShrinkedY, this.onMapAreaShrinkedY, this),
                    y.off(m.MapSetup, this.setup, this)
                }
                ,
                s.onMapAreaShrinkedX = function(i) {
                    this.shrinkedCount.x = i;
                    for (var t = this.byakugan.settings.grid, r = 0; r < this.mapImportScaleFactor; r++)
                        for (var a = 0; a < t.length; a++)
                            for (var n = 0; n < t[a].length; n++)
                                a == i * this.mapImportScaleFactor + r ? 1 == this.isValidPoint(a, n) && (t[a][n] = this.shrinkingAreaTileValue) : t.length - a == i * this.mapImportScaleFactor - r && 1 == this.isValidPoint(a, n) && (t[a][n] = this.shrinkingAreaTileValue);
                    this.debugMapVisualization(t)
                }
                ,
                s.onMapAreaShrinkedY = function(i) {
                    this.shrinkedCount.y = i;
                    for (var t = this.byakugan.settings.grid, r = 0; r < this.mapImportScaleFactor; r++)
                        for (var a = 0; a < t.length; a++)
                            for (var n = 0; n < t[a].length; n++)
                                n == i * this.mapImportScaleFactor + r ? 1 == this.isValidPoint(a, n) && (t[a][n] = this.shrinkingAreaTileValue) : t[a].length - n == i * this.mapImportScaleFactor - r && 1 == this.isValidPoint(a, n) && (t[a][n] = this.shrinkingAreaTileValue);
                    this.debugMapVisualization(t)
                }
                ,
                s.setup = function(i) {
                    var t = this;
                    this.visualize = !1;
                    var r = i.width;
                    this.originalGrid = new Array;
                    var a = 0;
                    i.layers[0].data.forEach((function(i) {
                        var n = Number(i)
                          , e = a % r;
                        NaN != n && -1 != n && (null == t.originalGrid[e] && t.originalGrid.push(new Array),
                        t.originalGrid[e].push(n)),
                        a += 1
                    }
                    ));
                    for (var n = [], e = 0; e < this.originalGrid.length; e++)
                        for (var o = this.originalGrid[e], s = 0; s < this.mapImportScaleFactor; s++) {
                            for (var h = [], l = 0; l < o.length; l++)
                                for (var u = 0; u < this.mapImportScaleFactor; u++)
                                    h.push(this.originalGrid[e][l]);
                            n.push(h)
                        }
                    for (var d = [1, 2, 4], g = 0; g < n.length; g++)
                        for (var c = n[g], f = 0; f < c.length; f++)
                            0 == n[g][f] && this.checkNeighborsForObstacles(n, g, f, this.unwalkableRadius, d) && (n[g][f] = 6);
                    this.logGrid(this.originalGrid),
                    this.logGrid(n),
                    d.push(6),
                    console.log("obstacles: " + d);
                    var v = {
                        grid: n,
                        obstacles: d,
                        diagonal: !0,
                        heuristics: {
                            normal: "MANHATTAN"
                        }
                    };
                    this.byakugan = new k(v),
                    this.width = this.byakugan.settings.grid.length,
                    this.height = this.byakugan.settings.grid[0].length,
                    this.ready = !0,
                    this.debugMapVisualization(n)
                }
                ,
                s.debugMapVisualization = function(i) {
                    if (this.visualize) {
                        if (!this.prefabDebugVisualizeTile)
                            return void console.log("Can not visualize map, prefab not configured.", v.Gameplay, b.Error);
                        var t = 1 / this.mapImportScaleFactor
                          , r = i.length
                          , a = i[0].length;
                        if (!this.visualizeTiles) {
                            this.visualizeTiles = new Array(r);
                            for (var n = 0; n < r; n++)
                                this.visualizeTiles[n] = new Array(a),
                                this.visualizeTiles[n].fill(null)
                        }
                        for (var e = 0; e < a; e++)
                            for (var o = 0; o < r; o++) {
                                var s, h = i[o][e];
                                if (null == this.visualizeTiles[o][e]) {
                                    var l = void 0;
                                    (l = d(this.prefabDebugVisualizeTile)).setParent(this.node);
                                    var u = this.gridToWorld(o, e);
                                    l.setWorldPosition(u),
                                    l.setWorldScale(t, t, t),
                                    this.visualizeTiles[o][e] = l.getComponent(A)
                                }
                                null === (s = this.visualizeTiles[o][e]) || void 0 === s || s.setup(h)
                            }
                    }
                }
                ,
                s.checkNeighborsForObstacles = function(i, t, r, a, n) {
                    function e(i, t, r, a) {
                        return !(t < 0 || r < 0 || t >= i.length || r >= i[t].length) && a.indexOf(i[t][r]) > -1
                    }
                    for (var o = 1; o <= a; o++) {
                        if (e(i, t - o, r, n))
                            return !0;
                        if (e(i, t + o, r, n))
                            return !0;
                        if (e(i, t, r - o, n))
                            return !0;
                        if (e(i, t, r - o, n))
                            return !0;
                        if (e(i, t - o, r + o, n))
                            return !0;
                        if (e(i, t + o, r + o, n))
                            return !0;
                        if (e(i, t - o, r - o, n))
                            return !0;
                        if (e(i, t + o, r - o, n))
                            return !0
                    }
                    return !1
                }
                ,
                s.getMapCenterPoint = function() {
                    var i = this.getValidRandomNeighbour(~~(this.width / 2), ~~(this.height / 2), 2);
                    return i ? this.gridToWorld(i[0], i[1]) : this.gridToWorld(~~(this.width / 2), ~~(this.height / 2))
                }
                ,
                s.getValidRandomPoint = function() {
                    var i = 0
                      , t = 0
                      , r = 0
                      , a = 4;
                    this.shrinkedCount.x < 7 && (a = 0);
                    var n = 3;
                    this.shrinkedCount.y < 7 && (n = 0);
                    do {
                        i = ~~(i = this.shrinkedCount.x + Math.floor(Math.random() * (this.width - (2 * this.shrinkedCount.x + a)))),
                        t = ~~(t = this.shrinkedCount.y + Math.floor(Math.random() * (this.height - (2 * this.shrinkedCount.y + n)))),
                        r++,
                        null !== this.byakugan.settings.grid[i] && null !== this.byakugan.settings.grid[i][t] || (console.log("Invalid random point (" + i + "," + t + ")", v.AI, b.Error),
                        i = 0,
                        t = 0)
                    } while (0 != this.byakugan.settings.grid[i][t] && r < 200);
                    return r >= 200 && console.log("No more valid points on map.", v.Gameplay, b.Error),
                    this.gridToWorld(i, t)
                }
                ,
                s.getValidRandomPath = function(i, t) {
                    for (var r, a = !1, n = 0, e = new Array; !a && n < 200; ) {
                        r = this.getValidRandomPoint(),
                        e = this.getPath(i, t, r.x, r.z);
                        for (var s, h = o(e); !(s = h()).done; ) {
                            var l = s.value;
                            if (0 == (a = !this.isPointInsideOfShrinkingArea(l[0], l[1])))
                                break
                        }
                        n++
                    }
                    return 0 == e.length && console.log(this.node.name + " Could not find any valid path to a random point.", v.AI, b.Error),
                    e
                }
                ,
                s.isPointInsideOfShrinkingArea = function(i, t) {
                    return t = ~~t,
                    (i = ~~i) < this.shrinkedCount.x || i > this.width - this.shrinkedCount.x || (t < this.shrinkedCount.y || t > this.height - this.shrinkedCount.y)
                }
                ,
                s.getValidRandomNeighbour = function(i, t, r) {
                    var a = i - r;
                    a < 0 && (a = 0);
                    var n = t - r;
                    n < 0 && (n = 0);
                    var e = i + r;
                    e > this.width - 1 && (e = this.width - 1);
                    var o = t + r;
                    o > this.height - 1 && (o = this.height - 1);
                    for (var s = new Array, h = a; h < e; h++)
                        for (var l = n; l < o; l++)
                            this.isValidPoint(h, l) && s.push([h, l]);
                    return 0 == s.length ? null : s[Math.floor(Math.random() * s.length)]
                }
                ,
                s.getPath = function(i, t, r, a) {
                    (i < 1 || i > this.width - 1) && (
                        // console.log("Error: FromX '" + i + "'>" + (this.width - 1), v.AI, b.Error),
                    i = g.clamp(i, 1, this.width - 1)),
                    (t < 1 || t > this.height - 1) && (
                        // console.log("Error: fromY '" + t + "'>" + (this.height - 1), v.AI, b.Error),
                    t = g.clamp(t, 1, this.height - 1)),
                    (r < 1 || r > this.width - 1) && (
                        // console.log("Error: FromX '" + r + "'>" + (this.width - 1), v.AI, b.Error),
                    r = g.clamp(r, 1, this.width - 1)),
                    (a < 1 || a > this.height - 1) && (
                        // console.log("Error: toY '" + a + "'>" + (this.height - 1), v.AI, b.Error),
                    a = g.clamp(a, 1, this.height - 1));
                    var n = this.worldToGrid(i, t)
                      , e = this.worldToGrid(r, a);
                    return this.byakugan.search(n.x, n.y, e.x, e.y)
                }
                ,
                s.worldToGrid = function(i, t) {
                    var r = new u;
                    return r.x = Math.floor((i + .5) / (1 / this.mapImportScaleFactor)),
                    r.y = Math.floor((t + .5) / (1 / this.mapImportScaleFactor)),
                    r
                }
                ,
                s.gridToWorld = function(i, t) {
                    var r = new c
                      , a = (this.mapImportScaleFactor - 1) * (1 / (2 * this.mapImportScaleFactor));
                    return r.x = i * (1 / this.mapImportScaleFactor) - a,
                    r.z = t * (1 / this.mapImportScaleFactor) - a,
                    r
                }
                ,
                s.isValidWorldPoint = function(i, t) {
                    i = ~~i,
                    t = ~~t;
                    var r = this.worldToGrid(i, t);
                    return !(r.x < 0 || r.x >= this.width) && (!(r.y < 0 || r.y >= this.height) && !this.obstaclesForRaycast.has(this.byakugan.settings.grid[r.x][r.y]))
                }
                ,
                s.isPointWalkable = function(i) {
                    try {
                        var t = this.worldToGrid(i.x, i.z);
                        return !this.obstaclesForRaycast.has(this.byakugan.settings.grid[t.x][t.y])
                    } catch (i) {
                        return console.log("isPointWalkable exception: " + i, v.AI, b.Error),
                        !1
                    }
                }
                ,
                s.isValidWorldPointOnOriginalGrid = function(i, t) {
                    return t = ~~t,
                    !((i = ~~i) < 0 || i >= this.width) && (!(t < 0 || t >= this.height) && !this.obstaclesForRaycast.has(this.originalGrid[i][t]))
                }
                ,
                s.raycastOnOriginalMap = function(i, t, r, a, n) {
                    void 0 === r && (r = 1),
                    void 0 === a && (a = null),
                    void 0 === n && (n = null);
                    var e = new Array(2);
                    return e[0] = Math.round(i[0]),
                    e[1] = Math.round(i[1]),
                    w(this.getTileForRaycast.bind(this), e, t, r, a, n)
                }
                ,
                s.isValidPoint = function(i, t) {
                    return !(i < 0 || i >= this.width) && (!(t < 0 || t >= this.height) && (i = ~~i,
                    t = ~~t,
                    !this.byakugan.settings.obstacles.has(this.byakugan.settings.grid[i][t])))
                }
                ,
                s.logGrid = function(i) {
                    for (var t = "\n", r = i.length, a = i[0].length, n = 0; n < a; n++) {
                        for (var e = 0; e < r; e++)
                            t += i[e][n];
                        t += "\n"
                    }
                    // console.log("pathfinding grid: " + t)
                }
                ,
                s.getTileForRaycast = function(i, t) {
                    var r = this.originalGrid[i][t];
                    return this.obstaclesForRaycast.has(r) ? 1 : 0
                }
                ,
                r
            }(f),
            t(G, "instance", void 0),
            M = r((F = C).prototype, "mapImportScaleFactor", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            V = r(F.prototype, "unwalkableRadius", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            I = r(F.prototype, "prefabDebugVisualizeTile", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            x = r(F.prototype, "visualize", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            P = F)) || P) || P));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/WeaponPickup.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./WeaponEnums.ts", "./CharacterBlackboard.ts", "./CharacterShoot.ts", "./WeaponPickupCollectionFeedback.ts", "./BasePickup.ts", "./WeaponPickupRarityEffect.ts", "./WeaponPickupManager.ts"], (function(t) {
    "use strict";
    var e, i, r, n, o, a, c, u, p, s, l, h, f, y, d, g, W;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            r = t.initializerDefineProperty,
            n = t.assertThisInitialized,
            o = t.defineProperty
        }
        , function(t) {
            a = t.cclegacy,
            c = t._decorator,
            u = t.Enum,
            p = t.CCInteger
        }
        , function(t) {
            s = t.WeaponType,
            l = t.WeaponRarity
        }
        , function(t) {
            h = t.CharacterBlackboard
        }
        , function(t) {
            f = t.CharacterShoot
        }
        , function(t) {
            y = t.PowerLevelFeedback
        }
        , function(t) {
            d = t.BasePickup
        }
        , function(t) {
            g = t.WeaponPickupRarityEffect
        }
        , function(t) {
            W = t.WeaponPickupManager
        }
        ],
        execute: function() {
            var v, P, b, k, C, R, m, S, w;
            a._RF.push({}, "b7667fYWghOVqElXUE3ShH4", "WeaponPickup", void 0);
            var I = c.ccclass
              , B = c.property;
            t("WeaponPickup", (v = I("WeaponPickup"),
            P = B({
                type: u(s)
            }),
            b = B({
                type: [p]
            }),
            k = B({
                type: u(l)
            }),
            v((m = e((R = function(t) {
                function e() {
                    for (var e, i = arguments.length, a = new Array(i), c = 0; c < i; c++)
                        a[c] = arguments[c];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    r(n(e), "targetWeapon", m, n(e)),
                    r(n(e), "raritySpread", S, n(e)),
                    r(n(e), "debugRarity", w, n(e)),
                    o(n(e), "rarity", void 0),
                    o(n(e), "effect", void 0),
                    e
                }
                i(e, t);
                var a = e.prototype;
                return a.onLoad = function() {
                    t.prototype.onLoad.call(this)
                }
                ,
                a.reuse = function() {
                    t.prototype.reuse.call(this),
                    this.targetWeapon == s.Basic && this.scheduleOnce(this.returnToPool, 3)
                }
                ,
                a.getRarity = function() {
                    return this.rarity
                }
                ,
                a.setRarity = function(t) {
                    this.rarity = t,
                    null == this.effect && (this.effect = this.node.getComponentInChildren(g)),
                    this.effect && this.effect.onSetRarity(this.rarity)
                }
                ,
                a.randomizeRarity = function() {
                    var t = Math.random()
                      , e = 0;
                    for (e = 0; e < this.raritySpread.length && !(t <= this.raritySpread[e]); e++)
                        ;
                    this.setRarity(e)
                }
                ,
                a.handlePickupCollection = function() {
                    var e;
                    if (null === (e = this.originalCollector) || void 0 === e ? void 0 : e.isValid) {
                        var i = this.originalCollector.getComponentInChildren(f);
                        (null == i ? void 0 : i.isValid) && i.changeWeapon(this.targetWeapon, this.rarity),
                        t.prototype.unuse.call(this),
                        this.returnToPool()
                    }
                }
                ,
                a.returnToPool = function() {
                    var t;
                    null === (t = W.instance) || void 0 === t || t.put(this.targetWeapon, this.node)
                }
                ,
                a.onSetupUI = function() {
                    var t, e = this.uiInstance, i = y.Hide, r = null === (t = this.originalCollector) || void 0 === t ? void 0 : t.getComponentInChildren(h);
                    r && r.IsPlayer && (r.currentWeaponObject.weaponRarity < this.rarity ? i = y.ShowBetter : r.currentWeaponObject.weaponRarity > this.rarity && (i = y.ShowWorse)),
                    e && e.setupWeaponPickupUI(this.rarity, this.targetWeapon, i)
                }
                ,
                e
            }(d)).prototype, "targetWeapon", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return s.Basic
                }
            }),
            S = e(R.prototype, "raritySpread", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            w = e(R.prototype, "debugRarity", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return l.Common
                }
            }),
            C = R)) || C));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PrefabPool.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, n, i, o, s, r, a, l, c, u, h, f;
    return {
        setters: [function(t) {
            e = t.defineProperty,
            n = t.inheritsLoose,
            i = t.assertThisInitialized,
            o = t.createForOfIteratorHelperLoose,
            s = t.createClass
        }
        , function(t) {
            r = t.cclegacy,
            a = t._decorator,
            l = t.director,
            c = t.NodePool,
            u = t.instantiate,
            h = t.Node,
            f = t.Component
        }
        ],
        execute: function() {
            var p, v, d;
            r._RF.push({}, "b7fd3GtjZNCgZZkkorYWOYh", "PrefabPool", void 0);
            var g = a.ccclass
              , P = (a.property,
            a.executionOrder);
            t("PrefabPool", g("PrefabPool")(p = P(-5)((d = v = function(t) {
                function r() {
                    for (var n, o = arguments.length, s = new Array(o), r = 0; r < o; r++)
                        s[r] = arguments[r];
                    return n = t.call.apply(t, [this].concat(s)) || this,
                    e(i(n), "pools", new Map),
                    e(i(n), "scene", void 0),
                    n
                }
                n(r, t);
                var a = r.prototype;
                return a.onLoad = function() {
                    null == r._instance && (r._instance = this),
                    this.scene = l.getScene()
                }
                ,
                a.onDestroy = function() {
                    this.clearAll(),
                    r._instance == this && (r._instance = null)
                }
                ,
                a.initializeWithCallbacks = function(t, e, n) {
                    void 0 === n && (n = 3),
                    this.initialize(t, e, n)
                }
                ,
                a.initialize = function(t, e, n) {
                    if (void 0 === n && (n = 3),
                    0 == this.pools.has(t)) {
                        for (var i = new c, o = 0; o < n; o++) {
                            var s = u(t);
                            i.put(s)
                        }
                        this.pools.set(t, i)
                    }
                }
                ,
                a.getInScene = function(t) {
                    var e = this.get(t);
                    return e.setParent(this.scene),
                    e
                }
                ,
                a.get = function(t) {
                    var e;
                    0 == this.pools.has(t) && this.initialize(t);
                    var n = null === (e = this.pools.get(t)) || void 0 === e ? void 0 : e.get();
                    return null == n && (n = u(t)),
                    n
                }
                ,
                a.putByName = function(t, e) {
                    for (var n, i = o(this.pools); !(n = i()).done; ) {
                        var s = n.value
                          , r = s[0];
                        s[1];
                        if (r.name == t) {
                            this.put(r, e);
                            break
                        }
                    }
                }
                ,
                a.put = function(t, e) {
                    var n;
                    this.pools.has(t) && (null === (n = this.pools.get(t)) || void 0 === n || n.put(e))
                }
                ,
                a.schedulePut = function(t, e, n) {
                    var i = this;
                    this.scheduleOnce((function() {
                        i.put(t, e)
                    }
                    ), n)
                }
                ,
                a.clear = function(t) {
                    var e;
                    this.pools.has(t) && (null === (e = this.pools.get(t)) || void 0 === e || e.clear())
                }
                ,
                a.clearAll = function() {
                    this.pools.forEach((function(t) {
                        t.clear()
                    }
                    ))
                }
                ,
                a.has = function(t) {
                    return this.pools.has(t)
                }
                ,
                s(r, null, [{
                    key: "instance",
                    get: function() {
                        if (null == r._instance) {
                            var t = new h(r.name);
                            t.setParent(l.getScene()),
                            this._instance = t.addComponent(r)
                        }
                        return r._instance
                    }
                }]),
                r
            }(f),
            e(v, "_instance", void 0),
            p = d)) || p) || p);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletEnums.ts", ["cc"], (function(t) {
    "use strict";
    var e;
    return {
        setters: [function(t) {
            e = t.cclegacy
        }
        ],
        execute: function() {
            var u;
            t("BulletEvent", void 0),
            e._RF.push({}, "b8e5euUXhxH8YucSi9oFt9B", "BulletEnums", void 0),
            function(t) {
                t.HitAnything = "bullet-hit-anything",
                t.HitPlayer = "bullet-hit-player"
            }(u || (u = t("BulletEvent", {}))),
            e._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/LogCategoryWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./PanelEnums.ts", "./Panel.ts", "./LogCategoryToggle.ts"], (function(e) {
    "use strict";
    var t, n, o, r, i, a, l, s, g, u, p, c, f, b, h;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            o = e.initializerDefineProperty,
            r = e.assertThisInitialized
        }
        , function(e) {
            i = e.cclegacy,
            a = e._decorator,
            l = e.Prefab,
            s = e.Node,
            g = e.instantiate,
            u = e.Component
        }
        , function(e) {
            p = e.logger,
            c = e.LogCategory
        }
        , function(e) {
            f = e.EventPanel
        }
        , function(e) {
            b = e.Panel
        }
        , function(e) {
            h = e.LogCategoryToggle
        }
        ],
        execute: function() {
            var y, d, v, L, C, m, P, T, w;
            i._RF.push({}, "ba55aY70h1Ad7H1aeNwO/gO", "LogCategoryWidget", void 0);
            var z = a.ccclass
              , N = a.property;
            e("LogCategoryWidget", (y = z("LogCategoryWidget"),
            d = N(b),
            v = N(l),
            L = N(s),
            y((P = t((m = function(e) {
                function t() {
                    for (var t, n = arguments.length, i = new Array(n), a = 0; a < n; a++)
                        i[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(i)) || this,
                    o(r(t), "panel", P, r(t)),
                    o(r(t), "prefabToggle", T, r(t)),
                    o(r(t), "container", w, r(t)),
                    t
                }
                n(t, e);
                var i = t.prototype;
                return i.onEnable = function() {
                    this.panel && this.panel.node.on(f.OpenStart, this.setup, this)
                }
                ,
                i.onDisable = function() {
                    this.panel && this.panel.node.off(f.OpenStart, this.setup, this)
                }
                ,
                i.setup = function() {
                    for (var e = 0, t = Object.keys(c); e < t.length; e++) {
                        var n = t[e];
                        console.log("" + n);
                        var o = Number(n);
                        if (!isNaN(o)) {
                            var r = g(this.prefabToggle);
                            r.setParent(this.container);
                            var i = r.getComponent(h);
                            null == i || i.setup(o)
                        }
                    }
                }
                ,
                t
            }(u)).prototype, "panel", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            T = t(m.prototype, "prefabToggle", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            w = t(m.prototype, "container", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            C = m)) || C));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BasePickup.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./CharacterEnums.ts", "./PrefabPool.ts", "./PickupCollectionFeedback.ts", "./CanvasGameplay.ts"], (function(i) {
    "use strict";
    var e, t, n, o, r, l, a, c, s, u, p, h, d, g, f, k, m, v, P;
    return {
        setters: [function(i) {
            e = i.defineProperty,
            t = i.applyDecoratedDescriptor,
            n = i.inheritsLoose,
            o = i.initializerDefineProperty,
            r = i.assertThisInitialized,
            l = i.createClass
        }
        , function(i) {
            a = i.cclegacy,
            c = i._decorator,
            s = i.Prefab,
            u = i.Node,
            p = i.Collider,
            h = i.Component
        }
        , function(i) {
            d = i.logger,
            g = i.LogCategory
        }
        , function(i) {
            f = i.OnTrigger
        }
        , function(i) {
            k = i.EventCharacterAction
        }
        , function(i) {
            m = i.PrefabPool
        }
        , function(i) {
            v = i.PickupCollectionFeedback
        }
        , function(i) {
            P = i.CanvasGameplay
        }
        ],
        execute: function() {
            var y, b, C, T, I, S, w, E, D, M, _;
            a._RF.push({}, "ba7c7gw6kFL84vA+fCeKzdS", "BasePickup", void 0);
            var z = c.ccclass
              , B = c.property;
            i("BasePickup", (y = z("BasePickup"),
            b = B({
                type: s
            }),
            C = B({
                type: u
            }),
            y((_ = M = function(i) {
                function t() {
                    for (var t, n = arguments.length, l = new Array(n), a = 0; a < n; a++)
                        l[a] = arguments[a];
                    return t = i.call.apply(i, [this].concat(l)) || this,
                    o(r(t), "feedbackPrefab", S, r(t)),
                    o(r(t), "uiTrackNode", w, r(t)),
                    o(r(t), "initialSpawnDelay", E, r(t)),
                    o(r(t), "collectionTimer", D, r(t)),
                    e(r(t), "originalCollector", void 0),
                    e(r(t), "interactions", []),
                    e(r(t), "spawnDelayTimer", 0),
                    e(r(t), "timer", 0),
                    e(r(t), "_isAValidPickup", !0),
                    e(r(t), "uiInstance", void 0),
                    t
                }
                n(t, i);
                var a = t.prototype;
                return a.onLoad = function() {
                    var i, e = this.getComponent(p);
                    (null == e || e.on(f.Enter, this.onTriggerEnter, this),
                    null == e || e.on(f.Exit, this.onTriggerExit, this),
                    this.feedbackPrefab) && (null === (i = m.instance) || void 0 === i || i.initializeWithCallbacks(this.feedbackPrefab, t.name))
                }
                ,
                a.reuse = function() {
                    this._isAValidPickup = !0
                }
                ,
                a.unuse = function() {
                    var i;
                    (
                        // console.log("Weapon pickup unuse"),
                    this._isAValidPickup = !1,
                    this.feedbackPrefab && this.uiInstance && this.uiInstance.node && this.uiInstance.node.isValid) && (null === (i = m.instance) || void 0 === i || i.put(this.feedbackPrefab, this.uiInstance.node))
                }
                ,
                a.update = function(i) {
                    var e, t, n, o;
                    (this.spawnDelayTimer += i,
                    this.interactions.length > 0 && this.spawnDelayTimer >= this.initialSpawnDelay) ? (this.timer += i,
                    null === (e = this.uiInstance) || void 0 === e || e.setFillRate(this.timer / this.collectionTimer),
                    this.timer > this.collectionTimer && (null === (t = this.originalCollector) || void 0 === t || null === (n = t.children[0]) || void 0 === n || n.emit(k.StopPicking),
                    this.handlePickupCollection())) : null === (o = this.uiInstance) || void 0 === o || o.setFillRate(0)
                }
                ,
                a.handlePickupCollection = function() {
                    var i;
                   console.log(this.node.name + " picked up by " + (null === (i = this.originalCollector) || void 0 === i ? void 0 : i.name), g.Gameplay),
                    this.removePickupBlocking(this.originalCollector),
                    this.node.destroy()
                }
                ,
                a.onTriggerEnter = function(i) {
                    if (t.pickupMapping.has(i.otherCollider.node)) {
                        var e = t.pickupMapping.get(i.otherCollider.node);
                       console.log("Player " + i.otherCollider.node.name + " is already picking up " + e.name + ", overriding it", g.Gameplay),
                        null == e || e.removeInteraction(i.otherCollider.node)
                    }
                    var n;
                    0 == this.interactions.length && (this.originalCollector = i.otherCollider.node,
                    null === (n = this.originalCollector.children[0]) || void 0 === n || n.emit(k.StartPicking),
                    t.pickupMapping.set(i.otherCollider.node, this),
                //    console.log("Player " + i.otherCollider.node.name + " started picking " + this.name, g.Gameplay),
                    this.onSomeoneStartToPick());
                    this.interactions.push(i.otherCollider.node)
                }
                ,
                a.onTriggerExit = function(i) {
                    this.removeInteraction(i.otherCollider.node)
                }
                ,
                a.removeInteraction = function(i) {
                    var e = this.interactions.indexOf(i);
                    if (!(e < 0) && (this.interactions.splice(e, 1),
                    this.removePickupBlocking(i),
                   console.log("Trigger exit, length =  " + this.interactions.length),
                    0 == this.interactions.length)) {
                        var t, n;
                        if (this.originalCollector && this.originalCollector.isValid)
                            if (0 == this.originalCollector.children.length)
                               console.log("ERROR: No children on original collector, maybe its not a player or bot? : " + this.originalCollector);
                            else
                                null === (t = this.originalCollector) || void 0 === t || null === (n = t.children[0]) || void 0 === n || n.emit(k.StopPicking);
                        this.originalCollector = null,
                        this.timer = 0,
                        this.onEveryoneStopToPick()
                    }
                }
                ,
                a.onSomeoneStartToPick = function() {
                    if (this.feedbackPrefab) {
                        var i, e = null === (i = m.instance) || void 0 === i ? void 0 : i.get(this.feedbackPrefab);
                        if (e) {
                            if (this.uiInstance = e.getComponent(v),
                            this.uiInstance && P.instance && this.uiInstance.node.setParent(P.instance.node),
                            !this.uiInstance)
                                return voidconsole.log("Failed to instantiate UI for pickup");
                            this.uiInstance.setup(this.uiTrackNode),
                            this.onSetupUI(),
                            this.uiInstance.show()
                        }
                    }
                }
                ,
                a.onEveryoneStopToPick = function() {
                    var i;
                    null === (i = this.uiInstance) || void 0 === i || i.hide()
                }
                ,
                a.onSetupUI = function() {}
                ,
                a.removePickupBlocking = function(i) {
                    if (t.pickupMapping.has(i)) {
                        var e = t.pickupMapping.get(i);
                        e == this && (t.pickupMapping.delete(i)
                    //     ,
                    //    console.log("Player " + i.name + " stopped picking " + e.name, g.Gameplay)
                       )
                    }
                }
                ,
                l(t, [{
                    key: "isValidPickup",
                    get: function() {
                        return this._isAValidPickup
                    }
                }, {
                    key: "CollectionTimer",
                    get: function() {
                        return this.collectionTimer
                    }
                }]),
                t
            }(h),
            e(M, "pickupMapping", new Map),
            S = t((I = _).prototype, "feedbackPrefab", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return null
                }
            }),
            w = t(I.prototype, "uiTrackNode", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return null
                }
            }),
            E = t(I.prototype, "initialSpawnDelay", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1.5
                }
            }),
            D = t(I.prototype, "collectionTimer", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3
                }
            }),
            T = I)) || T));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterInterfaces.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, r, n, a, c;
    return {
        setters: [function(e) {
            t = e.inheritsLoose,
            r = e.defineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            a = e.cclegacy,
            c = e.Component
        }
        ],
        execute: function() {
            a._RF.push({}, "bdaa58oN6JEiYgcIBIDP577", "CharacterInterfaces", void 0);
            e("CharacterInputBase", function(e) {
                function a() {
                    for (var t, a = arguments.length, c = new Array(a), i = 0; i < a; i++)
                        c[i] = arguments[i];
                    return t = e.call.apply(e, [this].concat(c)) || this,
                    r(n(t), "horizontal", 0),
                    r(n(t), "vertical", 0),
                    t
                }
                return t(a, e),
                a
            }(c));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIToastWeaponName.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./UIToast.ts"], (function(t) {
    "use strict";
    var e, n, o, a, s, i, r, c, l, u, p, h, f;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            o = t.initializerDefineProperty,
            a = t.assertThisInitialized,
            s = t.defineProperty
        }
        , function(t) {
            i = t.cclegacy,
            r = t._decorator,
            c = t.CCString,
            l = t.Component
        }
        , function(t) {
            u = t.logger
        }
        , function(t) {
            p = t.ProjectEventType
        }
        , function(t) {
            h = t.projectEvent
        }
        , function(t) {
            f = t.UIToast
        }
        ],
        execute: function() {
            var g, y, d, v, m;
            i._RF.push({}, "bf08ejrf1ZJKa5VIMX2X186", "UIToastWeaponName", void 0);
            var P = r.ccclass
              , C = r.property;
            t("UIToastWeaponName", (g = P("UIToastWeaponName"),
            y = C({
                type: [c],
                tooltip: "Must be in the enum order!\nBasic = 0,\nAssaultRifle = 1,\nShotgun = 2,\nBazooka = 3,\nDebug = 4,"
            }),
            g((m = e((v = function(t) {
                function e() {
                    for (var e, n = arguments.length, i = new Array(n), r = 0; r < n; r++)
                        i[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(i)) || this,
                    o(a(e), "texts", m, a(e)),
                    s(a(e), "toast", void 0),
                    e
                }
                n(e, t);
                var i = e.prototype;
                return i.onLoad = function() {
                    this.toast = this.node.getComponent(f)
                }
                ,
                i.onEnable = function() {
                    h.on(p.PlayerWeaponChange, this.onPlayerChangeWeapon, this)
                }
                ,
                i.onDisable = function() {
                    h.off(p.PlayerWeaponChange, this.onPlayerChangeWeapon, this)
                }
                ,
                i.onPlayerChangeWeapon = function(t) {
                    var e;
                    this.texts && 0 != this.texts.length ? t >= this.texts.length ? console.log("ERROR: Miss configured weapon names on UI Toast") : null === (e = this.toast) || void 0 === e || e.show(this.texts[t]) : console.log("ERROR: Miss configured weapon names on UI Toast")
                }
                ,
                e
            }(l)).prototype, "texts", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ["Basic", "Assault Rifle", "Shotgun", "Bazooka"]
                }
            }),
            d = v)) || d));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MetagameWeaponData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Weapon.ts"], (function(e) {
    "use strict";
    var t, n, a, r, i, o, u, p, c, s, l, f;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.createClass,
            a = e.inheritsLoose,
            r = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            u = e._decorator,
            p = e.CCString,
            c = e.SpriteFrame,
            s = e.Prefab,
            l = e.Component
        }
        , function(e) {
            f = e.Weapon
        }
        ],
        execute: function() {
            var g, b, h, m, y, D, W, w, d, z, M, v, P, k;
            o._RF.push({}, "bf19dG8KJBOFq71lcrliBz6", "MetagameWeaponData", void 0);
            var B = u.ccclass
              , C = u.property
              , _ = e("MetagameWeapon", (g = B("MetagameWeapon"),
            b = C(p),
            h = C(c),
            m = C(s),
            g((W = t((D = function() {
                function e() {
                    r(this, "name", W, this),
                    r(this, "icon", w, this),
                    r(this, "prefab", d, this)
                }
                return n(e, [{
                    key: "Name",
                    get: function() {
                        return this.name
                    }
                }, {
                    key: "Icon",
                    get: function() {
                        return this.icon
                    }
                }, {
                    key: "Prefab",
                    get: function() {
                        return this.prefab
                    }
                }]),
                e
            }()).prototype, "name", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            w = t(D.prototype, "icon", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            d = t(D.prototype, "prefab", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = D)) || y));
            e("MetagameWeaponData", (z = B("MetagameWeaponData"),
            M = C({
                type: [_],
                tooltip: "Must be in the enum order!\nBasic = 0,\nAssaultRifle = 1,\nShotgun = 2,\nBazooka = 3,\nDebug = 4,"
            }),
            z((k = t((P = function(e) {
                function t() {
                    for (var t, n = arguments.length, a = new Array(n), o = 0; o < n; o++)
                        a[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    r(i(t), "weaponDatas", k, i(t)),
                    t
                }
                a(t, e);
                var n = t.prototype;
                return n.getWeaponName = function(e) {
                    return this.weaponDatas[e].Name
                }
                ,
                n.getWeaponData = function(e) {
                    return this.weaponDatas[e].Prefab.data.getComponent(f)
                }
                ,
                n.getWeaponPrefab = function(e) {
                    return this.weaponDatas[e].Prefab
                }
                ,
                n.getWeaponIcon = function(e) {
                    return this.weaponDatas[e].Icon
                }
                ,
                t
            }(l)).prototype, "weaponDatas", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            v = P)) || v));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/ProjectConstants.ts", ["cc"], (function(e) {
    "use strict";
    var a;
    return {
        setters: [function(e) {
            a = e.cclegacy
        }
        ],
        execute: function() {
            var n, r;
            e({
                BundleNames: void 0,
                CurrencyRewardTweenMode: void 0,
                MapTile: void 0,
                MetagameEvent: void 0,
                OnCollision: void 0,
                OnTrigger: void 0,
                PHY_GROUP: void 0,
                ProjectEventType: void 0,
                SceneNames: void 0,
                StorageKey: void 0,
                UIEventType: void 0
            }),
            a._RF.push({}, "bfb85Ehd/BEn7t7SLjyVhc8", "ProjectConstants", void 0),
            function(e) {
                e.Game = "game",
                e.Tutorial = "tutorial"
            }(n || (n = e("BundleNames", {}))),
            function(e) {
                e.Splash = "Splash",
                e.Menu = "Menu",
                e.Tutorial = "Tutorial",
                e.PreTutorial = "PreTutorial"
            }(r || (r = e("SceneNames", {})));
            var t, o, i, c, l, s, p, u, h;
            e("SceneLevels", ["Level_00", "Level_01", "Level_02", "Level_03"]);
            !function(e) {
                e[e.DEFAULT = 1] = "DEFAULT",
                e[e.PLAYER = 2] = "PLAYER",
                e[e.BULLET = 4] = "BULLET"
            }(t || (t = e("PHY_GROUP", {}))),
            function(e) {
                e.FinishedTutorial = "finishedTutorial"
            }(o || (o = e("StorageKey", {}))),
            function(e) {
                e.Enter = "onTriggerEnter",
                e.Stay = "onTriggerStay",
                e.Exit = "onTriggerExit"
            }(i || (i = e("OnTrigger", {}))),
            function(e) {
                e.Enter = "onCollisionEnter",
                e.Exit = "onCollisionExit"
            }(c || (c = e("OnCollision", {}))),
            function(e) {
                e.CharacterSpawn = "character-spawn",
                e.CharacterDeath = "character-death",
                e.MatchTimerStart = "match-timer-start",
                e.MatchStart = "match-start",
                e.MatchFinish = "match-finish",
                e.PlayerShoot = "player-shoot",
                e.PlayerShootBullet = "player-shoot-bullet",
                e.PlayerWinMatch = "player-win-match",
                e.PlayerLoseMatch = "player-lose-match",
                e.PlayerHitReceived = "player-hit-received",
                e.PlayerKill = "player-kill",
                e.PlayerLevelUp = "player-level-up",
                e.PlayerWeaponChange = "player-weapon-change",
                e.PlayerEnterDamageZone = "player-enter-damage-zone",
                e.PlayerExitDamageZone = "player-exit-damage-zone",
                e.PlayerCollectedChest = "player-collected-chest",
                e.MapAreaShrinkedX = "map-area-shrinked-x",
                e.MapAreaShrinkedY = "map-area-shrinked-y",
                e.WeaponPickupSpawned = "weapon-pickup-spawned",
                e.WeaponPickupDestroyed = "weapon-pickup-destroyed",
                e.MapSetup = "map-setup"
            }(l || (l = e("ProjectEventType", {}))),
            function(e) {
                e.ArenaSelected = "arena-selected",
                e.ArenaPurchaseConfirmation = "arena-purchase-confirmation",
                e.ArenaPurchaseSucccess = "arena-purchase-success",
                e.CurrencyRewardSpawned = "money-spawned",
                e.BlockMoneyUpdate = "block-money-update",
                e.UnblockMoneyUpdate = "unblock-money-update",
                e.MissionComplete = "mission-complete",
                e.MetagameLevelUp = "ui-metagame-level-up",
                e.ButtonClickPlay = "button-click-play",
                e.ButtonClickMissions = "button-click-missions",
                e.StopRotateModel = "stop-rotate-model",
                e.CharacterModelChanged = "character-model-changed"
            }(s || (s = e("UIEventType", {}))),
            function(e) {
                e[e.Generic = 0] = "Generic",
                e[e.Mission = 1] = "Mission"
            }(p || (p = e("CurrencyRewardTweenMode", {}))),
            function(e) {
                e.WeaponUpgradePurchaseSuccess = "weapon-upgrade-purchase-success",
                e.WeaponUpgradePurchaseConfirmation = "weapon-upgrade-purchase-confirmation",
                e.CurrencyChanged = "currency-changed",
                e.CharacterPurchaseConfirmation = "character-purchase-confirmation",
                e.CharacterPurchaseSuccess = "character-purchase-success",
                e.TrophiesChanged = "trophies-changed",
                e.LevelUp = "metagame-level-up"
            }(u || (u = e("MetagameEvent", {}))),
            function(e) {
                e[e.Nothing = 0] = "Nothing",
                e[e.Wall1 = 1] = "Wall1",
                e[e.Wall2 = 2] = "Wall2",
                e[e.Grass = 3] = "Grass",
                e[e.Barrel = 4] = "Barrel",
                e[e.SpawnBot = 5] = "SpawnBot",
                e[e.NavigationBlock = 6] = "NavigationBlock",
                e[e.Chest = 7] = "Chest",
                e[e.SpawnPlayer = 8] = "SpawnPlayer",
                e[e.SpawnTurret = 9] = "SpawnTurret"
            }(h || (h = e("MapTile", {})));
            e("version", "");
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RewardedAdDebug.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./RewardedAdOportunity.ts"], (function(e) {
    "use strict";
    var r, t, i, n, o, a, d, u;
    return {
        setters: [function(e) {
            r = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            i = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            d = e.Component
        }
        , function(e) {
            u = e.RewardedAdOportunity
        }
        ],
        execute: function() {
            var p, c, s, l, y;
            o._RF.push({}, "c0418CM9Q1L6a2ptByDOdRV", "RewardedAdDebug", void 0);
            var f = a.ccclass
              , w = a.property;
            e("RewardedAdDebug", (p = f("RewardedAdDebug"),
            c = w(u),
            p((y = r((l = function(e) {
                function r() {
                    for (var r, t = arguments.length, o = new Array(t), a = 0; a < t; a++)
                        o[a] = arguments[a];
                    return r = e.call.apply(e, [this].concat(o)) || this,
                    i(n(r), "rewardedAdOpportunity", y, n(r)),
                    r
                }
                return t(r, e),
                r.prototype.start = function() {
                    this.rewardedAdOpportunity.setup()
                }
                ,
                r
            }(d)).prototype, "rewardedAdOpportunity", [c], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            s = l)) || s));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CurrencyWidget.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts"], (function(e) {
    "use strict";
    var n, t, o, r, i, a, c, s, u, l, d, p, h, y, g, f, C, U, w, b;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            o = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            i = e.defineProperty
        }
        , function(e) {
            a = e.cclegacy,
            c = e._decorator,
            s = e.Label,
            u = e.Animation,
            l = e.tween,
            d = e.Vec3,
            p = e.Component
        }
        , function(e) {
            h = e.logger,
            y = e.LogCategory,
            g = e.LogType
        }
        , function(e) {
            f = e.MetagameEvent,
            C = e.UIEventType,
            U = e.CurrencyRewardTweenMode
        }
        , function(e) {
            w = e.projectEvent
        }
        , function(e) {
            b = e.globalPlayer
        }
        ],
        execute: function() {
            var k, P, m, v, V, L, W;
            a._RF.push({}, "c07dcJvzKVL/qFb557TqQiR", "CurrencyWidget", void 0);
            var R = c.ccclass
              , M = c.property;
            e("CurrencyWidget", (k = R("CurrencyWidget"),
            P = M(s),
            m = M(u),
            k((L = n((V = function(e) {
                function n() {
                    for (var n, t = arguments.length, a = new Array(t), c = 0; c < t; c++)
                        a[c] = arguments[c];
                    return n = e.call.apply(e, [this].concat(a)) || this,
                    o(r(n), "lValue", L, r(n)),
                    o(r(n), "animation", W, r(n)),
                    i(r(n), "lastValue", 0),
                    i(r(n), "blockUpdateCounter", 0),
                    n
                }
                t(n, e);
                var a = n.prototype;
                return a.onLoad = function() {
                    console.log(this.node.name + " onLoad", y.UI),
                    w.on(f.WeaponUpgradePurchaseSuccess, this.onUpgradePurchased, this),
                    w.on(f.CurrencyChanged, this.onCurrencyChanged, this),
                    w.on(C.BlockMoneyUpdate, this.onBlockUpdate, this),
                    w.on(C.UnblockMoneyUpdate, this.onUnblockUpdate, this),
                    w.on(C.CurrencyRewardSpawned, this.onCurrencyRewardSpawned, this),
                    this.updateWidget()
                }
                ,
                a.onDestroy = function() {
                    w.off(f.WeaponUpgradePurchaseSuccess, this.onUpgradePurchased, this),
                    w.off(f.CurrencyChanged, this.onCurrencyChanged, this),
                    w.off(C.BlockMoneyUpdate, this.onBlockUpdate, this),
                    w.off(C.UnblockMoneyUpdate, this.onUnblockUpdate, this),
                    w.off(C.CurrencyRewardSpawned, this.onCurrencyRewardSpawned, this)
                }
                ,
                a.onUpgradePurchased = function() {
                    this.updateWidget()
                }
                ,
                a.onUnblockUpdate = function() {
                    this.blockUpdateCounter--
                }
                ,
                a.onBlockUpdate = function() {
                    this.blockUpdateCounter++
                }
                ,
                a.onCurrencyChanged = function(e, n) {
                    this.blockUpdateCounter > 0 || this.tweenCurrencyValue()
                }
                ,
                a.onCurrencyRewardSpawned = function(e, n) {
                    var t = this;
                    this.onBlockUpdate(),
                    n == U.Mission ? l(e).delay(1).by(.5, {
                        position: new d(30,-10,0)
                    }, {
                        easing: "quintOut"
                    }).delay(.5).to(.5, {
                        worldPosition: this.node.worldPosition
                    }, {
                        easing: "quintOut",
                        onComplete: function(n) {
                            e.destroy(),
                            t.onUnblockUpdate(),
                            0 == t.blockUpdateCounter && t.tweenCurrencyValue()
                        }
                    }).repeat(1).start() : l(e).delay(0).by(.8, {
                        scale: new d(.5,.5,0),
                        worldPosition: new d(0,30,0)
                    }, {
                        easing: "quintInOut"
                    }).by(.8, {
                        worldPosition: new d(0,10,0)
                    }, {
                        easing: "quadIn"
                    }).to(.5, {
                        scale: new d(.5,.5,.5),
                        worldPosition: this.node.worldPosition
                    }, {
                        easing: "quintOut",
                        onComplete: function(n) {
                            e.destroy(),
                            t.onUnblockUpdate(),
                            0 == t.blockUpdateCounter && t.tweenCurrencyValue()
                        }
                    }).repeat(1).start()
                }
                ,
                a.tweenCurrencyValue = function() {
                    var e = this
                      , n = this.lastValue
                      , t = b.currency - n;
                    l(this.lValue).to(1, {}, {
                        easing: "linear",
                        onUpdate: function(o, r) {
                            e.setLabelText(e.lValue, "" + (n + t * r).toFixed(0))
                        },
                        onComplete: function(n) {
                            e.updateWidget()
                        }
                    }).repeat(1).start()
                }
                ,
                a.updateWidget = function() {
                    console.log(this.node.name + " UpdateWidegt", y.UI),
                    null != b.currency ? (this.setLabelText(this.lValue, b.currency.toFixed()),
                    this.lastValue = b.currency,
                    this.animation.play()) : console.log("Currency is undefined", y.UI, g.Error)
                }
                ,
                a.setLabelText = function(e, n) {
                    e.string = n,
                    e.updateRenderData(!0)
                }
                ,
                n
            }(p)).prototype, "lValue", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            W = n(V.prototype, "animation", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = V)) || v));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestCustomGlobalEventEmitter.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(t) {
    "use strict";
    var e, n, o, r, s, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            n = t.cclegacy,
            o = t._decorator,
            r = t.Component
        }
        , function(t) {
            s = t.ProjectEventType
        }
        , function(t) {
            c = t.projectEvent
        }
        ],
        execute: function() {
            var i;
            n._RF.push({}, "c0c39QQ0DxLrKPmhDath0Nb", "TestCustomGlobalEventEmitter", void 0);
            var u = o.ccclass;
            o.property,
            t("TestCustomGlobalEventEmitter", u("TestCustomGlobalEventEmitter")(i = function(t) {
                function n() {
                    return t.apply(this, arguments) || this
                }
                return e(n, t),
                n.prototype.start = function() {
                    c.emit(s.MatchFinish)
                }
                ,
                n
            }(r)) || i);
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIEnums.ts", ["cc"], (function(t) {
    "use strict";
    var n;
    return {
        setters: [function(t) {
            n = t.cclegacy
        }
        ],
        execute: function() {
            var e, i;
            t({
                AIEvent: void 0,
                AIStateList: void 0
            }),
            n._RF.push({}, "c2bbf9p7p5DlqzRfFs4TwV6", "AIEnums", void 0),
            function(t) {
                t.Idle = "idle",
                t.Wandering = "wandering",
                t.Attacking = "attacking",
                t.Chasing = "chasing",
                t.Fleeing = "fleeing",
                t.Looting = "looting",
                t.Reloading = "reloading"
            }(e || (e = t("AIStateList", {}))),
            function(t) {
                t.StateChanged = "state-changed"
            }(i || (i = t("AIEvent", {}))),
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TutorialTriggerOnCharacterDeath.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./TutorialStepBase.ts", "./CharacterHealthControl.ts"], (function(t) {
    "use strict";
    var r, e, a, i, n, o, c, s, u, h, l;
    return {
        setters: [function(t) {
            r = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            a = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            n = t.defineProperty
        }
        , function(t) {
            o = t.cclegacy,
            c = t._decorator,
            s = t.CCFloat
        }
        , function(t) {
            u = t.EventCharacterAction
        }
        , function(t) {
            h = t.TutorialStepBase
        }
        , function(t) {
            l = t.CharacterHealthControl
        }
        ],
        execute: function() {
            var g, f, p, d, y, v, C;
            o._RF.push({}, "c54faE1acdKmpU85egbQJyr", "TutorialTriggerOnCharacterDeath", void 0);
            var D = c.ccclass
              , T = c.property;
            t("TutorialTriggerOnCharacterDeath", (g = D("TutorialTriggerOnCharacterDeath"),
            f = T({
                type: s,
                min: .2
            }),
            p = T([l]),
            g((v = r((y = function(t) {
                function r() {
                    for (var r, e = arguments.length, o = new Array(e), c = 0; c < e; c++)
                        o[c] = arguments[c];
                    return r = t.call.apply(t, [this].concat(o)) || this,
                    a(i(r), "duration", v, i(r)),
                    a(i(r), "characters", C, i(r)),
                    n(i(r), "triggered", !1),
                    r
                }
                e(r, t);
                var o = r.prototype;
                return o.onEnable = function() {
                    var t = this;
                    this.characters.forEach((function(r) {
                        r.node.on(u.DyingStart, t.onAnyCharacterStartDying, t)
                    }
                    ))
                }
                ,
                o.onDisable = function() {
                    var t = this;
                    this.characters.forEach((function(r) {
                        var e;
                        r && (null === (e = r.node) || void 0 === e ? void 0 : e.isValid) && r.node.on(u.DyingStart, t.onAnyCharacterStartDying, t)
                    }
                    ))
                }
                ,
                o.onAnyCharacterStartDying = function(t, r, e) {
                    this.triggered || (this.triggered = !0,
                    this.activate(),
                    this.scheduleOnce(this.deactivate, this.duration))
                }
                ,
                r
            }(h)).prototype, "duration", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3
                }
            }),
            C = r(y.prototype, "characters", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            d = y)) || d));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CheatOpenMenuDebug.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./env", "./PanelManager.ts", "./PanelEnums.ts"], (function(e) {
    "use strict";
    var n, t, u, o, c, a, r;
    return {
        setters: [function(e) {
            n = e.inheritsLoose
        }
        , function(e) {
            t = e.cclegacy,
            u = e._decorator,
            o = e.Component
        }
        , function(e) {
            c = e.DEBUG
        }
        , function(e) {
            a = e.PanelManager
        }
        , function(e) {
            r = e.PanelId
        }
        ],
        execute: function() {
            var i;
            t._RF.push({}, "c61b8Vc+SVNm4/MCHoFteok", "CheatOpenMenuDebug", void 0);
            var s = u.ccclass;
            u.property,
            e("CheatOpenMenuDebug", s("CheatOpenMenuDebug")(i = function(e) {
                function t() {
                    return e.apply(this, arguments) || this
                }
                n(t, e);
                var u = t.prototype;
                return u.onLoad = function() {
                    this.node.active = c
                }
                ,
                u.openMenuDebug = function() {
                    var e;
                    null === (e = a.instance) || void 0 === e || e.open(r.DebugMenu)
                }
                ,
                t
            }(o)) || i);
            t._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestStorage.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(t) {
    "use strict";
    var e, o, r, s, n, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose
        }
        , function(t) {
            o = t.cclegacy,
            r = t._decorator,
            s = t.sys,
            n = t.Component
        }
        , function(t) {
            c = t.logger
        }
        ],
        execute: function() {
            var a;
            o._RF.push({}, "c9963vvxlRPc71bDnpt10ku", "TestStorage", void 0);
            var u = r.ccclass;
            r.property,
            t("TestStorage", u("TestStorage")(a = function(t) {
                function o() {
                    return t.apply(this, arguments) || this
                }
                return e(o, t),
                o.prototype.start = function() {
                    var t = "test"
                      , e = s.localStorage.getItem(t);
                   console.log("savedValue " + e),
                    s.localStorage.setItem(t, 1),
                   console.log("saved value")
                }
                ,
                o
            }(n)) || a);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UITrackWorldNode.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CameraGameplay.ts"], (function(t) {
    "use strict";
    var i, e, o, n, a, r, s, c, u, l, p, h;
    return {
        setters: [function(t) {
            i = t.applyDecoratedDescriptor,
            e = t.inheritsLoose,
            o = t.initializerDefineProperty,
            n = t.assertThisInitialized,
            a = t.defineProperty
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator,
            c = t.Node,
            u = t.Vec3,
            l = t.UIOpacity,
            p = t.Component
        }
        , function(t) {
            h = t.CameraGameplay
        }
        ],
        execute: function() {
            var d, y, f, m, g;
            r._RF.push({}, "ca55c4KX9pOeJCZ9CnliWcx", "UITrackWorldNode", void 0);
            var P = s.ccclass
              , v = s.property;
            t("UITrackWorldNode", (d = P("UITrackWorldNode"),
            y = v(c),
            d((g = i((m = function(t) {
                function i() {
                    for (var i, e = arguments.length, r = new Array(e), s = 0; s < e; s++)
                        r[s] = arguments[s];
                    return i = t.call.apply(t, [this].concat(r)) || this,
                    o(n(i), "target", g, n(i)),
                    a(n(i), "out", new u),
                    i
                }
                e(i, t);
                var r = i.prototype;
                return r.onLoad = function() {
                    this.uiOpacity = this.node.getComponent(l),
                    this.hide(),
                    this.updatePosition()
                }
                ,
                r.start = function() {
                    this.camera = h.instance.camera,
                    this.updatePosition(),
                    this.scheduleOnce(this.show, .5)
                }
                ,
                r.update = function() {
                    this.updatePosition()
                }
                ,
                r.setup = function(t) {
                    this.target = t
                }
                ,
                r.hide = function() {
                    null != this.uiOpacity && (this.uiOpacity.opacity = 0)
                }
                ,
                r.show = function() {
                    null != this.uiOpacity && (this.uiOpacity.opacity = 255)
                }
                ,
                r.updatePosition = function() {
                    null != this.camera && null != this.target && null != this.node.parent && (this.camera.convertToUINode(this.target.worldPosition, this.node.parent, this.out),
                    this.node.setPosition(this.out))
                }
                ,
                i
            }(p)).prototype, "target", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            f = m)) || f));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/LandscapeFitter.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(t) {
    "use strict";
    var i, e, n, s, o, r, a, g, c, d;
    return {
        setters: [function(t) {
            i = t.inheritsLoose,
            e = t.defineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            s = t.cclegacy,
            o = t._decorator,
            r = t.Widget,
            a = t.UITransform,
            g = t.view,
            c = t.Component
        }
        , function(t) {
            d = t.logger
        }
        ],
        execute: function() {
            var h;
            s._RF.push({}, "cdc74BfVqdGn70uyUgrdTEg", "LandscapeFitter", void 0);
            var l = o.ccclass;
            o.property,
            t("LandscapeFitter", l("LandscapeFitter")(h = function(t) {
                function s() {
                    for (var i, s = arguments.length, o = new Array(s), r = 0; r < s; r++)
                        o[r] = arguments[r];
                    return i = t.call.apply(t, [this].concat(o)) || this,
                    e(n(i), "widget", null),
                    e(n(i), "uiTransform", null),
                    i
                }
                i(s, t);
                var o = s.prototype;
                return o.onLoad = function() {
                    this.widget = this.node.getComponent(r),
                    this.uiTransform = this.node.getComponent(a)
                }
                ,
                o.start = function() {
                    this.onSizeChanged()
                }
                ,
                o.onEnable = function() {
                    g.on("canvas-resize", this.onSizeChanged, this)
                }
                ,
                o.onDisable = function() {
                    g.off("canvas-resize", this.onSizeChanged, this)
                }
                ,
                o.onSizeChanged = function() {
                    var t, i = g.getCanvasSize(), e = i.x / i.y, n = e > 1;
                   console.log("CanvasSize: " + i + " aspect: " + e + " isLandscape: " + n),
                    n ? (this.widget.isAlignLeft = !1,
                    this.widget.isAlignRight = !1,
                    this.widget.isAlignHorizontalCenter = !0,
                    this.uiTransform.width = 720) : (this.widget.isAlignLeft = !0,
                    this.widget.isAlignRight = !0,
                    this.widget.isAlignHorizontalCenter = !1,
                    this.widget.left = 0,
                    this.widget.right = 0),
                    null === (t = this.widget) || void 0 === t || t.updateAlignment()
                }
                ,
                s
            }(c)) || h);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestExecutionOrderLow.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, r, o, n, c;
    return {
        setters: [function(e) {
            t = e.inheritsLoose
        }
        , function(e) {
            r = e.cclegacy,
            o = e._decorator,
            n = e.Component
        }
        , function(e) {
            c = e.logger
        }
        ],
        execute: function() {
            var s;
            r._RF.push({}, "ceee5YXYBVGxKSymGfcxgh4", "TestExecutionOrderLow", void 0);
            var u = o.ccclass
              , i = (o.property,
            o.executionOrder);
            e("TestExecutionOrderLow", u("TestExecutionOrderLow")(s = i(-1)(s = function(e) {
                function r() {
                    return e.apply(this, arguments) || this
                }
                return t(r, e),
                r.prototype.start = function() {
                   console.log("Order: -1")
                }
                ,
                r
            }(n)) || s) || s);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIDamageOverlay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts"], (function(e) {
    "use strict";
    var t, n, i, o, a, r, c, s, l, u;
    return {
        setters: [function(e) {
            t = e.inheritsLoose,
            n = e.defineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            r = e.Animation,
            c = e.UIOpacity,
            s = e.Component
        }
        , function(e) {
            l = e.ProjectEventType
        }
        , function(e) {
            u = e.projectEvent
        }
        ],
        execute: function() {
            var v;
            o._RF.push({}, "cfd0f61y8VJkKCT4Z+qeAVb", "UIDamageOverlay", void 0);
            var y = a.ccclass;
            a.property,
            e("UIDamageOverlay", y("UIDamageOverlay")(v = function(e) {
                function o() {
                    for (var t, o = arguments.length, a = new Array(o), r = 0; r < o; r++)
                        a[r] = arguments[r];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    n(i(t), "anim", void 0),
                    t
                }
                t(o, e);
                var a = o.prototype;
                return a.onLoad = function() {
                    this.anim = this.getComponent(r);
                    var e = this.node.getComponent(c);
                    e && (e.opacity = 0)
                }
                ,
                a.onEnable = function() {
                    u.on(l.PlayerHitReceived, this.onPlayerHitReceived, this)
                }
                ,
                a.onDisable = function() {
                    u.off(l.PlayerHitReceived, this.onPlayerHitReceived, this)
                }
                ,
                a.onPlayerHitReceived = function() {
                    this.anim && this.anim.play()
                }
                ,
                o
            }(s)) || v);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AILootingState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./Pathfinding.ts", "./Target.ts", "./AIState.ts", "./AIEnums.ts", "./BasePickup.ts", "./WeaponPickupManager.ts", "./TreasurePickup.ts"], (function(t) {
    "use strict";
    var i, n, e, o, a, s, r, l, d, h, g, c, u, p, f, P, v, m, w;
    return {
        setters: [function(t) {
            i = t.inheritsLoose,
            n = t.defineProperty,
            e = t.assertThisInitialized,
            o = t.createForOfIteratorHelperLoose,
            a = t.createClass
        }
        , function(t) {
            s = t.cclegacy,
            r = t._decorator,
            l = t.director,
            d = t.Vec2
        }
        , function(t) {
            h = t.logger,
            g = t.LogCategory,
            c = t.LogType
        }
        , function(t) {
            u = t.Pathfinding
        }
        , function(t) {
            p = t.Target
        }
        , function(t) {
            f = t.AIState
        }
        , function(t) {
            P = t.AIStateList
        }
        , function(t) {
            v = t.BasePickup
        }
        , function(t) {
            m = t.WeaponPickupManager
        }
        , function(t) {
            w = t.TreasurePickup
        }
        ],
        execute: function() {
            var I;
            s._RF.push({}, "d20409d+6tAP5sGbFV1IARn", "AILootingState", void 0);
            var A = r.ccclass;
            r.property,
            t("AILootingState", A("AILootingState")(I = function(t) {
                function s() {
                    for (var i, o = arguments.length, a = new Array(o), s = 0; s < o; s++)
                        a[s] = arguments[s];
                    return i = t.call.apply(t, [this].concat(a)) || this,
                    n(e(i), "lootingTarget", void 0),
                    n(e(i), "isLootingAChest", void 0),
                    n(e(i), "weaponSearchDelay", -1),
                    n(e(i), "treasureCollectionWaitTime", -1),
                    i
                }
                i(s, t);
                var r = s.prototype;
                return r.stateEnter = function() {
                    if (t.prototype.stateEnter.call(this),
                    u.instance) {
                        var i = this.findClosestWeaponPickup(!0)
                          , n = null;
                        if (null == i ? void 0 : i.isValidPickup)
                            this.isLootingAChest = !1,
                            n = i ? i.node : null;
                        else
                            for (var e, a, s = 999, r = null == l || null === (e = l.getScene()) || void 0 === e ? void 0 : e.getComponentsInChildren(w), d = o(r); !(a = d()).done; ) {
                                var c = a.value;
                                if (c.isValidPickup) {
                                    var f = p.distance(this.node, c.node);
                                    if (f < s) {
                                        var v = u.instance.isPointInsideOfShrinkingArea(c.node.worldPosition.x, c.node.worldPosition.z)
                                          , m = !1;
                                        if (v) {
                                            this.characterBlackboard.healthPercentage <= 1 ? console.log(this.node.name + " Looting: Target chest is inside of shrinking area and my health is bellow 1", g.AI) : (console.log(this.node.name + " Looting: Target chest is inside of shrinking area and my health is above 1", g.AI),
                                            m = !0)
                                        } else
                                            // console.log("Target chest valid random neighour is: " + v, g.AI),
                                            m = !0;
                                        if (m) {
                                            var I = u.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, c.node.worldPosition.x, c.node.worldPosition.z);
                                            I.length > 0 && (s = f,
                                            n = c.node,
                                            this.isLootingAChest = !0
                                            // console.log(this.node.name + " Looting: chest " + n.name + " path: " + I + ".")
                                            )
                                        }
                                    }
                                }
                            }
                        if (!n)
                            return console.log(this.node.name + " Looting: Could not find target.", g.AI),
                            this.brain.data.idleData.lootingPercentage = -.1,
                            this.brain.data.idleData.lootingPercentage < 0 && (this.brain.data.idleData.lootingPercentage = 0),
                            void this.brain.changeState(P.Wandering);
                        this.setLootingTarget(n)
                    }
                }
                ,
                r.stateUpdate = function(i) {
                    var n, e, o;
                    t.prototype.stateUpdate.call(this, i);
                    var a = this.characterBlackboard.target;
                    if (this.brain.isCurrentTargetValid() && this.brain.isTargetInShootingRange(a))
                        return this.brain.setDirection(0, 0),
                        void this.brain.changeState(P.Attacking);
                    if (
                      // console.log(
                      // this.node.name + "  Looting: " + (null === (n = this.lootingTarget) || void 0 === n ? void 0 : n.name) + " isValidPickup " + (null === (e = this.lootingTarget) || void 0 === e ? void 0 : e.isValidPickup), g.AI
                      // ),
                    !(null === (o = this.lootingTarget) || void 0 === o ? void 0 : o.isValidPickup) && this.weaponSearchDelay <= 0 && (this.isLootingAChest ? (console.log(this.node.name + " Looting: Lotting chest finished, by me or someone else.", g.AI),
                    this.weaponSearchDelay = 30) : this.swapToIdleState()),
                    this.weaponSearchDelay > 0 && (this.weaponSearchDelay--,
                    this.weaponSearchDelay <= 0)) {
                        var s = this.findClosestWeaponPickup(!1);
                        // s || console.log(this.node.name + " Looting: Didn't found closest weapon.", g.AI, c.Warning),
                        (null == s ? void 0 : s.isValidPickup) && this.brain.isWeaponAnUpgrade(s) ? (console.log(this.node.name + " Looting: Closest weapon is good, gonna catch it.", g.AI),
                        this.setLootingTarget(s.node),
                        this.isLootingAChest = !1) : (console.log(this.node.name + " Looting: Closest weapon is not valid or not an upgrade.", g.AI),
                        this.swapToWanderState())
                    }
                    if (this.brain.reachedPathingDestination())
                        this.brain.setDirection(0, 0)
                        // console.log(this.node.name + " Looting: standing still.", g.AI);
                    else {
                        var r = this.brain.getPathingDirection();
                        this.brain.setDirection(r.x, r.y),
                        this.treasureCollectionWaitTime -= i,
                        this.treasureCollectionWaitTime <= 0 && this.swapToIdleState()
                    }
                }
                ,
                r.swapToIdleState = function() {
                    // console.log(this.node.name + " Looting: Going Idle.", g.AI),
                    this.brain.changeState(P.Idle)
                }
                ,
                r.swapToWanderState = function() {
                    console.log(this.node.name + " Looting: There is not time to waste! Going to wander directly.", g.AI),
                    this.brain.changeState(P.Wandering)
                }
                ,
                r.setLootingTarget = function(t) {
                    this.lootingTarget = t.getComponent(v),
                    this.lootingTarget ? this.treasureCollectionWaitTime = this.lootingTarget.CollectionTimer + .1 : this.treasureCollectionWaitTime = 5;
                    var i = u.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, t.worldPosition.x, t.worldPosition.z);
                    // console.log(this.node.name + " Looting: set loot target " + t.name + ", path: " + i, g.AI),
                    i.length > 0 ? this.brain.setActivePath(new d(t.worldPosition.x,t.worldPosition.z), i) : (this.brain.setDirection(0, 0),
                    this.aiBlackboard.currentPathingTarget = new d(t.worldPosition.x,t.worldPosition.z))
                }
                ,
                r.findClosestWeaponPickup = function(t) {
                    var i, n;
                    if (null == m.instance)
                        return null;
                    if (null == u.instance)
                        return null;
                    var e = 999
                      , a = null
                      , s = null
                      , r = null === (i = m.instance) || void 0 === i ? void 0 : i.pickupsInScene;
                    if (
                      // console.log(this.node.name + " Looting: Found " + r.length + " weapons in scene.", g.AI),
                    0 == r.length)
                        return null;
                    for (var l, d = o(r); !(l = d()).done; ) {
                        var f = l.value;
                        if (!t || this.brain.isWeaponAnUpgrade(f))
                            if (!u.instance.isPointInsideOfShrinkingArea(f.node.worldPosition.x, f.node.worldPosition.z)) {
                                var P = p.distance(this.node, f.node);
                                P < e && (e = P,
                                a = f.node,
                                s = f)
                            }
                    }
                    if (
                        // console.log(this.node.name + " Looting: Found closest weapon " + (null === (n = a) || void 0 === n ? void 0 : n.name) + " at " + e + " distance", g.AI),
                    a) {
                        var v = u.instance.getPath(this.node.worldPosition.x, this.node.worldPosition.z, a.worldPosition.x, a.worldPosition.z);
                        0 == v.length ? console.log(this.node.name + " Looting: Could not find path to " + a.name + ", hoping it is on this tile.", g.AI, c.Warning) : 0 == v.length && e > .6 && (console.log(this.node.name + " Looting: Could not find path to " + a.name + " and distance is " + e + ", this weapon is probably in a unreacheble tile, forget it.", g.AI, c.Warning),
                        s = null)
                    }
                    return s
                }
                ,
                a(s, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return this.brain.data.lootingData.minimumTimeInState
                    }
                }]),
                s
            }(f)) || I);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotAttackingData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./BotStateData.ts"], (function(e) {
    "use strict";
    var t, r, a, n, i, c, o;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            a = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            i = e.cclegacy,
            c = e._decorator
        }
        , function(e) {
            o = e.BotStateData
        }
        ],
        execute: function() {
            var l, s, u, p, g, f, b, d, y;
            i._RF.push({}, "d242bQQ/qRGPYn6KIF8Depa", "BotAttackingData", void 0);
            var D = c.ccclass
              , h = c.property;
            e("BotAttackingData", (l = D("BotAttackingData"),
            s = h({
                range: [0, 1],
                step: .05,
                slide: !0
            }),
            u = h({
                range: [0, 1],
                step: .05,
                slide: !0
            }),
            p = h({
                range: [0, 1],
                step: .05,
                slide: !0
            }),
            l((b = t((f = function(e) {
                function t() {
                    for (var t, r = arguments.length, i = new Array(r), c = 0; c < r; c++)
                        i[c] = arguments[c];
                    return t = e.call.apply(e, [this].concat(i)) || this,
                    a(n(t), "fleeingPercentage", b, n(t)),
                    a(n(t), "chasePercentage", d, n(t)),
                    a(n(t), "sideStepPercentage", y, n(t)),
                    t
                }
                return r(t, e),
                t
            }(o)).prototype, "fleeingPercentage", [s], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .1
                }
            }),
            d = t(f.prototype, "chasePercentage", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            y = t(f.prototype, "sideStepPercentage", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .1
                }
            }),
            g = f)) || g));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CheatMatchLevelUp.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./CharacterLevelControl.ts"], (function(e) {
    "use strict";
    var t, r, n, a, o, c, i, l, s, h;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            n = e.initializerDefineProperty,
            a = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            c = e._decorator,
            i = e.macro,
            l = e.Component
        }
        , function(e) {
            s = e.EventCharacterAction
        }
        , function(e) {
            h = e.CharacterLevelControl
        }
        ],
        execute: function() {
            var p, u, v, C, f;
            o._RF.push({}, "d4071fTm1FI8ZFSGBIA5C67", "CheatMatchLevelUp", void 0);
            var L = c.ccclass
              , y = c.property;
            e("CheatMatchLevelUp", (p = L("CheatMatchLevelUp"),
            u = y(h),
            p((f = t((C = function(e) {
                function t() {
                    for (var t, r = arguments.length, o = new Array(r), c = 0; c < r; c++)
                        o[c] = arguments[c];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    n(a(t), "characterToLevelUp", f, a(t)),
                    t
                }
                r(t, e);
                var o = t.prototype;
                return o.onEnable = function() {}
                ,
                o.onDisable = function() {}
                ,
                o.onCheatKeyDown = function(e) {
                    e.keyCode == i.KEY.l && null != this.characterToLevelUp && this.characterToLevelUp.node.emit(s.CollectedChest)
                }
                ,
                t
            }(l)).prototype, "characterToLevelUp", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = C)) || v));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RewardedAdAfterMatch.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./RewardedAdOpportunitySaveData.ts", "./GlobalPlayer.ts", "./Panel.ts", "./CurrencyRewardWidget.ts", "./RewardedAdEnums.ts", "./RewardedAdOportunity.ts"], (function(e) {
    "use strict";
    var t, r, n, d, a, i, o, l, s, c, u, p, h, w, f, y, g, A, R, m, b;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            n = e.initializerDefineProperty,
            d = e.assertThisInitialized,
            a = e.defineProperty
        }
        , function(e) {
            i = e.cclegacy,
            o = e._decorator,
            l = e.Label,
            s = e.Prefab,
            c = e.Component
        }
        , function(e) {
            u = e.logger,
            p = e.LogCategory,
            h = e.LogType
        }
        , function(e) {
            w = e.ProjectEventType
        }
        , function(e) {
            f = e.projectEvent
        }
        , function(e) {
            y = e.RewardedAdAfterMatchData
        }
        , function(e) {
            g = e.globalPlayer
        }
        , function(e) {
            A = e.Panel
        }
        , function(e) {
            R = e.CurrencyRewardWidget
        }
        , function(e) {
            m = e.EventRewardedAd
        }
        , function(e) {
            b = e.RewardedAdOportunity
        }
        ],
        execute: function() {
            var P, v, C, M, B, F, D, z, E, L, O;
            i._RF.push({}, "d58ecx+zIlN7pAuvGyBB60f", "RewardedAdAfterMatch", void 0);
            var j = o.ccclass
              , x = o.property;
            e("RewardedAdAfterMatch", (P = j("RewardedAdAfterMatch"),
            v = x(A),
            C = x(b),
            M = x(l),
            B = x(s),
            P((z = t((D = function(e) {
                function t() {
                    for (var t, r = arguments.length, i = new Array(r), o = 0; o < r; o++)
                        i[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(i)) || this,
                    n(d(t), "panel", z, d(t)),
                    n(d(t), "rewardedAdOpportunity", E, d(t)),
                    n(d(t), "lBonus", L, d(t)),
                    n(d(t), "widgetCurrencyReward", O, d(t)),
                    a(d(t), "placement", 0),
                    t
                }
                r(t, e);
                var i = t.prototype;
                return i.onLoad = function() {
                    console.log("RewardedAdAfterMatch onload", p.RewardedAd),
                    f.on(w.MatchFinish, this.onMatchFinish, this),
                    f.on(m.Completed, this.onAdComplete, this)
                }
                ,
                i.onDestroy = function() {
                    f.off(w.MatchFinish, this.onMatchFinish, this),
                    f.off(m.Completed, this.onAdComplete, this)
                }
                ,
                i.onMatchFinish = function(e) {
                    this.placement = e
                }
                ,
                i.checkEligibility = function() {
                    this.rewardedAdOpportunity ? (console.log("Finished " + this.placement + ", checking rewarded ad eligibility", p.RewardedAd),
                    y.matchsPlayedInCurrentSession >= 1 ? this.placement > 1 ? g.hasAfterMatchRewardedAd() ? (this.lBonus.string = "+" + g.getDailyRewardedAdBonus().toFixed(),
                    console.log("Rewarded ad bonus configured as: " + this.lBonus.string, p.RewardedAd),
                    console.log("Internally eligible, setting up GameSnacks.", p.RewardedAd),
                    this.rewardedAdOpportunity.setup()) : console.log("Player already reached max claims for today.", p.RewardedAd) : console.log("Player finished first, no rewarded ad for you.", p.RewardedAd) : (console.log("Played first match of the session, next may be eligible for rewarded ad.", p.RewardedAd),
                    y.matchsPlayedInCurrentSession++)) : console.log("Not configured rewarded ad opportunity in : " + this.node.name, p.RewardedAd, h.Error)
                }
                ,
                i.onAdComplete = function() {
                    console.log("Rewarded ad complete, giving reward.", p.RewardedAd);
                    var e = g.claimAfterMatchRewardedAd();
                    console.log("Ad complete, result: " + e, p.RewardedAd),
                    e && (g.save(),
                    this.widgetCurrencyReward && R.spawn(this.widgetCurrencyReward, g.getDailyRewardedAdBonus(), this.node.worldPosition, !1))
                }
                ,
                t
            }(c)).prototype, "panel", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = t(D.prototype, "rewardedAdOpportunity", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = t(D.prototype, "lBonus", [M], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            O = t(D.prototype, "widgetCurrencyReward", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            F = D)) || F));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIMetagameLevelUpSFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./AudioManager.ts"], (function(e) {
    "use strict";
    var t, n, a, i, o, r, l, s, c, p, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            a = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            r = e._decorator,
            l = e.Prefab,
            s = e.Component
        }
        , function(e) {
            c = e.UIEventType
        }
        , function(e) {
            p = e.projectEvent
        }
        , function(e) {
            u = e.AudioManager
        }
        ],
        execute: function() {
            var v, f, y, g, U;
            o._RF.push({}, "d7d6dvqHT1AIrNAhSrsVt+U", "UIMetagameLevelUpSFX", void 0);
            var h = r.ccclass
              , m = r.property;
            e("UIMetagameLevelUpSFX", (v = h("UIMetagameLevelUpSFX"),
            f = m(l),
            v((U = t((g = function(e) {
                function t() {
                    for (var t, n = arguments.length, o = new Array(n), r = 0; r < n; r++)
                        o[r] = arguments[r];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    a(i(t), "key", U, i(t)),
                    t
                }
                n(t, e);
                var o = t.prototype;
                return o.onEnable = function() {
                    p.on(c.MetagameLevelUp, this.onMetagameLevelUp, this)
                }
                ,
                o.onDisable = function() {
                    p.off(c.MetagameLevelUp, this.onMetagameLevelUp, this)
                }
                ,
                o.onMetagameLevelUp = function() {
                    var e;
                    this.key && (null === (e = u.instance) || void 0 === e || e.playByKey(this.key))
                }
                ,
                t
            }(s)).prototype, "key", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = g)) || y));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TutorialStepWeaponPickup.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./TutorialVolume.ts"], (function(t) {
    "use strict";
    var e, o, n, a, i, r, l, s;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            o = t.defineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            a = t.cclegacy,
            i = t._decorator
        }
        , function(t) {
            r = t.ProjectEventType
        }
        , function(t) {
            l = t.projectEvent
        }
        , function(t) {
            s = t.TutorialVolume
        }
        ],
        execute: function() {
            var c;
            a._RF.push({}, "d9529HxDwlN66KJRIUh7f+v", "TutorialStepWeaponPickup", void 0);
            var h = i.ccclass;
            i.property,
            t("TutorialStepWeaponPickup", h("TutorialStepWeaponPickup")(c = function(t) {
                function a() {
                    for (var e, a = arguments.length, i = new Array(a), r = 0; r < a; r++)
                        i[r] = arguments[r];
                    return e = t.call.apply(t, [this].concat(i)) || this,
                    o(n(e), "shouldShow", !1),
                    e
                }
                e(a, t);
                var i = a.prototype;
                return i.onEnable = function() {
                    l.on(r.PlayerCollectedChest, this.onPlayerCollectedChest, this),
                    l.on(r.PlayerWeaponChange, this.onPlayerWeaponChange, this)
                }
                ,
                i.onDisable = function() {
                    l.off(r.PlayerCollectedChest, this.onPlayerCollectedChest, this),
                    l.off(r.PlayerWeaponChange, this.onPlayerWeaponChange, this)
                }
                ,
                i.playerEntered = function() {
                    this.shouldShow && this.activate()
                }
                ,
                i.onPlayerCollectedChest = function() {
                    this.shouldShow = !0,
                    this.activate()
                }
                ,
                i.onPlayerWeaponChange = function() {
                    this.shouldShow = !1,
                    this.deactivate()
                }
                ,
                a
            }(s)) || c);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletExplosion.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./CharacterEnums.ts"], (function(e) {
    "use strict";
    var o, t, n, r, l, i, a, s, u, c, d, g;
    return {
        setters: [function(e) {
            o = e.inheritsLoose,
            t = e.defineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            r = e.cclegacy,
            l = e._decorator,
            i = e.SphereCollider,
            a = e.Component
        }
        , function(e) {
            s = e.logger,
            u = e.LogCategory
        }
        , function(e) {
            c = e.OnTrigger,
            d = e.PHY_GROUP
        }
        , function(e) {
            g = e.EventCharacterAction
        }
        ],
        execute: function() {
            var h;
            r._RF.push({}, "d9e3et4xNRGUp8GL48z9hZc", "BulletExplosion", void 0);
            var p = l.ccclass;
            l.property,
            e("BulletExplosion", p("BulletExplosion")(h = function(e) {
                function r() {
                    for (var o, r = arguments.length, l = new Array(r), i = 0; i < r; i++)
                        l[i] = arguments[i];
                    return o = e.call.apply(e, [this].concat(l)) || this,
                    t(n(o), "damage", 230),
                    t(n(o), "owner", void 0),
                    o
                }
                o(r, e);
                var l = r.prototype;
                return l.setup = function(e, o) {
                    this.owner = e,
                    this.damage = o,
                    console.log("BulletBazooka - BulletExplosion setup - owner: " + (null == e ? void 0 : e.name) + " dmg: " + o, u.Gameplay)
                }
                ,
                l.onLoad = function() {
                    var e = this.node.getComponent(i);
                    e && e.on(c.Enter, this.onTriggerEnter, this)
                }
                ,
                l.onTriggerEnter = function(e) {
                    var o;
                    (console.log("BulletBazooka - " + e.otherCollider.name + " entered the trigger"),
                    null != e.otherCollider && e.otherCollider.node.isValid) && (e.otherCollider.getGroup() == d.PLAYER && (e.otherCollider.node.children[0].emit(g.HitReceived, this.damage, null === (o = this.owner) || void 0 === o ? void 0 : o.children[0]),
                    console.log("BulletBazooka - BulletExplosion hit: " + e.otherCollider.node.name + " - dmg: " + this.damage, u.Gameplay)))
                }
                ,
                r
            }(a)) || h);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TutorialStepChest.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./TutorialVolume.ts"], (function(t) {
    "use strict";
    var e, o, n, r, s, i, l, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            o = t.defineProperty,
            n = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator
        }
        , function(t) {
            i = t.ProjectEventType
        }
        , function(t) {
            l = t.projectEvent
        }
        , function(t) {
            c = t.TutorialVolume
        }
        ],
        execute: function() {
            var a;
            r._RF.push({}, "db976RBUENCgaji5mKM7tkf", "TutorialStepChest", void 0);
            var u = s.ccclass;
            s.property,
            t("TutorialStepChest", u("TutorialStepChest")(a = function(t) {
                function r() {
                    for (var e, r = arguments.length, s = new Array(r), i = 0; i < r; i++)
                        s[i] = arguments[i];
                    return e = t.call.apply(t, [this].concat(s)) || this,
                    o(n(e), "shouldShow", !0),
                    e
                }
                e(r, t);
                var s = r.prototype;
                return s.onEnable = function() {
                    l.on(i.PlayerCollectedChest, this.onPlayerCollectedChest, this)
                }
                ,
                s.onDisable = function() {
                    l.off(i.PlayerCollectedChest, this.onPlayerCollectedChest, this)
                }
                ,
                s.playerEntered = function() {
                    this.shouldShow && this.activate()
                }
                ,
                s.onPlayerCollectedChest = function() {
                    this.shouldShow = !1,
                    this.deactivate()
                }
                ,
                r
            }(c)) || a);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BotChasingData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./BotStateData.ts"], (function(t) {
    "use strict";
    var e, a, n, r, i, o, s, c;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            a = t.inheritsLoose,
            n = t.initializerDefineProperty,
            r = t.assertThisInitialized
        }
        , function(t) {
            i = t.cclegacy,
            o = t._decorator,
            s = t.CCInteger
        }
        , function(t) {
            c = t.BotStateData
        }
        ],
        execute: function() {
            var l, u, p, h, g, f;
            i._RF.push({}, "dc2a2JVRRNFgqXFgyVBpq4a", "BotChasingData", void 0);
            var d = o.ccclass
              , y = o.property;
            t("BotChasingData", (l = d("BotChasingData"),
            u = y({
                type: s,
                tooltip: "Interval on which to search for a new updated path",
                unit: "frames"
            }),
            l((g = e((h = function(t) {
                function e() {
                    for (var e, a = arguments.length, i = new Array(a), o = 0; o < a; o++)
                        i[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(i)) || this,
                    n(r(e), "pathingUpdateInterval", g, r(e)),
                    n(r(e), "shouldChaseIntoShrinkingArea", f, r(e)),
                    e
                }
                return a(e, t),
                e
            }(c)).prototype, "pathingUpdateInterval", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 30
                }
            }),
            f = e(h.prototype, "shouldChaseIntoShrinkingArea", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            p = h)) || p));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayAnimationAfterDelay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, i, n, a, r, l, o, c;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            a = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            l = t._decorator,
            o = t.Animation,
            c = t.Component
        }
        ],
        execute: function() {
            var u, p, s, y, f, m;
            r._RF.push({}, "dd3b054MgtJ+Ktdb9KIIvdj", "PlayAnimationAfterDelay", void 0);
            var d = l.ccclass
              , h = l.property;
            t("PlayAnimationAfterDelay", (u = d("PlayAnimationAfterDelay"),
            p = h({
                tooltip: "If left empty default clip will be played"
            }),
            u((f = e((y = function(t) {
                function e() {
                    for (var e, i = arguments.length, r = new Array(i), l = 0; l < i; l++)
                        r[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(r)) || this,
                    n(a(e), "animationName", f, a(e)),
                    n(a(e), "delay", m, a(e)),
                    e
                }
                i(e, t);
                var r = e.prototype;
                return r.start = function() {
                    this.scheduleOnce(this.playAnim, this.delay)
                }
                ,
                r.playAnim = function() {
                    var t = this.node.getComponent(o);
                    null != t && null != t.defaultClip && t.play(this.animationName)
                }
                ,
                e
            }(c)).prototype, "animationName", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            m = e(y.prototype, "delay", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            s = y)) || s));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TweenBase.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenEnums.ts"], (function(e) {
    "use strict";
    var t, n, i, r, o, a, s, u, l, c, p, f, b;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            i = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            o = e.defineProperty
        }
        , function(e) {
            a = e.cclegacy,
            s = e._decorator,
            u = e.Node,
            l = e.Enum,
            c = e.CCBoolean,
            p = e.EventHandler,
            f = e.Component
        }
        , function(e) {
            b = e.TweenEasing
        }
        ],
        execute: function() {
            var h, d, y, m, g, v, w, C, z, S, T, R, V, B, E, _, j, D, I;
            a._RF.push({}, "dd4cdrVIG5OaIfVTAjX8scj", "TweenBase", void 0);
            var L = s.ccclass
              , O = s.property;
            e("TweenBase", (h = L("TweenBase"),
            d = O(u),
            y = O({
                min: 0,
                unit: "sec"
            }),
            m = O({
                min: 0,
                unit: "sec"
            }),
            g = O({
                type: l(b)
            }),
            v = O(c),
            w = O(c),
            C = O({
                type: [p],
                displayOrder: 20
            }),
            z = O({
                type: [p],
                displayOrder: 20
            }),
            h((R = t((T = function(e) {
                function t() {
                    for (var t, n = arguments.length, a = new Array(n), s = 0; s < n; s++)
                        a[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    i(r(t), "target", R, r(t)),
                    i(r(t), "delay", V, r(t)),
                    i(r(t), "duration", B, r(t)),
                    i(r(t), "easing", E, r(t)),
                    i(r(t), "useCustomStartValue", _, r(t)),
                    i(r(t), "useRelativeValue", j, r(t)),
                    i(r(t), "onStart", D, r(t)),
                    i(r(t), "onComplete", I, r(t)),
                    o(r(t), "tweenCache", void 0),
                    o(r(t), "tweenReverseCache", void 0),
                    o(r(t), "options", {}),
                    t
                }
                n(t, e);
                var a = t.prototype;
                return a.onLoad = function() {
                    var e = this;
                    this.target || (this.target = this.node),
                    this.options.onStart = function(t) {
                        p.emitEvents(e.onStart, t)
                    }
                    .bind(this),
                    this.options.onComplete = function(t) {
                        p.emitEvents(e.onComplete, t)
                    }
                    .bind(this),
                    this.options.easing = b[this.easing]
                }
                ,
                a.play = function() {
                    this.useCustomStartValue && this.reset(),
                    this.tweenCache.start()
                }
                ,
                a.reset = function() {}
                ,
                a.playReverse = function() {
                    var e;
                    null === (e = this.tweenReverseCache) || void 0 === e || e.start()
                }
                ,
                a.stop = function() {
                    this.tweenCache.stop()
                }
                ,
                t
            }(f)).prototype, "target", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            V = t(T.prototype, "delay", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            B = t(T.prototype, "duration", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1
                }
            }),
            E = t(T.prototype, "easing", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return b.linear
                }
            }),
            _ = t(T.prototype, "useCustomStartValue", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            j = t(T.prototype, "useRelativeValue", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            D = t(T.prototype, "onStart", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            I = t(T.prototype, "onComplete", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            S = T)) || S));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PanelManager.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(n) {
    "use strict";
    var e, t, r, a, s, i, o, c;
    return {
        setters: [function(n) {
            e = n.defineProperty,
            t = n.inheritsLoose,
            r = n.assertThisInitialized,
            a = n.asyncToGenerator
        }
        , function(n) {
            s = n.cclegacy,
            i = n._decorator,
            o = n.Component
        }
        , function(n) {
            c = n.logger
        }
        ],
        execute: function() {
            var u, l, p;
            s._RF.push({}, "dd60fb0cwVANrUPb0SN5V4w", "PanelManager", void 0);
            var f = i.ccclass
              , h = (i.property,
            i.executionOrder);
            n("PanelManager", f("PanelManager")(u = h(-5)((p = l = function(n) {
                function s() {
                    for (var t, a = arguments.length, s = new Array(a), i = 0; i < a; i++)
                        s[i] = arguments[i];
                    return t = n.call.apply(n, [this].concat(s)) || this,
                    e(r(t), "panels", new Map),
                    t
                }
                t(s, n);
                var i = s.prototype;
                return i.onLoad = function() {
                    null == s.instance && (s.instance = this)
                }
                ,
                i.onDestroy = function() {
                    s.instance == this && (s.instance = null)
                }
                ,
                i.register = function(n) {
                    this.panels.set(n.Id, n)
                }
                ,
                i.open = function(n) {
                    //xz 界面管理工具

                    var e;
                    this.panels && (this.panels.has(n) ? null === (e = this.panels.get(n)) || void 0 === e || e.open(n) :console.log("Could not find panel: " + n))
                }
                ,
                i.openAsync = function() {
                    var n = a(regeneratorRuntime.mark((function n(e) {
                        var t;
                        return regeneratorRuntime.wrap((function(n) {
                            for (; ; )
                                switch (n.prev = n.next) {
                                case 0:
                                    if (this.panels) {
                                        n.next = 2;
                                        break
                                    }
                                    return n.abrupt("return");
                                case 2:
                                    if (!this.panels.has(e)) {
                                        n.next = 10;
                                        break
                                    }
                                    if (!(t = this.panels.get(e))) {
                                        n.next = 8;
                                        break
                                    }
                                    return t.open(),
                                    n.next = 8,
                                    this.delay(t.DurationOpen);
                                case 8:
                                    n.next = 11;
                                    break;
                                case 10:
                                   console.log("Could not find panel: " + e);
                                case 11:
                                case "end":
                                    return n.stop()
                                }
                        }
                        ), n, this)
                    }
                    )));
                    return function(e) {
                        return n.apply(this, arguments)
                    }
                }(),
                i.close = function(n) {
                    var e;
                    null === (e = this.panels.get(n)) || void 0 === e || e.close(n)
                }
                ,
                i.delay = function(n) {
                    return new Promise((function(e) {
                        return setTimeout(e, 1e3 * n)
                    }
                    ))
                }
                ,
                s
            }(o),
            e(l, "instance", void 0),
            u = p)) || u) || u);
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/Note.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, r, i, n, o, c, a;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            i = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            c = e._decorator,
            a = e.Component
        }
        ],
        execute: function() {
            var l, u, s, p, f;
            o._RF.push({}, "dd6cd2D7YtHqLiXyXAeROu7", "Note", void 0);
            var y = c.ccclass
              , d = c.property;
            e("Note", (l = y("Note"),
            u = d({
                multiline: !0,
                editorOnly: !0
            }),
            l((f = t((p = function(e) {
                function t() {
                    for (var t, r = arguments.length, o = new Array(r), c = 0; c < r; c++)
                        o[c] = arguments[c];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    i(n(t), "note", f, n(t)),
                    t
                }
                return r(t, e),
                t
            }(a)).prototype, "note", [u], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            s = p)) || s));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIMatchStart.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./TweenCollection.ts", "./PanelManager.ts", "./PanelEnums.ts"], (function(t) {
    "use strict";
    var e, i, n, r, a, o, s, l, c, h, u, m, p, f, g, T, d;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            i = t.inheritsLoose,
            n = t.initializerDefineProperty,
            r = t.assertThisInitialized,
            a = t.defineProperty
        }
        , function(t) {
            o = t.cclegacy,
            s = t._decorator,
            l = t.Label,
            c = t.ProgressBar,
            h = t.Component
        }
        , function(t) {
            u = t.logger
        }
        , function(t) {
            m = t.ProjectEventType
        }
        , function(t) {
            p = t.projectEvent
        }
        , function(t) {
            f = t.TweenCollection
        }
        , function(t) {
            g = t.PanelManager
        }
        , function(t) {
            T = t.EventPanel,
            d = t.PanelId
        }
        ],
        execute: function() {
            var S, v, b, y, M, P, F, w, I;
            o._RF.push({}, "ddb3bBmpuJEaYNHBFFYg5mL", "UIMatchStart", void 0);
            var C = s.ccclass
              , E = s.property;
            t("UIMatchStart", (S = C("UIMatchStart"),
            v = E(l),
            b = E(c),
            y = E(f),
            S((F = e((P = function(t) {
                function e() {
                    for (var e, i = arguments.length, o = new Array(i), s = 0; s < i; s++)
                        o[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    n(r(e), "lTimer", F, r(e)),
                    n(r(e), "pgTimer", w, r(e)),
                    n(r(e), "tweenTimerChanged", I, r(e)),
                    a(r(e), "timeToStart", -1),
                    a(r(e), "timer", -1),
                    a(r(e), "lastTimerInteger", -1),
                    e
                }
                i(e, t);
                var o = e.prototype;
                return o.onEnable = function() {
                    this.node.on(T.OpenFinish, this.onPanelOpenFinish, this),
                    p.on(m.MatchTimerStart, this.onMatchTimerStart, this)
                }
                ,
                o.onDisable = function() {
                    this.node.off(T.OpenFinish, this.onPanelOpenFinish, this),
                    p.off(m.MatchTimerStart, this.onMatchTimerStart, this)
                }
                ,
                o.onPanelOpenFinish = function() {}
                ,
                o.onMatchTimerStart = function(t) {
                    var e;
                    console.log("Received " + t + " as match start delay"),
                    this.timeToStart = t,
                    this.timer = 0,
                    null === (e = g.instance) || void 0 === e || e.open(d.MatchStart)
                }
                ,
                o.update = function(t) {
                    if (-1 != this.timer && -1 != this.timeToStart) {
                        this.timer += t,
                        this.pgTimer.progress = 1 - this.timer / this.timeToStart;
                        var e, i, n = Math.ceil(this.timeToStart - this.timer);
                        if (this.lastTimerInteger != n)
                            this.lastTimerInteger = n,
                            this.lTimer.string = n.toFixed(),
                            null === (e = this.tweenTimerChanged) || void 0 === e || e.play();
                        if (this.timer >= this.timeToStart)
                            this.timer = -1,
                            null === (i = g.instance) || void 0 === i || i.close(d.MatchStart)
                    }
                }
                ,
                e
            }(h)).prototype, "lTimer", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            w = e(P.prototype, "pgTimer", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            I = e(P.prototype, "tweenTimerChanged", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = P)) || M));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RewardedAdDaily.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./CurrencyRewardWidget.ts", "./RewardedAdEnums.ts", "./RewardedAdOportunity.ts"], (function(e) {
    "use strict";
    var r, t, d, n, i, o, a, l, u, s, c, p, w, y, g, A, R;
    return {
        setters: [function(e) {
            r = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            d = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            i = e.cclegacy,
            o = e._decorator,
            a = e.Label,
            l = e.Prefab,
            u = e.Component
        }
        , function(e) {
            s = e.logger,
            c = e.LogCategory,
            p = e.LogType
        }
        , function(e) {
            w = e.projectEvent
        }
        , function(e) {
            y = e.globalPlayer
        }
        , function(e) {
            g = e.CurrencyRewardWidget
        }
        , function(e) {
            A = e.EventRewardedAd
        }
        , function(e) {
            R = e.RewardedAdOportunity
        }
        ],
        execute: function() {
            var f, h, m, b, v, C, D, E, L;
            i._RF.push({}, "deadbWSlcpDGZ71FoVELKzE", "RewardedAdDaily", void 0);
            var O = o.ccclass
              , P = o.property;
            o.requireComponent,
            e("RewardedAdDaily", (f = O("RewardedAdDaily"),
            h = P(R),
            m = P(a),
            b = P(l),
            f((D = r((C = function(e) {
                function r() {
                    for (var r, t = arguments.length, i = new Array(t), o = 0; o < t; o++)
                        i[o] = arguments[o];
                    return r = e.call.apply(e, [this].concat(i)) || this,
                    d(n(r), "rewardedAdOpportunity", D, n(r)),
                    d(n(r), "lBonus", E, n(r)),
                    d(n(r), "widgetCurrencyReward", L, n(r)),
                    r
                }
                t(r, e);
                var i = r.prototype;
                return i.start = function() {
                    this.rewardedAdOpportunity ? y.hasDailyRewardedAd() ? (console.log("Has daily rewarded Ad : " + this.node.name, c.RewardedAd),
                    this.rewardedAdOpportunity.setup(),
                    this.lBonus.string = "+" + y.getDailyRewardedAdBonus().toFixed()) : (console.log("Don't have daily rewarded Ad : " + this.node.name, c.RewardedAd),
                    this.rewardedAdOpportunity.node.active = !1) : console.log("Not configured rewarded ad opportunity in : " + this.node.name, c.RewardedAd, p.Error)
                }
                ,
                i.onEnable = function() {
                    w.on(A.Completed, this.onAdComplete, this)
                }
                ,
                i.onDisable = function() {
                    w.off(A.Completed, this.onAdComplete, this)
                }
                ,
                i.onAdComplete = function() {
                    console.log("Rewarded ad complete, giving reward.", c.RewardedAd);
                    var e = y.claimDailyRewardedAd();
                    console.log("Ad complete, result: " + e, c.RewardedAd),
                    e && (y.save(),
                    this.widgetCurrencyReward && g.spawn(this.widgetCurrencyReward, y.getDailyRewardedAdBonus(), this.node.worldPosition, !0))
                }
                ,
                r
            }(u)).prototype, "rewardedAdOpportunity", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = r(C.prototype, "lBonus", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            L = r(C.prototype, "widgetCurrencyReward", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = C)) || v));
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuArenaUnlockPanel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts"], (function(e) {
    "use strict";
    var n, t, r, i, a, o, l, c, s, u, p, b, f, h, g, y, P;
    return {
        setters: [function(e) {
            n = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            r = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            a = e.defineProperty
        }
        , function(e) {
            o = e.cclegacy,
            l = e._decorator,
            c = e.Label,
            s = e.Sprite,
            u = e.Button,
            p = e.Component
        }
        , function(e) {
            b = e.logger,
            f = e.LogCategory,
            h = e.LogType
        }
        , function(e) {
            g = e.UIEventType
        }
        , function(e) {
            y = e.projectEvent
        }
        , function(e) {
            P = e.globalPlayer
        }
        ],
        execute: function() {
            var d, m, v, L, C, A, M, U, z, k, w, B, D;
            o._RF.push({}, "dfa30yKvxtIGYUpP/Qedxs8", "MainMenuArenaUnlockPanel", void 0);
            var E = l.ccclass
              , I = l.property;
            e("MainMenuArenaUnlockPanel", (d = E("MainMenuArenaUnlockPanel"),
            m = I(c),
            v = I(c),
            L = I(s),
            C = I(c),
            A = I(u),
            d((z = n((U = function(e) {
                function n() {
                    for (var n, t = arguments.length, o = new Array(t), l = 0; l < t; l++)
                        o[l] = arguments[l];
                    return n = e.call.apply(e, [this].concat(o)) || this,
                    r(i(n), "nameLabel", z, i(n)),
                    r(i(n), "descriptionLabel", k, i(n)),
                    r(i(n), "icon", w, i(n)),
                    r(i(n), "upgradeCost", B, i(n)),
                    r(i(n), "purchaseButton", D, i(n)),
                    a(i(n), "arena", void 0),
                    n
                }
                t(n, e);
                var o = n.prototype;
                return o.onEnable = function() {
                    y.on(g.ArenaPurchaseConfirmation, this.setup, this)
                }
                ,
                o.onDisable = function() {
                    y.off(g.ArenaPurchaseConfirmation, this.setup, this)
                }
                ,
                o.setup = function(e) {
                    e ? (this.nameLabel.string = e.Name,
                    this.descriptionLabel.string = e.Description,
                    this.upgradeCost.string = e.UnlockCost.toFixed(),
                    this.icon.spriteFrame = e.Icon,
                    this.purchaseButton.interactable = P.canPurchaseArena(e),
                    this.arena = e) :console.log("Null arena", f.UI, h.Error)
                }
                ,
                o.onPurchaseConfirmation = function() {
                    y.emit(g.ArenaPurchaseSucccess, this.arena)
                }
                ,
                n
            }(p)).prototype, "nameLabel", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            k = n(U.prototype, "descriptionLabel", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            w = n(U.prototype, "icon", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            B = n(U.prototype, "upgradeCost", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            D = n(U.prototype, "purchaseButton", [A], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            M = U)) || M));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayerStatisticsHook.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./GlobalPlayer.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var e, a, s, i, o, n, r, l, d, c, h, u;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            a = t.defineProperty,
            s = t.assertThisInitialized,
            i = t.createForOfIteratorHelperLoose
        }
        , function(t) {
            o = t.cclegacy,
            n = t._decorator,
            r = t.Component
        }
        , function(t) {
            l = t.logger
        }
        , function(t) {
            d = t.Statistic,
            c = t.globalPlayer
        }
        , function(t) {
            h = t.EventCharacterAction
        }
        , function(t) {
            u = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var f;
            o._RF.push({}, "dff6fOQEslIw50Y3p1Jyhdu", "PlayerStatisticsHook", void 0);
            var p = n.ccclass;
            n.property,
            t("PlayerStatisticsHook", p("PlayerStatisticsHook")(f = function(t) {
                function o() {
                    for (var e, i = arguments.length, o = new Array(i), n = 0; n < i; n++)
                        o[n] = arguments[n];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    a(s(e), "data", void 0),
                    e
                }
                e(o, t);
                var n = o.prototype;
                return n.onLoad = function() {
                    this.data = this.getComponentInChildren(u)
                }
                ,
                n.onEnable = function() {
                    this.data && (this.data.node.on(h.CollectedChest, this.onCollectedChest, this),
                    this.data.node.on(h.KilledOther, this.onKilledOther, this),
                    this.data.node.on(h.LevelUp, this.onLevelUp, this),
                    this.data.node.on(h.DealtDamage, this.onDealtDamage, this))
                }
                ,
                n.onDisable = function() {
                    this.data && (this.data.node.off(h.CollectedChest, this.onCollectedChest, this),
                    this.data.node.off(h.KilledOther, this.onKilledOther, this),
                    this.data.node.off(h.LevelUp, this.onLevelUp, this),
                    this.data.node.off(h.DealtDamage, this.onDealtDamage, this))
                }
                ,
                n.start = function() {
                  //xz 杀敌管理
                    d.resetCurrent(c.statistics.chestsOpened),
                    d.resetCurrent(c.statistics.inMatchLevel),
                    d.resetCurrent(c.statistics.enemyKilledTotal),
                    d.resetCurrent(c.statistics.damageDealtTotal);
                    for (var t, e = i(c.statistics.enemyKilled); !(t = e()).done; ) {
                        var a = t.value
                          , s = (a[0],
                        a[1]);
                        d.resetCurrent(s)
                    }
                    for (var o, n = i(c.statistics.damageDealt); !(o = n()).done; ) {
                        var r = o.value
                          , l = (r[0],
                        r[1]);
                        d.resetCurrent(l)
                    }
                }
                ,
                n.onCollectedChest = function() {
                    d.add(c.statistics.chestsOpened, 1)
                }
                ,
                n.onKilledOther = function() {
                    if (this.data) {
                        d.add(c.statistics.enemyKilledTotal, 1);
                        var t = c.statistics.enemyKilled.get(this.data.currentWeapon);
                        t ? d.add(t, 1) : console.log("Could not find statistic for weapon " + this.data.currentWeapon)
                    }
                }
                ,
                n.onLevelUp = function(t) {
                    d.set(c.statistics.inMatchLevel, t)
                }
                ,
                n.onDealtDamage = function(t) {
                    if (this.data) {
                        d.add(c.statistics.damageDealtTotal, t);
                        var e = c.statistics.damageDealt.get(this.data.currentWeapon);
                        e ? d.add(e, t) : console.log("Could not find statistic for damage " + this.data.currentWeapon)
                    }
                }
                ,
                o
            }(r)) || f);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterUISetup.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts", "./CanvasGameplay.ts", "./CharacterUI.ts"], (function(t) {
    "use strict";
    var n, a, e, i, r, s, o, c, u, l, h, p, f, I;
    return {
        setters: [function(t) {
            n = t.applyDecoratedDescriptor,
            a = t.inheritsLoose,
            e = t.initializerDefineProperty,
            i = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator,
            o = t.Prefab,
            c = t.instantiate,
            u = t.Component
        }
        , function(t) {
            l = t.logger
        }
        , function(t) {
            h = t.EventCharacterAction
        }
        , function(t) {
            p = t.CharacterBlackboard
        }
        , function(t) {
            f = t.CanvasGameplay
        }
        , function(t) {
            I = t.CharacterUI
        }
        ],
        execute: function() {
            var d, y, g, v, C;
            r._RF.push({}, "e06bdD//9tIYYvCKX3kOSWr", "CharacterUISetup", void 0);
            var b = s.ccclass
              , S = s.property;
            t("CharacterUISetup", (d = b("CharacterUISetup"),
            y = S(o),
            d((C = n((v = function(t) {
                function n() {
                    for (var n, a = arguments.length, r = new Array(a), s = 0; s < a; s++)
                        r[s] = arguments[s];
                    return n = t.call.apply(t, [this].concat(r)) || this,
                    e(i(n), "prefabUI", C, i(n)),
                    n
                }
                a(n, t);
                var r = n.prototype;
                return r.start = function() {
                    if (null != f.instance && (this.data = this.node.getComponent(p),
                    this.data)) {
                        var t = f.instance.canvas;
                        if (!t)
                            return void console.log("Canvas is null");
                        if (this.uiInstance = c(this.prefabUI),
                        this.uiInstance) {
                            this.uiInstance.setParent(t.node);
                            var n = this.uiInstance.getComponent(I);
                            null == n || n.setup(this.data),
                            this.uiInstance.setSiblingIndex(0)
                        }
                    }
                }
                ,
                r.onEnable = function() {
                    this.node.on(h.DyingStart, this.onDyingStart, this)
                }
                ,
                r.onDisable = function() {
                    this.node.off(h.DyingStart, this.onDyingStart, this)
                }
                ,
                r.onDyingStart = function() {
                    var t;
                    this.uiInstance && this.uiInstance.isValid && (null === (t = this.uiInstance) || void 0 === t || t.destroy())
                }
                ,
                r.onDestroy = function() {
                    this.uiInstance && this.uiInstance.isValid && this.uiInstance.destroy()
                }
                ,
                n
            }(u)).prototype, "prefabUI", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            g = v)) || g));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RewardedAdEnums.ts", ["cc"], (function(e) {
    "use strict";
    var d;
    return {
        setters: [function(e) {
            d = e.cclegacy
        }
        ],
        execute: function() {
            var r;
            e("EventRewardedAd", void 0),
            d._RF.push({}, "e1d7cV/5qNDlanVv7KnBOio", "RewardedAdEnums", void 0),
            function(e) {
                e.Completed = "rewarded-ad-completed",
                e.Dismissed = "rewarded-ad-dismissed",
                e.Finished = "rewarded-ad-finished"
            }(r || (r = e("EventRewardedAd", {}))),
            d._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/LogLevelChanger.ts", ["cc", "./Logger.ts"], (function() {
    "use strict";
    var e, o, n, t, r, g, c, i, s;
    return {
        setters: [function(i) {
            e = i.cclegacy,
            o = i._decorator,
            n = i.game,
            t = i.Game,
            r = i.systemEvent,
            g = i.SystemEventType,
            c = i.macro
        }
        , function(e) {
            i = e.logger,
            s = e.LogType
        }
        ],
        execute: function() {
            e._RF.push({}, "e3027fmw7VI8bm2znU7aUU4", "LogLevelChanger", void 0);
            o.ccclass,
            o.property,
            new (function() {
                function e() {
                    var e = this;
                    n.on(t.EVENT_GAME_INITED, (function() {
                        console.log("Constructor of LogLevelChanger game inited"),
                        r.on(g.KEY_DOWN, e.onKeyDown.bind(e), e)
                    }
                    ), this)
                }
                return e.prototype.onKeyDown = function(e) {
                    if (e.keyCode == c.KEY.l) {
                        console.log("Key down to change log level.");
                        var o = i.getLoggingLevel();
                        ++o > s.Error && (o = s.Info),
                        i.setLoggingLevel(o)
                    }
                }
                ,
                e
            }());
            e._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/ChangeLabelByOS.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, n, i, r, o, a, l, s, c;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            i = e.initializerDefineProperty,
            r = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            l = e.Label,
            s = e.sys,
            c = e.Component
        }
        ],
        execute: function() {
            var u, p, b, y, h, f, g;
            o._RF.push({}, "e37abGxs+1ACoaEuwctMF9N", "ChangeLabelByOS", void 0);
            var O = a.ccclass
              , x = a.property;
            e("ChangeLabelByOS", (u = O("ChangeLabelByOS"),
            p = x({
                multiline: !0
            }),
            b = x({
                multiline: !0
            }),
            u((f = t((h = function(e) {
                function t() {
                    for (var t, n = arguments.length, o = new Array(n), a = 0; a < n; a++)
                        o[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    i(r(t), "textOnMobile", f, r(t)),
                    i(r(t), "textOnDesktop", g, r(t)),
                    t
                }
                return n(t, e),
                t.prototype.start = function() {
                    var e = this.node.getComponent(l);
                    null != e && (s.isMobile ? e.string = this.textOnMobile : e.string = this.textOnDesktop)
                }
                ,
                t
            }(c)).prototype, "textOnMobile", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            g = t(h.prototype, "textOnDesktop", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            y = h)) || y));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIDebugState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./WeaponEnums.ts", "./CharacterEnums.ts", "./UITrackWorldNode.ts", "./AIEnums.ts", "./CanvasGameplay.ts", "./AIBrain.ts"], (function(e) {
    "use strict";
    var t, n, a, i, r, o, s, u, l, c, p;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            a = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            r = e.defineProperty
        }
        , function(e) {
            o = e.cclegacy,
            s = e._decorator,
            u = e.Prefab,
            l = e.Component
        }
        , null, function(e) {
            c = e.WeaponType
        }
        , null, null, null, null, function(e) {
            p = e.AIBrain
        }
        ],
        execute: function() {
            var h, f, d, b, g, m;
            o._RF.push({}, "e5d44PFwiJJi6xBPX3ZV6jR", "AIDebugState", void 0);
            var y = s.ccclass
              , I = s.property;
            e("AIDebugState", (h = y("AIDebugState"),
            f = I(u),
            h((g = t((b = function(e) {
                function t() {
                    for (var t, n = arguments.length, o = new Array(n), s = 0; s < n; s++)
                        o[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    a(i(t), "showDebug", g, i(t)),
                    a(i(t), "prefabUI", m, i(t)),
                    r(i(t), "uiInstance", void 0),
                    r(i(t), "label", void 0),
                    r(i(t), "states", void 0),
                    r(i(t), "profileName", void 0),
                    r(i(t), "currentWeapon", null),
                    r(i(t), "currentStateIndex", 0),
                    t
                }
                n(t, e);
                var o = t.prototype;
                return o.onLoad = function() {}
                ,
                o.start = function() {
                    this.profileName = this.node.getComponent(p).dataPrefab.data.name,
                    this.profileName = this.profileName.replace("P_BotProfile_Base-", "")
                }
                ,
                o.onEnable = function() {}
                ,
                o.onDisable = function() {}
                ,
                o.onDestroy = function() {}
                ,
                o.onStateChange = function(e) {
                    if (null != this.states && this.states.length > 0) {
                        var t = this.states.indexOf(e);
                        t >= 0 && (this.currentStateIndex = t,
                        this.updateLabel())
                    }
                }
                ,
                o.onWeaponChange = function(e) {
                    this.currentWeapon = e,
                    this.currentWeapon && this.updateLabel()
                }
                ,
                o.updateLabel = function() {
                    this.label && this.currentWeapon && (this.label.string = this.node.name + "\n" + this.profileName + "\n" + c[this.currentWeapon.Type] + " : " + (this.currentWeapon.weaponRarity + 1) + "⭐\n" + this.states[this.currentStateIndex],
                    this.label.updateRenderData(!0))
                }
                ,
                t
            }(l)).prototype, "showDebug", [I], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            m = t(b.prototype, "prefabUI", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            d = b)) || d));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MatchController.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./GameplayEnums.ts", "./CharacterBlackboard.ts"], (function(t) {
    "use strict";
    var e, a, n, r, i, c, s, o, h, l, u, f, C, p, g, m, y;
    return {
        setters: [function(t) {
            e = t.defineProperty,
            a = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            r = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            c = t.createClass
        }
        , function(t) {
            s = t.cclegacy,
            o = t._decorator,
            h = t.director,
            l = t.Component
        }
        , function(t) {
            u = t.logger
        }
        , function(t) {
            f = t.ProjectEventType,
            C = t.SceneNames
        }
        , function(t) {
            p = t.projectEvent
        }
        , function(t) {
            g = t.globalPlayer
        }
        , function(t) {
            m = t.MatchState
        }
        , function(t) {
            y = t.CharacterBlackboard
        }
        ],
        execute: function() {
            var d, M, v, _, D, S, b, P;
            s._RF.push({}, "e667c4n0tJM/4dgbDxXQT2l", "MatchController", void 0);
            var T = o.ccclass
              , w = o.property
              , E = o.executionOrder;
            t("MatchController", (d = T("MatchController"),
            M = E(-10),
            v = w({
                min: 1
            }),
            d(_ = M((P = b = function(t) {
                function a() {
                    for (var a, n = arguments.length, c = new Array(n), s = 0; s < n; s++)
                        c[s] = arguments[s];
                    return a = t.call.apply(t, [this].concat(c)) || this,
                    r(i(a), "startMatchDelay", S, i(a)),
                    e(i(a), "_state", m.Starting),
                    e(i(a), "_characters", []),
                    e(i(a), "remainingCharacterCount", 0),
                    a
                }
                n(a, t);
                var s = a.prototype;
                return s.onLoad = function() {
                    null == a.instance && (a.instance = this)
                }
                ,
                s.onEnable = function() {
                    p.on(f.CharacterSpawn, this.onCharacterSpawn, this),
                    p.on(f.CharacterDeath, this.onCharacterDeath, this)
                }
                ,
                s.onDisable = function() {
                    p.off(f.CharacterSpawn, this.onCharacterSpawn, this),
                    p.off(f.CharacterDeath, this.onCharacterDeath, this)
                }
                ,
                s.start = function() {
                    this._state = m.Starting,
                    p.emit(f.MatchTimerStart, this.startMatchDelay),
                    this.scheduleOnce(this.onStartTimerFinish, this.startMatchDelay)
                }
                ,
                s.onDestroy = function() {
                    a.instance == this && (a.instance = null)
                }
                ,
                s.onStartTimerFinish = function() {
                    this._state = m.Runing,
                    p.emit(f.MatchStart)
                }
                ,
                s.onCharacterDeath =async function(t) {
                    if (this.state == m.Runing)
                        if (0 != this._characters.length) {
                            this.remainingCharacterCount--;
                            var e, a = t.getComponentInChildren(y);
                            if (a)
                                if (a.IsPlayer)
                                    this.remainingCharacterCount++,
                                    (null === (e = h.getScene()) || void 0 === e ? void 0 : e.name) != C.Tutorial && await this.finishMatch(),
                                    p.emit(f.PlayerLoseMatch);
                                else
                                    1 == this.remainingCharacterCount && (await this.finishMatch(),
                                    p.emit(f.PlayerWinMatch));
                            var n = this._characters.indexOf(t);
                            this._characters.splice(n, 1)
                        } else
                            console.log("ERROR: Target death count is invalid")
                }
                ,
                s.finishMatch =async function() {
                    this._state = m.Finished,
                     await   g.onMatchEnded(this.remainingCharacterCount),
                    p.emit(f.MatchFinish, this.remainingCharacterCount);


                     //xz 新玩家进入游戏后，开始的第一局游戏不能弹出插屏广告
                    let gameIsPlaied = await CoinApp.getItem("gameIsPlaied");
                    if(!gameIsPlaied){
                        //第一局 建议创建快捷方式
                        CoinApp.createShortcutAsync();
                    }else{
                        CoinApp.showInterstitial();
                    }
                    await CoinApp.setItem("gameIsPlaied","gameIsPlaied");
                }
                ,
                s.onCharacterSpawn = function(t) {
                    this._characters.push(t),
                    this.remainingCharacterCount++
                }
                ,
                c(a, [{
                    key: "state",
                    get: function() {
                        return this._state
                    }
                }, {
                    key: "characters",
                    get: function() {
                        return this._characters
                    }
                }]),
                a
            }(l),
            e(b, "instance", void 0),
            S = a((D = P).prototype, "startMatchDelay", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 3
                }
            }),
            _ = D)) || _) || _));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIBlackboard.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(t) {
    "use strict";
    var e, n, r, i, o, a, c, s, u;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            n = t.defineProperty,
            r = t.assertThisInitialized,
            i = t.createClass
        }
        , function(t) {
            o = t.cclegacy,
            a = t._decorator,
            c = t.Component
        }
        , function(t) {
            s = t.logger,
            u = t.LogCategory
        }
        ],
        execute: function() {
            var g;
            o._RF.push({}, "e883fuY4WBEWoXPqeEI7aDW", "AIBlackboard", void 0);
            var h = a.ccclass;
            a.property,
            t("AIBlackboard", h("AIBlackboard")(g = function(t) {
                function o() {
                    for (var e, i = arguments.length, o = new Array(i), a = 0; a < i; a++)
                        o[a] = arguments[a];
                    return e = t.call.apply(t, [this].concat(o)) || this,
                    n(r(e), "_currentMovementIndex", void 0),
                    n(r(e), "_currentPath", void 0),
                    n(r(e), "_currentPathingTarget", void 0),
                    n(r(e), "_visionTarget", void 0),
                    n(r(e), "_chaseTarget", void 0),
                    e
                }
                return e(o, t),
                i(o, [{
                    key: "currentMovementIndex",
                    get: function() {
                        return this._currentMovementIndex
                    },
                    set: function(t) {
                        this._currentMovementIndex = t
                    }
                }, {
                    key: "currentPath",
                    get: function() {
                        return this._currentPath
                    },
                    set: function(t) {
                        this._currentPath = t
                    }
                }, {
                    key: "currentPathingTarget",
                    get: function() {
                        return this._currentPathingTarget
                    },
                    set: function(t) {
                        this._currentPathingTarget = t
                    }
                }, {
                    key: "chaseTarget",
                    get: function() {
                        return this._chaseTarget
                    },
                    set: function(t) {
                        this._chaseTarget = t
                    }
                }, {
                    key: "visionTarget",
                    get: function() {
                        return this._visionTarget
                    },
                    set: function(t) {
                        this._visionTarget = t
                        // this._visionTarget && console.log(this.node.name + " vision target changed to " + this._visionTarget.name, u.AI)
                    }
                }]),
                o
            }(c)) || g);
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MetagameArenaData.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var t, n, i, r, a, o, u, c, l, s, p;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.createClass,
            i = e.inheritsLoose,
            r = e.initializerDefineProperty,
            a = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            u = e._decorator,
            c = e.CCString,
            l = e.SpriteFrame,
            s = e.CCInteger,
            p = e.Component
        }
        ],
        execute: function() {
            var f, g, h, b, m, y, d, k, z, C, v, w, D, I, A, M, x, _, F, L;
            o._RF.push({}, "ebeeez8OQdKRrmjvuV7sftt", "MetagameArenaData", void 0);
            var R = u.ccclass
              , S = u.property
              , j = e("MetagameArena", (f = R("MetagameLevel"),
            g = S(c),
            h = S({
                multiline: !0
            }),
            b = S(l),
            m = S(s),
            y = S(s),
            d = S(c),
            f((C = t((z = function() {
                function e() {
                    r(this, "name", C, this),
                    r(this, "description", v, this),
                    r(this, "icon", w, this),
                    r(this, "unlockCost", D, this),
                    r(this, "index", I, this),
                    r(this, "unlockId", A, this)
                }
                return n(e, [{
                    key: "Name",
                    get: function() {
                        return this.name
                    }
                }, {
                    key: "Description",
                    get: function() {
                        return this.description
                    }
                }, {
                    key: "Icon",
                    get: function() {
                        return this.icon
                    }
                }, {
                    key: "Index",
                    get: function() {
                        return this.index
                    }
                }, {
                    key: "UnlockId",
                    get: function() {
                        return this.unlockId
                    }
                }, {
                    key: "UnlockCost",
                    get: function() {
                        return this.unlockCost
                    }
                }]),
                e
            }()).prototype, "name", [g], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            v = t(z.prototype, "description", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            w = t(z.prototype, "icon", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            D = t(z.prototype, "unlockCost", [m], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            I = t(z.prototype, "index", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            A = t(z.prototype, "unlockId", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return ""
                }
            }),
            k = z)) || k));
            e("MetagameArenaData", (M = R("MetagameArenaData"),
            x = S({
                type: [j]
            }),
            M((L = t((F = function(e) {
                function t() {
                    for (var t, n = arguments.length, i = new Array(n), o = 0; o < n; o++)
                        i[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(i)) || this,
                    r(a(t), "arenas", L, a(t)),
                    t
                }
                return i(t, e),
                n(t, [{
                    key: "Arenas",
                    get: function() {
                        return this.arenas
                    }
                }]),
                t
            }(p)).prototype, "arenas", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            _ = F)) || _));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestExecutionOrderHigh.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var t, r, o, n, i;
    return {
        setters: [function(e) {
            t = e.inheritsLoose
        }
        , function(e) {
            r = e.cclegacy,
            o = e._decorator,
            n = e.Component
        }
        , function(e) {
            i = e.logger
        }
        ],
        execute: function() {
            var c;
            r._RF.push({}, "ec7b55Kx3NElI5m3i7JzX3b", "TestExecutionOrderHigh", void 0);
            var s = o.ccclass
              , u = (o.property,
            o.executionOrder);
            e("TestExecutionOrderHigh", s("TestExecutionOrderHigh")(c = u(1)(c = function(e) {
                function r() {
                    return e.apply(this, arguments) || this
                }
                return t(r, e),
                r.prototype.start = function() {
                    console.log("Order: 1")
                }
                ,
                r
            }(n)) || c) || c);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/RewardedAdOportunity.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectEvent.ts", "./TweenCollection.ts", "./RewardedAdEnums.ts"], (function(e) {
    "use strict";
    var t, n, i, o, r, d, a, l, c, s, u, p, w, f, g;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            i = e.initializerDefineProperty,
            o = e.assertThisInitialized,
            r = e.defineProperty
        }
        , function(e) {
            d = e.cclegacy,
            a = e._decorator,
            l = e.Node,
            c = e.Component
        }
        , function(e) {
            s = e.logger,
            u = e.LogCategory,
            p = e.LogType
        }
        , function(e) {
            w = e.projectEvent
        }
        , function(e) {
            f = e.TweenCollection
        }
        , function(e) {
            g = e.EventRewardedAd
        }
        ],
        execute: function() {
            var A, h, y, v, b, R, m;
            d._RF.push({}, "eccb5Bz3DpHrZLT9hCNJIH8", "RewardedAdOportunity", void 0);
            var C = a.ccclass
              , S = a.property;
            e("RewardedAdOportunity", (A = C("RewardedAdOportunity"),
            h = S(l),
            y = S(f),
            A((R = t((b = function(e) {
                function t() {
                    for (var t, n = arguments.length, d = new Array(n), a = 0; a < n; a++)
                        d[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(d)) || this,
                    i(o(t), "content", R, o(t)),
                    i(o(t), "tweenCollection", m, o(t)),
                    r(o(t), "showAdFunction", void 0),
                    t
                }
                n(t, e);
                var d = t.prototype;
                return d.onLoad = function() {
                    this.content.active = !1
                }
                ,
                d.setup = function() {
                    var e = this;
                    if (console.log("Setting up rewarded ad opportunity", u.RewardedAd),
                    "undefined" != typeof GAMESNACKS) {
                        var t = {};
                        t.beforeReward = function(t) {
                            var n;
                            console.log("beforeReward - ad is ready, showing button", u.RewardedAd),
                            e.content.active = !0,
                            null === (n = e.tweenCollection) || void 0 === n || n.play(),
                            e.showAdFunction = t
                        }
                        .bind(this),
                        t.beforeBreak = function() {
                            console.log("beforeBreak - game will be paused to show ad", u.RewardedAd)
                        }
                        .bind(this),
                        t.adComplete = function() {
                            console.log("adComplete - rewarding player", u.RewardedAd),
                            w.emit(g.Completed)
                        }
                        .bind(this),
                        t.adDismissed = function() {
                            console.log("adDismissed - player will not receive anything", u.RewardedAd),
                            w.emit(g.Dismissed)
                        }
                        .bind(this),
                        t.afterBreak = function() {
                            console.log("afterBreak - game will be resumed now", u.RewardedAd),
                            e.content.active = !1,
                            w.emit(g.Finished)
                        }
                        .bind(this),
                        console.log("Calling GAMESNACKS.rewardedAdOpportunity", u.RewardedAd),
                        GAMESNACKS.rewardedAdOpportunity(t)
                    } else
                        console.log("GAMESNACKS is invalid", u.RewardedAd)
                }
                ,
                d.showAd = function() {
                    this.showAdFunction ? this.showAdFunction() : (console.log("Trying to show ad without initializing.", u.RewardedAd, p.Error),
                    this.content.active = !1)
                }
                ,
                t
            }(c)).prototype, "content", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            m = t(b.prototype, "tweenCollection", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = b)) || v));
            d._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/EnemySignal.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./CharacterEnums.ts", "./CharacterBlackboard.ts"], (function(e) {
    "use strict";
    var t, r, n, i, o, a, s, l, c, d, h, g, u, f, p;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            n = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            s = e.Collider,
            l = e.Node,
            c = e.Vec3,
            d = e.tween,
            h = e.Component
        }
        , function(e) {
            g = e.logger
        }
        , function(e) {
            u = e.OnTrigger
        }
        , function(e) {
            f = e.EventCharacterAction
        }
        , function(e) {
            p = e.CharacterBlackboard
        }
        ],
        execute: function() {
            var E, T, y, w, m, v, C, b, k;
            o._RF.push({}, "ed3d1X65dxJmJmJCf33t2Gq", "EnemySignal", void 0);
            var M = a.ccclass
              , U = a.property
              , x = a.executionOrder;
            e("EnemySignal", (E = M("EnemySignal"),
            T = x(-1),
            y = U({
                type: s
            }),
            w = U({
                type: l
            }),
            E(m = T((C = t((v = function(e) {
                function t() {
                    for (var t, r = arguments.length, o = new Array(r), a = 0; a < r; a++)
                        o[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    n(i(t), "collider", C, i(t)),
                    n(i(t), "showMarkers", b, i(t)),
                    n(i(t), "targetMarkers", k, i(t)),
                    t
                }
                r(t, e);
                var o = t.prototype;
                return o.start = function() {
                    this.targetMarkers.setScale(c.ZERO),
                    this.scaleTweenUp = d(this.targetMarkers).to(1, {
                        scale: c.ONE
                    }, {
                        easing: "elasticOut"
                    }).repeat(1),
                    this.scaleTweenDown = d(this.targetMarkers).to(.5, {
                        scale: c.ZERO
                    }, {
                        easing: "quadIn"
                    }).repeat(1)
                }
                ,
                o.onEnable = function() {
                    var e, t;
                    null === (e = this.collider) || void 0 === e || e.on(u.Enter, this.onTriggerEnter, this),
                    null === (t = this.collider) || void 0 === t || t.on(u.Exit, this.onTriggerExit, this),
                    this.node.on(f.Targeted, this.onTargeted, this),
                    this.node.on(f.Untargeted, this.onUntargeted, this)
                }
                ,
                o.onDisable = function() {
                    var e, t;
                    null === (e = this.collider) || void 0 === e || e.off(u.Enter, this.onTriggerEnter, this),
                    null === (t = this.collider) || void 0 === t || t.off(u.Exit, this.onTriggerExit, this),
                    this.node.off(f.Targeted, this.onTargeted, this),
                    this.node.off(f.Untargeted, this.onUntargeted, this)
                }
                ,
                o.onTriggerEnter = function(e) {
                    e.otherCollider.node.parent != e.selfCollider.node && e.otherCollider.node.emit(f.Detected, this.collider.node)
                }
                ,
                o.onTriggerExit = function(e) {
                    e.otherCollider && e.otherCollider.node.emit(f.Undetected, this.collider.node)
                }
                ,
                o.onTargeted = function(e) {
                    var t = e.getComponent(p);
                    t ? t.IsPlayer && (this.scaleTweenDown.stop(),
                    this.scaleTweenUp.start()) : console.log("Could not get character data.")
                }
                ,
                o.onUntargeted = function() {
                    this.showMarkers && (this.scaleTweenUp.stop(),
                    this.scaleTweenDown.start())
                }
                ,
                t
            }(h)).prototype, "collider", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            b = t(v.prototype, "showMarkers", [U], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            k = t(v.prototype, "targetMarkers", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            m = v)) || m) || m));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuMissionOverlay.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./Mission.ts", "./GlobalPlayer.ts", "./MainMenuMissionWidget.ts"], (function(i) {
    "use strict";
    var e, t, n, s, a, o, r, l, u, d, c, g, h, y, f, p, m, v, M, W;
    return {
        setters: [function(i) {
            e = i.applyDecoratedDescriptor,
            t = i.inheritsLoose,
            n = i.initializerDefineProperty,
            s = i.assertThisInitialized,
            a = i.defineProperty,
            o = i.createForOfIteratorHelperLoose
        }
        , function(i) {
            r = i.cclegacy,
            l = i._decorator,
            u = i.Prefab,
            d = i.Layout,
            c = i.instantiate,
            g = i.Component
        }
        , function(i) {
            h = i.logger,
            y = i.LogCategory,
            f = i.LogType
        }
        , function(i) {
            p = i.UIEventType
        }
        , function(i) {
            m = i.projectEvent
        }
        , function(i) {
            v = i.MissionCategory
        }
        , function(i) {
            M = i.globalPlayer
        }
        , function(i) {
            W = i.MainMenuMissionWidget
        }
        ],
        execute: function() {
            var b, P, A, w, D, L, O, E;
            r._RF.push({}, "ef4f1MpRYhIgYWh5dhQ5vSb", "MainMenuMissionOverlay", void 0);
            var C = l.ccclass
              , F = l.property;
            i("MainMenuMissionOverlay", (b = C("MainMenuMissionOverlay"),
            P = F(u),
            A = F(d),
            b((L = e((D = function(i) {
                function e() {
                    for (var e, t = arguments.length, o = new Array(t), r = 0; r < t; r++)
                        o[r] = arguments[r];
                    return e = i.call.apply(i, [this].concat(o)) || this,
                    n(s(e), "missionWidgetPrefab", L, s(e)),
                    n(s(e), "missionWidgetLayout", O, s(e)),
                    n(s(e), "barAnimationDelayPerWidget", E, s(e)),
                    a(s(e), "canvas", void 0),
                    a(s(e), "widgets", void 0),
                    a(s(e), "shouldAnimate", !1),
                    e
                }
                t(e, i);
                var r = e.prototype;
                return r.setupSpecific = function(i) {
                    this.clearWidgets(),
                    this.shouldAnimate = !0,
                    this.spawnMissionWidgets(i),
                    m.emit(p.BlockMoneyUpdate)
                }
                ,
                r.setupAll = function() {
                  //xz 每日成就 设置
                    this.clearWidgets(),
                    this.shouldAnimate = !1;
                    var i = [v.Easy, v.Medium, v.Hard, v.FirstWinOfTheDay];
                    this.spawnMissionWidgets(i)
                }
                ,
                r.spawnMissionWidgets = function(i) {
                    for (var e, t = 0, n = o(i); !(e = n()).done; ) {
                        var s = e.value;
                        if (s == v.FirstWinOfTheDay) {
                            var a = c(this.missionWidgetPrefab);
                            a.setParent(this.missionWidgetLayout.node);
                            var r = a.getComponent(W);
                            r.setupAsFirstWinOfTheDay(this.shouldAnimate),
                            r.animationDelay = t * this.barAnimationDelayPerWidget,
                            this.widgets.push(r)
                        } else {
                            var l = M.missions.get(s);
                            if (!l) {
                                console.log("Invalid " + v[s] + " mission for player!", y.Metagame, f.Error);
                                continue
                            }
                            var u = c(this.missionWidgetPrefab);
                            u.setParent(this.missionWidgetLayout.node);
                            var d = u.getComponent(W);
                            d.setupAsMission(l, this.shouldAnimate),
                            d.animationDelay = t * this.barAnimationDelayPerWidget,
                            this.widgets.push(d)
                        }
                        t++
                    }
                }
                ,
                r.clearWidgets = function() {
                    for (var i, e = o(this.missionWidgetLayout.node.children); !(i = e()).done; ) {
                        i.value.destroy()
                    }
                    this.widgets = []
                }
                ,
                r.animateWidgetEntry = function(i) {
                    i < this.widgets.length && this.widgets[i].playEntryAnimation()
                }
                ,
                r.animateBars = function() {
                    if (this.shouldAnimate)
                        for (var i, e = o(this.widgets); !(i = e()).done; ) {
                            i.value.animateBar()
                        }
                    m.emit(p.UnblockMoneyUpdate)
                }
                ,
                e
            }(g)).prototype, "missionWidgetPrefab", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            O = e(D.prototype, "missionWidgetLayout", [A], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            E = e(D.prototype, "barAnimationDelayPerWidget", [F], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return .1
                }
            }),
            w = D)) || w));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TreasureVFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./PickupEnums.ts", "./PrefabPool.ts"], (function(e) {
    "use strict";
    var t, i, r, n, o, a, l, c, s, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            r = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            l = e.Prefab,
            c = e.Component
        }
        , function(e) {
            s = e.EventPickup
        }
        , function(e) {
            u = e.PrefabPool
        }
        ],
        execute: function() {
            var f, p, d, h, P;
            o._RF.push({}, "ef7f6Mo37VDMqe8/rLZA/Rw", "TreasureVFX", void 0);
            var b = a.ccclass
              , v = a.property;
            e("TreasureVFX", (f = b("TreasureVFX"),
            p = v(l),
            f((P = t((h = function(e) {
                function t() {
                    for (var t, i = arguments.length, o = new Array(i), a = 0; a < i; a++)
                        o[a] = arguments[a];
                    return t = e.call.apply(e, [this].concat(o)) || this,
                    r(n(t), "prefabParticle", P, n(t)),
                    t
                }
                i(t, e);
                var o = t.prototype;
                return o.onLoad = function() {
                    var e;
                    this.prefabParticle && (null === (e = u.instance) || void 0 === e || e.initialize(this.prefabParticle))
                }
                ,
                o.onEnable = function() {
                    this.node.on(s.Collected, this.onCollected, this)
                }
                ,
                o.onDisable = function() {
                    this.node.off(s.Collected, this.onCollected, this)
                }
                ,
                o.onCollected = function() {
                    var e;
                    if (this.prefabParticle) {
                        var t, i = null === (e = u.instance) || void 0 === e ? void 0 : e.getInScene(this.prefabParticle);
                        if (i)
                            i.setWorldPosition(this.node.worldPosition),
                            null === (t = u.instance) || void 0 === t || t.schedulePut(this.prefabParticle, i, 2)
                    }
                }
                ,
                t
            }(c)).prototype, "prefabParticle", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            d = h)) || d));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/BulletVFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./BulletEnums.ts", "./PrefabPool.ts"], (function(i) {
    "use strict";
    var t, e, n, l, r, a, o, s, c, u;
    return {
        setters: [function(i) {
            t = i.applyDecoratedDescriptor,
            e = i.inheritsLoose,
            n = i.initializerDefineProperty,
            l = i.assertThisInitialized
        }
        , function(i) {
            r = i.cclegacy,
            a = i._decorator,
            o = i.Prefab,
            s = i.Component
        }
        , function(i) {
            c = i.BulletEvent
        }
        , function(i) {
            u = i.PrefabPool
        }
        ],
        execute: function() {
            var f, P, h, p, b, y, d;
            r._RF.push({}, "f0889XsGYFNWoDFVVzUKIbS", "BulletVFX", void 0);
            var H = a.ccclass
              , v = a.property;
            i("BulletVFX", (f = H("BulletVFX"),
            P = v(o),
            h = v(o),
            f((y = t((b = function(i) {
                function t() {
                    for (var t, e = arguments.length, r = new Array(e), a = 0; a < e; a++)
                        r[a] = arguments[a];
                    return t = i.call.apply(i, [this].concat(r)) || this,
                    n(l(t), "prefabParticleHitPlayer", y, l(t)),
                    n(l(t), "prefabParticleHitWall", d, l(t)),
                    t
                }
                e(t, i);
                var r = t.prototype;
                return r.onLoad = function() {
                    var i, t;
                    this.prefabParticleHitWall && (null === (i = u.instance) || void 0 === i || i.initialize(this.prefabParticleHitWall)),
                    this.prefabParticleHitPlayer && (null === (t = u.instance) || void 0 === t || t.initialize(this.prefabParticleHitPlayer))
                }
                ,
                r.onEnable = function() {
                    this.node.on(c.HitAnything, this.onHitAnything, this),
                    this.node.on(c.HitPlayer, this.onHitPlayer, this)
                }
                ,
                r.onDisable = function() {
                    this.node.off(c.HitAnything, this.onHitAnything, this),
                    this.node.off(c.HitPlayer, this.onHitPlayer, this)
                }
                ,
                r.onHitPlayer = function() {
                    var i;
                    if (this.prefabParticleHitPlayer) {
                        var t, e = null === (i = u.instance) || void 0 === i ? void 0 : i.getInScene(this.prefabParticleHitPlayer);
                        if (e)
                            e.setWorldPosition(this.node.worldPosition),
                            null === (t = u.instance) || void 0 === t || t.schedulePut(this.prefabParticleHitPlayer, e, 2)
                    }
                }
                ,
                r.onHitAnything = function() {
                    var i;
                    if (this.prefabParticleHitWall) {
                        var t, e = null === (i = u.instance) || void 0 === i ? void 0 : i.getInScene(this.prefabParticleHitWall);
                        if (e)
                            e.setWorldPosition(this.node.worldPosition),
                            null === (t = u.instance) || void 0 === t || t.schedulePut(this.prefabParticleHitWall, e, 2)
                    }
                }
                ,
                t
            }(s)).prototype, "prefabParticleHitPlayer", [P], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            d = t(b.prototype, "prefabParticleHitWall", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            p = b)) || p));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AutoRotate.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(t) {
    "use strict";
    var e, o, r, i, n, a, c, u, l, s;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            o = t.inheritsLoose,
            r = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            n = t.defineProperty
        }
        , function(t) {
            a = t.cclegacy,
            c = t._decorator,
            u = t.CCFloat,
            l = t.Quat,
            s = t.Component
        }
        ],
        execute: function() {
            var p, f, y, h, v;
            a._RF.push({}, "f2259PaclBBH7Zth41ZQzqY", "AutoRotate", void 0);
            var d = c.ccclass
              , R = c.property;
            t("AutoRotate", (p = d("AutoRotate"),
            f = R(u),
            p((v = e((h = function(t) {
                function e() {
                    for (var e, o = arguments.length, a = new Array(o), c = 0; c < o; c++)
                        a[c] = arguments[c];
                    return e = t.call.apply(t, [this].concat(a)) || this,
                    r(i(e), "velocity", v, i(e)),
                    n(i(e), "rot", new l),
                    e
                }
                return o(e, t),
                e.prototype.update = function(t) {
                    this.velocity > 0 && (l.fromEuler(this.rot, 0, 0, -this.velocity),
                    this.node.rotate(this.rot))
                }
                ,
                e
            }(s)).prototype, "velocity", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 0
                }
            }),
            y = h)) || y));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterLevelVFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterEnums.ts", "./PrefabPool.ts"], (function(e) {
    "use strict";
    var t, i, r, n, a, o, l, c, s, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            r = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            a = e.cclegacy,
            o = e._decorator,
            l = e.Prefab,
            c = e.Component
        }
        , function(e) {
            s = e.EventCharacterAction
        }
        , function(e) {
            u = e.PrefabPool
        }
        ],
        execute: function() {
            var f, p, h, v, P;
            a._RF.push({}, "f3a8c2GrTtMbaz9awClcXPL", "CharacterLevelVFX", void 0);
            var b = o.ccclass
              , d = o.property;
            e("CharacterLevelVFX", (f = b("CharacterLevelVFX"),
            p = d(l),
            f((P = t((v = function(e) {
                function t() {
                    for (var t, i = arguments.length, a = new Array(i), o = 0; o < i; o++)
                        a[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    r(n(t), "prefabParticle", P, n(t)),
                    t
                }
                i(t, e);
                var a = t.prototype;
                return a.onEnable = function() {
                    this.node.on(s.LevelUp, this.onLevelUp, this)
                }
                ,
                a.onDisable = function() {
                    this.node.off(s.LevelUp, this.onLevelUp, this)
                }
                ,
                a.onLoad = function() {
                    var e;
                    this.prefabParticle && (null === (e = u.instance) || void 0 === e || e.initialize(this.prefabParticle))
                }
                ,
                a.onLevelUp = function() {
                    var e;
                    if (this.prefabParticle) {
                        var t, i = null === (e = u.instance) || void 0 === e ? void 0 : e.getInScene(this.prefabParticle);
                        if (i)
                            i.setWorldPosition(this.node.worldPosition),
                            null === (t = u.instance) || void 0 === t || t.schedulePut(this.prefabParticle, i, 2)
                    }
                }
                ,
                t
            }(c)).prototype, "prefabParticle", [p], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            h = v)) || h));
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIToast.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./TweenCollection.ts"], (function(e) {
    "use strict";
    var t, n, i, o, l, r, a, c, s, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            i = e.initializerDefineProperty,
            o = e.assertThisInitialized
        }
        , function(e) {
            l = e.cclegacy,
            r = e._decorator,
            a = e.Node,
            c = e.Label,
            s = e.Component
        }
        , function(e) {
            u = e.TweenCollection
        }
        ],
        execute: function() {
            var p, f, h, w, y, T, b, d, v;
            l._RF.push({}, "f48d1/zl79Orqq+3EfvjU+W", "UIToast", void 0);
            var g = r.ccclass
              , C = r.property;
            e("UIToast", (p = g("UIToast"),
            f = C(a),
            h = C(u),
            w = C(c),
            p((b = t((T = function(e) {
                function t() {
                    for (var t, n = arguments.length, l = new Array(n), r = 0; r < n; r++)
                        l[r] = arguments[r];
                    return t = e.call.apply(e, [this].concat(l)) || this,
                    i(o(t), "content", b, o(t)),
                    i(o(t), "tweenCollection", d, o(t)),
                    i(o(t), "lText", v, o(t)),
                    t
                }
                n(t, e);
                var l = t.prototype;
                return l.onLoad = function() {
                    this.content.active = !1
                }
                ,
                l.show = function(e) {
                    void 0 === e && (e = null),
                    this.lText && this.tweenCollection && (this.content.active = !0,
                    e && (this.lText.string = e),
                    this.lText.updateRenderData(!0),
                    this.tweenCollection.reset(),
                    this.tweenCollection.play())
                }
                ,
                t
            }(s)).prototype, "content", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            d = t(T.prototype, "tweenCollection", [h], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = t(T.prototype, "lText", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            y = T)) || y));
            l._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CameraFree.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var o, t, s, i, n, h, u, r, _, a, c, l, y, d;
    return {
        setters: [function(e) {
            o = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            s = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            n = e.defineProperty
        }
        , function(e) {
            h = e.cclegacy,
            u = e._decorator,
            r = e.Vec2,
            _ = e.Vec3,
            a = e.systemEvent,
            c = e.SystemEventType,
            l = e.macro,
            y = e.Component
        }
        , function(e) {
            d = e.logger
        }
        ],
        execute: function() {
            var E, C, p;
            h._RF.push({}, "f4d5cKlilZFAIfcgsLaiZSb", "CameraFree", void 0);
            var f = u.ccclass
              , K = u.property;
            e("CameraFree", f("CameraFree")((p = o((C = function(e) {
                function o() {
                    for (var o, t = arguments.length, h = new Array(t), u = 0; u < t; u++)
                        h[u] = arguments[u];
                    return o = e.call.apply(e, [this].concat(h)) || this,
                    s(i(o), "speed", p, i(o)),
                    n(i(o), "_isMouseDown", !1),
                    n(i(o), "_mousePos", new r),
                    n(i(o), "_mousePosOnDown", new r),
                    n(i(o), "_mouseDelta", new r),
                    n(i(o), "_x", 0),
                    n(i(o), "_y", 0),
                    n(i(o), "_z", 0),
                    n(i(o), "_translateValue", new _),
                    n(i(o), "_sprintMultiplier", 1),
                    o
                }
                t(o, e);
                var h = o.prototype;
                return h.start = function() {
                    a.on(c.KEY_DOWN, this.onKeyDown, this),
                    a.on(c.KEY_UP, this.onKeyUp, this),
                    a.on(c.MOUSE_MOVE, this.onMouseMove, this),
                    a.on(c.MOUSE_DOWN, this.onMouseDown, this),
                    a.on(c.MOUSE_UP, this.onMouseUp, this),
                    a.on(c.TOUCH_START, this.onTouchStart, this),
                    a.on(c.TOUCH_MOVE, this.onTouchMove, this),
                    a.on(c.TOUCH_END, this.onTouchEndOrCancel, this),
                    a.on(c.TOUCH_CANCEL, this.onTouchEndOrCancel, this)
                }
                ,
                h.onDestroy = function() {
                    a.off(c.KEY_DOWN, this.onKeyDown, this),
                    a.off(c.KEY_UP, this.onKeyUp, this),
                    a.off(c.MOUSE_MOVE, this.onMouseMove, this),
                    a.off(c.MOUSE_DOWN, this.onMouseDown, this),
                    a.off(c.MOUSE_UP, this.onMouseUp, this),
                    a.off(c.TOUCH_START, this.onTouchStart, this),
                    a.off(c.TOUCH_MOVE, this.onTouchMove, this),
                    a.off(c.TOUCH_END, this.onTouchEndOrCancel, this),
                    a.off(c.TOUCH_CANCEL, this.onTouchEndOrCancel, this)
                }
                ,
                h.update = function(e) {
                    this._translateValue.set(this._x, this._y, -1 * this._z),
                    this._translateValue.multiplyScalar(e * (this.speed * this._sprintMultiplier)),
                    this.node.translate(this._translateValue)
                }
                ,
                h.onKeyDown = function(e) {
                    e.keyCode == l.KEY.w || e.keyCode == l.KEY.up ? this._z = 1 : e.keyCode != l.KEY.s && e.keyCode != l.KEY.down || (this._z = -1),
                    e.keyCode == l.KEY.d || e.keyCode == l.KEY.right ? this._x = 1 : e.keyCode != l.KEY.a && e.keyCode != l.KEY.left || (this._x = -1),
                    e.keyCode == l.KEY.e || e.keyCode == l.KEY.pageup ? this._y = 1 : e.keyCode != l.KEY.q && e.keyCode != l.KEY.pagedown || (this._y = -1),
                    e.keyCode == l.KEY.shift && (this._sprintMultiplier = 2),
                    e.keyCode == l.KEY.c &&console.log("Free camera world position: " + this.node.worldPosition)
                }
                ,
                h.onKeyUp = function(e) {
                    e.keyCode == l.KEY.w || e.keyCode == l.KEY.up ? 1 == this._z && (this._z = 0) : e.keyCode != l.KEY.s && e.keyCode != l.KEY.down || -1 == this._z && (this._z = 0),
                    e.keyCode == l.KEY.d || e.keyCode == l.KEY.right ? 1 == this._x && (this._x = 0) : e.keyCode != l.KEY.a && e.keyCode != l.KEY.left || -1 == this._x && (this._x = 0),
                    e.keyCode == l.KEY.e || e.keyCode == l.KEY.pageup ? 1 == this._y && (this._y = 0) : e.keyCode != l.KEY.q && e.keyCode != l.KEY.pagedown || -1 == this._y && (this._y = 0),
                    e.keyCode == l.KEY.shift && (this._sprintMultiplier = 1)
                }
                ,
                h.onMouseDown = function(e) {
                    this._isMouseDown = !0,
                    e.getLocation(this._mousePosOnDown)
                }
                ,
                h.onMouseMove = function(e) {
                    this._isMouseDown && (e.getLocation(this._mousePos),
                    this._mouseDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._mouseDelta.normalize(),
                    this._x = this._mouseDelta.x,
                    this._z = this._mouseDelta.y)
                }
                ,
                h.onMouseUp = function(e) {
                    this._isMouseDown = !1,
                    this._x = 0,
                    this._z = 0
                }
                ,
                h.onTouchStart = function(e, o) {
                    o.getLocation(this._mousePosOnDown),
                    this._isMouseDown = !0
                }
                ,
                h.onTouchMove = function(e, o) {
                    o.getLocation(this._mousePos),
                    this._mouseDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._mouseDelta.normalize(),
                    this._x = this._mouseDelta.x,
                    this._z = this._mouseDelta.y
                }
                ,
                h.onTouchEndOrCancel = function(e, o) {
                    this._isMouseDown = !1,
                    this._x = 0,
                    this._z = 0
                }
                ,
                o
            }(y)).prototype, "speed", [K], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 5
                }
            }),
            E = C)) || E);
            h._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestArrayProperties.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc"], (function(e) {
    "use strict";
    var r, t, i, n, o, s, a, u, l, p;
    return {
        setters: [function(e) {
            r = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            i = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            s = e._decorator,
            a = e.CCString,
            u = e.CCInteger,
            l = e.Node,
            p = e.Component
        }
        ],
        execute: function() {
            var c, f, y, b, g, d, h, m, P;
            o._RF.push({}, "f540f6BPllO0piS1Nl2/3fp", "TestArrayProperties", void 0);
            var v = s.ccclass
              , z = s.property;
            e("TestArrayProperties", (c = v("TestArrayProperties"),
            f = z({
                type: [a]
            }),
            y = z({
                type: [u]
            }),
            b = z({
                type: [l],
                tooltip: "Must be in the enum order!"
            }),
            c((h = r((d = function(e) {
                function r() {
                    for (var r, t = arguments.length, o = new Array(t), s = 0; s < t; s++)
                        o[s] = arguments[s];
                    return r = e.call.apply(e, [this].concat(o)) || this,
                    i(n(r), "strings", h, n(r)),
                    i(n(r), "numbers", m, n(r)),
                    i(n(r), "nodes", P, n(r)),
                    r
                }
                return t(r, e),
                r
            }(p)).prototype, "strings", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            m = r(d.prototype, "numbers", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            P = r(d.prototype, "nodes", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            g = d)) || g));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TestGetPrefabValuesWithoutInstantiating.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Weapon.ts"], (function(t) {
    "use strict";
    var e, n, a, i, r, o, s, l, u, p;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            a = t.initializerDefineProperty,
            i = t.assertThisInitialized
        }
        , function(t) {
            r = t.cclegacy,
            o = t._decorator,
            s = t.Prefab,
            l = t.log,
            u = t.Component
        }
        , function(t) {
            p = t.Weapon
        }
        ],
        execute: function() {
            var c, f, b, g, h, y, v;
            r._RF.push({}, "f576aPDv2VMsJgJvIgYSCxr", "TestGetPrefabValuesWithoutInstantiating", void 0);
            var P = o.ccclass
              , w = o.property;
            t("TestGetPrefabValuesWithoutInstantiating", (c = P("TestGetPrefabValuesWithoutInstantiating"),
            f = w(s),
            b = w(p),
            c((y = e((h = function(t) {
                function e() {
                    for (var e, n = arguments.length, r = new Array(n), o = 0; o < n; o++)
                        r[o] = arguments[o];
                    return e = t.call.apply(t, [this].concat(r)) || this,
                    a(i(e), "prefab", y, i(e)),
                    a(i(e), "weapon", v, i(e)),
                    e
                }
                return n(e, t),
                e.prototype.start = function() {
                    l(this.prefab),
                    l(this.weapon)
                }
                ,
                e
            }(u)).prototype, "prefab", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            v = e(h.prototype, "weapon", [b], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            g = h)) || g));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIMatchEnd.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./PanelManager.ts", "./PanelEnums.ts", "./ExperienceRewardWidget.ts", "./TrophyRewardWidget.ts", "./Loading.ts", "./CurrencyRewardWidget.ts", "./RewardedAdAfterMatch.ts"], (function(e) {
    "use strict";
    var t, i, n, r, a, l, o, s, u, c, p, d, h, b, g, m, f, v, y, w, x, P, C, L, T, B, O, E, R, G, M, U, z, D, X, F;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            i = e.inheritsLoose,
            n = e.initializerDefineProperty,
            r = e.assertThisInitialized,
            a = e.defineProperty,
            l = e.asyncToGenerator
        }
        , function(e) {
            o = e.cclegacy,
            s = e._decorator,
            u = e.Animation,
            c = e.AnimationClip,
            p = e.Node,
            d = e.UIOpacity,
            h = e.Label,
            b = e.ProgressBar,
            g = e.Prefab,
            m = e.director,
            f = e.tween,
            v = e.assetManager,
            y = e.Layout,
            w = e.Widget,
            x = e.Component
        }
        , function(e) {
            P = e.logger,
            C = e.LogCategory
        }
        , function(e) {
            L = e.SceneNames,
            T = e.ProjectEventType,
            B = e.UIEventType,
            O = e.BundleNames
        }
        , function(e) {
            E = e.projectEvent
        }
        , function(e) {
            R = e.globalPlayer
        }
        , function(e) {
            G = e.PanelManager
        }
        , function(e) {
            M = e.PanelId
        }
        , function(e) {
            U = e.ExperienceRewardWidget
        }
        , function(e) {
            z = e.TrophyRewardWidget
        }
        , function(e) {
            D = e.Loading
        }
        , function(e) {
            X = e.CurrencyRewardWidget
        }
        , function(e) {
            F = e.RewardedAdAfterMatch
        }
        ],
        execute: function() {
            var A, S, k, I, W, N, j, _, K, Y, H, V, q, J, Q, Z, $, ee, te, ie, ne, re, ae, le, oe, se, ue, ce, pe, de, he, be, ge, me, fe, ve, ye, we, xe, Pe, Ce, Le, Te, Be, Oe, Ee, Re, Ge, Me, Ue;
            o._RF.push({}, "f610fa/dutDypnRNx+GhSoX", "UIMatchEnd", void 0);
            var ze = s.ccclass
              , De = s.property;
            e("UIMatchEnd", (A = ze("UIMatchEnd"),
            S = De(u),
            k = De(u),
            I = De(c),
            W = De(c),
            N = De(c),
            j = De(p),
            _ = De(d),
            K = De(p),
            Y = De(z),
            H = De(h),
            V = De(h),
            q = De(h),
            J = De(h),
            Q = De(h),
            Z = De(h),
            $ = De(h),
            ee = De(h),
            te = De(h),
            ie = De(b),
            ne = De(g),
            re = De(p),
            ae = De(F),
            le = De(U),
            A((ue = t((se = function(e) {
                function t() {
                    for (var t, i = arguments.length, l = new Array(i), o = 0; o < i; o++)
                        l[o] = arguments[o];
                    return t = e.call.apply(e, [this].concat(l)) || this,
                    n(r(t), "animation", ue, r(t)),
                    n(r(t), "animationXPbar", ce, r(t)),
                    n(r(t), "clipOpenXPBar", pe, r(t)),
                    n(r(t), "clipOpenMatchStats", de, r(t)),
                    n(r(t), "clipOpenConfirmButton", he, r(t)),
                    n(r(t), "containerXPBar", be, r(t)),
                    n(r(t), "containerMatchStatus", ge, r(t)),
                    n(r(t), "containerButtonOk", me, r(t)),
                    n(r(t), "trophyRewardWidget", fe, r(t)),
                    n(r(t), "lPlacement", ve, r(t)),
                    n(r(t), "lPlacementOrdinal", ye, r(t)),
                    n(r(t), "lTopTitle", we, r(t)),
                    n(r(t), "lKillCount", xe, r(t)),
                    n(r(t), "lChestsOpened", Pe, r(t)),
                    n(r(t), "lChestsOpenedTitle", Ce, r(t)),
                    n(r(t), "lDamageDealt", Le, r(t)),
                    n(r(t), "lGlobalLevel", Te, r(t)),
                    n(r(t), "lGlobalExperience", Be, r(t)),
                    n(r(t), "lGlobalExperienceBar", Oe, r(t)),
                    n(r(t), "xpAnimationDuration", Ee, r(t)),
                    n(r(t), "widgetCurrencyReward", Re, r(t)),
                    n(r(t), "widgetCurrencyRewardPivot", Ge, r(t)),
                    n(r(t), "rewardedAd", Me, r(t)),
                    n(r(t), "experienceRewardWidget", Ue, r(t)),
                    a(r(t), "initialLevel", void 0),
                    a(r(t), "initialExperience", void 0),
                    a(r(t), "initialFillRatio", void 0),
                    a(r(t), "currentLevelUpTarget", void 0),
                    a(r(t), "previousProgressBarNumber", void 0),
                    a(r(t), "tweenXPBar", void 0),
                    a(r(t), "clickedContinue", !1),
                    a(r(t), "debugDmgContainerWidget", void 0),
                    a(r(t), "onGameBundleLoaded", (function(e, i) {
                        console.log("Finished loading bundle. " + i.name + ", loading scene"),
                        i.loadScene(L.Menu, t.onSceneLoaded)
                    }
                    )),
                    a(r(t), "onSceneLoaded", (function(e, i) {
                        console.log("Finished loading scene " + i.name + ", starting it."),
                        t.scheduleOnce((function() {
                            m.runScene(i)
                        }
                        ), 2)
                    }
                    )),
                    t
                }
                i(t, e);
                var o = t.prototype;
                return o.onEnable = function() {
                    E.on(T.MatchFinish, this.onMatchFinish, this),
                    this.runInitialSetup()
                }
                ,
                o.onDisable = function() {
                    E.off(T.MatchFinish, this.onMatchFinish, this)
                }
                ,
                o.onMatchFinish = function() {
                    var e = l(regeneratorRuntime.mark((function e(t) {
                        var i, n, r;
                        return regeneratorRuntime.wrap((function(e) {
                            for (; ; )
                                switch (e.prev = e.next) {
                                case 0:
                                    CoinApp.hideBanner();
                                    if (console.log("Match finish, setting up match end UI", C.UI),
                                    this.lPlacement && (this.lPlacement.string = t.toFixed()),
                                    !this.lPlacementOrdinal) {
                                        e.next = 14;
                                        break
                                    }
                                    e.t0 = t,
                                    e.next = 1 === e.t0 ? 6 : 2 === e.t0 ? 8 : 3 === e.t0 ? 10 : 12;
                                    break;
                                case 6:
                                    return this.lPlacementOrdinal.string = "ST",
                                    e.abrupt("break", 14);
                                case 8:
                                    return this.lPlacementOrdinal.string = "ND",
                                    e.abrupt("break", 14);
                                case 10:
                                    return this.lPlacementOrdinal.string = "RD",
                                    e.abrupt("break", 14);
                                case 12:
                                    return this.lPlacementOrdinal.string = "TH",
                                    e.abrupt("break", 14);
                                case 14:
                                    return this.lTopTitle && (t <= 1 ? this.setLabelText(this.lTopTitle, "VICTORY\nROYALE!") : this.setLabelText(this.lTopTitle, "TRY\nAGAIN!")),
                                    this.setLabelText(this.lKillCount, R.statistics.enemyKilledTotal.current.toFixed()),
                                    this.setLabelText(this.lChestsOpened, R.statistics.chestsOpened.current.toFixed()),
                                    this.lChestsOpenedTitle && (1 == R.statistics.chestsOpened.current ? this.setLabelText(this.lChestsOpenedTitle, "Chest Opened") : this.setLabelText(this.lChestsOpenedTitle, "Chests Opened")),
                                    this.setLabelText(this.lDamageDealt, R.statistics.damageDealtTotal.current.toFixed()),
                                    this.containerXPBar.active = !1,
                                    this.containerMatchStatus.opacity = 0,
                                    this.containerButtonOk.active = !1,
                                    this.debugDmgContainerWidget = null === (i = this.lDamageDealt.node.parent) || void 0 === i ? void 0 : i.getComponent(w),
                                    e.next = 25,
                                    null === (n = G.instance) || void 0 === n ? void 0 : n.openAsync(M.MatchEnd);
                                case 25:
                                    return e.next = 27,
                                    this.trophyRewardWidget.show();
                                case 27:
                                    return this.containerXPBar.active = !0,
                                    this.animation.play(this.clipOpenXPBar.name),
                                    e.next = 31,
                                    this.delay(this.clipOpenXPBar.duration);
                                case 31:
                                    return r = R.getPlacementXPAward(t),
                                    e.next = 34,
                                    this.experienceRewardWidget.show(r);
                                case 34:
                                    return e.next = 36,
                                    this.animateXpBar();
                                case 36:
                                    if (!e.sent) {
                                        e.next = 40;
                                        break
                                    }
                                    return e.next = 40,
                                    this.onPlayerLeveledUp();
                                case 40:
                                    return this.containerMatchStatus.opacity = 255,
                                    this.animation.play(this.clipOpenMatchStats.name),
                                    e.next = 44,
                                    this.delay(this.clipOpenMatchStats.duration);
                                case 44:
                                    console.log("Forcing left to zero", C.UI),
                                    this.debugDmgContainerWidget && (this.debugDmgContainerWidget.left = 0),
                                    this.rewardedAd.checkEligibility(),
                                    this.containerButtonOk.active = !0,
                                    this.animation.play(this.clipOpenConfirmButton.name);
                                case 49:
                                case "end":
                                    return e.stop()
                                }
                        }
                        ), e, this)
                    }
                    )));
                    return function(t) {
                        return e.apply(this, arguments)
                    }
                }(),
                o.animateXpBar = function() {
                    var e = this
                      , t = R.experience / R.getCurrentLevelUpTarget();
                    return R.level > this.initialLevel && (t += 1),
                    new Promise((function(i) {
                        e.tweenXPBar = f(e.lGlobalExperienceBar).to(e.xpAnimationDuration, {
                            progress: t
                        }, {
                            easing: "linear",
                            onUpdate: function(t, n) {
                                var r = t.progress;
                                r >= 1 && e.previousProgressBarNumber < 1 && e.lGlobalLevel ? i(!0) : (e.previousProgressBarNumber = r,
                                e.setupExperienceBar(r, r > 1))
                            },
                            onComplete: function(e) {
                                i(!1),
                                console.log("XP bar tween complete", C.UI)
                            }
                        }).repeat(1).start()
                    }
                    ))
                }
                ,
                o.onPlayerLeveledUp = function() {
                    var e;
                    if (this.initialLevel++,
                    null === (e = this.tweenXPBar) || void 0 === e || e.stop(),
                    console.log("Player leveled up!", C.UI),
                    E.emit(B.MetagameLevelUp),
                    this.lGlobalExperience && (this.lGlobalExperience.string = this.currentLevelUpTarget + "/" + this.currentLevelUpTarget),
                    this.lGlobalExperienceBar && (this.lGlobalExperienceBar.progress = 1),
                    this.animationXPbar.play(),
                    this.animationXPbar.defaultClip) {
                        var t = this.animationXPbar.defaultClip.duration;
                        return this.delay(t)
                    }
                    return this.delay(1)
                }
                ,
                o.updateLevelCounter = function() {
                    null != this.lGlobalLevel ? (this.lGlobalLevel.string = (R.level + 1).toFixed(),
                    this.currentLevelUpTarget = R.getCurrentLevelUpTarget(),
                    this.widgetCurrencyReward && X.spawn(this.widgetCurrencyReward, R.levelUpReward, this.widgetCurrencyRewardPivot.worldPosition, !1)) : console.log("this.lGlobalLevel is null")
                }
                ,
                o.continueXpBarFill = function() {
                    return this.setupExperienceBar(0, !0),
                    this.animateXpBar()
                }
                ,
                o.runInitialSetup = function() {
                    this.lGlobalLevel && (this.lGlobalLevel.string = (R.level + 1).toFixed()),
                    this.initialLevel = R.level,
                    this.initialExperience = R.experience,
                    this.currentLevelUpTarget = R.getCurrentLevelUpTarget(),
                    this.initialFillRatio = this.initialExperience / this.currentLevelUpTarget,
                    this.lGlobalExperienceBar && (this.lGlobalExperienceBar.progress = this.initialFillRatio),
                    this.setupExperienceBar(this.initialFillRatio, !1)
                }
                ,
                o.setupExperienceBar = function(e, t) {
                    e %= 1;
                    var i = Math.floor(e * this.currentLevelUpTarget);
                    t && (i = Math.floor(e * R.getCurrentLevelUpTarget())),
                    this.lGlobalExperience && (this.lGlobalExperience.string = i + "/" + this.currentLevelUpTarget),
                    this.lGlobalExperienceBar && (this.lGlobalExperienceBar.progress = e)
                }
                ,
                o.onClickContinue = function() {
                    var e;
                    this.clickedContinue || (this.clickedContinue = !0,
                    console.log("Starting to load " + O.Game + " bundle."),
                    null === (e = D.instance) || void 0 === e || e.show(),
                    v.loadBundle(O.Game, this.onGameBundleLoaded))
                }
                ,
                o.setLabelText = function(e, t) {
                    if (e && (e.string = t,
                    e.updateRenderData(!0),
                    e.node.parent)) {
                        var i = e.node.parent.getComponent(y);
                        null == i || i.updateLayout(!0);
                        var n = e.node.parent.getComponent(w);
                        null == n || n.updateAlignment()
                    }
                }
                ,
                o.delay = function(e) {
                    return new Promise((function(t) {
                        return setTimeout(t, 1e3 * e)
                    }
                    ))
                }
                ,
                t
            }(x)).prototype, "animation", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            ce = t(se.prototype, "animationXPbar", [k], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            pe = t(se.prototype, "clipOpenXPBar", [I], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            de = t(se.prototype, "clipOpenMatchStats", [W], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            he = t(se.prototype, "clipOpenConfirmButton", [N], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            be = t(se.prototype, "containerXPBar", [j], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            ge = t(se.prototype, "containerMatchStatus", [_], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            me = t(se.prototype, "containerButtonOk", [K], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            fe = t(se.prototype, "trophyRewardWidget", [Y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            ve = t(se.prototype, "lPlacement", [H], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            ye = t(se.prototype, "lPlacementOrdinal", [V], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            we = t(se.prototype, "lTopTitle", [q], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            xe = t(se.prototype, "lKillCount", [J], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Pe = t(se.prototype, "lChestsOpened", [Q], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Ce = t(se.prototype, "lChestsOpenedTitle", [Z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Le = t(se.prototype, "lDamageDealt", [$], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Te = t(se.prototype, "lGlobalLevel", [ee], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Be = t(se.prototype, "lGlobalExperience", [te], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Oe = t(se.prototype, "lGlobalExperienceBar", [ie], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Ee = t(se.prototype, "xpAnimationDuration", [De], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 1.5
                }
            }),
            Re = t(se.prototype, "widgetCurrencyReward", [ne], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Ge = t(se.prototype, "widgetCurrencyRewardPivot", [re], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Me = t(se.prototype, "rewardedAd", [ae], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Ue = t(se.prototype, "experienceRewardWidget", [le], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            oe = se)) || oe));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AIIdleState.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./AIState.ts", "./AIEnums.ts"], (function(t) {
    "use strict";
    var e, a, i, n, r, s, o, c;
    return {
        setters: [function(t) {
            e = t.inheritsLoose,
            a = t.defineProperty,
            i = t.assertThisInitialized,
            n = t.createClass
        }
        , function(t) {
            r = t.cclegacy,
            s = t._decorator
        }
        , function(t) {
            o = t.AIState
        }
        , function(t) {
            c = t.AIStateList
        }
        ],
        execute: function() {
            var l;
            r._RF.push({}, "f61b2PNXNtKK7hdVmIDBKic", "AIIdleState", void 0);
            var h = s.ccclass;
            s.property,
            t("AIIdleState", h("AIIdleState")(l = function(t) {
                function r() {
                    for (var e, n = arguments.length, r = new Array(n), s = 0; s < n; s++)
                        r[s] = arguments[s];
                    return e = t.call.apply(t, [this].concat(r)) || this,
                    a(i(e), "chosenDelay", 0),
                    e
                }
                e(r, t);
                var s = r.prototype;
                return s.stateEnter = function() {
                    t.prototype.stateEnter.call(this);
                    var e = this.brain.data.idleData;
                    this.chosenDelay = e.idleDelayMin + Math.random() * (e.idleDelayMax - e.idleDelayMin)
                }
                ,
                s.stateUpdate = function(e) {
                    t.prototype.stateUpdate.call(this, e),
                    this.chosenDelay -= e,
                    this.chosenDelay <= 0 && (Math.random() < this.brain.data.idleData.lootingPercentage || !this.brain.isCombatReady() ? this.brain.changeState(c.Looting) : this.brain.changeState(c.Wandering))
                }
                ,
                n(r, [{
                    key: "minimumTimeInState",
                    get: function() {
                        return this.brain.data.idleData.minimumTimeInState
                    }
                }]),
                r
            }(o)) || l);
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/CharacterModel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./Weapon.ts"], (function(e) {
    "use strict";
    var t, n, r, o, i, a, s, l, u, c, p, h, d, f, g, m, y;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            n = e.inheritsLoose,
            r = e.defineProperty,
            o = e.assertThisInitialized,
            i = e.initializerDefineProperty,
            a = e.createClass
        }
        , function(e) {
            s = e.cclegacy,
            l = e._decorator,
            u = e.Texture2D,
            c = e.Color,
            p = e.SkinnedMeshRenderer,
            h = e.SkeletalAnimation,
            d = e.Component
        }
        , function(e) {
            f = e.logger,
            g = e.LogCategory,
            m = e.LogType
        }
        , function(e) {
            y = e.Weapon
        }
        ],
        execute: function() {
            var x, C, v, k, A, I, T;
            s._RF.push({}, "f64cfUvKZlFGo/LLQ3Pu1I+", "CharacterModel", void 0);
            var w = l.ccclass
              , M = l.property;
            e("CharacterModel", (x = w("CharacterModel"),
            C = M([u]),
            v = M([c]),
            x((I = t((A = function(e) {
                function t() {
                    for (var t, n = arguments.length, a = new Array(n), s = 0; s < n; s++)
                        a[s] = arguments[s];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    r(o(t), "weapons", []),
                    i(o(t), "textures", I, o(t)),
                    i(o(t), "colors", T, o(t)),
                    r(o(t), "skAnimation", void 0),
                    t
                }
                n(t, e);
                var s = t.prototype;
                return s.applyTexture = function(e) {
                    e < 0 || e >= this.textures.length ? console.log("ERROR: Invalid texture index") : this.applyTextureOfIndex(e)
                }
                ,
                s.applyRandomTexture = function() {
                    var e = Math.floor(Math.random() * this.textures.length);
                    this.applyTextureOfIndex(e)
                }
                ,
                s.applyTextureOfIndex = function(e) {
                    var t, n = this.node.getComponentInChildren(p);
                    n && null != this.textures[e] && (null === (t = n.material) || void 0 === t || t.setProperty("mainTexture", this.textures[e]))
                }
                ,
                a(t, [{
                    key: "SkAnimation",
                    get: function() {
                        if (!this.skAnimation) {
                            var e = this.node.getComponent(h);
                            if (e && (this.skAnimation = e),
                            !this.skAnimation) {
                                var t = this.node.getComponentInChildren(h);
                                t ? this.skAnimation = t : console.log("Could not get skeletal animation on character - " + this.node.name, g.Generic, m.Error)
                            }
                        }
                        return this.skAnimation
                    }
                }, {
                    key: "Weapons",
                    get: function() {
                        return 0 != this.weapons.length && null != this.weapons[0] || (this.weapons = this.node.getComponentsInChildren(y)),
                        this.weapons
                    }
                }, {
                    key: "Colors",
                    get: function() {
                        return this.colors
                    }
                }]),
                t
            }(d)).prototype, "textures", [C], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            T = t(A.prototype, "colors", [v], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            k = A)) || k));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/UIToastPlayerKill.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./ProjectEvent.ts", "./UIToast.ts"], (function(t) {
    "use strict";
    var e, n, o, i, r, s, l, a, c, u, h, p;
    return {
        setters: [function(t) {
            e = t.applyDecoratedDescriptor,
            n = t.inheritsLoose,
            o = t.initializerDefineProperty,
            i = t.assertThisInitialized,
            r = t.defineProperty
        }
        , function(t) {
            s = t.cclegacy,
            l = t._decorator,
            a = t.CCString,
            c = t.Component
        }
        , function(t) {
            u = t.ProjectEventType
        }
        , function(t) {
            h = t.projectEvent
        }
        , function(t) {
            p = t.UIToast
        }
        ],
        execute: function() {
            var f, y, P, v, d;
            s._RF.push({}, "f6dd74/XQRC8JC3HmtjetPn", "UIToastPlayerKill", void 0);
            var g = l.ccclass
              , K = l.property;
            t("UIToastPlayerKill", (f = g("UIToastPlayerKill"),
            y = K([a]),
            f((d = e((v = function(t) {
                function e() {
                    for (var e, n = arguments.length, s = new Array(n), l = 0; l < n; l++)
                        s[l] = arguments[l];
                    return e = t.call.apply(t, [this].concat(s)) || this,
                    o(i(e), "texts", d, i(e)),
                    r(i(e), "toast", void 0),
                    r(i(e), "counter", 0),
                    e
                }
                n(e, t);
                var s = e.prototype;
                return s.onLoad = function() {
                    this.toast = this.node.getComponent(p)
                }
                ,
                s.onEnable = function() {
                    h.on(u.PlayerKill, this.onPlayerKill, this)
                }
                ,
                s.onDisable = function() {
                    h.off(u.PlayerKill, this.onPlayerKill, this)
                }
                ,
                s.onPlayerKill = function() {
                    var t;
                    this.texts && 0 != this.texts.length && (this.counter >= this.texts.length && (this.counter = this.texts.length - 1),
                    null === (t = this.toast) || void 0 === t || t.show(this.texts[this.counter]),
                    this.counter++)
                }
                ,
                e
            }(c)).prototype, "texts", [y], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            P = v)) || P));
            s._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/MainMenuChooseCharacterPanel.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./ProjectConstants.ts", "./ProjectEvent.ts", "./GlobalPlayer.ts", "./CharacterModel.ts", "./MetagameEnums.ts", "./MetagameUICharacterModelData.ts"], (function(e) {
    "use strict";
    var t, r, o, i, l, a, n, s, c, d, u, h, g, I, p, C, f, m, y, v, M, b, k, P, U, T;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            r = e.inheritsLoose,
            o = e.initializerDefineProperty,
            i = e.assertThisInitialized,
            l = e.defineProperty,
            a = e.createClass
        }
        , function(e) {
            n = e.cclegacy,
            s = e._decorator,
            c = e.Prefab,
            d = e.Node,
            u = e.Label,
            h = e.Toggle,
            g = e.Layout,
            I = e.Button,
            p = e.Sprite,
            C = e.Component
        }
        , function(e) {
            f = e.logger,
            m = e.LogCategory,
            y = e.LogType
        }
        , function(e) {
            v = e.MetagameEvent,
            M = e.UIEventType
        }
        , function(e) {
            b = e.projectEvent
        }
        , function(e) {
            k = e.globalPlayer
        }
        , function(e) {
            P = e.CharacterModel
        }
        , function(e) {
            U = e.Rarity
        }
        , function(e) {
            T = e.MetagameUICharacterModelData
        }
        ],
        execute: function() {
            var D, x, L, w, B, z, S, R, E, A, N, _, j, F, G, O, H, J, W, X, Y, Z, q, K, Q, V, $;
            n._RF.push({}, "f7407LtvCJO8ptnUXZ/Y80U", "MainMenuChooseCharacterPanel", void 0);
            var ee = s.ccclass
              , te = s.property;
            e("MainMenuChooseCharacterPanel", (D = ee("MainMenuChooseCharacterPanel"),
            x = te(c),
            L = te({
                tooltip: "Check true for pre tutorial character selection. This will only show unlocked characters to choose."
            }),
            w = te(d),
            B = te(u),
            z = te([h]),
            S = te(d),
            R = te(d),
            E = te(d),
            A = te(u),
            N = te(u),
            _ = te(g),
            j = te(I),
            D((O = t((G = function(e) {
                function t() {
                    for (var t, r = arguments.length, a = new Array(r), n = 0; n < r; n++)
                        a[n] = arguments[n];
                    return t = e.call.apply(e, [this].concat(a)) || this,
                    o(i(t), "uiCharacterModelDataPrefab", O, i(t)),
                    o(i(t), "onlyUnlocked", H, i(t)),
                    o(i(t), "modelsContainer", J, i(t)),
                    o(i(t), "lTitle", W, i(t)),
                    o(i(t), "tglColors", X, i(t)),
                    o(i(t), "lockedContainer", Y, i(t)),
                    o(i(t), "lockedByLevelContainer", Z, i(t)),
                    o(i(t), "lockedByPurchaseContainer", q, i(t)),
                    o(i(t), "lPurchasePrice", K, i(t)),
                    o(i(t), "lUnlockPrice", Q, i(t)),
                    o(i(t), "layoutBottom", V, i(t)),
                    o(i(t), "btnPurchase", $, i(t)),
                    l(i(t), "canvas", void 0),
                    l(i(t), "modelsData", void 0),
                    l(i(t), "models", []),
                    l(i(t), "currentModelId", 0),
                    l(i(t), "currentRarity", U.Common),
                    l(i(t), "tglColorsNodes", []),
                    l(i(t), "tglColorsSprites", []),
                    t
                }
                r(t, e);
                var n = t.prototype;
                return n.onLoad = function() {
                    this.modelsData = this.uiCharacterModelDataPrefab.data.getComponent(T),
                    b.on(v.CharacterPurchaseSuccess, this.updateUIAndSaveIfIsUnlocked, this)
                }
                ,
                n.start =async function() {
                  //xz 英雄界面

                    var e = this;
                    if (this.modelsData) {
                        this.tglColors.forEach((function(t) {
                            e.tglColorsNodes.push(t.node);
                            var r = t.getComponent(p);
                            r ? e.tglColorsSprites.push(r) : console.log("Could not get sprite from " + t.node.name)
                        }
                        )),
                        this.currentModelId = k.characterModelId,
                        this.currentRarity = this.modelsData.getRarity(this.currentModelId, k.characterTextureId);
                        var t = this.modelsData.ModelCount;
                        (this.currentModelId < 0 || this.currentModelId >= t) && (console.log("Invalid character model id saved, changing to zero", m.UI, y.Warning),
                        this.currentModelId = 0);
                        for (var r = 0; r < t; r++)
                            if (!this.onlyUnlocked || this.modelsData.isUnlocked(r, 0)) {
                                var o = this.modelsData.getModelInstance(r);
                                if (o) {
                                    o.setParent(this.modelsContainer),
                                    console.log("Instantiated: " + o);
                                    var i = o.getComponent(P);
                                    i ? (this.models.push(i),
                                    i.applyTexture(this.currentTextureId),
                                    r != this.currentModelId && (o.active = !1)) : console.log("Error while getting CharacterModel component from instance.", m.UI, y.Error)
                                } else
                                    console.log("Error while instantiating character model.", m.UI, y.Error)
                            }
                        this.tglColors[this.currentRarity].isChecked = !0,
                    await    this.updateUIAndSaveIfIsUnlocked()
                    } else
                        console.log("No character model", m.UI, y.Error)
                }
                ,
                n.onDestroy = function() {
                    b.off(v.CharacterPurchaseSuccess, this.updateUIAndSaveIfIsUnlocked, this)
                }
                ,
                n.nextModel = function() {
                    this.models[this.currentModelId].node.active = !1,
                    this.currentModelId++,
                    this.currentModelId >= this.models.length && (this.currentModelId = 0),
                    this.updateUIAndSaveIfIsUnlocked()
                }
                ,
                n.previousModel = function() {
                    this.models[this.currentModelId].node.active = !1,
                    this.currentModelId--,
                    this.currentModelId < 0 && (this.currentModelId = this.models.length - 1),
                    this.updateUIAndSaveIfIsUnlocked()
                }
                ,
                n.toggleColorCallback =async function(e, t) {
                    if (e.target) {
                        var r = this.tglColorsNodes.indexOf(e.target);
                        this.currentRarity != r && (this.currentRarity = r,
                        console.log("Clicked tgl: " + r + " using as rarity: " + this.currentRarity + " texId: " + this.currentTextureId, m.UI),
                    await    this.updateUIAndSaveIfIsUnlocked()),
                        b.emit(M.StopRotateModel)
                    }
                }
                ,
                n.openPurchaseConfirmation = function() {
                    this.lockedByPurchaseContainer.active && b.emit(v.CharacterPurchaseConfirmation, this.currentModelId, this.currentTextureId)
                }
                ,
                n.updateToggles = function() {
                    var e = this.models[this.currentModelId];
                    if (null != this.tglColors && e.Colors.length == this.tglColors.length)
                        for (var t = 0; t < e.Colors.length; t++) {
                            if (this.tglColors[t] && null != this.tglColors[t].checkMark) {
                                var r = this.tglColorsSprites[t]
                                  , o = this.modelsData.getTextureIdByRarity(this.currentModelId, t);
                                if (r && (r.color = e.Colors[o]),
                                this.tglColors[t].node.children.length > 1) {
                                    var i = this.tglColors[t].node.children[0]
                                      , l = this.modelsData.isUnlocked(this.currentModelId, o)
                                      , a = this.modelsData.isLockedByLevel(this.currentModelId, o);
                                    i && (i.active = !l);
                                    var n = this.tglColors[t].node.children[1];
                                    n && (n.active = a)
                                }
                            }
                            this.onlyUnlocked && (this.tglColors[t].node.active = this.modelsData.isUnlocked(this.currentModelId, t))
                        }
                }
                ,
                n.updateUIAndSaveIfIsUnlocked =async function() {
                    var e;
                    if (this.models[this.currentModelId].node.active = !0,
                    this.models[this.currentModelId].applyTexture(this.currentTextureId),
                    this.updateToggles(),
                    this.lTitle.string = this.modelsData.getName(this.currentModelId, this.currentTextureId),
                    this.modelsData.isUnlocked(this.currentModelId, this.currentTextureId))
                        this.lockedContainer.active = !1,
                    await    this.saveToGlobalPlayer();
                    else {
                        this.lockedContainer.active = !0;
                        var t = this.modelsData.isLockedByLevel(this.currentModelId, this.currentTextureId);
                        this.lockedByLevelContainer.active = t,
                        this.lockedByPurchaseContainer.active = !t;
                        var r = this.modelsData.getPrice(this.currentModelId, this.currentTextureId);
                        this.lPurchasePrice.string = r.toFixed(),
                        this.btnPurchase.interactable = k.currency >= r;
                        var o = this.modelsData.getUnlockToBuyLevel(this.currentModelId, this.currentTextureId) + 1;
                        this.lUnlockPrice.string = o.toFixed()
                    }
                    null === (e = this.layoutBottom) || void 0 === e || e.updateLayout(),
                    b.emit(M.CharacterModelChanged, this.models[this.currentModelId])
                }
                ,
                n.saveToGlobalPlayer =async function() {
                    k.characterModelId = this.currentModelId,
                    k.characterTextureId = this.currentTextureId,
                 await   k.save()
                }
                ,
                a(t, [{
                    key: "currentTextureId",
                    get: function() {
                        return this.modelsData.getTextureIdByRarity(this.currentModelId, this.currentRarity)
                    }
                }]),
                t
            }(C)).prototype, "uiCharacterModelDataPrefab", [x], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            H = t(G.prototype, "onlyUnlocked", [L], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return !1
                }
            }),
            J = t(G.prototype, "modelsContainer", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            W = t(G.prototype, "lTitle", [B], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            X = t(G.prototype, "tglColors", [z], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            Y = t(G.prototype, "lockedContainer", [S], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Z = t(G.prototype, "lockedByLevelContainer", [R], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            q = t(G.prototype, "lockedByPurchaseContainer", [E], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            K = t(G.prototype, "lPurchasePrice", [A], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            Q = t(G.prototype, "lUnlockPrice", [N], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            V = t(G.prototype, "layoutBottom", [_], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            $ = t(G.prototype, "btnPurchase", [j], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: null
            }),
            F = G)) || F));
            n._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TutorialPlayer.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./ProjectConstants.ts", "./TutorialVolume.ts"], (function(t) {
    "use strict";
    var r, e, o, n, i, l, u;
    return {
        setters: [function(t) {
            r = t.inheritsLoose
        }
        , function(t) {
            e = t.cclegacy,
            o = t._decorator,
            n = t.Collider,
            i = t.Component
        }
        , function(t) {
            l = t.OnTrigger
        }
        , function(t) {
            u = t.TutorialVolume
        }
        ],
        execute: function() {
            var a;
            e._RF.push({}, "f94f0kR0IJOvoj3cPVkQfg9", "TutorialPlayer", void 0);
            var s = o.ccclass;
            o.property,
            t("TutorialPlayer", s("TutorialPlayer")(a = function(t) {
                function e() {
                    return t.apply(this, arguments) || this
                }
                r(e, t);
                var o = e.prototype;
                return o.start = function() {
                    var t = this.getComponent(n);
                    null == t || t.on(l.Enter, this.onTriggerEnter, this),
                    null == t || t.on(l.Exit, this.onTriggerExit, this)
                }
                ,
                o.onTriggerEnter = function(t) {
                    if (t.otherCollider) {
                        var r = t.otherCollider.node.getComponent(u);
                        null != r && r.playerEntered()
                    }
                }
                ,
                o.onTriggerExit = function(t) {
                    if (t.otherCollider) {
                        var r = t.otherCollider.node.getComponent(u);
                        null != r && r.playerExited()
                    }
                }
                ,
                e
            }(i)) || a);
            e._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/AudioManager.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts", "./AudioListener.ts"], (function(i) {
    "use strict";
    var o, n, e, t, a, s, d, u, r, l, c, h, A, y, g, p, f;
    return {
        setters: [function(i) {
            o = i.defineProperty,
            n = i.inheritsLoose,
            e = i.assertThisInitialized,
            t = i.createClass
        }
        , function(i) {
            a = i.cclegacy,
            s = i._decorator,
            d = i.systemEvent,
            u = i.SystemEventType,
            r = i.AudioSource,
            l = i.macro,
            c = i.Node,
            h = i.game,
            A = i.Component
        }
        , function(i) {
            y = i.logger,
            g = i.LogCategory,
            p = i.LogType
        }
        , function(i) {
            f = i.AudioListener
        }
        ],
        execute: function() {
            var E, b, m;
            a._RF.push({}, "fa285OT0dpI3qmSmqpPzoY2", "AudioManager", void 0);
            var v = s.ccclass
              , S = (s.property,
            s.executionOrder);
            i("AudioManager", v("AudioManager")(E = S(-10)((m = b = function(i) {
                function a() {
                    for (var n, t = arguments.length, a = new Array(t), s = 0; s < t; s++)
                        a[s] = arguments[s];
                    return n = i.call.apply(i, [this].concat(a)) || this,
                    o(e(n), "audioData", void 0),
                    o(e(n), "source", void 0),
                    o(e(n), "_isAudioEnabled", !0),
                    o(e(n), "initialized", !1),
                    o(e(n), "storageKey", "debugIsAudioEnabled"),
                    o(e(n), "onAudioPermissionChanged", (function(i) {
                        n._isAudioEnabled = i,
                        i ? n.onAudioEnabled() : n.onAudioDisabled()
                    }
                    )),
                    n
                }
                n(a, i);
                var s = a.prototype;
                return s.setup = function(i) {
                    i && (this.audioData = i)
                }
                ,
                s.onLoad = function() {
                    null == a._instance ? a._instance = this : a._instance != this && (console.log("ERROR: Audio manager already exists", g.Audio, p.Warning),
                    this.node.destroy())
                }
                ,
                s.onEnable = function() {
                    d.on(u.KEY_DOWN, this.onMuteKeyDown, this)
                }
                ,
                s.onDisable = function() {
                    d.off(u.KEY_DOWN, this.onMuteKeyDown, this)
                }
                ,
                s.start = function() {
                    if (!this.initialized) {
                        var i = this.node.getComponent(r);
                        this.source = i || this.node.addComponent(r),
                        "undefined" != typeof GAMESNACKS && (GAMESNACKS.subscribeToAudioUpdates(this.onAudioPermissionChanged),
                        this._isAudioEnabled = GAMESNACKS.isAudioEnabled()),
                        this.initialized = !0
                    }
                }
                ,
                s.onMuteKeyDown = function(i) {
                    i.keyCode == l.KEY.m && this.onAudioPermissionChanged(!this._isAudioEnabled)
                }
                ,
                s.onAudioEnabled = function() {
                    console.log("Audio enabled", g.Audio)
                }
                ,
                s.onAudioDisabled = function() {
                    console.log("Audio disabled", g.Audio)
                }
                ,
                s.playSpatialSoundOneShot = function(i, o, n) {
                    void 0 === n && (n = 1),
                    f.instance ? (n *= f.instance.getVolumeScale(o),
                    this.playOneShot(i, n)) : this.playOneShot(i, n)
                }
                ,
                s.playRandomOneShot = function(i, o) {
                    var n;
                    if (void 0 === o && (o = 1),
                    i && 0 != i.length) {
                        var e = Math.floor(Math.random() * i.length);
                        null === (n = a.instance) || void 0 === n || n.playOneShot(i[e], o)
                    } else
                        console.log("Received null or empty audio clips", g.Audio, p.Error)
                }
                ,
                s.playOneShot = function(i, o) {
                  //xz
                  if(window.pocketBattleIsMute){
                    return;
                  }
                    void 0 === o && (o = 1),
                    this._isAudioEnabled && i && (this.source ? this.source.playOneShot(i, o) : console.log("ERROR: AudioSource is null"))
                }
                ,
                s.playByKey = function(i) {
                    if (i)
                        if (this.audioData) {
                            var o = this.audioData.getItem(i);
                            o && this.playRandomOneShot(o.SFXs, o.Volume)
                        } else
                            console.log("Can not play audio by key because audio data is null", g.Audio, p.Error);
                    else
                        console.log("Received null key to play audio", g.Audio, p.Error)
                }
                ,
                t(a, [{
                    key: "isAudioEnabled",
                    get: function() {
                        return this._isAudioEnabled
                    }
                }], [{
                    key: "instance",
                    get: function() {
                        if (null == a._instance) {
                            var i = new c("AudioManager");
                            this._instance = i.addComponent(a),
                            h.addPersistRootNode(i),
                            this._instance.start()
                        }
                        return a._instance
                    }
                }]),
                a
            }(A),
            o(b, "_instance", void 0),
            E = m)) || E) || E);
            a._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/PlayerInput.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./CharacterInterfaces.ts"], (function(o) {
    "use strict";
    var t, s, e, i, n, h, u, r, a, c;
    return {
        setters: [function(o) {
            t = o.inheritsLoose,
            s = o.defineProperty,
            e = o.assertThisInitialized
        }
        , function(o) {
            i = o.cclegacy,
            n = o._decorator,
            h = o.Vec2,
            u = o.systemEvent,
            r = o.SystemEventType,
            a = o.macro
        }
        , function(o) {
            c = o.CharacterInputBase
        }
        ],
        execute: function() {
            var l;
            i._RF.push({}, "fb701olsh1NHbRZPGod6m9d", "PlayerInput", void 0);
            var _ = n.ccclass;
            n.property,
            o("PlayerInput", _("PlayerInput")(l = function(o) {
                function i() {
                    for (var t, i = arguments.length, n = new Array(i), u = 0; u < i; u++)
                        n[u] = arguments[u];
                    return t = o.call.apply(o, [this].concat(n)) || this,
                    s(e(t), "_isMouseDown", !1),
                    s(e(t), "_mousePos", new h),
                    s(e(t), "_mousePosOnDown", new h),
                    s(e(t), "_mouseDelta", new h),
                    t
                }
                t(i, o);
                var n = i.prototype;
                return n.start = function() {
                  //xz 玩法操作控制
                    u.on(r.KEY_DOWN, this.onKeyDown, this),
                    u.on(r.KEY_UP, this.onKeyUp, this),
                    u.on(r.MOUSE_MOVE, this.onMouseMove, this),
                    u.on(r.MOUSE_DOWN, this.onMouseDown, this),
                    u.on(r.MOUSE_UP, this.onMouseUp, this),
                    u.on(r.TOUCH_START, this.onTouchStart, this),
                    u.on(r.TOUCH_MOVE, this.onTouchMove, this),
                    u.on(r.TOUCH_END, this.onTouchEndOrCancel, this),
                    u.on(r.TOUCH_CANCEL, this.onTouchEndOrCancel, this)
                }
                ,
                n.onDestroy = function() {
                    u.off(r.KEY_DOWN, this.onKeyDown, this),
                    u.off(r.KEY_UP, this.onKeyUp, this),
                    u.off(r.MOUSE_MOVE, this.onMouseMove, this),
                    u.off(r.MOUSE_DOWN, this.onMouseDown, this),
                    u.off(r.MOUSE_UP, this.onMouseUp, this),
                    u.off(r.TOUCH_START, this.onTouchStart, this),
                    u.off(r.TOUCH_MOVE, this.onTouchMove, this),
                    u.off(r.TOUCH_END, this.onTouchEndOrCancel, this),
                    u.off(r.TOUCH_CANCEL, this.onTouchEndOrCancel, this)
                }
                ,
                n.onKeyDown = function(o) {
                    o.keyCode == a.KEY.w || o.keyCode == a.KEY.up ? this.vertical = 1 : o.keyCode != a.KEY.s && o.keyCode != a.KEY.down || (this.vertical = -1),
                    o.keyCode == a.KEY.d || o.keyCode == a.KEY.right ? this.horizontal = 1 : o.keyCode != a.KEY.a && o.keyCode != a.KEY.left || (this.horizontal = -1)
                }
                ,
                n.onKeyUp = function(o) {
                    o.keyCode == a.KEY.w || o.keyCode == a.KEY.up ? 1 == this.vertical && (this.vertical = 0) : o.keyCode != a.KEY.s && o.keyCode != a.KEY.down || -1 == this.vertical && (this.vertical = 0),
                    o.keyCode == a.KEY.d || o.keyCode == a.KEY.right ? 1 == this.horizontal && (this.horizontal = 0) : o.keyCode != a.KEY.a && o.keyCode != a.KEY.left || -1 == this.horizontal && (this.horizontal = 0)
                }
                ,
                n.onMouseDown = function(o) {
                    this._isMouseDown = !0,
                    o.getLocation(this._mousePosOnDown)
                }
                ,
                n.onMouseMove = function(o) {
                    this._isMouseDown && (o.getLocation(this._mousePos),
                    this._mouseDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._mouseDelta.normalize(),
                    this.horizontal = this._mouseDelta.x,
                    this.vertical = this._mouseDelta.y)
                }
                ,
                n.onMouseUp = function(o) {
                    this._isMouseDown = !1,
                    this.horizontal = 0,
                    this.vertical = 0
                }
                ,
                n.onTouchStart = function(o, t) {
                    t.getLocation(this._mousePosOnDown),
                    this._isMouseDown = !0
                }
                ,
                n.onTouchMove = function(o, t) {
                    t.getLocation(this._mousePos),
                    this._mouseDelta = this._mousePos.subtract(this._mousePosOnDown),
                    this._mouseDelta.normalize(),
                    this.horizontal = this._mouseDelta.x,
                    this.vertical = this._mouseDelta.y
                }
                ,
                n.onTouchEndOrCancel = function(o, t) {
                    this._isMouseDown = !1,
                    this.horizontal = 0,
                    this.vertical = 0
                }
                ,
                i
            }(c)) || l);
            i._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/TreasureSFX.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./AudioManager.ts", "./PickupEnums.ts"], (function(e) {
    "use strict";
    var t, o, n, i, r, c, l, a, s, u;
    return {
        setters: [function(e) {
            t = e.applyDecoratedDescriptor,
            o = e.inheritsLoose,
            n = e.initializerDefineProperty,
            i = e.assertThisInitialized
        }
        , function(e) {
            r = e.cclegacy,
            c = e._decorator,
            l = e.AudioClip,
            a = e.Component
        }
        , function(e) {
            s = e.AudioManager
        }
        , function(e) {
            u = e.EventPickup
        }
        ],
        execute: function() {
            var p, d, f, h, v;
            r._RF.push({}, "fcd7afbWP5O4oNvukKP8i0w", "TreasureSFX", void 0);
            var y = c.ccclass
              , g = c.property;
            e("TreasureSFX", (p = y("TreasureSFX"),
            d = g([l]),
            p((v = t((h = function(e) {
                function t() {
                    for (var t, o = arguments.length, r = new Array(o), c = 0; c < o; c++)
                        r[c] = arguments[c];
                    return t = e.call.apply(e, [this].concat(r)) || this,
                    n(i(t), "collect", v, i(t)),
                    t
                }
                o(t, e);
                var r = t.prototype;
                return r.onEnable = function() {
                    this.node.on(u.Collected, this.onCollected, this)
                }
                ,
                r.onDisable = function() {
                    this.node.off(u.Collected, this.onCollected, this)
                }
                ,
                r.onCollected = function() {
                    var e, t = Math.floor(Math.random() * this.collect.length);
                    null === (e = s.instance) || void 0 === e || e.playSpatialSoundOneShot(this.collect[t], this.node.worldPosition)
                }
                ,
                t
            }(a)).prototype, "collect", [d], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            f = h)) || f));
            r._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/FloorSpawner.ts", ["./_rollupPluginModLoBabelHelpers.js", "cc", "./Logger.ts"], (function(e) {
    "use strict";
    var r, t, i, n, o, a, l, s, u, c;
    return {
        setters: [function(e) {
            r = e.applyDecoratedDescriptor,
            t = e.inheritsLoose,
            i = e.initializerDefineProperty,
            n = e.assertThisInitialized
        }
        , function(e) {
            o = e.cclegacy,
            a = e._decorator,
            l = e.Prefab,
            s = e.instantiate,
            u = e.Component
        }
        , function(e) {
            c = e.logger
        }
        ],
        execute: function() {
            var p, f, b, h, g, y, m, v;
            o._RF.push({}, "fd4a2DYLWVNw4/s1D+kNtmo", "FloorSpawner", void 0);
            var z = a.ccclass
              , w = a.property;
            e("FloorSpawner", (p = z("FloorSpawner"),
            f = w({
                type: [l]
            }),
            p((g = r((h = function(e) {
                function r() {
                    for (var r, t = arguments.length, o = new Array(t), a = 0; a < t; a++)
                        o[a] = arguments[a];
                    return r = e.call.apply(e, [this].concat(o)) || this,
                    i(n(r), "prefabs", g, n(r)),
                    i(n(r), "size", y, n(r)),
                    i(n(r), "collum", m, n(r)),
                    i(n(r), "line", v, n(r)),
                    r
                }
                return t(r, e),
                r.prototype.start = function() {
                    for (var e = 0; e < this.collum; e++)
                        for (var r = 0; r < this.line; r++) {
                            var t = Math.floor(Math.random() * this.prefabs.length);
                           console.log(t);
                            var i = s(this.prefabs[t]);
                            i.setParent(this.node);
                            var n = e * this.size
                              , o = r * this.size;
                           console.log("x " + n + " z " + o),
                            i.setPosition(n, 0, o)
                        }
                }
                ,
                r
            }(u)).prototype, "prefabs", [f], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return []
                }
            }),
            y = r(h.prototype, "size", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 4
                }
            }),
            m = r(h.prototype, "collum", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 5
                }
            }),
            v = r(h.prototype, "line", [w], {
                configurable: !0,
                enumerable: !0,
                writable: !0,
                initializer: function() {
                    return 5
                }
            }),
            b = h)) || b));
            o._RF.pop()
        }
    }
}
));

System.register("chunks:///_virtual/main", ["./Logger.ts", "./ProjectConstants.ts", "./Splash.ts", "./ProjectEvent.ts", "./UIEnemyCounter.ts", "./AudioListener.ts", "./WeaponEnums.ts", "./Mission.ts", "./RewardedAdOpportunitySaveData.ts", "./GlobalPlayer.ts", "./MainMenuMissionWidget.ts", "./MainMenuMissionOverlay.ts", "./MainMenuMissionOverlayEventProxy.ts", "./BulletPools.ts", "./TweenEnums.ts", "./TweenBase.ts", "./TweenCollection.ts", "./UIVirtualJoystick.ts", "./PanelManager.ts", "./PanelEnums.ts", "./OverlayButton.ts", "./UIMatchPageViewToScreenWidth.ts", "./MainMenuOverlay.ts", "./CharacterEnums.ts", "./DebugVisualizeTile.ts", "./Pathfinding.ts", "./BulletEnums.ts", "./Bullet.ts", "./Weapon.ts", "./CharacterModel.ts", "./MetagameEnums.ts", "./MetagameUICharacterModelData.ts", "./RotateCharacterModel.ts", "./PlayerUIModel.ts", "./LoadingPrepareMatch.ts", "./MainMenuCanvas.ts", "./CharacterHitEffect.ts", "./ExperienceWidget.ts", "./MetagameWeaponData.ts", "./WeaponUpgradeWidget.ts", "./ExperienceRewardWidget.ts", "./CharacterHealthRegenVFX.ts", "./GameplayEnums.ts", "./CharacterBlackboard.ts", "./MatchController.ts", "./PlayerNode.ts", "./CameraGameplay.ts", "./UITrackWorldNode.ts", "./TutorialStepBase.ts", "./TutorialVolume.ts", "./TestRaycastTileMap.ts", "./Target.ts", "./SetStartScale.ts", "./BotStateData.ts", "./BotFleeData.ts", "./TestPathfinding.ts", "./TestRaycastPathfindingTileMap.ts", "./AudioManager.ts", "./UIMissionCompleteSFX.ts", "./CharacterShrinkingAreaDamage.ts", "./MapReader.ts", "./MatchAudio.ts", "./CharacterHealthControl.ts", "./CheatKillCharacter.ts", "./AIState.ts", "./AIEnums.ts", "./AIChasingState.ts", "./TrophyRewardWidget.ts", "./TestRuntimePlatform.ts", "./TestExecutionOrderChild.ts", "./BotIdleData.ts", "./TestExecutionOrderDefault.ts", "./BotGenericData.ts", "./BotAttackingData.ts", "./BotChasingData.ts", "./BotReloadingData.ts", "./BotVisionData.ts", "./BotCharacterOverridesData.ts", "./BotData.ts", "./EnemySpawner.ts", "./TestUIToasts.ts", "./Panel.ts", "./LogCategoryToggle.ts", "./CharacterShoot.ts", "./TurretWeapon.ts", "./CharacterModelManager.ts", "./AIReloadingState.ts", "./VersionLabel.ts", "./CharacterAnimation.ts", "./UIUpdateLevelCounter.ts", "./RotateByInput.ts", "./TestRewardedAds.ts", "./AudioItem.ts", "./AudioData.ts", "./AudioManagerInitializer.ts", "./MainMenuArenaWidget.ts", "./MainMenuConfirmWeaponUpgradeOverlay.ts", "./Loading.ts", "./PreTutorial.ts", "./TestCustomGlobalEventListener.ts", "./ToggleProfiler.ts", "./TestCollisionEvents.ts", "./CharacterCombatDetection.ts", "./AIAttackingState.ts", "./GSGameReady.ts", "./MainMenuWeaponUpgradesPanel.ts", "./CurrencyRewardWidget.ts", "./TestTriggerEvents.ts", "./TweenNodeScale.ts", "./IMap.ts", "./TweenNodePosition.ts", "./BulletShotgun.ts", "./AIFleeState.ts", "./PickupEnums.ts", "./WeaponRarityData.ts", "./TestGlobalPlayerData.ts", "./PrefabPool.ts", "./BulletExplosion.ts", "./BulletBazooka.ts", "./PickupCollectionFeedback.ts", "./UIMatchProgressBarTotalLength.ts", "./TestScreenSize.ts", "./CharacterModelSetup.ts", "./MainMenuConfirmCharacterPurchaseOverlay.ts", "./PlayerSpawner.ts", "./CheatFinishMatch.ts", "./WeaponPickupCollectionFeedback.ts", "./MetagameArenaData.ts", "./MainMenuPlayPanel.ts", "./TurretSpawner.ts", "./AnimationPlayProxy.ts", "./CharacterSoundEffects.ts", "./GSOnMatchFinish.ts", "./TweenUIOpacity.ts", "./BulletBasic.ts", "./GameSnacksAPITest.ts", "./TweenNodeRotation.ts", "./BulletAssaultRifle.ts", "./CharacterInterfaces.ts", "./AIBlackboard.ts", "./AIIdleState.ts", "./CanvasGameplay.ts", "./BasePickup.ts", "./WeaponPickupRarityEffect.ts", "./WeaponPickup.ts", "./WeaponPickupManager.ts", "./TreasurePickup.ts", "./AILootingState.ts", "./AIWanderState.ts", "./EnemySensor.ts", "./AIVision.ts", "./AIBrain.ts", "./UIToast.ts", "./UIToastAreaDamage.ts", "./UIClickSFX.ts", "./TestCameraPosition.ts", "./TestHitEffect.ts", "./UIToastLevelUp.ts", "./CharacterMovement.ts", "./MainMenuArenaUnlockPanel.ts", "./MainMenuArenaSelector.ts", "./CharacterUI.ts", "./MapSpawner.ts", "./WeaponEffects.ts", "./PlayerMissionHook.ts", "./ShrinkingAreaManager.ts", "./CompassIndicator.ts", "./AudioProxy.ts", "./CharacterLevelControl.ts", "./TutorialController.ts", "./CharacterFSM.ts", "./TestPlayAnimation.ts", "./DebugMenu.ts", "./PlayerInput.ts", "./PlayerCompass.ts", "./LogCategoryWidget.ts", "./UIToastWeaponName.ts", "./RewardedAdEnums.ts", "./RewardedAdOportunity.ts", "./RewardedAdDebug.ts", "./CurrencyWidget.ts", "./TestCustomGlobalEventEmitter.ts", "./TutorialTriggerOnCharacterDeath.ts", "./CheatOpenMenuDebug.ts", "./TestStorage.ts", "./LandscapeFitter.ts", "./TestExecutionOrderLow.ts", "./UIDamageOverlay.ts", "./CheatMatchLevelUp.ts", "./RewardedAdAfterMatch.ts", "./UIMetagameLevelUpSFX.ts", "./TutorialStepWeaponPickup.ts", "./TutorialStepChest.ts", "./PlayAnimationAfterDelay.ts", "./Note.ts", "./UIMatchStart.ts", "./RewardedAdDaily.ts", "./PlayerStatisticsHook.ts", "./CharacterUISetup.ts", "./LogLevelChanger.ts", "./ChangeLabelByOS.ts", "./AIDebugState.ts", "./TestExecutionOrderHigh.ts", "./EnemySignal.ts", "./TreasureVFX.ts", "./BulletVFX.ts", "./AutoRotate.ts", "./CharacterLevelVFX.ts", "./CameraFree.ts", "./TestArrayProperties.ts", "./TestGetPrefabValuesWithoutInstantiating.ts", "./UIMatchEnd.ts", "./UIToastPlayerKill.ts", "./MainMenuChooseCharacterPanel.ts", "./TutorialPlayer.ts", "./TreasureSFX.ts", "./FloorSpawner.ts"], (function() {
    "use strict";
    return {
        setters: [null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null],
        execute: function() {}
    }
}
));

(function(r) {
    r('virtual:///prerequisite-imports/main', 'chunks:///_virtual/main');
}
)(function(mid, cid) {
    System.register(mid, [cid], function(_export, _context) {
        return {
            setters: [function(_m) {
                var _exportObj = {};

                for (var _key in _m) {
                    if (_key !== "default" && _key !== "__esModule")
                        _exportObj[_key] = _m[_key];
                }

                _export(_exportObj);
            }
            ],
            execute: function() {}
        };
    });
});
