var AppLovinMAX = cordova.require('cordova-plugin-applovin-max.AppLovinMAX');

var missAmount = -1;
var interstitialCoolTime = -1;

var BANNER_AD_UNIT_ID;
if (window.cordova.platformId.toUpperCase() === 'IOS') {
    BANNER_AD_UNIT_ID = 'YOUR_IOS_BANNER_AD_UNIT_ID';
} else {
    // Assume Android
    BANNER_AD_UNIT_ID = '89fca631e654fccb';
}

var INTER_AD_UNIT_ID;
if (window.cordova.platformId.toUpperCase() === 'IOS') {
    INTER_AD_UNIT_ID = 'YOUR_IOS_INTER_AD_UNIT_ID';
} else {
    // Assume Android
    INTER_AD_UNIT_ID = 'fe60f76add73f8d1';
}

var REWARDED_AD_UNIT_ID;
if (window.cordova.platformId.toUpperCase() === 'IOS') {
    REWARDED_AD_UNIT_ID = 'YOUR_IOS_REWARDED_AD_UNIT_ID';
} else {
    // Assume Android
    REWARDED_AD_UNIT_ID = 'f3bc0617bf7a41eb';
}


var adManager = {};

adManager.init = function () {
    console.log("开始初始化AppLovinMAX");
    AppLovinMAX.initialize("X_TDfUQkKtNxo70H36135sJlwK4a8tzWd8bAa5mWQ4t13lDTF5t7DkTH7kUd8gpBpznid7qTOyTsFWZlW2-oLN", function (configuration) {
        console.log("AppLovinMAX inited");
//        AppLovinMAX.showMediationDebugger();
        adManager.loadAds();
    });
};

adManager.loadAds = function () {
    this.initializeInterstitialAds();
    this.initializeRewardedAds();
    this.initializeBannerAds();
};

adManager.initializeInterstitialAds = function () {
    var loadInterstitial = function () {
        AppLovinMAX.loadInterstitial(INTER_AD_UNIT_ID);
    };

    window.addEventListener('OnInterstitialLoadedEvent', function (adInfo) {
    });
    window.addEventListener('OnInterstitialLoadFailedEvent', function (adInfo) {
        setTimeout(function () {
            loadInterstitial();
        }, 30000);
    });
    window.addEventListener('OnInterstitialClickedEvent', function (adInfo) {
    });
    window.addEventListener('OnInterstitialDisplayedEvent', function (adInfo) {
    });
    window.addEventListener('OnInterstitialAdFailedToDisplayEvent', function (adInfo) {
        loadInterstitial();
    });
    window.addEventListener('OnInterstitialHiddenEvent', function (adInfo) {
        loadInterstitial();
        adManager.coolTime();
        interstitialComplete && interstitialComplete();
    });
    loadInterstitial();
};

adManager.interstitialComplete = null;
adManager.showInterstitial = function (complete) {
    if (AppLovinMAX.isInterstitialReady(INTER_AD_UNIT_ID) && cloudShowInterstitial) {
        if (window.cordova.platformId.toUpperCase() === 'ANDROID') {
            if (missAmount < 0) {
                missAmount = firebaseManager.interstitialConfig.missAmount;
            }
            if (missAmount > 0 && firebaseManager.adConfig[1].Category.gailv_android < Math.random()) {
                missAmount--;
                complete && complete();
                return;
            }
        }
        cloudShowInterstitial = false;
        AppLovinMAX.showInterstitial(INTER_AD_UNIT_ID);
        interstitialComplete = complete;
    } else {
        complete && complete();
    }
};

var coolTimer = -1;
var cloudShowInterstitial = true;
adManager.coolTime = function () {
    if (coolTimer >= 0) {
        clearTimeout(coolTimer);
    }
    if (interstitialCoolTime < 0) {
        interstitialCoolTime = firebaseManager.interstitialConfig.interstitialCoolTime;
    }
    coolTimer = setTimeout(() => {
        cloudShowInterstitial = true;
    }, interstitialCoolTime);
    cloudShowInterstitial = false;
}


adManager.initializeRewardedAds = function () {
    var loadRewardedAd = function () {
        AppLovinMAX.loadRewardedAd(REWARDED_AD_UNIT_ID);
    };

    window.addEventListener('OnRewardedAdLoadedEvent', function (adInfo) {
    });

    window.addEventListener('OnRewardedAdLoadFailedEvent', function (adInfo) {
        setTimeout(function () {
            loadRewardedAd();
        }, 30);
    });

    window.addEventListener('OnRewardedAdClickedEvent', function (adInfo) {
    });
    window.addEventListener('OnRewardedAdDisplayedEvent', function (adInfo) {
    });
    window.addEventListener('OnRewardedAdFailedToDisplayEvent', function (adInfo) {
        loadRewardedAd();
        if (adManager.onComplete != null) {
            adManager.onComplete(adManager.receivedReward);
        }
    });
    window.addEventListener('OnRewardedAdHiddenEvent', function (adInfo) {
        loadRewardedAd();
        if (adManager.onComplete != null) {
            adManager.onComplete(adManager.receivedReward);
        }
        adManager.coolTime();
    });
    window.addEventListener('OnRewardedAdReceivedRewardEvent', function (adInfo) {
        // Rewarded ad was displayed and user should receive the reward
        adManager.receivedReward = true;
    });

    loadRewardedAd();
};

adManager.receivedReward = false;
adManager.onComplete = null;
adManager.showRewardedAd = function (onComplete) {
    if (AppLovinMAX.isRewardedAdReady(REWARDED_AD_UNIT_ID)) {
        AppLovinMAX.showRewardedAd(REWARDED_AD_UNIT_ID, () => {
        });
        this.onComplete = onComplete;
        this.receivedReward = false;
    } else {
        onComplete(false);
    }
};
adManager.isRewardedAdReady = function () {
    return AppLovinMAX.isRewardedAdReady(REWARDED_AD_UNIT_ID);
};


adManager.initializeBannerAds = function () {
    AppLovinMAX.createBanner(BANNER_AD_UNIT_ID, AppLovinMAX.AdViewPosition.BOTTOM_CENTER);
//    AppLovinMAX.setBannerBackgroundColor(BANNER_AD_UNIT_ID, '#000000');
};

adManager.showBanner = function () {
    AppLovinMAX.showBanner(BANNER_AD_UNIT_ID, function () {
    });
};

adManager.hideBanner = function () {
     AppLovinMAX.hideBanner(BANNER_AD_UNIT_ID, function () {
     });
};


window.adManager = adManager;

adManager.init();