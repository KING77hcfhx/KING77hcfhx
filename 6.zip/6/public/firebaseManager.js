var firebaseManager = {};
firebaseManager.adConfig = [{"Category": "launch", "gailv_android": 0.8, "gailv_ios": 0.8}, {"Category": "interstitial","gailv_android": 0.8,"gailv_ios": 0.8}];
firebaseManager.interstitialConfig = {"missAmount": 4, "interstitialCoolTime": 30000};
firebaseManager.init = function () {
    var fetchTimeout = 60;
    var minimumFetchInterval = 3600;
    FirebasePlugin.setConfigSettings(fetchTimeout, minimumFetchInterval, function () {
        console.log("Successfully set Remote Config settings");
        firebaseManager.getConfig();
    }, function (error) {
        console.error("Error setting Remote Config settings: " + error);
    });
    FirebasePlugin.setDefaults({
        "advertisement": JSON.stringify(firebaseManager.adConfig),
        "interstitial": JSON.stringify(firebaseManager.interstitialConfig)
    });
};


firebaseManager.getConfig = function () {
    FirebasePlugin.fetchAndActivate(function (activated) {
        FirebasePlugin.getValue("advertisement", function (value) {
            try {
                console.log("getConfig", value);
                firebaseManager.adConfig = JSON.parse(value);
            } catch (e) {
                adConfig = [{"Category": "launch", "gailv_android": 0.8, "gailv_ios": 0.8}, {
                    "Category": "interstitial",
                    "gailv_android": 0.8,
                    "gailv_ios": 0.8
                }];
            }
        }, function (error) {
            console.error(error);
        });
        FirebasePlugin.getValue("interstitial", function (value) {
            try {
                firebaseManager.interstitialConfig = JSON.parse(value);
            } catch (e) {
                firebaseManager.interstitialConfig = {"missAmount": 4, "interstitialCoolTime": 30000};
            }
        }, function (error) {
            console.error(error);
        });
    }, function (error) {
        console.error(error);
    });
};

firebaseManager.init();
window.firebaseManager = firebaseManager;